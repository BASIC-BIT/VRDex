"""Generated in-memory contract fixtures; no SDK imports or SDK execution.

The preload/content/model conversion order follows the pinned source contract
cited in sdk-response-guard-design.md. Fixture passes do not accept an SDK path.
"""
import io
from types import SimpleNamespace
import unittest

import transport
from test_transport import setup


class Raw(io.BytesIO):
    def __init__(self, data=b'', *, short=None, read_error=None, close_error=None):
        super().__init__(data)
        self.requests=[]; self.delivered=0; self.close_calls=0
        self.short=short; self.read_error=read_error; self.close_error=close_error
        self.before_read=None
    def read(self, n=-1, **kwargs):
        self.requests.append(n)
        if self.before_read:self.before_read(n)
        if self.read_error:raise self.read_error
        data=super().read(min(n,self.short) if self.short else n)
        self.delivered+=len(data)
        return data
    def stream(self, amt=65536, decode_content=False):
        while True:
            data=self.read(amt,decode_content=decode_content)
            if not data:break
            yield data
    def close(self):
        self.close_calls+=1
        if self.close_error:raise self.close_error
        super().close()


class AWSResponseFixture:
    # AWSResponse.content joins raw.stream once and caches the result.
    def __init__(self, raw, status=200, headers=None):
        self.raw=raw; self.status_code=status
        self.headers={} if headers is None else headers
        self._content=None
    @property
    def content(self):
        if self._content is None:self._content=b''.join(self.raw.stream())
        return self._content


class StreamingBodyFixture:
    def __init__(self,raw):self.raw=raw
    def read(self,n=None):return self.raw.read(n)
    def close(self):return self.raw.close()


class SDKFixture:
    """One send; endpoint conversion uses status/model, never the request hint."""
    def __init__(self,p,raw, *, operation='control',status=200,stream_output=False,
                 streaming_model=False,parsed=None,parser_error=None,send_error=None,headers=None):
        self.p=p; self.raw=raw; self.operation=operation; self.send_error=send_error
        self.request=SimpleNamespace(stream_output=stream_output,method='POST',
            url='https://ecr.us-east-1.amazonaws.com/',headers={'signed':'unchanged'},
            body=b'prepared-body',context={'checksum':{'algorithm':'unchanged'}})
        self.response=AWSResponseFixture(raw,status,headers)
        self.model=SimpleNamespace(has_streaming_output=streaming_model)
        self.parsed={} if parsed is None else parsed; self.parser_error=parser_error
        self.send_flags=[]; self.reads_at_send_return=[]; self.parser_inputs=[]
        self.converted=[]
    def send(self,request):
        self.send_flags.append(request.stream_output)
        if self.send_error:raise self.send_error
        # URLLib3Session.send explicitly preloads on a false prepared hint.
        if not request.stream_output:self.response.content
        self.reads_at_send_return.append(len(self.raw.requests))
        return self.response
    def convert(self,response):
        if response.status_code>=300 or not self.model.has_streaming_output:
            body=response.content
        else:body=StreamingBodyFixture(response.raw)
        self.converted.append(body)
        return body
    def invoke(self,**kwargs):
        self.p.before_send(self.request)
        response=self.p.bounded_sdk_send(self.send)(self.request)
        body=self.convert(response)
        self.parser_inputs.append(body)
        if self.parser_error:raise self.parser_error
        parsed=dict(self.parsed)
        if self.model.has_streaming_output and response.status_code<300:parsed.setdefault('Body',body)
        parsed.setdefault('ResponseMetadata',{'HTTPStatusCode':response.status_code,'HTTPHeaders':{}})
        # Endpoint._get_response converts again after parsing; content is cached.
        self.convert(response)
        return parsed
    def call(self,**kwargs):
        self.p.clients={'test':SimpleNamespace(**{self.operation:self.invoke})}
        return self.p.sdk('test',self.operation,**kwargs)


class ResponseGuardTests(unittest.TestCase):
    def provider(self):
        m,_=setup();p=transport.RealIO(m);p.bind(transport.Guards(lambda:0,100))
        return p
    def test_eager_preload_is_deferred_until_raw_is_bounded(self):
        p=self.provider();raw=Raw(b'x'*65537);f=SDKFixture(p,raw)
        with self.assertRaisesRegex(transport.Negative,'response_body_cap'):f.call()
        self.assertEqual(f.send_flags,[True])
        self.assertEqual(f.reads_at_send_return,[0])
        self.assertFalse(f.request.stream_output)
        self.assertEqual(f.parser_inputs,[])
        self.assertEqual(raw.delivered,65537)
        self.assertEqual(raw.close_calls,1)
        self.assertEqual(p.g.calls,1)
        self.assertIsNone(p._pending_raw)
