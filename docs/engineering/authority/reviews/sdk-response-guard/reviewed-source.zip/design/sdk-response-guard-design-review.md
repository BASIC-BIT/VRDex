# SDK response body-guard design review

2026-10-27. **SPEC: PASS. QUALITY: PASS.** No actionable design blocker found within the requested body-guard scope. The proposed change addresses the demonstrated eager nonstreaming body-read defect without changing modeled parsing or granting SDK support. This is design acceptance only; an implementation and its focused generated tests still require review.

## Pinned subjects

| Subject | SHA256 |
| --- | --- |
| `sdk-response-guard-design.md` | `89d5d3a5fc76cb97d29c54f2ff2c42e144c2941efb0d9f95c099de6b0d0c7d25` |
| Current `retained-image-ecr-transport/transport.py` | `b4cf9e720ca27ff2d8a9a88ccf3911a2d38be6e349c92c3999a4b50134e71bba` |
| `actual-sdk-reader-path-assessment.md` | `a6ab9132778a817d70aa0d7660b0797f4de36ce6c945f98a9ea5afa2ef61c17c` |
| Possessed `sdk-sources.zip`,349676 bytes | `91c89dc2e2e6db84eaa8fdd3c04681eaaf663b06740a3638eaf61417741fc520` |

The ZIP was read as data only. Selected full members inspected for the cited contract:

| Member under `sources/` | Bytes | SHA256 |
| --- | ---: | --- |
| `botocore/httpsession.py` |20785| `14b2961314c711499da785ec30f00d9b04ead55a4403b2aba5c5e822ffd93b7b` |
| `botocore/awsrequest.py` |23375| `85d0ae028b154a991db1078c70987440c290c55b9c34f66e8ae4053de5d22c2f` |
| `botocore/endpoint.py` |17469| `0ce924a118e3ad98a2c71293541508efc1b3e0f84fb1b80272394829ba656262` |
| `botocore/response.py` |7865| `e2ee6f81ec35f5dae9879f5f5c600dca22b78a2c43cefb0dac3b8b894ce9d11d` |

## SPEC assessment

The current worker installs `BoundedRaw` after original send returns. Possessed `httpsession.py:509–533` confirms that urllib3 preload is already disabled, but botocore then accesses `.content` when the prepared request's `stream_output` is false. Possessed `awsrequest.py:568–581` confirms that this access joins the raw stream and caches bytes. The design correctly moves installation ahead of that body read by temporarily changing only the ordinary prepared-request field shown at `awsrequest.py:508–516`.

Restoring the flag in `finally` preserves request state on both success and send failure. Endpoint subsequently chooses error bytes, event-stream raw, modeled StreamingBody or ordinary bytes from status and the operation model (`endpoint.py:43–74`), not that restored flag. Its normal checksum/parser flow remains downstream (`:290–317`); repeated nonstreaming conversion (`:250–255`) uses the cached bytes. Therefore the proposal preserves ordinary ECR/control parsing and the modeled successful S3 stream under this source contract.

The exact integer200/GetObject classification retains source-size ownership; all other replies retain the64KiB control treatment. Attempted control reads and overflow/EOF probes remain charged before consumption. Content-Length is not accepted as a substitute cap. The empty-cache check is correctly described as a drift detector, not a remedy for a sender that already read data.

The existing before-send guard continues to charge one dispatch, and original send retains `Retry(False)`. Moving body errors out of the sender's exception-mapping region can change exception classes; the design explicitly accepts that while preserving the primary exception and sanitized negative. It does not introduce a retry or fabricate a parsed success.

## QUALITY assessment and implementation review points

The three affected surfaces are appropriately limited: send wrapping, `BoundedRaw` failure/close behavior, and a single pending-raw ownership slot around the complete `sdk` invocation/validation scope. The slot addresses parser/checksum/event and post-parse failures that occur after the send wrapper has returned. A wrapper-only try/finally would not cover those failures.

The stated ownership rules must be retained literally in the implementation: close control raw without draining after successful parsing; transfer successful GetObject raw only to an actual returned body; close any untransferred raw on failure; always clear the pending slot. A missing/rejected body cannot count as an ownership transfer. An independent later call must neither inherit nor close the earlier response. This is an implementation check of the design's ownership contract, not a new design blocker.

Idempotent close must distinguish an attempted close from confirmed successful closure, avoid touching raw after closure, and preserve a primary read/guard/parser failure if cleanup also raises. On an otherwise successful control path, a cleanup failure cannot silently become successful closure. The design already requires these outcomes. Source metadata rejection and ordinary consumer cleanup must continue to work with the idempotent wrapper without prematurely closing a successfully handed-off stream.

The proposed focused fixture matrix is sufficient for this scope: eager-preload regression, flag restoration, empty/near-cap/exact-cap/overflow control bodies, short reads, cached second conversion, real-model-style streaming distinction, malformed source limits, read/guard/parser/post-validation failures, slot reset, cleanup failure, and the unchanged unsupported preflight. Fixtures must remain source-faithful mocks; passing them will not establish actual SDK/runtime compatibility. No existing suite was rerun during this review.

## Gates preserved

The design explicitly leaves pre-parsed aggregate headers, chunk framing/extensions/trailers, alternate forwarded raw-read methods, history/event/audit observers, model/checksum/profile closure, Root uploader accounting, <=20B proof and same-attempt memory fit unresolved. This narrow body fix cannot close those gates. In particular, changing the preload hint does not validate before-send observers or guarantee that an alternate sender never preloads; those belong to the still-unaccepted profile.

`unsupported_sdk_path` remains mandatory. The patch cannot enable a real support branch, substitute the fake14B model, disable global/platform observers, or authorize a provider action. Existing128-exchange, no-retry, part,256MiB AS, disk/time/evidence and image-identity limits remain unchanged.

## Review accounting

This review used a separate16MiB logical-read/work ceiling and2MiB new-disk ceiling. Conservative debit and owned outputs are recorded in `sdk-response-guard-design-review-meter.json`; prior design/assessment meters were not changed. No SDK source was imported or executed, no SDK/provider/network/corpus operation or test occurred, no implementation was edited, and no subagent was used.
