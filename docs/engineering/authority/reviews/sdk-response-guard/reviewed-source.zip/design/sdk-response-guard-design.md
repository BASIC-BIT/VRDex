# Defer SDK body buffering until the raw response is bounded

2026-10-27. Design only, for Root review before implementation. No SDK import/execution, network/provider operation, source acquisition, corpus read or subagent. Real transport acceptance remains `unsupported_sdk_path`.

## Evidence and exact defect

Pinned archive: `/workspace/scratch/sdk-inspection-live-2ecb80bc230c4d8c9db7b0140d72219a/sdk-sources.zip`, SHA256 `91c89dc2e2e6db84eaa8fdd3c04681eaaf663b06740a3638eaf61417741fc520`; references below are its full `sources/` members. Current worker is `/workspace/scratch/retained-image-ecr-transport/transport.py`.

- Worker `RealIO.bounded_sdk_send`, lines 478–487, calls original send before installing `BoundedRaw`.
- `botocore/httpsession.py:509–519`, `URLLib3Session.send`, already requests `preload_content=False`, `decode_content=False`, `Retry(False)` from urllib3. However, lines 529–533 explicitly access `http_response.content` for a prepared request with false `stream_output`.
- `botocore/awsrequest.py:571–581`, `AWSResponse.content`, materializes that body with `b''.join(self.raw.stream())` and caches it. Installing a wrapper afterward cannot bound the earlier read or erase the cache.
- `botocore/awsrequest.py:508–516`, `AWSPreparedRequest.__init__`, stores `stream_output` as an ordinary mutable instance field. It is a transport preload hint, not the operation model.
- `botocore/endpoint.py:43–74`, `convert_to_response_dict`, selects **model-based** parsing: status>=300 becomes content bytes; otherwise event streams use raw, streaming output uses `StreamingBody`, and other operations use content bytes. It does not consult the prepared request's `stream_output` flag.
- `Endpoint._do_get_response` at `endpoint.py:290–317` converts, applies checksum handling and parses after send returns. `_get_response` at lines 250–255 converts again; a nonstreaming body's cache avoids a second body read.

The fix must move the guard before the first SDK content materialization. A post-buffer length check does not satisfy that requirement.

## Minimal change and invariant

Change the worker wrapper around the existing original SDK send; do not modify SDK source, models, serializers, parsers, signing, or urllib3 request construction.

For each prepared request, save its original `stream_output`, set it to **True immediately before calling original send**, call original send exactly once, and restore the original flag in `finally`, including exceptions. With the pinned implementation, this skips only its eager `.content` access. Keep the existing request object, method, URL, headers, body, context and already completed signing/preparation unchanged. The single-flight worker permits this temporary per-request mutation; do not introduce sharing/concurrency.

After original send returns, require its content cache still unpopulated, classify the body limit from existing operation/status state, and install `BoundedRaw` before returning to Endpoint. The cache check is a profile-drift detector, not a retrospective guard if an unexpected sender already buffered data. Do not access `.content`, `.text`, `.data`, drain, or raw.stream in this wrapper. Reading status/header metadata is not body consumption; preserve existing header checks without claiming they occur before HTTP header parsing.

Keep the current classification exactly: `active_operation=='get_object'` and exact integer HTTP status 200 uses the frozen row size and `source=True`; **every other response**, including S3 GetObject errors/redirects and all ECR/receipt replies, uses 65,536 and `source=False`. Validate a nonnegative exact-integer limit before wrapping; a missing source size fails closed. No Content-Length trust shortcut and no change to operation/status acceptance.

On wrapper admission failure after a response is obtained, close its raw response without draining before propagating the original failure. If send itself raises, restore the request flag and propagate; do not invent a response, send again, or alter the exchange counter.

**Invariant:** when Endpoint first asks for nonstreaming/error content, `response.raw` is already the bounded wrapper; successful GetObject retains an unread bounded stream for its normal consumer.

## Body-limit behavior and ownership

Keep `BoundedRaw.read`'s existing maximum underlying request of 64 KiB and remaining-limit-plus-one overflow probe (worker lines 361–371). Reserve attempted control read work before touching raw; do not refund on an exception or overflow. On overflow, the offending chunk is rejected before it is yielded to the content join/parser. The raw consumer can receive **limit+1 bytes** in total to prove overflow; the accepted body remains <=limit. Exact-cap bodies require an EOF probe, and its work remains charged. Source input still uses the worker's existing source reservations and separate EOF probe.

Make error cleanup explicit at the same body boundary: guard failure, deadline/budget failure, bad returned type/length, raw-read exception and stream rejection close raw without draining, then propagate the primary failure. Add an idempotent wrapper `close()`/closed state so caller cleanup and failure cleanup cannot trigger repeated closes/reads; a read after closure must not touch raw. Closing must not consult an expired work deadline. Preserve primary exceptions if close also raises; do not claim successful closure merely because it was attempted.

For exceptions after the send wrapper returns but before a parsed body is handed to its caller, use one private **per-SDK-call pending-raw reference** in RealIO. Initialize/reset it at call entry, set it to the wrapper when installed, and clear it in `sdk`'s finalization. Wrap the existing SDK invocation **and existing response/receipt validation** so any exception closes that pending raw. On successful GetObject return, transfer ownership to its returned body and leave it open; `source()` metadata failure and the existing stream loop already close it. On successful control return, raw is exhausted; close it without draining. This is a single-flight cleanup slot, not a registry of requests or a new transport interface.

Minimal affected implementation surfaces: `RealIO.bounded_sdk_send`, the private pending-raw field plus `RealIO.sdk` call/validation ownership scope, and `BoundedRaw` close/failure handling. Existing `sdk(...)`, `source(...)`, dispatch/runner signatures, manifest schema and receipt schema stay unchanged. No new API call, retry, allocation category, body decoder, profile framework or source inventory is introduced.

Deferred nonstreaming read errors now arise during Endpoint conversion rather than inside `URLLib3Session.send`'s exception mapping. Preserve the existing sanitized negative outcome and original exception propagation; do not promise identical SDK exception classes at the old boundary, or add a broad exception translation layer. The pinned endpoint's retry decision remains disabled. A body cap failure must never become a partial successful parse or a retry.

## Parsing and streaming remain model-driven

For ECR/control success, Endpoint reads bounded content into bytes and applies its normal parser; for error responses it reads the same bounded content before normal error parsing. Repeated content access uses the existing AWSResponse cache and performs no extra read. Do not manually parse or replace the cached bytes.

For successful S3 GetObject, Endpoint still constructs StreamingBody from wrapped raw because the operation model selects streaming. Existing modeled checksum wrapping remains outside this change and continues to consume the same underlying bounded stream. The temporary transport hint neither marks the operation streaming nor changes its output shape, checksum context or status. No generalized event-stream support is added; those paths remain outside the accepted transport profile.

The wrapper does not count a second dispatch: the existing before-send guard remains the only SDK exchange charge, and original send retains Retry(False). Do not make the new unit tests call the real network or remove the real-path unsupported preflight.

## Required focused tests before merging any implementation

Use deterministic in-memory fake send/raw objects and a source-faithful preload/content-conversion fixture. These fixtures prove worker behavior under the cited contract; label them accordingly. Do not import/execute the possessed SDK source or claim a live SDK test as part of this design.

| Trigger | Required observation |
| --- | --- |
| Initially false stream_output, nonstreaming response | Fake original send observes True; no raw read occurs before it returns; wrapper installed before subsequent content access; original flag restored False. Regression test must expose eager preload with the old wrapper. |
| Initially true stream_output; send raises | Original True remains True; false-origin request is also restored on its failure case; one send attempt, no manufactured response or extra exchange. |
| Control body lengths 0, 65,535, 65,536, 65,537; unknown/misleading Content-Length | First three reach normal bytes/parser with exact content; oversized body fails before parser receives it. Raw requests <=64 KiB, total delivered <=65,537; cap/EOF work reserved before reads. |
| Short reads and exact-cap EOF | Multiple short reads reconstruct the same complete body; zero-length read terminates; exact cap needs the bounded extra EOF probe. No premature truncation or free failed read. |
| Successful GetObject row size, including >64 KiB | No eager materialization; consumer receives the stream, reads the exact bytes, detects overflow at size+1, and closes it. Source remains open across successful sdk return until ownership consumer closes it. |
| GetObject 3xx/4xx/5xx or invalid/missing row size | Error/redirect gets 64 KiB control limit regardless of large row; malformed successful-source limit fails before body consumption. No redirect/retry dispatch. |
| Two normal content conversions and model distinction | Nonstreaming second conversion uses cached bytes with no second raw read; streaming model continues to receive a stream despite restoration of the original request flag. Model, request body/context and checksum metadata are unchanged. |
| Raw raises, returns wrong type/oversize chunk, or guard deadline/read allowance expires | Primary negative propagates, raw closes once without drain, reservations remain; no partial parse, retry or success receipt. Close failure does not mask the primary error. |
| Wrapper validation fails, parser fails, or sdk post-parse validation fails | Obtained pending raw is closed; pending slot cleared. Next independent fake call cannot inherit/close the earlier raw. No received response means no close attempt. |
| Source metadata rejection and normal consumer closure | Existing source/runner cleanup remains valid with idempotent close; no SDK finalization closes an owned streaming body prematurely. |
| Existing unsupported-preflight regression with fake dependencies | RealIO.serialization_preflight still raises unsupported_sdk_path; no test substitutes a fabricated work factor or enables transport acceptance. |

Later reviewed execution against the exact managed runtime, if separately authorized, would be additional evidence. Offline fixtures alone establish neither model identity nor the full SDK reader bound.

## Explicitly unresolved and outside this change

HTTP header parsing occurs before this wrapper and is still only checked afterward; aggregate framing/chunk-extension/trailer work is not fixed here. History/event/audit observers, forwarded alternate raw-read methods, model/checksum/profile closure, Root uploader accounting, <=20B proof and same-attempt memory fit remain separate gates. No global/platform observer is disabled. The nine-module supplement design and acquisition are not prerequisites to writing this small change, but acceptance still requires their relevant missing evidence or an explicit reviewed premise.

Keep the current 128 exchanges/no retries, part sizes, 256 MiB AS, disk/time/evidence limits and image identity unchanged. Root must review this design and any later patch/tests before implementation acceptance; no paid trial or provider mutation is authorized here.

Independent design allowance: <=16 MiB reads/work and <=2 MiB new disk, recorded in `sdk-response-guard-design-meter.json`; earlier assessment/design allocations remain untouched.
