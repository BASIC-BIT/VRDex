# SDK response body guard implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development. One implementation writer at a time.

**Goal:** Enforce body limits before the SDK buffers control responses.

**Architecture:** Temporarily defer SDK preload, install the existing raw-body limiter, and preserve operation-model parsing and explicit stream ownership. Add idempotent cleanup around the complete SDK call without expanding accepted transport profiles.

**Tech stack:** Python standard library and generated in-memory unit fixtures. No actual SDK execution.

**Spec:** /workspace/scratch/sdk-response-guard-design.md SHA256 89d5d3a5fc76cb97d29c54f2ff2c42e144c2941efb0d9f95c099de6b0d0c7d25. Independent SPEC/QUALITY PASS /workspace/scratch/sdk-response-guard-design-review.md SHA256 a3af2d88a7fda46ffc7cc4166e9b0b40ed720432596b58e728c3c65ed829fa2c.

## Global constraints

- Modify only private /workspace/scratch/retained-image-ecr-transport helper source/tests/README and this task's report/freeze artifacts. Preserve the reviewed62-test baseline and its exact hashes before edits. No tracked app changes, provider/network actions, SDK source execution/imports, corpus/native reads, subagents or commits by worker.
- sdk/source/dispatch/runner signatures, manifest and receipt schemas, part limits,128exchanges/no retries,256MiBAS,disk/time/evidence limits and image identity remain unchanged.
- Keep RealIO.serialization_preflight rejecting unsupported_sdk_path. No actual acceptance branch, fake14B approval, new reader-profile framework, source acquisition, global audit hook change, header/framing fix or observer closure.
- Temporary stream_output=True immediately before original send; restore the exact original value in finally. One send attempt only; unchanged request body, headers, context and model.
- Pending-raw ownership spans SDK invocation and post-parse validation. Transfer only an actual successful GetObject returned body; close untransferred responses without draining; preserve primary failures and clear the slot on every path.
- Every non-successful-GetObject reply retains65536-bytecontrol limit; exact integer200GetObject uses its valid frozen nonnegative integer row size. Limit+1 overflow/EOF probe remains charged before read.

## Review focus

- Old eager preload must be exposed by a real failing fixture before the fix.
- Exact-cap, short-read and error bodies must remain bounded and charged before raw reads.
- Parser/post-parse failures and failed close attempts must preserve primary errors and honest cleanup state.
- Successful streams must stay open through handoff; next calls cannot inherit stale pending state.
- Unsupported real SDK preflight must remain unchanged despite fixture passes.

### Task 1: Move the guard before buffering and close owned responses

**Files:** transport.py, test_response_guard.py and existing related generated tests, README.md in the private helper. Report in assigned SDD workspace. No packet.py changes unless directly required by existing source hash freeze; do not expand scope.

**Interfaces:** Preserve RealIO.sdk/source/serialization_preflight and BoundedRaw.read external behavior. Introduce only the design's private pending-raw slot and idempotent BoundedRaw.close/failure state as necessary. Fixtures mimic pinned SDK preload/content/model conversion behavior without importing it.

- [ ] Preserve all reviewed62-test subjects unchanged in an explicit baseline directory, freeze references. Add focused matrix tests from the accepted design; capture genuine RED against the old implementation.
- [ ] Implement bounded_sdk_send temporary preload hint and restoration, empty-cache admission, valid limit classification and pre-Endpoint raw wrapping, with failure cleanup. No other prepared-request mutation.
- [ ] Implement idempotent close/read-after-close and complete sdk ownership scope. Confirm cleanup failures do not mask primary errors or silently yield successful control closure; stream transfer requires an actual body.
- [ ] Run PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v. Retain command/full output/exit. Run once after changes; expand only on failures/new edits.
- [ ] Self-review and freeze exact source/tests/docs/fixtures with baseline preservation, full scoped diff, RED/GREEN results and remaining gates in task-1-report.md. Independent SPEC/QUALITY review follows. No provider trial.
