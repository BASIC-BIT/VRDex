# SDK response guard Task 1 fix round1 review

2026-10-27. **Finding1: ADDRESSED. SPEC: PASS. QUALITY: PASS.** The actual source-upload owner now preserves primary failures while retaining failure on an otherwise successful path whose close fails. No new actionable breakage was found in the scoped fix diff.

## Pinned subjects

| Subject | SHA256 |
| --- | --- |
| Appended `task-1-report.md` | `00db13cc60f7c4ae02d55c7ca2d2e95cb00f19c4663f479185b4e237ac9aa858` |
| `task-1-fixround1-freeze/artifact-manifest.json` | `360facfaf39d75580f9542dde75f6eb2cfb795dfcd000114c9597d83aa5ab47c` |
| `task-1-fixround1-freeze/review-subjects.json` | `a863fb80211935447ece2c082d2ae4d2113a7f8e32b14ae82b3c9ad8a1bb0c56` |
| `task-1-fixround1-freeze/fixround1-scoped.diff` | `d593c4c7b78caf4ac11f4f86fdd98ecef3eab17dc93fc15f0b7521f2a2bebccc` |
| Current `transport.py`,49188 bytes | `9beb963400c72a4f6e8b91c1573bfba609c3acb1aba215428c190fc1234622e5` |
| Current `test_response_guard.py`,20868 bytes | `f7703ed748a853dc679495713b3b0feddcec1f0193470376894d341adfeac715` |

Verified15 selected frozen manifest subjects and all six current helper subjects against their hashes, with no mismatch. The archived original report matches its original reviewed hash. Static AST comparison confirms that only `run_transport` changed in production and all five previous response-guard fixture/test classes are unchanged. The reported preservation of all91 initial freeze files was not exhaustively repeated; no source ZIP was read.

## Finding1 disposition

Source-identity rejection now catches only the cleanup exception while re-raising the active primary exception. It therefore preserves `source_identity` when the returned body's close fails.

The actual upload part loop initializes `source_failed=True` and changes it to False only after all part reads, uploads/acknowledgements and the EOF probe complete. Its failure branch suppresses only a secondary close error; its successful branch calls close without suppression. Thus a primary read, overflow or in-loop upload/validation failure survives cleanup, while failed close after successful consumption still aborts before layer completion. The existing idempotent wrapper continues to make one underlying close attempt; no retry or replacement source dispatch was added.

The three new test methods exercise `run_transport` directly using existing generated FakeIO plus actual BoundedRaw. They cover four cases: overflow and distinct read failure each retain their primary codes; mismatched metadata retains `source_identity` without raw reads; successful consumption with failed close remains an `OSError` negative. All cases assert one underlying close, one source dispatch, expected part count, no completion/readback/image calls, no successful steps and only the final negative receipt. These assertions cover the actual owner missed by the initial helper-only tests.

## Retained verification

The genuine RED ran the three new methods against the reviewed implementation: three failing cases recorded `OSError` in place of the primary code. The successful-consumption/failed-close case already passed and remains a preservation check. RED log SHA256: `004f0ebbc2ce6119dd4491e6de264b7856d1081248c7bfac76552971d5f98632`.

The covering file command, `PYTHONDONTWRITEBYTECODE=1 python -m unittest test_response_guard -v`, is retained with exit0 and `Ran 23 tests in 0.361s` / `OK`. GREEN log SHA256: `086b532cb9e54bb067b61307e849781e6f45aee720260a3576745898dd86ee3b`. These23 include the prior20 response-guard tests and three new direct runner methods. This reviewer reran no test. The initial82-test full-suite pass remains historical evidence; no full85-test run is claimed.

## Scope and limits

This pass closes initial review finding1 and evaluates new breakage only in the fix diff. Other unchanged baseline observations are deferred. SDK/profile/preflight code is unchanged; `unsupported_sdk_path` remains in force. Source/model/header/framing/observer closure, uploader accounting, <=20B proof and actual SDK/runtime compatibility remain future gates. No launch, provider, spend, capacity or production-admission approval follows.

Separate8MiB logical-read/work and1MiB disk accounting is recorded in `task-1-round1-review-meter.json`. No code was changed, no test or reproduction was executed, no actual SDK was imported/executed, no provider/network/corpus/native/source-ZIP read occurred, and no subagent was used.
