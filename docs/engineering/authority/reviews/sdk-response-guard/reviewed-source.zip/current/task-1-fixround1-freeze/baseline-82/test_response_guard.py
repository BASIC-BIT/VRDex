"""Generated in-memory contract fixtures; no SDK imports or SDK execution.

The preload/content/model conversion order follows the pinned source contract
cited in sdk-response-guard-design.md. Fixture passes do not accept an SDK path.
"""
import io
from types import SimpleNamespace
import unittest

import transport
from test_transport import setup


class Raw(io.BytesIO):
    def __init__(self, data=b'', *, short=None, read_error=None, close_error=None):
        super().__init__(data)
        self.requests=[]; self.delivered=0; self.close_calls=0
        self.short=short; self.read_error=read_error; self.close_error=close_error
        self.before_read=None
    def read(self, n=-1, **kwargs):
        self.requests.append(n)
        if self.before_read:self.before_read(n)
        if self.read_error:raise self.read_error
        data=super().read(min(n,self.short) if self.short else n)
        self.delivered+=len(data)
        return data
    def stream(self, amt=65536, decode_content=False):
        while True:
            data=self.read(amt,decode_content=decode_content)
            if not data:break
            yield data
    def close(self):
        self.close_calls+=1
        if self.close_error:raise self.close_error
        super().close()


class AWSResponseFixture:
    # AWSResponse.content joins raw.stream once and caches the result.
    def __init__(self, raw, status=200, headers=None):
        self.raw=raw; self.status_code=status
        self.headers={} if headers is None else headers
        self._content=None
    @property
    def content(self):
        if self._content is None:self._content=b''.join(self.raw.stream())
        return self._content


class StreamingBodyFixture:
    def __init__(self,raw):self.raw=raw
    def read(self,n=None):return self.raw.read(n)
    def close(self):return self.raw.close()


class SDKFixture:
    """One send; endpoint conversion uses status/model, never the request hint."""
    def __init__(self,p,raw, *, operation='control',status=200,stream_output=False,
                 streaming_model=False,parsed=None,parser_error=None,send_error=None,headers=None):
        self.p=p; self.raw=raw; self.operation=operation; self.send_error=send_error
        self.request=SimpleNamespace(stream_output=stream_output,method='POST',
            url='https://ecr.us-east-1.amazonaws.com/',headers={'signed':'unchanged'},
            body=b'prepared-body',context={'checksum':{'algorithm':'unchanged'}})
        self.response=AWSResponseFixture(raw,status,headers)
        self.model=SimpleNamespace(has_streaming_output=streaming_model)
        self.parsed={} if parsed is None else parsed; self.parser_error=parser_error
        self.send_flags=[]; self.reads_at_send_return=[]; self.parser_inputs=[]
        self.converted=[]
    def send(self,request):
        self.send_flags.append(request.stream_output)
        if self.send_error:raise self.send_error
        # URLLib3Session.send explicitly preloads on a false prepared hint.
        if not request.stream_output:self.response.content
        self.reads_at_send_return.append(len(self.raw.requests))
        return self.response
    def convert(self,response):
        if response.status_code>=300 or not self.model.has_streaming_output:
            body=response.content
        else:body=StreamingBodyFixture(response.raw)
        self.converted.append(body)
        return body
    def invoke(self,**kwargs):
        self.p.before_send(self.request)
        response=self.p.bounded_sdk_send(self.send)(self.request)
        body=self.convert(response)
        self.parser_inputs.append(body)
        if self.parser_error:raise self.parser_error
        parsed=dict(self.parsed)
        if self.model.has_streaming_output and response.status_code<300:parsed.setdefault('Body',body)
        parsed.setdefault('ResponseMetadata',{'HTTPStatusCode':response.status_code,'HTTPHeaders':{}})
        # Endpoint._get_response converts again after parsing; content is cached.
        self.convert(response)
        return parsed
    def call(self,**kwargs):
        self.p.clients={'test':SimpleNamespace(**{self.operation:self.invoke})}
        return self.p.sdk('test',self.operation,**kwargs)


class ResponseGuardTests(unittest.TestCase):
    def provider(self):
        m,_=setup();p=transport.RealIO(m);p.bind(transport.Guards(lambda:0,100))
        return p
    def test_eager_preload_is_deferred_until_raw_is_bounded(self):
        p=self.provider();raw=Raw(b'x'*65537);f=SDKFixture(p,raw)
        with self.assertRaisesRegex(transport.Negative,'response_body_cap'):f.call()
        self.assertEqual(f.send_flags,[True])
        self.assertEqual(f.reads_at_send_return,[0])
        self.assertFalse(f.request.stream_output)
        self.assertEqual(f.parser_inputs,[])
        self.assertEqual(raw.delivered,65537)
        self.assertEqual(raw.close_calls,1)
        self.assertEqual(p.g.calls,1)
        self.assertIsNone(p._pending_raw)
    def test_control_boundaries_short_reads_and_cache(self):
        for size,short,headers in [(0,None,{}),(65535,None,{}),(65536,None,{'Content-Length':'1'}),
                                   (65536,1024,{'Content-Length':'999999999'}),(31,7,{})]:
            with self.subTest(size=size,short=short):
                p=self.provider();raw=Raw(b'a'*size,short=short);charged=[0]
                def before(n):
                    self.assertEqual(p.g.reads['preflight'],charged[0]+n)
                    charged[0]+=n
                raw.before_read=before;f=SDKFixture(p,raw,headers=headers)
                self.assertEqual(f.call(),{})
                self.assertEqual(f.parser_inputs,[b'a'*size])
                self.assertIs(f.converted[0],f.converted[1])
                self.assertEqual(raw.delivered,size)
                self.assertTrue(all(0<n<=65536 for n in raw.requests))
                self.assertEqual(raw.requests[-1],1 if size==65536 else min(65536,65536-size+1))
                self.assertEqual(raw.close_calls,1)
                self.assertIsNone(p._pending_raw)
    def test_request_flag_identity_and_model_are_restored(self):
        for initial in [False,True]:
            p=self.provider();f=SDKFixture(p,Raw(b'ok'),stream_output=initial)
            request=f.request;body=request.body;headers=request.headers;context=request.context;model=f.model
            self.assertEqual(f.call(),{})
            self.assertIs(request.stream_output,initial)
            self.assertIs(request.body,body);self.assertIs(request.headers,headers);self.assertIs(request.context,context)
            self.assertIs(f.model,model);self.assertEqual(f.send_flags,[True])
            self.assertEqual(context,{'checksum':{'algorithm':'unchanged'}})
    def test_send_failure_restores_flag_without_second_send_or_raw_close(self):
        for initial in [False,True]:
            p=self.provider();error=OSError('send');raw=Raw()
            f=SDKFixture(p,raw,stream_output=initial,send_error=error)
            with self.assertRaises(OSError) as caught:f.call()
            self.assertIs(caught.exception,error);self.assertIs(f.request.stream_output,initial)
            self.assertEqual(f.send_flags,[True]);self.assertEqual(raw.close_calls,0)
            self.assertEqual(p.g.calls,1);self.assertIsNone(p._pending_raw)
    def test_only_exact_integer_200_get_object_uses_source_limit(self):
        for status in [206,301,403,500,200.0,True]:
            with self.subTest(status=status):
                p=self.provider();p.active_operation='get_object';p.active_source_size=999999
                raw=Raw(b'x'*65537);response=AWSResponseFixture(raw,status)
                reply=p.bounded_sdk_send(lambda request:response)(SimpleNamespace(stream_output=True))
                with self.assertRaisesRegex(transport.Negative,'response_body_cap'):list(reply.raw.stream())
                self.assertEqual(p.g.reads['preflight'],65537)
                self.assertEqual(raw.close_calls,1)
    def test_invalid_source_limits_fail_before_read_and_close(self):
        for size in [None,-1,True,1.0,'10']:
            with self.subTest(size=size):
                p=self.provider();p.active_operation='get_object';p.active_source_size=size
                raw=Raw(b'x');response=AWSResponseFixture(raw)
                request=SimpleNamespace(stream_output=False)
                with self.assertRaisesRegex(transport.Negative,'response_limit'):
                    p.bounded_sdk_send(lambda request:response)(request)
                self.assertFalse(request.stream_output);self.assertEqual(raw.requests,[])
                self.assertEqual(raw.close_calls,1)
    def test_cached_response_is_rejected_without_new_body_read(self):
        p=self.provider();raw=Raw();response=AWSResponseFixture(raw);response._content=b''
        with self.assertRaisesRegex(transport.Negative,'response_preloaded'):
            p.bounded_sdk_send(lambda request:response)(SimpleNamespace(stream_output=False))
        self.assertEqual(raw.requests,[]);self.assertEqual(raw.close_calls,1)
    def test_missing_cache_is_rejected_and_cleanup_cannot_mask_admission_failure(self):
        p=self.provider();raw=Raw(close_error=OSError('close'))
        response=SimpleNamespace(raw=raw,status_code=200,headers={})
        with self.assertRaisesRegex(transport.Negative,'response_preloaded'):
            p.bounded_sdk_send(lambda request:response)(SimpleNamespace(stream_output=False))
        self.assertEqual(raw.requests,[]);self.assertEqual(raw.close_calls,1)
    def test_header_admission_failure_closes_without_masking_primary(self):
        p=self.provider();raw=Raw(close_error=OSError('close'))
        f=SDKFixture(p,raw,headers={'x':'a'*65536})
        with self.assertRaisesRegex(transport.Negative,'response_headers'):f.call()
        self.assertEqual(raw.requests,[]);self.assertEqual(raw.close_calls,1)
        self.assertIsNone(p._pending_raw)
    def test_successful_source_stream_handoff_and_normal_consumer_close(self):
        for size in [0,70000]:
            with self.subTest(size=size):
                p=self.provider();row=p.m['blobs'][0];row['size']=size
                raw=Raw(b's'*size);f=SDKFixture(p,raw,operation='get_object',streaming_model=True)
                reply=f.call(Key=row['key']);body=reply['Body']
                self.assertEqual(raw.requests,[]);self.assertEqual(raw.close_calls,0)
                self.assertIsNone(p._pending_raw);self.assertFalse(f.request.stream_output)
                SDKFixture(p,Raw(b'next')).call()
                self.assertEqual(raw.close_calls,0)
                preflight_before_consumer=p.g.reads['preflight']
                # Existing source consumer reserves source/EOF work and closes.
                result,collected=transport.stream_exact(body,size,p.g,'source',collect=True)
                self.assertEqual(result['bytes'],size);self.assertEqual(collected,b's'*size)
                self.assertEqual(raw.close_calls,1);body.close();self.assertEqual(raw.close_calls,1)
                self.assertEqual(p.g.reads['source'],size)
                self.assertEqual(p.g.reads['preflight'],preflight_before_consumer+1)
    def test_source_overflow_closes_once_with_reserved_probe(self):
        p=self.provider();row=p.m['blobs'][0];row['size']=70000
        raw=Raw(b's'*70001);f=SDKFixture(p,raw,operation='get_object',streaming_model=True)
        body=f.call(Key=row['key'])['Body']
        with self.assertRaisesRegex(transport.Negative,'response_body_cap'):
            transport.stream_exact(body,70000,p.g,'source')
        self.assertEqual(raw.delivered,70001);self.assertEqual(raw.close_calls,1)
        self.assertEqual(p.g.reads['source'],70000);self.assertEqual(p.g.reads['preflight'],1)
    def test_source_consumer_close_failure_preserves_overflow_primary(self):
        p=self.provider();row=p.m['blobs'][0];row['size']=3
        raw=Raw(b'four',close_error=OSError('close'))
        f=SDKFixture(p,raw,operation='get_object',streaming_model=True)
        body=f.call(Key=row['key'])['Body']
        with self.assertRaisesRegex(transport.Negative,'response_body_cap'):
            transport.stream_exact(body,3,p.g,'source')
        self.assertEqual(raw.close_calls,1);self.assertEqual(raw.delivered,4)
    def test_source_consumer_successful_read_does_not_hide_close_failure(self):
        p=self.provider();raw=Raw(b'abc',close_error=OSError('close'))
        wrapper=transport.BoundedRaw(raw,3,p.g,source=True)
        with self.assertRaisesRegex(OSError,'close'):
            transport.stream_exact(wrapper,3,p.g,'source')
        self.assertEqual(raw.close_calls,1)
    def test_source_metadata_rejection_keeps_primary_and_closes_once(self):
        p=self.provider();row=p.m['blobs'][0]
        raw=Raw(close_error=OSError('close'));f=SDKFixture(p,raw,operation='get_object',streaming_model=True)
        p.clients={'s3':SimpleNamespace(get_object=f.invoke)}
        with self.assertRaisesRegex(transport.Negative,'source_metadata'):p.source(row)
        self.assertEqual(raw.close_calls,1);self.assertEqual(raw.requests,[])
    def test_missing_or_invalid_stream_body_does_not_transfer_pending_raw(self):
        for body in [None,b'',object()]:
            with self.subTest(body=body):
                p=self.provider();row=p.m['blobs'][0];raw=Raw()
                f=SDKFixture(p,raw,operation='get_object',streaming_model=True,parsed={'Body':body})
                with self.assertRaisesRegex(transport.Negative,'source_body'):f.call(Key=row['key'])
                self.assertEqual(raw.close_calls,1);self.assertIsNone(p._pending_raw)
    def test_parser_and_postparse_failures_close_clear_and_preserve_primary(self):
        for case in ['parser','status','identity','semantic','originals']:
            with self.subTest(case=case):
                p=self.provider();raw=Raw(b'{}',close_error=OSError('close'))
                error=ValueError('parser');parsed={};status=200
                if case=='status':status=403
                if case=='identity':parsed={'registryId':'wrong'}
                if case=='semantic':parsed={'unrepresentable':object()}
                if case=='originals':p.original_bytes=128*1024
                f=SDKFixture(p,raw,status=status,parsed=parsed,parser_error=error if case=='parser' else None)
                expected={'status':'sdk_status','identity':'response_identity','semantic':'response_shape','originals':'originals_cap'}
                if case=='parser':
                    with self.assertRaises(ValueError) as caught:f.call()
                    self.assertIs(caught.exception,error)
                else:
                    with self.assertRaisesRegex(transport.Negative,expected[case]):f.call()
                self.assertEqual(raw.close_calls,1);self.assertIsNone(p._pending_raw)
                p.original_bytes=0
                next_raw=Raw(b'next');SDKFixture(p,next_raw).call()
                self.assertEqual(raw.close_calls,1)
    def test_successful_control_close_failure_is_not_silent_success(self):
        p=self.provider();error=OSError('close');raw=Raw(b'ok',close_error=error);f=SDKFixture(p,raw)
        with self.assertRaises(OSError) as caught:f.call()
        self.assertIs(caught.exception,error);self.assertIsNone(p._pending_raw)
        wrapper=f.response.raw;self.assertFalse(wrapper.closed)
        with self.assertRaises(OSError) as caught:wrapper.close()
        self.assertIs(caught.exception,error);self.assertEqual(raw.close_calls,1)
        with self.assertRaisesRegex(transport.Negative,'response_closed'):wrapper.read()
        self.assertEqual(len(raw.requests),2)
    def test_read_failures_close_preserve_error_and_do_not_refund_attempt(self):
        for case in ['raw','type','chunk','deadline','budget','amount','decoding']:
            with self.subTest(case=case):
                p=self.provider();error=OSError('read');raw=Raw(b'ok',close_error=OSError('close'))
                if case=='raw':raw.read_error=error
                if case=='type':raw.read=lambda n,**kwargs:'not bytes'
                if case=='chunk':raw.read=lambda n,**kwargs:b'x'*(n+1)
                if case=='deadline':p.g.deadline=0
                if case=='budget':p.g.reads['preflight']=transport.META_READ
                wrapper=transport.BoundedRaw(raw,65536,p.g)
                def read():
                    if case=='decoding':return list(wrapper.stream(decode_content=True))
                    return wrapper.read(-1 if case=='amount' else None)
                if case=='raw':
                    with self.assertRaises(OSError) as caught:read()
                    self.assertIs(caught.exception,error)
                else:
                    with self.assertRaises(transport.Negative):read()
                self.assertEqual(raw.close_calls,1)
                self.assertFalse(wrapper.closed)
                count=len(raw.requests)
                with self.assertRaisesRegex(transport.Negative,'response_closed'):wrapper.read()
                self.assertEqual(len(raw.requests),count)
                if case in ['raw','type','chunk']:self.assertEqual(p.g.reads['preflight'],65536)
                if case in ['deadline','budget','amount','decoding']:self.assertEqual(raw.requests,[])
    def test_close_does_not_check_deadline_and_read_after_close_never_touches_raw(self):
        p=self.provider();raw=Raw(b'abc');wrapper=transport.BoundedRaw(raw,3,p.g)
        p.g.deadline=0;wrapper.close();wrapper.close()
        self.assertTrue(wrapper.closed);self.assertEqual(raw.close_calls,1)
        with self.assertRaisesRegex(transport.Negative,'response_closed'):wrapper.read()
        self.assertEqual(raw.requests,[])
    def test_error_get_object_uses_control_bytes_before_normal_error_parse(self):
        p=self.provider();row=p.m['blobs'][0];row['size']=900000
        raw=Raw(b'error');f=SDKFixture(p,raw,operation='get_object',status=403,streaming_model=True)
        with self.assertRaisesRegex(transport.Negative,'sdk_status'):f.call(Key=row['key'])
        self.assertEqual(f.parser_inputs,[b'error']);self.assertEqual(p.g.reads['source'],0)
        self.assertGreater(p.g.reads['preflight'],0);self.assertEqual(raw.close_calls,1)


if __name__=='__main__':unittest.main()
