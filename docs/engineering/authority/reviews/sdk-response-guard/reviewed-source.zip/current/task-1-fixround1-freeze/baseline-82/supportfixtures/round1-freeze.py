"""Freeze round1 changes against preserved originals; generated fixtures only."""
import base64
import difflib
import hashlib
import json
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
SUPPORT=ROOT/'supportfixtures'
BEFORE=SUPPORT/'round1-before'
sys.path.insert(0,str(ROOT))
import packet
from test_packet import fixture


def write_json(name,value):
    (SUPPORT/name).write_bytes(packet.canonical(value)+b'\n')


def main():
    owned,metadata,pins,_=fixture()
    result=packet.prepare_packet(owned,metadata,pins)
    for name,key in [('source.zip','source_zip'),('input.json','input_bytes'),('buildspec.yml','buildspec')]:
        (SUPPORT/('round1-fixture-'+name)).write_bytes(result[key])
    for name,key in [('project','project'),('start','start'),('budget','budgets'),('predicted','predicted')]:
        write_json('round1-fixture-'+name+'.json',result[key])
    write_json('round1-fixture-refs.json',{key:result[key] for key in ['source_sha256','source_size','input_sha256','members']})
    originals={str(p.relative_to(BEFORE)):{'size':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(BEFORE.rglob('*')) if p.is_file()}
    write_json('round1-original-inventory.json',{'subjects':originals})
    primary=['transport.py','test_transport.py','packet.py','test_packet.py','README.md']
    selected=primary+['supportfixtures/'+p.name for p in sorted(SUPPORT.glob('round1-*')) if p.is_file() and p.name not in {'round1-review-subjects.json','round1-fix.diff'}]
    inventory={name:{'size':(ROOT/name).stat().st_size,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in selected}
    write_json('round1-review-subjects.json',{'fixture_only':True,'real_sdk_profiles':0,'subjects':inventory})
    selected.append('supportfixtures/round1-review-subjects.json')
    with (SUPPORT/'round1-fix.diff').open('w') as output:
        output.write('Round1 source changes against preserved supportfixtures/round1-before. Added review support is included in full. No Git/provider operations.\n')
        for name in selected:
            current=(ROOT/name).read_bytes()
            original=(BEFORE/name).read_bytes() if (BEFORE/name).is_file() else b''
            output.write('\nSubject '+name+' SHA256 '+hashlib.sha256(current).hexdigest()+' bytes '+str(len(current))+'\n')
            if name.endswith('.zip'):
                output.write('BASE64-BEGIN\n'+base64.b64encode(current).decode()+'\nBASE64-END\n')
            else:
                output.writelines(difflib.unified_diff(original.decode().splitlines(keepends=True),current.decode().splitlines(keepends=True),fromfile='round1-before/'+name if original else '/dev/null',tofile=name))
    # Verify all frozen subjects and preserved originals in place after writes.
    for prefix,subjects in [(ROOT,inventory),(BEFORE,originals)]:
        for name,ref in subjects.items():
            data=(prefix/name).read_bytes()
            assert len(data)==ref['size'] and hashlib.sha256(data).hexdigest()==ref['sha256'],name
    for name in ['round1-review-subjects.json','round1-fix.diff','round1-original-inventory.json']:
        data=(SUPPORT/name).read_bytes()
        print(name+' bytes='+str(len(data))+' sha256='+hashlib.sha256(data).hexdigest())
    print('verified '+str(len(inventory))+' current subjects and '+str(len(originals))+' preserved originals')
    return 0

if __name__=='__main__':raise SystemExit(main())
