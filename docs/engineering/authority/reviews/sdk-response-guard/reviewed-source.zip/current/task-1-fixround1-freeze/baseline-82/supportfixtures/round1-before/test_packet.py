import copy
import hashlib
import io
import json
from pathlib import Path
import unittest
import zipfile

import packet

ROOT = Path(__file__).parent

def fixture():
    layers = [bytes([i + 1]) * n for i, n in enumerate([37, 13, 39, 31, 11, 41, 7, 29])]
    diffs = [hashlib.sha256(b'diff' + b).hexdigest() for b in layers]
    config = packet.canonical({'architecture': 'amd64', 'os': 'linux', 'rootfs': {'type': 'layers', 'diff_ids': ['sha256:' + d for d in diffs]}})
    blobs = [config] + layers
    rows = [{'sha256': hashlib.sha256(b).hexdigest(), 'size': len(b), 'diff_id': None if i == 0 else diffs[i-1], 'retained_name': 'config.json' if i == 0 else 'layer-%04d.gz' % (i-1)} for i, b in enumerate(blobs)]
    owned = {'account': '079358094174', 'region': 'us-east-1', 'repository': 'retained-transport-fixture0123', 'nonce': 'fixture0123', 'bucket': 'private-fixture-bucket', 'prefix': 'transport/fixture0123/', 'versions': ['v%d' % i for i in range(9)], 'code_version': 'code-v1', 'role_arn': 'arn:aws:iam::079358094174:role/transport-fixture0123', 'project_name': 'transport-fixture0123', 'carrier_start': 1000, 'allocation_id':'transport-read-fixture0123','allocation_receipt_sha256':'b'*64, 'redirect_origins': ['https://prod-us-east-1-starport-layer-bucket.s3.us-east-1.amazonaws.com']}
    metadata = {'fixture': True, 'source_revision': packet.SOURCE, 'config_utf8': config.decode(), 'blobs': rows, 'replay': {'sha256': 'a'*64, 'validated': True, 'save_sha256': packet.SAVE}}
    pins = {'transport.py': (ROOT / 'transport.py').read_bytes()}
    return owned, metadata, pins, blobs

class PacketTests(unittest.TestCase):
    def test_deterministic_zip_and_no_hash_cycle(self):
        o, m, p, _ = fixture()
        a = packet.prepare_packet(o,m,p); b = packet.prepare_packet(o,m,p)
        self.assertEqual(a['source_zip'], b['source_zip'])
        self.assertEqual(a['source_sha256'], hashlib.sha256(a['source_zip']).hexdigest())
        with zipfile.ZipFile(io.BytesIO(a['source_zip'])) as z:
            self.assertEqual(set(z.namelist()), {'transport.py','input.json','buildspec.yml'})
            self.assertEqual(a['input_sha256'], hashlib.sha256(z.read('input.json')).hexdigest())
            self.assertNotIn('source_sha256', json.loads(z.read('input.json')))
        self.assertEqual(a['project']['environment']['image'], 'aws/codebuild/standard:7.0')
        self.assertFalse(a['project']['environment']['privilegedMode'])
        self.assertEqual(a['project']['logsConfig']['cloudWatchLogs']['status'], 'DISABLED')
        self.assertEqual(a['start']['idempotencyToken'], o['nonce'])
    def test_metadata_joins(self):
        o,m,p,_=fixture()
        for mutation in ['hash','order','source','diff','config','extra']:
            bad=copy.deepcopy(m)
            if mutation=='hash': bad['blobs'][0]['sha256']='0'*64
            if mutation=='order': bad['blobs'][1:3]=bad['blobs'][2:0:-1]
            if mutation=='source': bad['source_revision']='0'*40
            if mutation=='diff': bad['blobs'][1]['diff_id']='0'*64
            if mutation=='config': bad['config_utf8']+=' '
            if mutation=='extra': bad['blobs'].append(bad['blobs'][0])
            with self.subTest(mutation=mutation), self.assertRaises(ValueError): packet.prepare_packet(o,bad,p)
    def test_fixed_inputs_and_no_commands(self):
        o,m,p,_=fixture()
        for key,value in [('account','000000000000'),('region','us-west-2'),('repository','unowned'),('prefix','../bad'),('redirect_origins',['https://evil.example'])]:
            bad=copy.deepcopy(o);bad[key]=value
            with self.subTest(key=key), self.assertRaises(ValueError): packet.prepare_packet(bad,m,p)
        for name in ['../x','extra.py','input.json','buildspec.yml']:
            with self.subTest(name=name), self.assertRaises(ValueError): packet.prepare_packet(o,m,{**p,name:b'bad'})
    def test_source_limits(self):
        o,m,p,_=fixture()
        with self.assertRaises(ValueError): packet.prepare_packet(o,m,{'transport.py':b'x'*(4*1024*1024+1)})
    def test_real_identity_cannot_be_fixture(self):
        o,m,p,_=fixture();m['fixture']=False
        with self.assertRaises(ValueError):packet.prepare_packet(o,m,p)

if __name__=='__main__':unittest.main()

class AdditionalPacketTests(unittest.TestCase):
    def test_source_zip_rejects_duplicate_traversal_link_extra(self):
        import stat
        o,m,p,_=fixture();a=packet.prepare_packet(o,m,p)
        expected={'transport.py':p['transport.py'],'input.json':a['input_bytes'],'buildspec.yml':a['buildspec']}
        for mode in ['duplicate','traversal','link','extra']:
            out=io.BytesIO()
            with zipfile.ZipFile(out,'w') as z:
                for name,data in expected.items():
                    info=zipfile.ZipInfo(name);info.external_attr=(stat.S_IFREG|0o400)<<16
                    if mode=='link' and name=='transport.py':info.external_attr=(stat.S_IFLNK|0o777)<<16
                    z.writestr(info,data)
                if mode!='link':
                    name={'duplicate':'input.json','traversal':'../x','extra':'extra.py'}[mode]
                    info=zipfile.ZipInfo(name);info.external_attr=(stat.S_IFREG|0o400)<<16;z.writestr(info,b'bad')
            with self.subTest(mode=mode),self.assertRaises(ValueError):packet.inspect_zip(out.getvalue(),expected)
    def test_schema_does_not_accept_arbitrary_commands_or_support(self):
        o,m,p,_=fixture();o['commands']=['echo bad']
        with self.assertRaises(ValueError):packet.prepare_packet(o,m,p)
    def test_fixed_project_has_no_log_artifact_cache_vpc_or_install(self):
        o,m,p,_=fixture();a=packet.prepare_packet(o,m,p);project=a['project']
        self.assertEqual(project['artifacts'],{'type':'NO_ARTIFACTS'});self.assertEqual(project['cache'],{'type':'NO_CACHE'})
        self.assertNotIn('vpcConfig',project);self.assertEqual(project['timeoutInMinutes'],5);self.assertEqual(project['queuedTimeoutInMinutes'],5)
        spec=a['buildspec'].decode();self.assertIn('exec python3 -I -B transport.py '+a['input_sha256'],spec)
        for forbidden in ['pip','docker','curl','wget']:self.assertNotIn(forbidden,spec)
    def test_exact_read_ledger(self):
        b=packet.transport.budgets();self.assertEqual(sum(b['reads'].values()),b['read_reserved'])
        self.assertLessEqual(b['read_reserved'],b['read_ceiling']);self.assertEqual(b['joint'],276824064)
        self.assertEqual(b['reads']['copy'],20*301096124)
    def test_input_and_manifest_tampering_and_expanded_inventory(self):
        import tempfile
        o,m,p,_=fixture();a=packet.prepare_packet(o,m,p)
        with tempfile.TemporaryDirectory(dir=ROOT/'supportfixtures') as directory:
            root=Path(directory)
            for name,data in {'transport.py':p['transport.py'],'input.json':a['input_bytes'],'buildspec.yml':a['buildspec']}.items():(root/name).write_bytes(data)
            # Fixtures are not runnable through the real source preflight.
            with self.assertRaisesRegex(ValueError,'fixture_entrypoint'):packet.transport.read_source_tree(root,a['input_sha256'])
            (root/'extra.py').write_bytes(b'extra')
            with self.assertRaisesRegex(ValueError,'expanded_tree'):packet.transport.read_source_tree(root,a['input_sha256'])
            (root/'extra.py').unlink();(root/'input.json').write_bytes(a['input_bytes']+b' ')
            with self.assertRaisesRegex(ValueError,'input_hash'):packet.transport.read_source_tree(root,a['input_sha256'])
    def test_manifest_media_order_size_digest_enforced(self):
        o,m,p,_=fixture();a=packet.prepare_packet(o,m,p)
        for mode in ['media','order','size','digest']:
            manifest=copy.deepcopy(a['input_manifest']);image=json.loads(manifest['manifest_utf8'])
            if mode=='media':image['mediaType']='application/vnd.oci.image.manifest.v1+json'
            if mode=='order':image['layers'].reverse()
            if mode=='size':image['config']['size']+=1
            if mode=='digest':image['layers'][0]['digest']='sha256:'+'0'*64
            manifest['manifest_utf8']=packet.canonical(image).decode();manifest['manifest_sha256']=hashlib.sha256(manifest['manifest_utf8'].encode()).hexdigest()
            with self.subTest(mode=mode),self.assertRaises(ValueError):packet.transport.validate_manifest(manifest)
