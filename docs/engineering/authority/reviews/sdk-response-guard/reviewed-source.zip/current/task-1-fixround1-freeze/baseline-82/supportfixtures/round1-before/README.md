# Private retained-image transport

This is an offline-reviewed candidate for one finite CodeBuild transport attempt. It does not run the retained image, qualify native code, authorize spend, or replace the existing builder. No real AWS, Docker, corpus or layer reads are part of the tests.

## Interfaces

`packet.prepare_packet(owned_inputs, blob_metadata, support_pins)` constructs bytes and requests without reading image files or calling a provider. It returns `source_zip`, `source_sha256`, `source_size`, `input_manifest`, `input_bytes`, `input_sha256`, `buildspec`, member identities, `project`, `start`, predicted S3/registry inputs and budgets.

`owned_inputs` has exactly these keys:

- `account`, `region`: fixed `079358094174`, `us-east-1`.
- `nonce`: 8 to48 lowercase ASCII letters/digits. `repository`, `project_name`, `role_arn`, `prefix` must respectively equal `retained-transport-<nonce>`, `transport-<nonce>`, `arn:aws:iam::079358094174:role/transport-<nonce>`, `transport/<nonce>/`.
- `bucket`, nine immutable non-null `versions`, `code_version`.
- `carrier_start`: absolute epoch seconds, fixed at first resource mutation. Deadlines are derived, never caller widened.
- `redirect_origins`: reviewed exact subset of the two regional starport hostnames permitted in `validate_manifest`. An unlisted alias requires a code/source review rather than live discovery.
- `allocation_id`: `transport-read-<nonce>` and `allocation_receipt_sha256`: Root's retained ledger/allocation receipt hash. The input binds the separate8GiB reservation of8,416,415,151 bytes.

`blob_metadata` has exactly `fixture`, `source_revision`, `config_utf8`, `blobs`, `replay`. Each of nine rows has `sha256`, `size`, `diff_id`, `retained_name`, with config first followed by the eight actual manifest-order layers. Config's `diff_id` is null. `replay` is `{sha256: <Root receipt hash>, validated: true, save_sha256: <fixed save hash>}`. Root must perform and retain the one fresh reviewed local replay, including config/literal/scanner/diffID/order equality. These metadata fields bind that external observation; metadata alone does not establish it. The worker independently hashes actual S3 bytes and every complete registry readback. It does not repeat decompression.

`support_pins` is exactly `{'transport.py': <approved worker bytes>}`. Tests generate explicitly fake metadata. Real startup rejects `fixture: true`. The reviewed baseline is source `db9abbcd59a30d206d85c0dcb2f407150e31dd9e`, exact8177-byte config `9ff28822297fe7989bd62e1244edfcb16c72928fb84b0a74a92834eeb4eee0d4`, and eight compressed blobs, total301,096,124 bytes.

`transport.run_transport(input_manifest, io)` returns `complete`, `negative`, or `incomplete`. `complete` requires nine immutable step writes, exact blob/config/manifest verification, and observed final persistence before the deadline. `incomplete` covers missing/ambiguous/late final persistence or close failure. A negative never retries an upload, starts another worker, or widens a limit. Root owns compute termination, resource reconciliation, cleanup, custody and two fresh owned-resource censuses.

The fake IO contract is `now`, `runtime`, `dispatch`, `source`, `registry`, `serialization_preflight`, `observe`, `close`, with optional `bind`. `dispatch` operations are fixed: credential, availability, initiate, part, complete, token, put_image, get_image, receipt. `source` returns a bounded stream plus length/version. `registry` returns a bounded stream plus sanitized status/origin/length. RealIO counts at actual SDK sends and explicit credential/registry requests; fake IO is counted by the runner.

## Source and runtime boundary

The deterministic ZIP contains only regular `transport.py`, `input.json`, `buildspec.yml`. Sorted members have fixed timestamps/modes. The input pins the worker; the fixed buildspec embeds the exact input SHA256. The input does not contain its own hash or a future ZIP hash. Root externally pins the full ZIP and every member before creation. ZIP construction rejects duplicates, traversal, links and extraneous members; startup checks the exact expanded three-file tree, file sizes/no-follow regular files, input pin, worker hash and exact buildspec. There is no worker extraction command or arbitrary command input.

The single build command is `exec python3 -I -B transport.py <input SHA256>`. Standard7.0/Python3.12 must already exist. No installation or runtime fallback runs. The project is nonprivileged LINUX_CONTAINER/SMALL, S3 source with exact version, NO_ARTIFACTS, NO_CACHE,5-minute timeout/queue timeout, both log destinations disabled and no VPC configuration or secondary sources. Root must compare actual provider project/start/build facts to the returned fixed configuration before allowing image transfer. The worker additionally binds actual image, build/account/project identifiers and observed runtime facts.

The launcher sets and verifies soft/hard RLIMIT_AS268,435,456 before boto3 import, and installs a300-second alarm. It uses a monotonic elapsed clock joined to the fixed absolute deadline. Newly staged disk is reserved as sourceZIP<=1MiB plus exact expanded source<=4MiB; the worker writes no file. No threads, transfer managers or subprocesses are started. `-B` prevents cache writes. The8MiB disk/264MiB joint envelope is unchanged. Startup/import/serialization MemoryError is a capability negative, with Root retaining a negative if no final could be persisted.

The preinstalled AWS-managed boto3/botocore/dependency runtime is an explicit trust premise, not authenticated possession of provider package bytes. Runtime capture includes Python/executable/platform/architecture, service image, SDK versions/origins, SSL/urllib and a finite installed dependency closure. Missing packages, non3.12, packet/tmp/user-site origins, extra dependency names, unsupported shapes, >32 distributions or >64KiB facts fail before source reads. No patch version or library digest is invented.

## Requests, streams and copies

Only AWS's container relative credential mechanism `http://169.254.170.2/v2/credentials/<id>` is supported. Exactly one eager bounded credential fetch is attempted, with no redirect, proxy, auth token/file or default credential discovery. Credentials must outlive the entire deadline plus60seconds. Explicit in-memory static credentials are passed to boto3; no automatic refresh chain exists. Credential HTTP counts in the two-call credential/discovery allowance. Unsupported mechanisms fail closed. Credential/token bodies, signed locations, Authorization and external exception text never enter receipts or stdout.

Boto3 Config uses total_max_attempts1, one connection, one-second connect/read timeouts, no proxies and S3 path addressing. The endpoint retry decision is disabled. Runtime inspection checks selected botocore JSON blob serialization, signing/request preparation and HTTP methods, including explicit `Retry(False)` and `redirect=False`. Before-send validates exact service HTTPS endpoints and counts every SDK wire dispatch. A raw response wrapper caps control bodies before SDK parsing. No transfer manager is used.

After the initial availability check, initiate each of nine uploads once, retain upload IDs and exact returned integer5..20MiB part sizes, then require computed total<=65. A generated largest-part SDK serialization preflight runs before any input read. Conservatively reserve20B for all image assembly/hash/base64/JSON/signing/HTTP/readback consumers. The selected path estimate is28/3 per byte, with the full20B held regardless. Generated preflight is separately charged at28/3 times the largest selected part. Inspectable source identities and actual serialized length are retained. Unsupported shapes or inability to establish a finite path within the bound stop before image reads. This inspection and fake tests do not prove actual provider memory fit.

Config and the three smallest layers are the first normal operations. Their real short-part acceptance and full readbacks must succeed before the other five blobs. Stream short reads until one exact returned-size part, hash all source bytes, check version/length/EOF/hash, then complete. Nonfinal parts use exactly the returned size; the final remainder is unchanged. Inclusive offsets and integer acknowledgements must match. No padding, full-image buffering or image disk copy occurs.

Readback uses exact fixed ECR blob GETs. ECR auth is sent only to the pinned ECR origin. A single redirect may go only to an exact reviewed regional S3 origin, with a fresh request carrying no Authorization. TLS/hostname verification is enabled, content decoding disabled, size+EOF/hash enforced with<=64KiB reads. Neither Location nor query is retained. All nine config/layer blobs are independently read in full. PutImage and digest-based BatchGetImage must return the exact manifest bytes/digest/media/descriptors. Config ID, compressed hashes, diffIDs, source/replay references and eventual ECS image digest remain distinct joins.

The normal schedule is116 requests, plus<=9 redirect requests,<=2 credential/discovery requests and one guaranteed reconciliation slot: hard128. Smaller parts do not enlarge the extras pool. This worker chooses a negative for ambiguity rather than using reconciliation to retry a mutation. Root has a separate160-control schedule. A fatal path may attempt the single final write if time and calls remain. Failed step persistence stops further image work; no conditional-write retry occurs.

The separate all-reader reservation is8,416,415,151 of8,589,934,592 bytes: local validation1,222,768,843; local upload301,096,124; worker source301,096,124; full readback301,096,124; additional image-copy work6,021,922,480; generated/runtime/source/control work268,435,456. Hold the full20B even when observed work is smaller. Root must retain the unique allocation and disposition without resetting Task1 history. Source/readback counters charge actual stream bytes, including failed reads; EOF probes and unexpected-byte allowance use bounded preflight work. A fixed32MiB conservative reserve covers bounded source/receipt/runtime/control copies; generated preflight and raw responses are charged separately. All stream requests reserve before reading. Failed reservations stop before another read/write/request.

## Receipts and timing

Only `<prefix>steps/0.json` through `steps/8.json` and `<prefix>final.json` may be written, conditionally with IfNoneMatch`*` and SSE-AES256. Each step carries the exact input identity, initiation, offsets/acknowledgements, complete reply, readback EOF/hash/origin and counters. The final binds successful step hashes/sizes, upload obligations, runtime facts, source/replay/allocation joins, manifest/config/diffID joins, bounded redacted semantic SDK originals and outcome. Datetimes use ISO strings; authorization data and unsafe response headers are redacted. Full originals above their128KiB aggregate make the result incomplete; excerpts are not represented as complete originals.

Steps<=48KiB each, final<=256KiB including64KiB negative and64KiB runtime allocation, total transport evidence<=1MiB. No diagnostic file, log destination, artifact ZIP or response body is duplicated into another channel. Stdout is a fixed status token<=256bytes with no evidence authority. Final body counters describe dispatches before its own PUT and explicitly reserve one final exchange. The returned `observed_counters` include the final attempt. A final cannot include its own provider acknowledgement; Root must read and retain the actual exact-key object and terminal status. Missing/late objects remain incomplete.

Work must begin by carrierStart+120. Deadline is min(workerStart+300, carrierDeadline-180); carrierDeadline is carrierStart+600. Before each remaining blob, the plan reserves one second per remaining exchange plus both streamed legs at a4MiB/s planning rate. Those timing premises remain unproved until observed; the shared alarm/deadline stops an overrun. Startup, queue, staging, import, custody and cleanup consume the same carrier envelope. Root must stop/reconcile a queued or provisioning job at120seconds and enforce the closure reserve. There is no automatic restart.

Fresh all-in<=1USD reservation within the authorized20USD total, source custody, allocation, exact provider configuration readback and lifecycle readiness still precede a real launch. Actual SDK shape, credentials, short/config acceptance, TLS/network path, memory/throughput, final custody and cleanup remain open until that one attempt. This code grants no K/A, native, loader, provenance or measurement approval.

## Offline verification

Run `PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v`.

All payloads are generated fixtures; SDK/HTTP/runtime seams are replaced with local fakes. Test logs, frozen fake packet bytes, command records and review subjects are under `supportfixtures`. Do not upload that fixture packet. Root must construct and externally freeze an actual packet from the nine independently verified retained descriptors after review.
