# SDK response guard Task 1 independent review

2026-10-27. **SPEC: FAIL. QUALITY: CHANGES REQUIRED.** One medium-severity cleanup defect remains in the actual source-upload consumer. The preload placement, control limit, model-preserving behavior and SDK pending-response ownership satisfy the scoped design, but the outer source consumer can still replace a primary failure with a secondary close failure. No test was rerun.

## Frozen subjects and evidence

| Subject | SHA256 |
| --- | --- |
| `task-1-brief.md` | `61794211e5bf9c30c09c15ac5ad78bc185da3e4fa6f17cba5134035319af6498` |
| `task-1-report.md` | `8bbe1de5788638a3eb93c3a69bdc5dfb138725f8dbe83b6149b2f12a1b64e424` |
| `task-1-freeze/artifact-manifest.json` | `c29a4d2cd2288d3d8d06d1f607bd0e2e33458b613c35b87699d859ced2e3917f` |
| `task-1-freeze/review-subjects.json` | `3d76cd318ae3737a97993fbeb0172601b98364b0a39c660703e2820a8aa83d9a` |
| `task-1-freeze/task-1-scoped.diff` | `733d0629f495bec55a47273935d00e8d7810fa5e12a79155b9bb504d0791585f` |
| Current `transport.py` | `4e58dacd3b9e4ed7958c6ed2ddb0bc2d73c82ed68693d2189b2c87ef092fda22` |
| New `test_response_guard.py` | `0fc2373c4ad6894014ec820f35dfcb0cc64ff8e95e2eb9290854fbd0636b4c05` |

Verified22 selected manifest subjects and all six current helper subjects against frozen bytes/hashes, with no mismatch. This covered the reviewed current/baseline source, tests and README, report, scoped diff, subject/proof/command records and selected RED/GREEN evidence. No source ZIP was opened. Static AST comparison confirms `serialization_preflight`, `sdk_path_facts` and `dispatch` are unchanged; all62 original test names remain among82 current tests.

The retained `green-full.log` ends `Ran 82 tests in 0.889s` / `OK`; the recorded exit is0. Its SHA256 is `70be2a8fde7ca45fe77b9889c01a4be10291f849a8fec4af6fe1c93073f8d245`. The retained eager-preload RED reports `Negative not raised` against the old wrapper, establishing the intended regression. These are existing generated-fixture results, not executions by this reviewer or actual SDK evidence.

## 1. Medium — actual upload consumer still masks primary failures on close

**Locations:** `/workspace/scratch/retained-image-ecr-transport/transport.py:277` and `:296`, interacting with new `BoundedRaw.close` at`:367–375` and its failure cleanup at`:390–393`.

The real source-upload path in `run_transport` has its own part-reading loop. It does not consume its source through `stream_exact`. Its `finally: body.close()` remains unconditional. When a guarded source read or EOF probe fails and underlying close also raises, `BoundedRaw.read` correctly preserves the primary failure and remembers the failed close. The upload loop then calls close again; the idempotent wrapper re-raises the remembered cleanup exception, replacing the primary failure before `run_transport` records its sanitized outcome.

Concrete trace: a source has its declared bytes plus one extra byte, and raw close raises `OSError`. The EOF probe raises `Negative('response_body_cap')`; wrapper cleanup attempts raw close once and preserves that primary exception. The upload loop's line296 calls close again, re-raising the remembered `OSError`. The final negative therefore records `error='OSError'` instead of `response_body_cap`. A failed part acknowledgement or other primary exception inside that loop is similarly vulnerable when final close fails. The result stays negative, but its actual failure reason is lost, contrary to the accepted primary-preservation contract.

The adjacent source-identity rejection has the same outer-owner issue: if `io.source` returns mismatched length/version metadata with a body whose close fails, line277 replaces `Negative('source_identity')` with the close exception. The normal RealIO source validates metadata earlier, but this existing runner boundary still owns and rejects that returned body and must preserve its own primary failure.

The new tests named for source-consumer overflow and successful close failure invoke `stream_exact`, not `run_transport`'s source-upload loop. Their success proves the changed helper cleanup; it does not cover the remaining owner. This is a direct integration gap for the new close semantics and accepted ownership requirement, not a request to broaden the review into unrelated transport behavior.

**Required correction:** apply the same primary-preserving cleanup rule to those two actual source-owner paths. Suppress a secondary close failure only while a primary source-identity/read/validation/upload failure is propagating. If the source read/upload path otherwise succeeds, a close failure must still fail the attempt. Retain the wrapper's one underlying close attempt, failed-close state and no-retry behavior.

Add minimal generated regressions through `run_transport` using the existing fake transport fixture: (1) source overflow or a distinct primary source-read failure together with failing raw close retains the primary error and one underlying close attempt; (2) mismatched source metadata plus failing close retains `source_identity`; (3) otherwise successful source consumption plus failing close remains a negative and cannot proceed to successful completion. Assert no retry/replacement source dispatch and retain the real unsupported preflight unchanged. Direct `stream_exact` tests alone cannot close this finding. No reproduction was executed during this review; the failure follows directly from the shown exception/finally flow.

## Other scoped requirements

**Preload placement and model behavior: PASS.** The original request flag is saved and restored in finally around exactly one send, with no other request mutation. Empty-cache admission occurs before raw wrapping. The implementation leaves operation models and Endpoint parsing intact; the source-faithful fixture distinguishes request hint from model and verifies cached control conversion. A prepopulated cache remains an explicit drift negative, not a claimed retrospective bound.

**Limit classification/accounting: PASS.** Only exact integer200/GetObject receives a validated nonnegative integer frozen source size. Other replies retain65536. Underlying requests stay<=64KiB with remaining-limit-plus-one probing; attempted control work is charged before reads and retained on failure. The focused evidence covers short reads, exact-cap EOF, malformed limits and error statuses. No limit or exchange accounting was widened.

**Pending SDK ownership and wrapper close behavior: PASS at those boundaries.** The pending slot covers invocation and post-parse validation, is cleared with active operation state, and closes untransferred responses. Successful GetObject handoff requires a source-classified pending wrapper and a returned read/close body; missing or invalid bodies fail. Control close failure propagates on an otherwise successful call. Wrapper cleanup preserves primary errors, distinguishes failed close from confirmed closure and blocks reads after either attempt. Full model/observer closure remains a future gate, so this does not establish arbitrary replacement-body ownership.

**Authorized `source()` and `stream_exact()` changes: PASS locally.** Both preserve a primary error when secondary cleanup fails. `stream_exact` still propagates close failure after otherwise successful reads. The outstanding finding is the separate source-upload owner described above.

## Scope and accounting

This review is limited to the finite body guard and its source ownership integration. Header parsing, aggregate framing/extensions/trailers, alternate raw readers, source/model/checksum/profile closure, observers/audit, Root uploader accounting, <=20B proof and runtime memory fit remain explicit future gates. `unsupported_sdk_path` is unchanged; this report grants no real SDK support, provider trial, spend or production admission.

A separate16MiB logical-read/work and2MiB disk allowance is recorded in `task-1-review-meter.json`. No implementation was changed, no suite or targeted reproduction was executed, no SDK was imported/executed, no provider/network/native/corpus/source-ZIP read occurred, and no subagent was used. A focused fix and re-review of finding1 are required.
