import copy
import hashlib
import io
import json
import unittest

import packet
import transport
from test_packet import fixture

class FakeIO:
    def __init__(self, manifest, blobs):
        self.m=manifest;self.blobs=blobs;self.t=1010.;self.calls=[];self.receipts={};self.parts={};self.fail=None;self.part_size=5*1024*1024;self.runtime_ok=True;self.close_count=0
    def now(self):return self.t
    def runtime(self):
        if not self.runtime_ok:raise transport.Negative('runtime')
        return {'python':'3.12.fake','trust':'aws-managed-runtime','fixture':True}
    def dispatch(self, op, args):
        self.calls.append((op,args))
        if self.fail==op:raise RuntimeError('secret https://signed.example/?X=SECRET')
        if op=='credential':return {'expires':2000}
        if op=='availability':return {'layers':[{'layerDigest':'sha256:'+r['sha256'],'layerAvailability':'AVAILABLE'} for r in self.m['blobs'][1:]],'failures':[]} if args['after'] else {'layers': [], 'failures': [{'layerDigest':'sha256:'+r['sha256'],'failureCode':'MISSING'} for r in self.m['blobs'][1:]]}
        if op=='initiate':return {'uploadId':'u'+str(args['index']), 'partSize': self.part_size}
        if op=='part':
            self.parts.setdefault(args['index'],[]).append((args['first'],args['last'],len(args['body'])))
            return {'lastByteReceived': args['last'], 'uploadId':'u'+str(args['index'])}
        if op=='complete':return {'layerDigest':'sha256:'+self.m['blobs'][args['index']]['sha256']}
        if op=='token':return {'origin': transport.ecr_origin(self.m), 'authorization':'Basic SECRET'}
        if op=='put_image' or op=='get_image':return {'manifest':self.m['manifest_utf8'],'digest':'sha256:'+self.m['manifest_sha256']}
        if op=='receipt':self.receipts[args['key']]=args['body'];return {'stored':True}
        raise AssertionError(op)
    def source(self,row):
        self.calls.append(('source',row));return io.BytesIO(self.blobs[row['index']]), {'length':row['size'],'version':row['version']}
    def registry(self,row,authorization,guard):
        guard('registry');self.calls.append(('registry',row));return io.BytesIO(self.blobs[row['index']]), {'status':200,'origin':'ecr','length':row['size']}
    def serialization_preflight(self,size,charge):charge(size*10,'preflight');return {'size':size,'copy_factor':20,'supported':True}
    def observe(self):return {'rss':1234,'disk':0}
    def close(self):self.close_count+=1

def setup():
    o,m,p,b=fixture();result=packet.prepare_packet(o,m,p);return result['input_manifest'],b

class TransportTests(unittest.TestCase):
    def test_success_and_fixed_receipts(self):
        m,b=setup();f=FakeIO(m,b);r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'complete');self.assertEqual(len(f.receipts),10)
        self.assertEqual(set(f.receipts),{m['prefix']+'steps/%d.json'%i for i in range(9)}|{m['prefix']+'final.json'})
        self.assertEqual([a['index'] for op,a in f.calls if op=='source'],[0,7,5,2,1,3,4,6,8])
        self.assertEqual(f.close_count,1)
    def test_returned_part_sizes_and_inclusive_offsets(self):
        for size in [5*1024*1024,10*1024*1024,20*1024*1024]:
            m,b=setup();f=FakeIO(m,b);f.part_size=size
            self.assertEqual(transport.run_transport(m,f)['outcome'],'complete')
        for size in [5*1024*1024-1,20*1024*1024+1,True,5.0]:
            m,b=setup();f=FakeIO(m,b);f.part_size=size
            with self.subTest(size=size):self.assertEqual(transport.run_transport(m,f)['outcome'],'negative');self.assertFalse(any(op=='source' for op,_ in f.calls))
        self.assertEqual(list(transport.part_ranges(5*1024*1024*2+1,5*1024*1024)),[(0,5242879),(5242880,10485759),(10485760,10485760)])
    def test_tiny_failure_stops_bulk_and_no_retry(self):
        m,b=setup();f=FakeIO(m,b);f.fail='complete';r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'negative');self.assertEqual(sum(op=='complete' for op,_ in f.calls),1)
        self.assertEqual(sum(op=='source' for op,_ in f.calls),1);self.assertNotIn('SECRET',json.dumps(r));self.assertNotIn('signed.example',json.dumps(r))
    def test_truncated_overflow_hash_version(self):
        for mode in ['short','long','hash','version']:
            m,b=setup();f=FakeIO(m,b)
            if mode=='short':f.blobs[0]=f.blobs[0][:-1]
            if mode=='long':f.blobs[0]+=b'x'
            if mode=='hash':f.blobs[0]=b'x'*len(f.blobs[0])
            if mode=='version':m['blobs'][0]['version']='other'
            with self.subTest(mode=mode):
                if mode=='version':
                    original=f.source
                    f.source=lambda row:(original(row)[0],{'length':row['size'],'version':'mismatch'})
                self.assertEqual(transport.run_transport(m,f)['outcome'],'negative')
                self.assertFalse(any(op=='complete' for op,_ in f.calls))
    def test_runtime_and_deadline_before_data(self):
        for mode in ['runtime','late','reserve']:
            m,b=setup();f=FakeIO(m,b)
            if mode=='runtime':f.runtime_ok=False
            if mode=='late':f.t=1121
            if mode=='reserve':f.t=1410
            with self.subTest(mode=mode):self.assertEqual(transport.run_transport(m,f)['outcome'],'negative');self.assertFalse(any(op=='source' for op,_ in f.calls))
    def test_guards(self):
        g=transport.Guards(lambda:0,100)
        for _ in range(128):g.exchange('normal')
        with self.assertRaises(transport.Negative):g.exchange('normal')
        g=transport.Guards(lambda:0,100);g.exchange('credential');g.exchange('credential')
        with self.assertRaises(transport.Negative):g.exchange('credential')
        g.exchange('reconcile')
        with self.assertRaises(transport.Negative):g.exchange('reconcile')
        for category,cap in [('copy',20*transport.B),('source',transport.B),('readback',transport.B),('preflight',transport.META_READ)]:
            g=transport.Guards(lambda:0,100);g.read(cap,category)
            with self.subTest(category=category),self.assertRaises(transport.Negative):g.read(1,category)
        g=transport.Guards(lambda:0,100);g.disk(8*1024*1024)
        with self.assertRaises(transport.Negative):g.disk(1)
    def test_missing_final_stays_incomplete(self):
        m,b=setup();f=FakeIO(m,b);original=f.dispatch
        def dispatch(op,args):
            if op=='receipt' and args['key'].endswith('final.json'):raise OSError('ambiguous')
            return original(op,args)
        f.dispatch=dispatch;r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'incomplete');self.assertFalse(r['final_persisted']);self.assertEqual(len(f.receipts),9)
    def test_bad_manifest_no_dispatch(self):
        m,b=setup();m['blobs'].reverse();f=FakeIO(m,b)
        self.assertEqual(transport.run_transport(m,f)['outcome'],'negative');self.assertFalse(f.calls)
    def test_redirect_validation_and_no_auth_forward(self):
        m,_=setup();allowed=m['redirect_origins'];good=allowed[0]+'/blob?X=SECRET'
        self.assertEqual(transport.safe_redirect(good,allowed),good)
        for url in ['http://'+good[8:],good.replace('.amazonaws.com','.amazonaws.com.evil'),good.replace('https://','https://u@'),good.replace('/blob',':444/blob'),good+'#x','https://evil.example/x']:
            with self.subTest(url=url),self.assertRaises(transport.Negative):transport.safe_redirect(url,allowed)
        req=transport.registry_request(good,None);self.assertIsNone(req.get_header('Authorization'))
    def test_response_and_evidence_bounds(self):
        g=transport.Guards(lambda:0,100)
        with self.assertRaises(transport.Negative):g.response({'x':'x'*65536})
        with self.assertRaises(transport.Negative):g.evidence(b'x'*(48*1024+1),'step')
        g.evidence(b'x'*(256*1024),'final')
        with self.assertRaises(transport.Negative):g.evidence(b'x','final')

if __name__=='__main__':unittest.main()

class AdditionalTransportTests(unittest.TestCase):
    def test_ambiguous_upload_is_never_retried(self):
        m,b=setup();f=FakeIO(m,b);f.fail='part';r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'negative');self.assertEqual(sum(op=='part' for op,_ in f.calls),1)
        self.assertEqual(len(r['uploads']),9);self.assertEqual(len(f.receipts),1)
    def test_ambiguous_put_image_no_repeat(self):
        m,b=setup();f=FakeIO(m,b);f.fail='put_image';r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'negative');self.assertEqual(sum(op=='put_image' for op,_ in f.calls),1)
        self.assertEqual(len(r['steps']),9)
    def test_failed_step_persistence_stops(self):
        m,b=setup();f=FakeIO(m,b);f.fail='receipt';r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'incomplete');self.assertEqual(sum(op=='source' for op,_ in f.calls),1)
        self.assertEqual(sum(op=='receipt' for op,_ in f.calls),2)
    def test_late_final_is_incomplete(self):
        m,b=setup();f=FakeIO(m,b);original=f.dispatch
        def dispatch(op,args):
            r=original(op,args)
            if op=='receipt' and args['key'].endswith('final.json'):f.t=2000
            return r
        f.dispatch=dispatch;r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'incomplete');self.assertFalse(r['final_persisted'])
    def test_late_step_cannot_begin_next_source(self):
        m,b=setup();f=FakeIO(m,b);original=f.dispatch
        def dispatch(op,args):
            r=original(op,args)
            if op=='receipt':f.t=2000
            return r
        f.dispatch=dispatch;r=transport.run_transport(m,f)
        self.assertEqual(r['outcome'],'incomplete');self.assertEqual(sum(op=='source' for op,_ in f.calls),1)
    def test_memory_error_is_sanitized_fit_negative(self):
        m,b=setup();f=FakeIO(m,b)
        def fail(*args):raise MemoryError('SECRET')
        f.serialization_preflight=fail;r=transport.run_transport(m,f)
        self.assertEqual(r['error'],'MemoryError');self.assertFalse(any(op=='source' for op,_ in f.calls))
        self.assertNotIn('SECRET',json.dumps(r))
    def test_bad_ack_and_complete_digest(self):
        for target in ['part','complete']:
            m,b=setup();f=FakeIO(m,b);original=f.dispatch
            def dispatch(op,args):
                r=original(op,args)
                if op==target:r['lastByteReceived' if target=='part' else 'layerDigest']=-1
                return r
            f.dispatch=dispatch
            with self.subTest(target=target):self.assertEqual(transport.run_transport(m,f)['outcome'],'negative')
    def test_unexpected_existing_and_incomplete_availability(self):
        m,b=setup()
        for response in [{'layers':[{'layerDigest':'sha256:'+m['blobs'][1]['sha256'],'layerAvailability':'AVAILABLE'}],'failures':[]},{'layers':[],'failures':[]}]:
            f=FakeIO(m,b);original=f.dispatch
            f.dispatch=lambda op,args:response if op=='availability' else original(op,args)
            self.assertEqual(transport.run_transport(m,f)['outcome'],'negative');self.assertFalse(any(op=='initiate' for op,_ in f.calls))
    def test_readback_length_hash_and_eof(self):
        for mode in ['length','short','long','hash']:
            m,b=setup();f=FakeIO(m,b)
            def registry(row,auth,guard):
                guard('normal');data=b[row['index']]
                if mode=='short':data=data[:-1]
                if mode=='long':data+=b'x'
                if mode=='hash':data=b'x'*len(data)
                return io.BytesIO(data),{'status':200,'origin':'ecr','length':row['size']+1 if mode=='length' else None}
            f.registry=registry
            with self.subTest(mode=mode):self.assertEqual(transport.run_transport(m,f)['outcome'],'negative')
    def test_short_source_and_readback_reads(self):
        class Short(io.BytesIO):
            def read(self,n=-1):return super().read(min(n,7))
        m,b=setup();f=FakeIO(m,b)
        f.source=lambda row:(Short(b[row['index']]),{'length':row['size'],'version':row['version']})
        def registry(row,auth,guard):guard('normal');return Short(b[row['index']]),{'status':200,'origin':'ecr','length':row['size']}
        f.registry=registry;self.assertEqual(transport.run_transport(m,f)['outcome'],'complete')
    def test_copy_projection_fails_before_source(self):
        m,b=setup();f=FakeIO(m,b);f.serialization_preflight=lambda n,c:{'copy_factor':21,'supported':True}
        r=transport.run_transport(m,f);self.assertEqual(r['error'],'serialization_bound');self.assertFalse(any(op=='source' for op,_ in f.calls))
    def test_actual_part_counts_and_one_over(self):
        self.assertEqual(sum(len(list(transport.part_ranges(n,transport.MIN_PART))) for n in transport.ACTUAL_SIZES),65)
        self.assertEqual(sum(len(list(transport.part_ranges(n,transport.MAX_PART))) for n in transport.ACTUAL_SIZES),21)
        m,b=setup();m['blobs'][1]['size']=transport.MIN_PART*65
        # Invalid joined source metadata is rejected before dispatch.
        f=FakeIO(m,b);self.assertEqual(transport.run_transport(m,f)['outcome'],'negative');self.assertFalse(f.calls)
    def test_deadline_and_disk_before_io(self):
        g=transport.Guards(lambda:100,100)
        with self.assertRaises(transport.Negative):g.exchange()
        with self.assertRaises(transport.Negative):g.read(1,'copy')
        m,b=setup();f=FakeIO(m,b)
        def bind(g):g.disk(transport.DISK+1)
        f.bind=bind;r=transport.run_transport(m,f);self.assertEqual(r['error'],'disk_cap');self.assertFalse(any(op=='source' for op,_ in f.calls))
    def test_oversized_runtime_and_control(self):
        m,b=setup();f=FakeIO(m,b);f.runtime=lambda:{'bad':'x'*65536}
        self.assertEqual(transport.run_transport(m,f)['outcome'],'negative')
        m,b=setup();f=FakeIO(m,b);original=f.dispatch
        f.dispatch=lambda op,a:{'bad':'x'*65536} if op=='initiate' else original(op,a)
        self.assertEqual(transport.run_transport(m,f)['error'],'response_cap')
    def test_no_secret_exception_text_for_all_fatal_operations(self):
        for target in ['credential','availability','initiate','token','part','complete','put_image','get_image']:
            m,b=setup();f=FakeIO(m,b);f.fail=target;r=transport.run_transport(m,f)
            with self.subTest(target=target):self.assertNotIn('SECRET',json.dumps(r));self.assertNotIn('signed.example',json.dumps(r))
    def test_fixed_manifest_readback_mismatch(self):
        m,b=setup();f=FakeIO(m,b);original=f.dispatch
        def dispatch(op,a):
            r=original(op,a)
            if op=='get_image':r['manifest']+=' '
            return r
        f.dispatch=dispatch;self.assertEqual(transport.run_transport(m,f)['error'],'image_readback')
    def test_invalid_partsize_keeps_upload_obligation(self):
        m,b=setup();f=FakeIO(m,b);f.part_size=transport.MAX_PART+1
        self.assertEqual(len(transport.run_transport(m,f)['uploads']),1)
    def test_stream_control_bounds_before_parser(self):
        g=transport.Guards(lambda:0,100);raw=transport.BoundedRaw(io.BytesIO(b'x'*65537),65536,g)
        self.assertEqual(len(raw.read(65536)),65536)
        with self.assertRaises(transport.Negative):raw.read(1)
        class Raw(io.BytesIO):
            def read(self,n,**kwargs):return super().read(n)
        raw=transport.BoundedRaw(Raw(b'abc'),3,g)
        self.assertEqual(b''.join(raw.stream()),b'abc')
        with self.assertRaises(transport.Negative):list(raw.stream(decode_content=True))

class ProviderBoundaryTests(unittest.TestCase):
    def provider(self):
        m,b=setup();provider=transport.RealIO(m);provider.bind(transport.Guards(lambda:1010,1310));return provider
    def test_safe_single_redirect_no_auth_forward_or_url_retention(self):
        from unittest.mock import Mock
        p=self.provider();m=p.m;url=m['redirect_origins'][0]+'/blob?X=SECRET'
        class Reply(io.BytesIO):
            def __init__(self,status,headers,data=b''):super().__init__(data);self.status=status;self.headers=headers
        replies=[Reply(307,{'Location':url}),Reply(200,{'Content-Length':str(m['blobs'][0]['size'])},b'ok')]
        requests=[]
        def op(req,timeout):requests.append(req);return replies.pop(0)
        p.opener=Mock();p.opener.open=op
        body,meta=p.registry(m['blobs'][0],'Basic SECRET',p.g.exchange)
        self.assertEqual(requests[0].get_header('Authorization'),'Basic SECRET');self.assertIsNone(requests[1].get_header('Authorization'))
        self.assertEqual(p.g.calls,2);self.assertEqual(p.g.redirect,1);self.assertNotIn('SECRET',json.dumps(meta));body.close()
    def test_bad_destination_and_second_redirect_never_followed(self):
        from unittest.mock import Mock
        for destination in ['https://evil.example/?X=SECRET',self.provider().m['redirect_origins'][0]+'/blob?X=SECRET']:
            p=self.provider();requests=[]
            class Reply(io.BytesIO):
                status=307
                headers={'Location':destination}
            def op(req,timeout):requests.append(req);return Reply()
            p.opener=Mock();p.opener.open=op
            with self.assertRaises(transport.Negative):p.registry(p.m['blobs'][0],'Basic SECRET',p.g.exchange)
            self.assertEqual(len(requests),1 if 'evil.example' in destination else 2)
    def test_registry_identity_and_content_encoding(self):
        from unittest.mock import Mock
        p=self.provider();reply=Mock();reply.status=200;reply.headers={'Content-Encoding':'gzip'}
        p.opener=Mock();p.opener.open.return_value=reply
        with self.assertRaises(transport.Negative):p.registry(p.m['blobs'][0],'Basic SECRET',p.g.exchange)
        self.assertEqual(reply.close.call_count,1)
    def test_sdk_endpoint_and_wire_counter(self):
        from types import SimpleNamespace
        p=self.provider()
        with self.assertRaises(transport.Negative):p.before_send(SimpleNamespace(url='https://evil.example/'))
        self.assertEqual(p.g.calls,0)
        p.before_send(SimpleNamespace(url='https://api.ecr.us-east-1.amazonaws.com/'))
        self.assertEqual(p.g.calls,1)
        p.g.calls=128
        with self.assertRaises(transport.Negative):p.before_send(SimpleNamespace(url='https://s3.us-east-1.amazonaws.com/'))
    def test_credential_mechanism_fails_before_http(self):
        from unittest.mock import patch,Mock
        p=self.provider();p.opener=Mock()
        with patch.dict(transport.os.environ,{'AWS_CONTAINER_CREDENTIALS_RELATIVE_URI':'','AWS_CONTAINER_CREDENTIALS_FULL_URI':'http://evil.example'},clear=True):
            with self.assertRaises(transport.Negative):p.fetch_credentials()
        p.opener.open.assert_not_called()
    def test_expired_credentials_counted_no_sdk_import_or_refresh(self):
        from unittest.mock import patch,Mock
        p=self.provider()
        body=json.dumps({'AccessKeyId':'FAKEKEY','SecretAccessKey':'FAKESECRET','Token':'FAKETOKEN','Expiration':'1970-01-01T00:00:00Z'}).encode()
        class Reply(io.BytesIO):status=200
        p.opener=Mock();p.opener.open.return_value=Reply(body)
        with patch.dict(transport.os.environ,{'AWS_CONTAINER_CREDENTIALS_RELATIVE_URI':'/v2/credentials/fixture-01234567'},clear=True):
            with self.assertRaises(transport.Negative):p.fetch_credentials()
        self.assertEqual(p.g.credential,1);self.assertEqual(p.opener.open.call_count,1)
    def test_sdk_fixed_credentials_retries_and_redirects_disabled(self):
        from unittest.mock import patch,Mock
        from types import SimpleNamespace,ModuleType
        p=self.provider();body=json.dumps({'AccessKeyId':'FAKEKEY','SecretAccessKey':'FAKESECRET','Token':'FAKETOKEN','Expiration':'2099-01-01T00:00:00Z'}).encode()
        class Reply(io.BytesIO):status=200
        p.opener=Mock();p.opener.open.return_value=Reply(body)
        created=[]
        def client(service,endpoint_url,config):
            obj=SimpleNamespace(meta=SimpleNamespace(config=config,events=Mock()),_endpoint=SimpleNamespace(http_session=SimpleNamespace(send=Mock())))
            created.append((service,endpoint_url,config,obj));return obj
        session=Mock();session.client=client
        fake_boto=ModuleType('boto3');fake_boto.session=SimpleNamespace(Session=Mock(return_value=session))
        fake_config=ModuleType('botocore.config')
        class Config:
            def __init__(self,**kwargs):self.__dict__.update(kwargs)
        fake_config.Config=Config
        with patch.dict('sys.modules',{'boto3':fake_boto,'botocore.config':fake_config}),patch.dict(transport.os.environ,{'AWS_CONTAINER_CREDENTIALS_RELATIVE_URI':'/v2/credentials/fixture-01234567'},clear=True):p.fetch_credentials()
        self.assertEqual(fake_boto.session.Session.call_args.kwargs['aws_secret_access_key'],'FAKESECRET')
        for service,endpoint,c,obj in created:
            self.assertEqual(c.retries['total_max_attempts'],1);self.assertEqual(c.proxies,{})
            self.assertFalse(obj._endpoint._needs_retry());self.assertEqual(c.s3,{'addressing_style':'path'})
            self.assertEqual(obj.meta.events.register.call_args.args[0],'before-send.*.*')
        self.assertEqual(p.g.credential,1)
    def test_runtime_version_negative_before_sdk_data(self):
        from unittest.mock import patch
        from types import ModuleType
        p=self.provider()
        with patch.dict('sys.modules',{'boto3':ModuleType('boto3'),'botocore':ModuleType('botocore')}),patch.object(transport.sys,'version_info',(3,11,0)):
            with self.assertRaises(transport.Negative):p.runtime()
        self.assertEqual(p.g.calls,0)
    def test_no_general_http_redirect_handler(self):
        self.assertIsNone(transport.NoRedirect().redirect_request(None,None,307,'',{},'https://evil.example/'))

class LargeFixtureTests(unittest.TestCase):
    def test_exact_nonfinal_and_final_5_and_20_mib(self):
        for size in [transport.MIN_PART,transport.MAX_PART]:
            owned,metadata,pins,blobs=fixture();blobs[1]=b'generated-fixture'*(size//17+1);blobs[1]=blobs[1][:size]+b'Z'
            metadata['blobs'][1]['size']=len(blobs[1]);metadata['blobs'][1]['sha256']=hashlib.sha256(blobs[1]).hexdigest()
            m=packet.prepare_packet(owned,metadata,pins)['input_manifest'];f=FakeIO(m,blobs);f.part_size=size
            with self.subTest(size=size):
                self.assertEqual(transport.run_transport(m,f)['outcome'],'complete')
                self.assertEqual(f.parts[1],[(0,size-1,size),(size,size,1)])

class RuntimeFactsTests(unittest.TestCase):
    def test_provider_runtime_facts_and_rejections(self):
        from unittest.mock import patch
        from types import ModuleType,SimpleNamespace
        import importlib.metadata
        import resource
        m,_=setup();p=transport.RealIO(m);p.bind(transport.Guards(lambda:1010,1310))
        boto=ModuleType('boto3');boto.__version__='managed';boto.__file__='/usr/local/lib/python3.12/site-packages/boto3/__init__.py'
        core=ModuleType('botocore');core.__version__='managed';core.__file__='/usr/local/lib/python3.12/site-packages/botocore/__init__.py'
        env={'CODEBUILD_BUILD_IMAGE':'aws/codebuild/standard:7.0','CODEBUILD_BUILD_ID':m['project_name']+':fixture','CODEBUILD_BUILD_ARN':'arn:aws:codebuild:us-east-1:079358094174:build/'+m['project_name']+':fixture'}
        class Dist:
            version='managed'
            requires=[]
            def locate_file(self,path):return '/usr/local/lib/python3.12/site-packages/'+path
        with patch.dict('sys.modules',{'boto3':boto,'botocore':core}),patch.dict(transport.os.environ,env,clear=True),patch.object(importlib.metadata,'distribution',return_value=Dist()),patch.object(resource,'getrlimit',return_value=(transport.MEMORY,transport.MEMORY)):
            facts=p.runtime();self.assertLessEqual(len(transport.canonical(facts)),65536);self.assertEqual(len(facts['distributions']),6)
            for mode in ['writable','dependency','metadata','image','memory']:
                with self.subTest(mode=mode):
                    previous_file=boto.__file__;previous_requirements=Dist.requires;previous_version=Dist.version
                    try:
                        if mode=='writable':boto.__file__='/tmp/boto3/__init__.py'
                        if mode=='dependency':Dist.requires=['unexpected-package>=1']
                        if mode=='metadata':Dist.version='x'*65536
                        if mode=='image':transport.os.environ['CODEBUILD_BUILD_IMAGE']='unapproved'
                        with patch.object(resource,'getrlimit',return_value=(transport.MEMORY-1,transport.MEMORY-1) if mode=='memory' else (transport.MEMORY,transport.MEMORY)):
                            with self.assertRaises(transport.Negative):p.runtime()
                    finally:boto.__file__=previous_file;Dist.requires=previous_requirements;Dist.version=previous_version;transport.os.environ.update(env)
    def test_hard_limits_and_alarm_precede_runtime(self):
        from unittest.mock import patch,Mock
        from types import ModuleType
        m,b=setup();f=FakeIO(m,b);events=[]
        resource=ModuleType('resource');resource.RLIMIT_AS=9;resource.setrlimit=lambda *a:events.append(('limit',a));resource.getrlimit=lambda *a:(transport.MEMORY,transport.MEMORY)
        original=f.runtime
        f.runtime=lambda:(events.append(('runtime',None)) or original())
        stdout=io.StringIO()
        with patch.dict('sys.modules',{'resource':resource}),patch.object(transport.sys,'argv',['transport.py','a'*64]),patch.object(transport,'read_source_tree',return_value=(m,100)),patch.object(transport,'RealIO',return_value=f),patch.object(transport.time,'time',return_value=1010),patch.object(transport.signal,'signal'),patch.object(transport.signal,'setitimer',side_effect=lambda *a:events.append(('alarm',a))),patch.object(transport.sys,'stdout',stdout),patch('logging.disable'):
            self.assertEqual(transport.main(),0)
        self.assertEqual(events[0][0],'limit');self.assertLess(next(i for i,e in enumerate(events) if e[0]=='alarm'),next(i for i,e in enumerate(events) if e[0]=='runtime'))
        self.assertLessEqual(len(stdout.getvalue().encode()),256)
