# SDK response guard task 1 report

Implemented the accepted private body-guard design. The full private helper suite passed all 82 tests, exit 0. The real SDK path remains rejected by `unsupported_sdk_path`; fixture success grants no runtime/provider acceptance. Independent SPEC/QUALITY review is still required.

Root base is `da90d39b8752633e8b005791df0b2dc39ccd5f45`. Accepted design SHA256 is `89d5d3a5fc76cb97d29c54f2ff2c42e144c2941efb0d9f95c099de6b0d0c7d25`; accepted design review SHA256 is `a3af2d88a7fda46ffc7cc4166e9b0b40ed720432596b58e728c3c65ed829fa2c`.

## Changes

`RealIO.bounded_sdk_send` temporarily sets the existing prepared request's `stream_output` to True around exactly one original send and restores the original value in finally. It requires the returned response cache to exist and remain None, validates the existing headers and exact source/control classification, then installs `BoundedRaw` before returning to model-driven Endpoint conversion. Admission failures close raw without draining and preserve the primary exception. A populated cache is rejected as profile drift; this cannot reverse an unexpected sender preload.

`BoundedRaw` retains the 64 KiB maximum request and remaining-cap-plus-one rule. Attempted control reads and EOF probes remain charged before consumption, including short reads, exceptions and overflow. Failure cleanup closes without draining. Close attempts are idempotent, failed close state remains distinct from confirmed closure, subsequent reads cannot touch raw, and repeated failed closes re-raise the remembered cleanup failure. Cleanup does not check the work deadline.

One private pending-raw slot spans SDK invocation, parsing and existing SDK response validation. Every finalization clears the slot and active operation state. Valid successful GetObject bodies receive ownership and stay open across return and the next independent SDK call. Missing or invalid bodies cannot transfer ownership. Controls close on successful return; cleanup failure on an otherwise successful path propagates. Parser and post-parse failures retain their primary errors even if close fails.

Two narrow existing consumer cleanup paths also needed primary-error preservation. `source()` metadata rejection now suppresses only its secondary close failure. `stream_exact()` preserves an existing read/validation failure if final close also fails, while close failure after successful reads still fails the call. Root explicitly confirmed these changes are within the accepted ownership contract. Both have direct generated regressions.

Only helper `transport.py`, `test_transport.py`, new `test_response_guard.py` and `README.md` changed. `packet.py`, packet tests, prior fixture packets and support artifacts remain byte-for-byte unchanged. Three related existing test methods received fixture compatibility adjustments: prepared-request hints and empty response caches are now present, and the independent budget-failure check uses a fresh wrapper after the preceding read failure closes its wrapper. All 62 original test subjects remain present. No transport acceptance, header/framing, observer/audit, serialization model, schema, signature, retry, exchange/part limit or resource-limit change was made.

## Baseline and freeze

Before any helper edit, all 71 existing helper files were copied into `task-1-freeze/baseline-62`. Every subject in the reviewed `supportfixtures/round1-review-subjects.json` matched its recorded hash. `baseline-proof.json` records every old path, byte count and SHA256. Its transport baseline is `b4cf9e720ca27ff2d8a9a88ccf3911a2d38be6e349c92c3999a4b50134e71bba`.

`task-1-freeze/current` contains exact current source, tests and README bytes, including unchanged packet subjects. Existing generated fixtures are preserved under `baseline-62/supportfixtures`; new in-memory fixture definitions are in `current/test_response_guard.py`. No old fake packet was regenerated or approved. `review-subjects.json` pins current subjects, and `task-1-scoped.diff` contains the full baseline-to-current diff for all four changed/added helper files. `self-review-proof.json` records all original/new test names, changed files/methods and unchanged preflight/diagnostic/dispatch code. `artifact-manifest.json` freezes the report and evidence artifacts without a self-hash cycle.

| Current subject | Bytes | SHA256 |
| --- | ---: | --- |
| `README.md` | 17002 | `f8b7a27cdbe1025b38398caa63f2b97ca1c541f2c34f7aa392c073ab0ae86a9b` |
| `packet.py` | 6198 | `935710100ddde70e2b87939b58b1fa1bc72332fcfe8cae018de18d42d7119ef2` |
| `test_packet.py` | 9131 | `4bf5cf19185e673b6821dcc441eccd5e757f5165adcd15f5b36ecf900972dc46` |
| `test_response_guard.py` | 18242 | `0fc2373c4ad6894014ec820f35dfcb0cc64ff8e95e2eb9290854fbd0636b4c05` |
| `test_transport.py` | 33362 | `9d4c4298724cec736901374d663583e99cb6749363f182c1cae9cf1b4949aa97` |
| `transport.py` | 48915 | `4e58dacd3b9e4ed7958c6ed2ddb0bc2d73c82ed68693d2189b2c87ef092fda22` |

## Verification

The fixtures follow the pinned preload/content/model contract from the accepted design and import no actual SDK. The regression invokes the real helper wrapper and SDK ownership code. Its fake sender eagerly joins raw content on a false hint, while Endpoint-style conversion follows status and the operation model and uses the existing content cache. Request body, headers, context, checksum metadata and model identity are checked unchanged.

The exact requested full command ran once after focused tests were green:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v
```

It ran 82 tests in 0.889 seconds, returned exit 0 and reported OK. `green-full.log` retains its complete combined stdout/stderr. The existing `test_packet.AdditionalPacketTests.test_source_zip_rejects_duplicate_traversal_link_extra` intentionally emits a duplicate `input.json` ZIP warning; it passed. No warning was hidden. No unrelated suite ran.

The 20 new tests cover initial false/true preload hints and send failure restoration; one send/exchange; control lengths 0/65535/65536/65537; unknown/misleading Content-Length; short reads and charged EOF probes; cache reuse and model-based streaming; exact integer 200 versus redirects/errors/partial/float/bool status classification; malformed source limits; absent/prepopulated caches; successful 0/70000-byte source handoff; source overflow and consumer closure; source metadata rejection; missing/invalid returned bodies; parser and status/identity/semantic/originals post-validation failures; subsequent independent calls; read exceptions/bad type/oversize returned chunks; expired deadline/budget/read-argument/decoding rejection; and confirmed/failed idempotent close state. Existing unsupported-preflight and no-retry regressions also passed in the full suite.

All commands, environment overrides, full output paths and exit codes are retained in `commands.json`:

- `red-eager-preload.log`: genuine old-code RED, one failure, exit 1. A 65537-byte control body was eagerly cached by the fake sender, so old code raised no cap exception. This demonstrates the defect before production edits.
- `red-matrix.log`: old-code matrix, 18 tests, 42 subtest failures and one error, exit 1. Missing cleanup, ownership, cache admission and deferred preload behavior were exposed.
- `green-focused-attempt1.log`: 18 tests, one error, exit 1. A fixture split a full 64 KiB body into 7-byte short reads and correctly exhausted the unchanged attempted-read budget. The fixture now uses 1 KiB short reads at that cap plus a separate small 7-byte case. Production limits were not weakened.
- `red-consumer-cleanup.log`: the new source-consumer cleanup regression exposed close masking the primary overflow error, exit 1. The successful-read close-failure companion already passed.
- `green-focused-attempt2.log`: 20 tests, two failures, exit 1. The handoff regression added a second independent control call, so its previous absolute preflight counter expectation needed to include that call. It now checks the consumer's one-byte EOF charge relative to the prior counter.
- `green-focused.log`: 20 tests, exit 0, OK.
- `green-full.log`: all 82 tests, exit 0, OK.

Self-review found no remaining defect in the requested scope. Static comparison confirms `serialization_preflight`, `sdk_path_facts`, and `dispatch` ASTs are unchanged; original tests are still 62 and no old helper file outside the three declared edits changed. A tracked-app diff check was empty. No provider/network action, actual SDK source read/import/execution, corpus/native content read, provider trial, commit, subagent or tracked-app edit was performed by this worker. Local Python test subprocesses only ran the requested generated private helper tests. An early overbroad file-name search enumerated paths elsewhere under `/workspace`; no corpus/native file content was opened, and later reads stayed scoped.

## Remaining gates

This task fixes the demonstrated timing of the raw body guard under the cited contract. Actual SDK/runtime compatibility remains unestablished. Header parsing happens upstream; aggregate framing/extensions/trailers, forwarded alternate raw readers, model/checksum/profile closure, event/history/audit observers, Root uploader accounting, <=20B proof and managed-runtime memory fit remain unresolved. The 128 exchanges, no retries, part limits, 256 MiB AS, disk/time/evidence limits and image identity remain unchanged. Independent implementation SPEC/QUALITY review must precede acceptance. No provider trial is authorized or attempted here.
