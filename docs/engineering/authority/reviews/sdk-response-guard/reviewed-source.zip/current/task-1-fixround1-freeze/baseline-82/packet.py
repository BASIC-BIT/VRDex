"""Private, offline source packet construction. Never opens image-body files."""
import hashlib
import io
import json
import re
import stat
import zipfile

import transport

SOURCE = transport.SOURCE
SAVE = transport.SAVE
canonical = transport.canonical


def prepare_packet(owned_inputs, blob_metadata, support_pins):
    """Return frozen bytes, hashes, exact project/start requests, and finite budgets.

    support_pins is exactly {'transport.py': approved_worker_bytes}. Blob metadata
    is supplied by Root's descriptor/scanner and externally validated replay.
    Fixture packets cannot run through the real entrypoint.
    """
    o, m = owned_inputs, blob_metadata
    transport.require(set(o) == {'account','region','repository','nonce','bucket','prefix','versions','code_version','role_arn','project_name','carrier_start','redirect_origins','allocation_id','allocation_receipt_sha256'}, 'owned_schema')
    transport.require(set(m) == {'fixture','source_revision','config_utf8','blobs','replay'}, 'metadata_schema')
    transport.require(set(support_pins) == {'transport.py'}, 'source_members')
    worker = support_pins['transport.py']
    transport.require(isinstance(worker, bytes) and 0 < len(worker) <= 4*1024*1024, 'source_size')
    transport.require(m['source_revision'] == SOURCE, 'source_revision')
    transport.require(isinstance(o['versions'], list) and len(o['versions']) == 9, 'versions')
    transport.require(isinstance(m['blobs'], list) and len(m['blobs']) == 9, 'blobs')
    rows = []
    for i, r in enumerate(m['blobs']):
        transport.require(set(r) == {'sha256','size','diff_id','retained_name'}, 'blob_schema')
        rows.append({**r, 'index':i, 'key': o['prefix']+'inputs/%d'%i, 'version':o['versions'][i]})
    manifest = {'schemaVersion':2,'mediaType':transport.MANIFEST_MEDIA,
                'config':{'mediaType':transport.CONFIG_MEDIA,'size':rows[0]['size'],'digest':'sha256:'+rows[0]['sha256']},
                'layers':[{'mediaType':transport.LAYER_MEDIA,'size':r['size'],'digest':'sha256:'+r['sha256']} for r in rows[1:]]}
    image = canonical(manifest).decode()
    inputs = {'schema':1, 'fixture':m['fixture'], 'source_revision':SOURCE,
              **{k:o[k] for k in ['account','region','repository','nonce','bucket','prefix','redirect_origins','carrier_start']},
              'carrier_deadline':o['carrier_start']+600, 'work_start_cutoff':o['carrier_start']+120,
              'blobs':rows,'config_utf8':m['config_utf8'],'manifest_utf8':image,
              'manifest_sha256':hashlib.sha256(image.encode()).hexdigest(),
              'replay':m['replay'], 'worker_sha256':hashlib.sha256(worker).hexdigest(),
              'project_name':o['project_name'], 'role_arn':o['role_arn'],
              'allocation':{'id':o['allocation_id'],'receipt_sha256':o['allocation_receipt_sha256'],'reserved':8416415151,'ceiling':8589934592}}
    transport.validate_manifest(inputs)
    transport.require(isinstance(o['code_version'],str) and 0<len(o['code_version'])<=256 and o['code_version']!='null', 'code_version')
    encoded = canonical(inputs)
    transport.require(len(encoded)<=65536, 'input_size')
    input_sha = hashlib.sha256(encoded).hexdigest()
    buildspec = transport.buildspec(input_sha)
    members = {'transport.py':worker,'input.json':encoded,'buildspec.yml':buildspec}
    transport.require(sum(map(len,members.values()))<=4*1024*1024, 'expanded_size')
    output=io.BytesIO()
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in sorted(members):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0))
            info.external_attr=(stat.S_IFREG|0o400)<<16
            info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,members[name],compresslevel=9)
    source=output.getvalue()
    transport.require(len(source)<=1024*1024, 'zip_size')
    inspect_zip(source, members)
    source_key=o['prefix']+'source.zip'
    project={'name':o['project_name'],'source':{'type':'S3','location':o['bucket']+'/'+source_key,'buildspec':'buildspec.yml'},
             'sourceVersion':o['code_version'], 'artifacts':{'type':'NO_ARTIFACTS'},'cache':{'type':'NO_CACHE'},
             'environment':{'type':'LINUX_CONTAINER','computeType':'BUILD_GENERAL1_SMALL','image':'aws/codebuild/standard:7.0','privilegedMode':False,'environmentVariables':[]},
             'serviceRole':o['role_arn'],'timeoutInMinutes':5,'queuedTimeoutInMinutes':5,
             'logsConfig':{'cloudWatchLogs':{'status':'DISABLED'},'s3Logs':{'status':'DISABLED'}}}
    start={'projectName':o['project_name'],'sourceVersion':o['code_version'],'idempotencyToken':o['nonce']}
    return {'source_zip':source,'source_sha256':hashlib.sha256(source).hexdigest(),'source_size':len(source),
            'input_manifest':inputs,'input_bytes':encoded,'input_sha256':input_sha,'buildspec':buildspec,
            'members':{k:{'size':len(v),'sha256':hashlib.sha256(v).hexdigest()} for k,v in members.items()},
            'project':project,'start':start,'predicted':{'blob_gets':[{'Bucket':o['bucket'],'Key':r['key'],'VersionId':r['version']} for r in rows],
            'receipt_keys':[o['prefix']+'steps/%d.json'%i for i in range(9)]+[o['prefix']+'final.json'],
            'registry_urls':[transport.blob_url(inputs,r) for r in rows]},'budgets':transport.budgets()}


def inspect_zip(data, expected):
    transport.require(len(data)<=1024*1024, 'zip_size')
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        infos=z.infolist()
        transport.require(len(infos)==3 and len({x.filename for x in infos})==3, 'zip_duplicates')
        transport.require({x.filename for x in infos}==set(expected), 'zip_members')
        transport.require(sum(x.file_size for x in infos)<=4*1024*1024, 'expanded_size')
        for info in infos:
            transport.require(stat.S_ISREG(info.external_attr>>16) and not info.flag_bits & 1, 'zip_type')
            transport.require(info.filename in {'transport.py','input.json','buildspec.yml'}, 'zip_path')
            with z.open(info) as f:
                content=f.read(info.file_size+1)
            transport.require(content==expected[info.filename], 'zip_hash')
