"""Single-attempt private transport. Standard library until guarded SDK startup.

No image execution, decompression, installation, subprocess, thread or image file.
The real entrypoint is intentionally separate from fake-only run_transport tests.
"""
import base64
import hashlib
import io
import json
import math
import os
from pathlib import Path
import re
import signal
import ssl
import stat
import sys
import time
from urllib.parse import urlsplit
import urllib.request

SOURCE='db9abbcd59a30d206d85c0dcb2f407150e31dd9e'
CONFIG='9ff28822297fe7989bd62e1244edfcb16c72928fb84b0a74a92834eeb4eee0d4'
SAVE='2db9272432b1c51cee85bde91c0a8e1a580d8d1a9fd7e8f07fc27c581c19ec9f'
MANIFEST_MEDIA='application/vnd.docker.distribution.manifest.v2+json'
CONFIG_MEDIA='application/vnd.docker.container.image.v1+json'
LAYER_MEDIA='application/vnd.docker.image.rootfs.diff.tar.gzip'
MIN_PART=5242880
MAX_PART=20971520
B=301096124
META_READ=268435456
COPY_FACTOR=20
MEMORY=268435456
DISK=8388608
EVIDENCE=1048576
ACTUAL_SIZES=[8177,28279138,3199,48231547,1689787,418,204718126,112,18165620]
ACTUAL_NAMES=['config.json','layer-0003.gz','layer-0001.gz','layer-0006.gz','layer-0005.gz','layer-0004.gz','layer-0002.gz','layer-0007.gz','layer-0000.gz']
HEX=re.compile(r'^[0-9a-f]{64}$')

class Negative(ValueError):
    """An intentionally short, nonsecret failure code."""

def require(ok,code):
    if not ok:raise Negative(code)

def canonical(obj):return json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False).encode()

def logical_work_model(size):
    """Itemized candidate model for generated IO, NOT an audited SDK profile.

    Units are thirds of one input byte. Source and readback stream reads have
    their own B allocations; every listed additional consumer is charged here.
    JSON/base64 lengths need per-part rounding/headers in the metadata reserve.
    Enabled checksum/event payload readers require another reviewed derivation.
    RealIO has no accepted implementation of this model and cannot return it.
    """
    require(type(size) is int and MIN_PART<=size<=MAX_PART,'work_model_size')
    image=[('source_http',3),('part_assembly',3),('source_sha256',3),
           ('base64_encode',3),('base64_text',4),('json_scan',4),
           ('json_utf8',4),('sigv4_payload',4),('request_prepare',4),
           ('http_send',4),('readback_http',3),('readback_sha256',3)]
    generated=[('generated_allocation',3),('base64_encode',3),
               ('base64_text',4),('json_scan',4),('json_utf8',4)]
    def rows(terms):return [{'consumer':name,'thirds':thirds} for name,thirds in terms]
    image_thirds=sum(n for _,n in image)
    factor=image_thirds/3
    require(factor<=COPY_FACTOR,'work_model_bound')
    return {'model':'unaudited_candidate_only','copy_factor':factor,
            'image_consumers':rows(image),'generated_consumers':rows(generated),
            'image_bytes':sum((size*n+2)//3 for _,n in image),
            'generated_bytes':sum((size*n+2)//3 for _,n in generated)}

def budgets():
    return {'worker_exchanges':128,'normal':116,'redirects':9,'credential_discovery':2,'reconciliation':1,
            'root_exchanges':160,'parts':65,'memory':MEMORY,'disk':DISK,'joint':MEMORY+DISK,'evidence':EVIDENCE,
            'step':49152,'final':262144,'negative_reserve':65536,'runtime':65536,
            'reads':{'local_validation':1222768843,'local_upload':B,'source':B,'readback':B,'copy':COPY_FACTOR*B,'metadata':META_READ},
            'read_reserved':8416415151,'read_ceiling':8589934592,'worker_seconds':300,'carrier_seconds':600,'closure_seconds':180}

def buildspec(input_sha):
    require(isinstance(input_sha,str) and HEX.fullmatch(input_sha),'input_pin')
    return ('version: 0.2\nphases:\n  install:\n    runtime-versions:\n      python: 3.12\n  build:\n    commands:\n      - exec python3 -I -B transport.py '+input_sha+'\n').encode()

def ecr_origin(m):return 'https://'+m['account']+'.dkr.ecr.'+m['region']+'.amazonaws.com'
def blob_url(m,r):return ecr_origin(m)+'/v2/'+m['repository']+'/blobs/sha256:'+r['sha256']

def validate_manifest(m):
    expected={'schema','fixture','source_revision','account','region','repository','nonce','bucket','prefix','redirect_origins','carrier_start','carrier_deadline','work_start_cutoff','blobs','config_utf8','manifest_utf8','manifest_sha256','replay','worker_sha256','project_name','role_arn','allocation'}
    require(isinstance(m,dict) and set(m)==expected,'input_schema')
    require(m['schema']==1 and type(m['fixture']) is bool,'schema')
    allocation=m['allocation']
    require(isinstance(allocation,dict) and set(allocation)=={'id','receipt_sha256','reserved','ceiling'},'allocation_schema')
    require(allocation['id']=='transport-read-'+m['nonce'] and HEX.fullmatch(allocation['receipt_sha256']) and allocation['reserved']==8416415151 and allocation['ceiling']==8589934592,'allocation_join')
    require(m['account']=='079358094174' and m['region']=='us-east-1' and m['source_revision']==SOURCE,'identity')
    require(isinstance(m['nonce'],str) and re.fullmatch(r'[a-z0-9]{8,48}',m['nonce']),'nonce')
    require(m['repository']=='retained-transport-'+m['nonce'],'repository')
    require(m['project_name']=='transport-'+m['nonce'],'project')
    require(m['role_arn']=='arn:aws:iam::079358094174:role/transport-'+m['nonce'],'role')
    require(isinstance(m['bucket'],str) and re.fullmatch(r'[a-z0-9][a-z0-9.-]{1,61}[a-z0-9]',m['bucket']) and '..' not in m['bucket'],'bucket')
    require(m['prefix']=='transport/'+m['nonce']+'/','prefix')
    for key in ['carrier_start','carrier_deadline','work_start_cutoff']:
        require(type(m[key]) in (int,float) and math.isfinite(m[key]),'time')
    require(m['carrier_deadline']==m['carrier_start']+600 and m['work_start_cutoff']==m['carrier_start']+120,'time_join')
    require(isinstance(m['redirect_origins'],list) and 1<=len(m['redirect_origins'])<=4 and len(set(m['redirect_origins']))==len(m['redirect_origins']),'origins')
    for origin in m['redirect_origins']:
        require(isinstance(origin,str),'origin')
        p=urlsplit(origin)
        require(p.scheme=='https' and p.netloc==p.hostname and p.path=='' and not p.query and not p.fragment,'origin')
        # Exact reviewed regional backing hosts only; no suffix-only wildcard.
        require(p.hostname in {'prod-us-east-1-starport-layer-bucket.s3.us-east-1.amazonaws.com','prod-us-east-1-starport-layer-bucket.s3.amazonaws.com'},'origin')
    rows=m['blobs'];require(isinstance(rows,list) and len(rows)==9,'blob_count')
    require(len({r.get('sha256') for r in rows})==9,'blob_unique')
    for i,r in enumerate(rows):
        require(isinstance(r,dict) and set(r)=={'index','sha256','size','diff_id','retained_name','key','version'},'blob_schema')
        require(type(r['index']) is int and r['index']==i,'order')
        require(isinstance(r['sha256'],str) and HEX.fullmatch(r['sha256']),'blob_hash')
        require(type(r['size']) is int and 0<r['size']<=B,'blob_size')
        require(r['key']==m['prefix']+'inputs/%d'%i and isinstance(r['version'],str) and 1<=len(r['version'])<=256 and r['version']!='null','object_identity')
        require(r['diff_id'] is None if i==0 else isinstance(r['diff_id'],str) and HEX.fullmatch(r['diff_id']),'diff_id')
        require(isinstance(r['retained_name'],str) and re.fullmatch(r'config.json|layer-[0-9]{4}\.gz',r['retained_name']),'retained_name')
    require(isinstance(m['config_utf8'],str),'config')
    config=m['config_utf8'].encode()
    require(len(config)==rows[0]['size'] and hashlib.sha256(config).hexdigest()==rows[0]['sha256'],'config_hash')
    cfg=json.loads(config)
    require(cfg.get('architecture')=='amd64' and cfg.get('os')=='linux','platform')
    require(cfg.get('rootfs')=={'type':'layers','diff_ids':['sha256:'+r['diff_id'] for r in rows[1:]]},'diff_join')
    if not m['fixture']:
        require(rows[0]['sha256']==CONFIG and [r['size'] for r in rows]==ACTUAL_SIZES and [r['retained_name'] for r in rows]==ACTUAL_NAMES and sum(r['size'] for r in rows)==B,'baseline')
    require(set(m['replay'])=={'sha256','validated','save_sha256'} and m['replay']['validated'] is True and HEX.fullmatch(m['replay']['sha256']) and m['replay']['save_sha256']==SAVE,'root_replay_reference')
    require(HEX.fullmatch(m['worker_sha256']) is not None,'worker_pin')
    image=m['manifest_utf8'];require(isinstance(image,str) and len(image.encode())<=16384,'image_size')
    wanted={'schemaVersion':2,'mediaType':MANIFEST_MEDIA,'config':{'mediaType':CONFIG_MEDIA,'size':rows[0]['size'],'digest':'sha256:'+rows[0]['sha256']},'layers':[{'mediaType':LAYER_MEDIA,'size':r['size'],'digest':'sha256:'+r['sha256']} for r in rows[1:]]}
    require(json.loads(image)==wanted and hashlib.sha256(image.encode()).hexdigest()==m['manifest_sha256'],'manifest_join')
    return m


def validate_availability(m,response,after):
    require(isinstance(response,dict) and set(response)=={'layers','failures'},'availability_shape')
    wanted={'sha256:'+r['sha256'] for r in m['blobs'][1:]};seen=[]
    for row in response['layers']:
        require(row.get('layerAvailability')==('AVAILABLE' if after else 'UNAVAILABLE'),'unexpected_existing_layers')
        seen.append(row.get('layerDigest'))
    for row in response['failures']:
        require(not after and row.get('failureCode') in {'MISSING','MissingLayerDigest'},'availability_failure')
        seen.append(row.get('layerDigest'))
    require(len(seen)==8 and set(seen)==wanted,'availability_join')


def part_ranges(size,part_size):
    require(type(size) is int and size>0 and type(part_size) is int and MIN_PART<=part_size<=MAX_PART,'part_size')
    for first in range(0,size,part_size):yield first,min(size,first+part_size)-1

class Guards:
    def __init__(self,now,deadline):
        self.now=now;self.deadline=deadline;self.calls=0;self.credential=0;self.reconcile=0;self.redirect=0
        self.reads={'source':0,'readback':0,'copy':0,'preflight':0};self.disk_bytes=0;self.evidence_bytes=0;self.final_bytes=0;self.response_bytes=0
    def check(self):require(self.now()<self.deadline,'deadline')
    def exchange(self,kind='normal'):
        self.check();require(self.calls<128,'exchange_cap')
        if kind=='credential':require(self.credential<2,'credential_cap');self.credential+=1
        if kind=='reconcile':require(self.reconcile<1,'reconcile_cap');self.reconcile+=1
        if kind=='redirect':require(self.redirect<9,'redirect_cap');self.redirect+=1
        self.calls+=1
    def read(self,n,category):
        self.check();require(type(n) is int and n>=0 and category in self.reads,'read_shape')
        cap={'source':B,'readback':B,'copy':COPY_FACTOR*B,'preflight':META_READ}[category]
        require(self.reads[category]+n<=cap,'read_cap');self.reads[category]+=n
    def disk(self,n):
        require(type(n) is int and n>=0 and self.disk_bytes+n<=DISK,'disk_cap');self.disk_bytes+=n
    def response(self,obj):
        data=canonical(obj);require(len(data)<=65536 and self.response_bytes+len(data)<=128*1024,'response_cap');self.response_bytes+=len(data);return obj
    def evidence(self,data,kind):
        cap=49152 if kind=='step' else 262144
        require(len(data)<=cap and self.evidence_bytes+len(data)<=9*49152+262144,'evidence_cap')
        if kind=='final':require(self.final_bytes+len(data)<=262144,'final_cap');self.final_bytes+=len(data)
        self.evidence_bytes+=len(data)
    def snapshot(self):return {'exchanges':self.calls,'credential':self.credential,'reconcile':self.reconcile,'redirect':self.redirect,'reads':dict(self.reads),'disk':self.disk_bytes,'evidence':self.evidence_bytes,'responses':self.response_bytes}


def safe_redirect(location,origins):
    require(isinstance(location,str) and len(location)<=16384 and all(ord(c)>32 and ord(c)<127 for c in location),'redirect_shape')
    p=urlsplit(location)
    require(p.scheme=='https' and p.hostname and p.netloc==p.hostname and not p.fragment and p.path.startswith('/') and '\\' not in location,'redirect_origin')
    require('https://'+p.hostname in origins,'redirect_origin')
    return location


def registry_request(url,authorization):
    headers={'Accept-Encoding':'identity'}
    if authorization is not None:headers['Authorization']=authorization
    return urllib.request.Request(url,headers=headers,method='GET')

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kwargs):return None


def stream_exact(body,size,guard,category,collect=False):
    """Hash complete stream with size+one EOF bound; only config may collect."""
    h=hashlib.sha256();count=0;chunks=[];failed=True
    try:
        while count<size:
            wanted=min(65536,size-count);guard.read(wanted,category)
            chunk=body.read(wanted)
            require(isinstance(chunk,bytes) and 0<len(chunk)<=wanted,'stream_short')
            guard.reads[category]-=wanted-len(chunk);count+=len(chunk);h.update(chunk)
            if collect:chunks.append(chunk)
        guard.read(1,'preflight');extra=body.read(1);require(extra==b'','stream_overflow')
        result=({'bytes':count,'sha256':h.hexdigest(),'eof':True}, b''.join(chunks) if collect else None)
        failed=False;return result
    finally:
        if failed:
            try:body.close()
            except BaseException:pass
        else:body.close()


def run_transport(input_manifest,io):
    """Run one finite attempt. IO methods are the only side-effect boundary.

    An ambiguous operation is never retried. A missing/late final stays incomplete.
    The real IO counts at wire dispatch, including credentials and redirects.
    """
    m=input_manifest;steps=[];uploads=[];runtime={};phase='input';g=None;final_attempted=False;persisted=False
    result={'schema':1,'outcome':'negative','phase':phase,'steps':steps,'uploads':uploads,'runtime':runtime,'final_persisted':False}
    try:
        validate_manifest(m)
        start=getattr(io,'worker_start',io.now());require(io.now()<=m['work_start_cutoff'],'work_start_cutoff')
        deadline=min(start+300,m['carrier_deadline']-180)
        g=Guards(io.now,deadline)
        if hasattr(io,'bind'):io.bind(g)
        # Source<=4MiB*4, evidence<=1MiB*12, controls<=128KiB*16,
        # runtime<=64KiB*16, and1MiB overhead:32MiB conservative fixed work.
        g.read(32*1024*1024,'preflight')
        phase='runtime';runtime=io.runtime();require(len(canonical(runtime))<=65536,'runtime_cap')
        def call(op,args,kind='normal'):
            g.check()
            if not getattr(io,'wire_counted',False):g.exchange(kind)
            response=io.dispatch(op,args)
            # Tokens and credentials are never serialized into evidence.
            if op in {'token','credential'}:return response
            return g.response(response)
        phase='credential';call('credential',{},'credential')
        phase='availability_before';before=call('availability',{'after':False})
        validate_availability(m,before,False)
        phase='initiate'
        for row in m['blobs']:
            response=call('initiate',{'index':row['index']})
            require(set(response)=={'uploadId','partSize'} and isinstance(response['uploadId'],str) and 0<len(response['uploadId'])<=256,'initiate_shape')
            uploads.append({'index':row['index'],**response})
            require(type(response['partSize']) is int and MIN_PART<=response['partSize']<=MAX_PART,'part_size')
        total_parts=sum(math.ceil(r['size']/u['partSize']) for r,u in zip(m['blobs'],uploads));require(total_parts<=65,'part_count')
        phase='serialization_preflight'
        preflight=io.serialization_preflight(max(u['partSize'] for u in uploads),g.read)
        require(preflight.get('supported') is True and type(preflight.get('copy_factor')) in (int,float) and 0<preflight['copy_factor']<=COPY_FACTOR,'serialization_bound')
        # Source assembly/hash, SDK copies and readback hashing share the 20-B cap.
        factor=preflight['copy_factor'];require(sum(r['size'] for r in m['blobs'])*factor<=COPY_FACTOR*B,'copy_projection')
        require(len(canonical(preflight))<=4096,'preflight_evidence')
        phase='token';token=call('token',{})
        require(token.get('origin')==ecr_origin(m) and isinstance(token.get('authorization'),str) and token['authorization'].startswith('Basic '),'token_origin')
        # Config first, then three smallest layers, all successful steps reused.
        small=[0]+sorted(range(1,9),key=lambda i:m['blobs'][i]['size'])[:3]
        order=small+[i for i in range(9) if i not in small]
        for ordinal,index in enumerate(order):
            row=m['blobs'][index];u=uploads[index]
            phase='preflight_blob' if ordinal<4 else 'bulk_blob'
            # Conservative fixed one-second/exchange scheduling premise.
            remaining_parts=sum(math.ceil(m['blobs'][j]['size']/uploads[j]['partSize']) for j in order[ordinal:])
            remaining_calls=remaining_parts+(len(order)-ordinal)*5+4
            remaining_bytes=sum(m['blobs'][j]['size'] for j in order[ordinal:])
            # Reviewed planning premise: >=4MiB/s on each streamed leg, one
            # second per exchange. Absolute deadline still stops any overrun.
            schedule=remaining_calls+2*remaining_bytes/(4*1024*1024)
            require(g.deadline-io.now()>=schedule,'schedule_time')
            if not getattr(io,'wire_counted',False):g.exchange('normal')
            body,meta=io.source(row)
            try:require(meta.get('length')==row['size'] and meta.get('version')==row['version'],'source_identity')
            except BaseException:
                try:body.close()
                except BaseException:pass
                raise
            h=hashlib.sha256();parts=[];source_failed=True
            try:
                for first,last in part_ranges(row['size'],u['partSize']):
                    expected=last-first+1
                    # Reserve for consumers before allocation/read, including failures.
                    g.read(math.ceil(expected*factor),'copy')
                    pieces=[];got=0
                    while got<expected:
                        want=min(65536,expected-got);g.read(want,'source');chunk=body.read(want)
                        require(isinstance(chunk,bytes) and 0<len(chunk)<=want,'source_short')
                        pieces.append(chunk);got+=len(chunk);g.reads['source']-=want-len(chunk)
                    data=b''.join(pieces);del pieces
                    h.update(data)
                    response=call('part',{'index':index,'uploadId':u['uploadId'],'first':first,'last':last,'body':data})
                    require(type(response.get('lastByteReceived')) is int and response.get('lastByteReceived')==last and response.get('uploadId')==u['uploadId'],'part_ack')
                    parts.append({'first':first,'last':last,'bytes':expected,'response':response})
                    del data
                g.read(1,'preflight');require(body.read(1)==b'','source_overflow')
                source_failed=False
            finally:
                if source_failed:
                    try:body.close()
                    except BaseException:pass
                else:body.close()
            require(h.hexdigest()==row['sha256'],'source_hash')
            complete=call('complete',{'index':index,'uploadId':u['uploadId'],'digest':'sha256:'+row['sha256']})
            require(complete.get('layerDigest')=='sha256:'+row['sha256'],'complete_digest')
            rb,rbmeta=io.registry(row,token['authorization'],g.exchange)
            try:require(rbmeta.get('status')==200 and rbmeta.get('origin') in ['ecr']+['s3:%d'%i for i in range(len(m['redirect_origins']))],'readback_status')
            except BaseException:rb.close();raise
            try:require(rbmeta.get('length') in (None,row['size']),'readback_length')
            except BaseException:rb.close();raise
            readback,config=stream_exact(rb,row['size'],g,'readback',collect=index==0)
            require(readback['sha256']==row['sha256'],'readback_hash')
            if index==0:require(config==m['config_utf8'].encode(),'readback_config')
            step={'schema':1,'index':index,'input':row,'initiate':u,'parts':parts,'complete':complete,'readback':{**readback,**rbmeta},'counters':g.snapshot()}
            raw=canonical(step);g.evidence(raw,'step');key=m['prefix']+'steps/%d.json'%index
            phase='step_receipt';stored=call('receipt',{'key':key,'body':raw})
            require(stored.get('stored') is True,'step_persistence')
            steps.append({'index':index,'key':key,'sha256':hashlib.sha256(raw).hexdigest(),'size':len(raw)})
        phase='availability_after';after=call('availability',{'after':True})
        validate_availability(m,after,True)
        result['availability']={'before':before,'after':after}
        phase='put_image';put=call('put_image',{})
        phase='get_image';get=call('get_image',{'digest':'sha256:'+m['manifest_sha256']})
        for reply in [put,get]:require(reply.get('manifest')==m['manifest_utf8'] and reply.get('digest')=='sha256:'+m['manifest_sha256'],'image_readback')
        result.update(outcome='complete',manifest={'sha256':m['manifest_sha256'],'bytes':len(m['manifest_utf8'].encode()),'config':m['blobs'][0]['sha256'],'diff_ids':[r['diff_id'] for r in m['blobs'][1:]],'replay':m['replay']},preflight=preflight,put_image=put,get_image=get)
        phase='done';g.check()
    except BaseException as exc:
        # Never retain repr/str of external exceptions, URLs, headers or tokens.
        code=str(exc) if isinstance(exc,Negative) and re.fullmatch(r'[a-z0-9_]{1,64}',str(exc)) else type(exc).__name__
        result.update(outcome='negative',error=code)
    finally:
        result.update(phase=phase,steps=steps,uploads=uploads,runtime=runtime)
        if isinstance(m,dict) and 'allocation' in m:result['allocation']=m['allocation']
        if g is not None:
            result['counters']=g.snapshot()
            result['final_exchange']={'dispatched_before':g.calls,'reserved':1,'maximum_including_final':g.calls+1}
            try:
                result['observations']=io.observe()
                if hasattr(io,'originals'):result['provider_originals']=io.originals
                require(len(canonical(result['observations']))<=4096,'observations')
                raw=canonical(result);g.evidence(raw,'final');g.check()
                final_attempted=True
                if not getattr(io,'wire_counted',False):g.exchange('normal')
                reply=io.dispatch('receipt',{'key':m['prefix']+'final.json','body':raw})
                g.check();require(reply.get('stored') is True,'final_persistence');persisted=True
            except BaseException:
                result['outcome']='incomplete'
        result['final_persisted']=persisted;result['final_attempted']=final_attempted
        if g is not None:result['observed_counters']=g.snapshot()
        try:io.close()
        except BaseException:result['outcome']='incomplete'
    return result

def semantic(value,depth=0):
    """Finite JSON form of provider semantic originals, including SDK datetimes."""
    require(depth<=12,'response_depth')
    if isinstance(value,dict):
        require(len(value)<=256 and all(isinstance(k,str) for k in value),'response_shape')
        return {k:semantic(v,depth+1) for k,v in value.items()}
    if isinstance(value,list):
        require(len(value)<=256,'response_shape');return [semantic(v,depth+1) for v in value]
    if value is None or type(value) in (str,int,float,bool):return value
    from datetime import datetime
    if isinstance(value,datetime):return value.isoformat()
    raise Negative('response_shape')


class BoundedRaw:
    """Cap urllib3 response consumption before the SDK parser can buffer it."""
    def __init__(self,raw,limit,guard,source=False):
        self.raw=raw;self.limit=limit;self.seen=0;self.guard=guard;self.source=source
        self.closed=False;self._close_attempted=False;self._close_error=None
    def close(self):
        # Cleanup must work after deadlines and must not retry a failed close.
        if self._close_attempted:
            if self._close_error is not None:raise self._close_error
            return
        self._close_attempted=True
        try:self.raw.close()
        except BaseException as exc:
            self._close_error=exc;raise
        self.closed=True
    def read(self,amt=None,**kwargs):
        try:
            require(not self._close_attempted,'response_closed')
            self.guard.check()
            require(amt is None or type(amt) is int and amt>=0,'response_read')
            want=min(65536,self.limit-self.seen+1) if amt is None else min(amt,65536,self.limit-self.seen+1)
            # Reserve attempted control reads before the parser can consume bytes.
            # Keep the charge on overflow, short reads and underlying exceptions.
            if not self.source:self.guard.read(want,'preflight')
            data=self.raw.read(want,**kwargs)
            require(isinstance(data,bytes) and len(data)<=want,'response_read')
            self.seen+=len(data);require(self.seen<=self.limit,'response_body_cap')
            return data
        except BaseException:
            try:self.close()
            except BaseException:pass
            raise
    def stream(self,amt=65536,decode_content=False):
        try:
            require(decode_content is False,'response_decoding')
            while True:
                data=self.read(min(amt,65536),decode_content=False)
                if not data:break
                yield data
        except BaseException:
            try:self.close()
            except BaseException:pass
            raise
    def __getattr__(self,name):return getattr(self.raw,name)


class RealIO:
    """Fixed AWS/container client. Construction performs no credential HTTP.

    All lower-level SDK sends are counted by before-send, retries disabled both
    in Config and the endpoint retry decision. No provider chain is constructed.
    """
    wire_counted=True
    def __init__(self,m,source_disk=0):
        self.m=m;self.g=None;self.session=None;self.clients={};self.credentials=None;self.source_disk=source_disk;self.originals=[];self.original_bytes=0;self.active_operation=None;self.active_source_size=None;self.sdk_path=None;self._pending_raw=None
        self.opener=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect(),urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    def now(self):return time.time()
    def bind(self,g):self.g=g;g.disk(self.source_disk)
    def timeout(self):self.g.check();return max(0.01,min(1.,self.g.deadline-self.now()))
    def open(self,request,kind):
        self.g.exchange(kind)
        try:return self.opener.open(request,timeout=self.timeout())
        except urllib.error.HTTPError as e:
            if e.code in (301,302,303,307,308):return e
            e.close();raise Negative('http_status') from None
    def runtime(self):
        import importlib.metadata as md
        import platform
        import resource
        import boto3
        import botocore
        require(sys.version_info[:2]==(3,12),'python_version')
        require(os.environ.get('CODEBUILD_BUILD_IMAGE')=='aws/codebuild/standard:7.0','service_image')
        require(os.environ.get('CODEBUILD_BUILD_ID','').split(':',1)[0]==self.m['project_name'],'runtime_project')
        require(os.environ.get('CODEBUILD_BUILD_ARN','').startswith('arn:aws:codebuild:us-east-1:079358094174:build/'+self.m['project_name']+':'),'runtime_build')
        allowed={'boto3','botocore','s3transfer','jmespath','urllib3','python-dateutil','six'}
        pending=['boto3','botocore','s3transfer','jmespath','urllib3','python-dateutil'];facts={}
        def origin(path):
            p=Path(path).resolve();source=Path.cwd().resolve()
            require(not p.is_relative_to(source) and not p.is_relative_to('/tmp') and '/.local/' not in str(p) and ('/site-packages/' in str(p) or str(p).endswith('/site-packages')),'package_origin')
            return str(p)
        for module in [boto3,botocore]:origin(module.__file__)
        while pending:
            name=pending.pop(0)
            if name in facts:continue
            require(name in allowed and len(facts)<32,'dependency_shape')
            dist=md.distribution(name);requirements=dist.requires or []
            require(len(requirements)<=32,'dependency_shape')
            normalized=[]
            for req in requirements:
                # Extra-only optional packages are never activated by this worker.
                if re.search(r'\bextra\s*==',req):continue
                match=re.match(r'^([A-Za-z0-9_.-]+)',req);require(match is not None,'dependency_shape')
                dep=match.group(1).lower().replace('_','-');require(dep in allowed,'dependency_shape')
                normalized.append(req);pending.append(dep)
            root=origin(str(dist.locate_file('boto3/__init__.py' if name=='boto3' else 'botocore/__init__.py' if name=='botocore' else '.')))
            facts[name]={'version':dist.version,'origin':root,'requirements':normalized}
        require(len(facts)<=32,'dependency_count')
        result={'trust':'aws-managed-runtime','python':sys.version,'executable':sys.executable,
                'platform':platform.platform(),'machine':platform.machine(),'service_image':os.environ.get('CODEBUILD_BUILD_IMAGE'),
                'boto3':{'version':boto3.__version__,'origin':boto3.__file__},'botocore':{'version':botocore.__version__,'origin':botocore.__file__},
                'distributions':facts,'ssl':ssl.OPENSSL_VERSION,'urllib':{'origin':urllib.request.__file__,'version':sys.version},
                'as_limit':list(resource.getrlimit(resource.RLIMIT_AS))}
        require(result['as_limit']==[MEMORY,MEMORY] and len(canonical(result))<=65536,'runtime_limit')
        self.g.read(len(canonical(result)),'preflight');return result
    def fetch_credentials(self):
        # Only the AWS CodeBuild ECS-container relative-URI mechanism is accepted.
        relative=os.environ.get('AWS_CONTAINER_CREDENTIALS_RELATIVE_URI','')
        require(re.fullmatch(r'/v2/credentials/[A-Za-z0-9-]{8,128}',relative) is not None,'credential_mechanism')
        require(not os.environ.get('AWS_CONTAINER_CREDENTIALS_FULL_URI') and not os.environ.get('AWS_CONTAINER_AUTHORIZATION_TOKEN') and not os.environ.get('AWS_CONTAINER_AUTHORIZATION_TOKEN_FILE'),'credential_mechanism')
        request=urllib.request.Request('http://169.254.170.2'+relative,method='GET')
        response=self.open(request,'credential')
        try:
            require(response.status==200,'credential_status')
            self.g.read(65537,'preflight');body=response.read(65537)
            require(len(body)<=65536,'credential_body')
            obj=json.loads(body)
        finally:response.close()
        from datetime import datetime
        require(isinstance(obj,dict) and all(isinstance(obj.get(k),str) and 1<=len(obj[k])<=16384 for k in ['AccessKeyId','SecretAccessKey','Token','Expiration']),'credential_shape')
        expiry=datetime.fromisoformat(obj['Expiration'].replace('Z','+00:00')).timestamp()
        require(expiry>=self.g.deadline+60,'credential_expiry')
        self.credentials=(obj['AccessKeyId'],obj['SecretAccessKey'],obj['Token'])
        import boto3
        from botocore.config import Config
        self.session=boto3.session.Session(aws_access_key_id=self.credentials[0],aws_secret_access_key=self.credentials[1],aws_session_token=self.credentials[2],region_name=self.m['region'])
        cfg=Config(region_name=self.m['region'],retries={'total_max_attempts':1,'mode':'standard'},connect_timeout=1,read_timeout=1,max_pool_connections=1,proxies={},parameter_validation=True,s3={'addressing_style':'path'})
        for service in ['s3','ecr']:
            endpoint='https://'+('api.ecr' if service=='ecr' else 's3')+'.'+self.m['region']+'.amazonaws.com'
            client=self.session.client(service,endpoint_url=endpoint,config=cfg)
            require(client.meta.config.retries.get('total_max_attempts')==1,'sdk_retries')
            client.meta.events.register('before-send.*.*',self.before_send)
            # A retry or region-redirect decision cannot dispatch another request.
            client._endpoint._needs_retry=lambda *a,**k:False
            client._transport_original_send=client._endpoint.http_session.send
            client._endpoint.http_session.send=self.bounded_sdk_send(client._transport_original_send)
            self.clients[service]=client
        return {'expires':expiry}
    def before_send(self,request,**kwargs):
        p=urlsplit(request.url)
        require(p.scheme=='https' and p.port in (None,443) and not p.username and not p.fragment,'sdk_endpoint')
        require(p.hostname in {'s3.us-east-1.amazonaws.com','ecr.us-east-1.amazonaws.com','api.ecr.us-east-1.amazonaws.com'},'sdk_endpoint')
        self.g.exchange('normal')
    def bounded_sdk_send(self,send):
        def bounded(request):
            stream_output=request.stream_output
            try:
                request.stream_output=True
                response=send(request)
            finally:request.stream_output=stream_output
            raw=response.raw
            try:
                # Drift detector only: an unexpected preload is already too late.
                require(getattr(response,'_content',False) is None,'response_preloaded')
                headers=dict(response.headers)
                require(len(canonical(headers))<=65536,'response_headers')
                source=self.active_operation=='get_object' and type(response.status_code) is int and response.status_code==200
                limit=self.active_source_size if source else 65536
                require(type(limit) is int and limit>=0,'response_limit')
                wrapped=BoundedRaw(raw,limit,self.g,source)
                response.raw=wrapped;self._pending_raw=wrapped
                return response
            except BaseException:
                try:raw.close()
                except BaseException:pass
                raise
        return bounded
    def sdk(self,service,operation,**kwargs):
        # Single-flight ownership covers invocation, parsing and validation.
        self._pending_raw=None;transferred=False;failed=True
        try:
            self.g.check();client=self.clients[service]
            self.active_operation=operation
            self.active_source_size=next((r['size'] for r in self.m['blobs'] if operation=='get_object' and r['key']==kwargs.get('Key')),None)
            response=getattr(client,operation)(**kwargs)
            meta=response.pop('ResponseMetadata',{})
            require(meta.get('HTTPStatusCode')==200,'sdk_status')
            # Redacted complete semantic SDK originals, once, with fixed safe headers.
            safe_headers={'content-type','content-length','date','x-amzn-requestid','x-amz-request-id','x-amz-id-2','x-amz-version-id','x-amz-server-side-encryption','etag'}
            headers=meta.get('HTTPHeaders',{})
            require(isinstance(headers,dict) and len(canonical(headers))<=65536,'response_headers')
            safe_meta={k:meta[k] for k in ['RequestId','HTTPStatusCode','RetryAttempts'] if k in meta}
            safe_meta['HTTPHeaders']={k:v for k,v in headers.items() if k.lower() in safe_headers}
            for key,expected in [('registryId',self.m['account']),('repositoryName',self.m['repository'])]:
                require(key not in response or response[key]==expected,'response_identity')
            original=semantic({k:v for k,v in response.items() if k!='Body'})
            if operation=='get_authorization_token':
                original={'authorizationData':[{'proxyEndpoint':x.get('proxyEndpoint'),'expiresAt':str(x.get('expiresAt')),'authorizationToken':'REDACTED'} for x in response.get('authorizationData',[])]}
            record={'service':service,'operation':operation,'response':original,'metadata':safe_meta}
            encoded=canonical(record)
            require(len(encoded)<=65536 and self.original_bytes+len(encoded)<=128*1024,'originals_cap')
            self.originals.append(record);self.original_bytes+=len(encoded)
            if operation=='get_object':
                body=response.get('Body')
                require(self._pending_raw is not None and self._pending_raw.source and
                        callable(getattr(body,'read',None)) and callable(getattr(body,'close',None)),'source_body')
                transferred=True
            failed=False
            return response
        finally:
            pending=self._pending_raw;self._pending_raw=None
            self.active_operation=None;self.active_source_size=None
            if pending is not None and not transferred:
                if failed:
                    try:pending.close()
                    except BaseException:pass
                else:pending.close()
    def sdk_path_facts(self,charge):
        """Bounded diagnostic identities only; these never establish support.

        Hash <=16KiB method bytecode and <=64KiB regular module source files.
        Missing/large/uninspectable sources remain explicit facts. Never emit
        source text, arbitrary paths, event arguments, request bodies or secrets.
        Full call closure, enabled handlers/checksums and HTTP/readback readers
        have NOT been audited. No managed SDK profile is accepted in this build.
        """
        facts={'supported':False,'accepted_profiles':0,'reason':'unreviewed_sdk_path',
               'unestablished':['request_closure','events','checksums','readback_closure'],
               'source_methods':[]}
        def member(obj,name):return getattr(obj,name,None) if obj is not None else None
        ecr=self.clients.get('ecr');s3=self.clients.get('s3')
        serializer=member(ecr,'_serializer')
        nested=member(serializer,'_serializer')
        if nested is not None:serializer=nested
        endpoint=member(ecr,'_endpoint')
        auth=sys.modules.get('botocore.auth');request=sys.modules.get('botocore.awsrequest')
        response=sys.modules.get('botocore.response')
        methods=[('json',member(serializer,'serialize_to_request')),
                 ('blob',member(serializer,'_serialize_type_blob')),
                 ('endpoint',member(endpoint,'make_request')),
                 ('send_request',member(endpoint,'_send_request')),
                 ('http',member(ecr,'_transport_original_send')),
                 ('sign',member(member(ecr,'_request_signer'),'sign')),
                 ('payload',member(member(auth,'SigV4Auth'),'payload')),
                 ('prepare',member(member(request,'AWSRequest'),'prepare')),
                 ('source_read',member(member(response,'StreamingBody'),'read')),
                 ('s3_send',member(s3,'_transport_original_send')),
                 ('readback_open',member(self.opener,'open'))]
        # Generated diagnostics/source work is separate from image-copy20B.
        charge(65536,'preflight')
        for role,method in methods:
            item={'role':role,'source':'unavailable'}
            code=member(method,'__code__')
            module=member(method,'__module__')
            if isinstance(module,str) and re.fullmatch(r'[A-Za-z0-9_.]{1,96}',module):item['module']=module
            if isinstance(code,type((lambda:None).__code__)):
                if len(code.co_code)<=16384:
                    charge(len(code.co_code),'preflight')
                    item['code_sha256']=hashlib.sha256(code.co_code).hexdigest()
                # Source is a module-file hash, not a claim about call closure.
                try:
                    path=Path(code.co_filename)
                    if path.is_absolute() and not path.is_relative_to('/tmp'):
                        fd=os.open(path,os.O_RDONLY|os.O_NOFOLLOW)
                        try:
                            info=os.fstat(fd)
                            item['source']='over_cap'
                            if stat.S_ISREG(info.st_mode) and info.st_size<=65536:
                                charge(2*65537,'preflight')
                                with os.fdopen(fd,'rb',closefd=False) as source:data=source.read(65537)
                                require(len(data)<=65536,'sdk_source_cap')
                                item['source']='module_sha256';item['source_sha256']=hashlib.sha256(data).hexdigest()
                        finally:os.close(fd)
                except OSError:item['source']='unavailable'
            facts['source_methods'].append(item)
        # There is deliberately no event-enumeration heuristic or profile match.
        # Recording source hashes cannot turn an unknown consumer into support.
        require(len(canonical(facts))<=3072,'sdk_path_facts_cap')
        return facts
    def serialization_preflight(self,size,charge):
        """Reject the real path before generated serialization or image reads.

        No possessed/reviewed SDK implementation exists for the candidate model.
        A later implementation review must bind full request/response/readback
        closures, shapes, checksums and events to an itemized <=20B derivation.
        Runtime facts help that review but cannot grant acceptance in this build.
        """
        require(type(size) is int and MIN_PART<=size<=MAX_PART,'part_size')
        self.sdk_path=self.sdk_path_facts(charge)
        raise Negative('unsupported_sdk_path')
    def dispatch(self,op,a):
        repo={'registryId':self.m['account'],'repositoryName':self.m['repository']}
        if op=='credential':return self.fetch_credentials()
        if op=='availability':return self.sdk('ecr','batch_check_layer_availability',**repo,layerDigests=['sha256:'+r['sha256'] for r in self.m['blobs'][1:]])
        if op=='initiate':
            r=self.sdk('ecr','initiate_layer_upload',**repo)
            return {k:r[k] for k in ['uploadId','partSize']}
        if op=='part':
            r=self.sdk('ecr','upload_layer_part',**repo,uploadId=a['uploadId'],partFirstByte=a['first'],partLastByte=a['last'],layerPartBlob=a['body'])
            return {k:r[k] for k in ['uploadId','lastByteReceived']}
        if op=='complete':return self.sdk('ecr','complete_layer_upload',**repo,uploadId=a['uploadId'],layerDigests=[a['digest']])
        if op=='token':
            r=self.sdk('ecr','get_authorization_token',registryIds=[self.m['account']]);items=r.get('authorizationData')
            require(isinstance(items,list) and len(items)==1,'token_shape');item=items[0]
            require(item.get('proxyEndpoint')==ecr_origin(self.m),'token_endpoint')
            token=item.get('authorizationToken');require(isinstance(token,str) and len(token)<=16384,'token_shape')
            decoded=base64.b64decode(token,validate=True);require(decoded.startswith(b'AWS:') and len(decoded)>4,'token_shape')
            require(hasattr(item.get('expiresAt'),'timestamp') and item['expiresAt'].timestamp()>=self.g.deadline,'token_expiry')
            return {'origin':item['proxyEndpoint'],'authorization':'Basic '+token}
        if op in ('put_image','get_image'):
            if op=='put_image':r=self.sdk('ecr','put_image',**repo,imageManifest=self.m['manifest_utf8'],imageManifestMediaType=MANIFEST_MEDIA,imageTag=self.m['nonce']);image=r.get('image')
            else:
                r=self.sdk('ecr','batch_get_image',**repo,imageIds=[{'imageDigest':a['digest']}],acceptedMediaTypes=[MANIFEST_MEDIA]);require(r.get('failures')==[] and len(r.get('images',[]))==1,'image_response');image=r['images'][0]
            require(isinstance(image,dict) and image.get('imageManifestMediaType')==MANIFEST_MEDIA,'image_media')
            return {'manifest':image.get('imageManifest'),'digest':image.get('imageId',{}).get('imageDigest')}
        if op=='receipt':
            require(a['key'] in [self.m['prefix']+'steps/%d.json'%i for i in range(9)]+[self.m['prefix']+'final.json'],'receipt_key')
            response=self.sdk('s3','put_object',Bucket=self.m['bucket'],Key=a['key'],Body=a['body'],ContentType='application/json',ServerSideEncryption='AES256',IfNoneMatch='*')
            require(response.get('ServerSideEncryption')=='AES256','receipt_encryption')
            return {'stored':True,'version':response.get('VersionId'),'etag':response.get('ETag')}
        raise Negative('operation')
    def source(self,row):
        r=self.sdk('s3','get_object',Bucket=self.m['bucket'],Key=row['key'],VersionId=row['version'])
        body=r.pop('Body',None)
        try:require(body is not None and r.get('ServerSideEncryption')=='AES256' and r.get('ContentLength')==row['size'] and r.get('VersionId')==row['version'],'source_metadata')
        except BaseException:
            if body is not None:
                try:body.close()
                except BaseException:pass
            raise
        return body,{'length':r['ContentLength'],'version':r['VersionId']}
    def registry(self,row,authorization,guard):
        initial=self.open(registry_request(blob_url(self.m,row),authorization),'normal')
        origin='ecr';response=initial
        if initial.status in (301,302,303,307,308):
            try:location=safe_redirect(initial.headers.get('Location'),self.m['redirect_origins'])
            finally:initial.close()
            origin='s3:'+str(self.m['redirect_origins'].index('https://'+urlsplit(location).hostname))
            response=self.open(registry_request(location,None),'redirect')
            location=None
        try:
            require(response.status==200,'readback_status')
            encoding=response.headers.get('Content-Encoding');require(encoding in (None,'identity'),'content_encoding')
            length=response.headers.get('Content-Length')
            require(length is None or re.fullmatch(r'[0-9]{1,12}',length),'content_length')
            return response,{'status':200,'origin':origin,'length':None if length is None else int(length)}
        except BaseException:response.close();raise
    def observe(self):
        import resource
        return {'ru_maxrss_kib':resource.getrusage(resource.RUSAGE_SELF).ru_maxrss,'as_limit':list(resource.getrlimit(resource.RLIMIT_AS)),'new_disk_reserved':self.source_disk,'sdk_path':self.sdk_path}
    def close(self):
        for client in self.clients.values():client.close()
        self.credentials=None;self.session=None


def read_source_tree(root,pin):
    """Read only three fixed regular files, bounded and no-follow."""
    root=Path(root);require(set(p.name for p in root.iterdir())=={'transport.py','input.json','buildspec.yml'},'expanded_tree')
    contents={};total=0
    for name,cap in [('input.json',65536),('transport.py',4*1024*1024),('buildspec.yml',4096)]:
        p=root/name;info=p.lstat();require(stat.S_ISREG(info.st_mode) and info.st_nlink==1 and info.st_size<=cap,'source_file')
        fd=os.open(p,os.O_RDONLY|os.O_NOFOLLOW)
        with os.fdopen(fd,'rb') as f:content=f.read(cap+1)
        require(len(content)==info.st_size and len(content)<=cap,'source_file');contents[name]=content;total+=len(content)
    require(total<=4*1024*1024 and hashlib.sha256(contents['input.json']).hexdigest()==pin,'input_hash')
    m=json.loads(contents['input.json']);validate_manifest(m)
    require(m['fixture'] is False,'fixture_entrypoint')
    require(hashlib.sha256(contents['transport.py']).hexdigest()==m['worker_sha256'],'worker_hash')
    require(contents['buildspec.yml']==buildspec(pin),'buildspec_hash')
    return m,total+1024*1024 # exact expanded size plus reserved provider source ZIP


def main():
    # Hard address space enforced before provider SDK import/data. No dynamic raise.
    import resource
    import logging
    logging.disable(sys.maxsize)
    resource.setrlimit(resource.RLIMIT_AS,(MEMORY,MEMORY))
    require(resource.getrlimit(resource.RLIMIT_AS)==(MEMORY,MEMORY),'as_limit')
    started_wall=time.time();started_mono=time.monotonic()
    def alarm(*args):raise Negative('absolute_alarm')
    signal.signal(signal.SIGALRM,alarm);signal.setitimer(signal.ITIMER_REAL,300)
    result=None
    try:
        require(len(sys.argv)==2 and HEX.fullmatch(sys.argv[1]),'entry_arguments')
        m,source_disk=read_source_tree(Path.cwd(),sys.argv[1])
        require(started_wall<=m['work_start_cutoff'],'work_start_cutoff')
        remaining=min(300.,m['carrier_deadline']-180-started_wall)
        require(remaining>0,'deadline');signal.setitimer(signal.ITIMER_REAL,remaining)
        provider=RealIO(m,source_disk);provider.worker_start=started_wall
        # Wall-clock absolute join plus monotonic elapsed, resistant to clock rollback.
        provider.now=lambda: max(time.time(),started_wall+time.monotonic()-started_mono)
        result=run_transport(m,provider)
        token='TRANSPORT_'+result['outcome'].upper()+'\n'
    except BaseException:token='TRANSPORT_INCOMPLETE\n'
    finally:signal.setitimer(signal.ITIMER_REAL,0)
    sys.stdout.write(token[:256]);sys.stdout.flush()
    return 0 if result and result['outcome']=='complete' else 1

if __name__=='__main__':sys.exit(main())
