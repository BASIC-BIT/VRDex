"""Freeze generated fake packet and exact review subjects. No AWS/body inputs."""
import base64
import difflib
import hashlib
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import packet
from test_packet import fixture


def write_json(name,value):
    (ROOT/'supportfixtures'/name).write_bytes(packet.canonical(value)+b'\n')

def main():
    owned,metadata,pins,blobs=fixture()
    result=packet.prepare_packet(owned,metadata,pins)
    support=ROOT/'supportfixtures'
    (support/'fixture-source.zip').write_bytes(result['source_zip'])
    (support/'fixture-input.json').write_bytes(result['input_bytes'])
    (support/'fixture-buildspec.yml').write_bytes(result['buildspec'])
    for name,value in [('fixture-owned.json',owned),('fixture-metadata.json',metadata),('fixture-project.json',result['project']),('fixture-start.json',result['start']),('fixture-budget.json',result['budgets']),('fixture-predicted.json',result['predicted'])]:write_json(name,value)
    write_json('fixture-packet-refs.json',{k:result[k] for k in ['source_sha256','source_size','input_sha256','members']})
    selected=['transport.py','test_transport.py','packet.py','test_packet.py','README.md']
    selected+=['supportfixtures/'+p.name for p in sorted(support.iterdir()) if p.is_file() and p.name not in {'review-subjects.json','task-1.diff'}]
    inventory={name:{'size':(ROOT/name).stat().st_size,'sha256':hashlib.sha256((ROOT/name).read_bytes()).hexdigest()} for name in selected}
    write_json('review-subjects.json',{'fixture_only':True,'subjects':inventory})
    selected.append('supportfixtures/review-subjects.json')
    with (support/'task-1.diff').open('w') as f:
        f.write('All files below are new private files. No Git or old helper changes. Binary packet is included in exact base64.\n')
        for name in selected:
            data=(ROOT/name).read_bytes()
            f.write('\nSubject '+name+' SHA256 '+hashlib.sha256(data).hexdigest()+' bytes '+str(len(data))+'\n')
            if name.endswith('.zip'):
                f.write('BASE64-BEGIN\n'+base64.b64encode(data).decode()+'\nBASE64-END\n')
            else:f.writelines(difflib.unified_diff([],data.decode().splitlines(keepends=True),fromfile='/dev/null',tofile=name))
    return 0

if __name__=='__main__':raise SystemExit(main())
