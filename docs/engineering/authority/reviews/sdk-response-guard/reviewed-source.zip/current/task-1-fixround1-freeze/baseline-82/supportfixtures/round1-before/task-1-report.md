# Task 1 implementation report

2026-10-27. **DONE for independent SPEC/QUALITY review.** No AWS/network/Docker/native/corpus/layer read, resource creation, dependency/tool installation, old helper/repository-source edit, Git command, commit or subagent was used. All generated payloads are fake. Actual provider/runtime acceptance remains open by design. Root alone authorizes and runs any later paid candidate.

Requirements read first: `/workspace/VRDex/.superpowers/sdd/retained-image-ecr-transport/task-1-brief.md`. Governing design is `/workspace/scratch/retained-image-ecr-transport-design.md`, amendment at177 and final resource-only8GiB/20B/256MiB-work amendment. Design SHA256 `e941406bd5b4ef0979a72aedab6d92765072e6ea8e3e86d9d160174aa7f817ca`. Accepted design reviews are `/workspace/scratch/transportdesign-review-round1.md` and `/workspace/scratch/transportdesign-read-work-review.md`. These supersede historical4GiB/6B/128MiB logical-work and56MiB/128MiB remote proposals. Root separately confirmed that the worker binds Root's fresh replay receipt without repeating gzip replay/decompression.

## Delivered interfaces and source boundary

Created only the five requested private source/test/README files plus their own generated support fixtures and this assigned report. The public APIs are exactly `transport.run_transport(input_manifest, io)` and `packet.prepare_packet(owned_inputs, blob_metadata, support_pins)`. `README.md` specifies exact argument/return schemas and Root duties.

The packet is deterministic and contains exactly `transport.py`, `input.json`, `buildspec.yml`. The input pins the worker; the buildspec embeds input SHA256; Root externally pins ZIP/member bytes, avoiding any self-hash cycle. No arbitrary command, installer, dynamic source member or generic registry dispatch is accepted. ZIP and startup tree validations reject duplicates, extras, links/traversal, wrong size/hash and fixtures at the real entrypoint.

The packet's `owned_inputs` includes `allocation_id` and `allocation_receipt_sha256`, binding `transport-read-<nonce>` to the unique separate8GiB ledger reservation. No allocation is actually created by this report. Root must supply actual nine version-bound S3 identities and reviewed fresh replay/custody/allocation references later. `blob_metadata` binds exact configUTF8, compressed descriptors/order/diffIDs and Root replay SHA256. Real baseline constants fix source/config/nine sizes/names/B. Fixture mode bypasses baseline byte identities solely for tests and cannot pass real startup.

`project` and `start` are exact finite request dictionaries for standard7.0/Python3.12, LINUX_CONTAINER/SMALL, nonprivileged, versioned S3 source, NO_ARTIFACTS/NO_CACHE, disabled CloudWatch/S3 logs, five-minute service/queue ceilings and no VPC or secondary inputs. Root must compare provider-returned project/start/build configuration before image transfer under its separate160-control schedule. The worker additionally checks observed managed image and account/project/build identifiers. No real project request was sent.

## Worker behavior and enforcement

Before boto3 import the launcher sets/verifies256MiB soft/hard RLIMIT_AS and starts an absolute alarm. A monotonic elapsed clock is joined to the fixed wall deadline. Remote disk reserves sourceZIP<=1MiB plus exact expanded source<=4MiB, under8MiB total/264MiB joint; no image/output/temporary file is written. Python `-I -B`, no thread/subprocess/transfer manager/installation, one stream and one exact part plus bounded serialization buffers.

Managed boto3/botocore are an explicit provider-runtime trust premise. Actual Python3.12/executable/platform/machine/service image, SDK versions/origins, SSL/urllib and installed dependency closure are captured before source reads, <=32 distributions/64KiB. Writable packet/tmp/user-site imports, unexpected dependency names/API shapes, metadata overflow, missing imports or incompatible runtime produce a same-attempt negative. There is no invented expected patch version or package-byte authentication claim.

Credential HTTP cannot bypass the counter. Only one fixed AWS-container relative-URI request is accepted, no redirects/proxy/default provider chain/auth token/file. Its bounded credential body remains in memory and must expire after deadline+60seconds. Explicit credentials go to boto3; no refresh chain is present. Config total_max_attempts1, one pool connection, one-second connect/read timeouts, no proxies, fixed S3 path addressing; endpoint retries disabled and lower SDK sends counted/endpoint-validated. The selected HTTP implementation's explicit Retry(False)/redirect=False are inspected. Control response bodies are bounded before SDK parsing. No secrets, signed URL/query or raw external exception text enters receipts.

The worker checks fresh-repository availability, initiates nine uploads once and records IDs even when a returned part size fails. Returned integer5..20MiB sizes are used unchanged, computed total<=65, then one largest-size SDK serialization preflight. Source inspection records selected serializer/signing/preparation/HTTP function identities. The selected finite path's conservative estimate28/3 is below20; the full20B is nevertheless held. Generated serialization and runtime/source/receipt work are separately charged. Unsupported shapes or unestablished bounds stop before source reads.

The normal first four blobs are config and three smallest layers. They must each pass exact S3 version/length/hash/EOF, unchanged parts/inclusive integer acknowledgements, complete digest and independent full fixed registry readback before bulk. Short reads are gathered with actual-byte accounting. ContentLength, exact length/EOF/hash and config bytes are checked. One exact allowlisted regional S3 redirect may follow each fixed ECR GET, with a fresh unauthenticated request and no second redirect. TLS verification and identity encoding remain enabled. Manifest publication/readback requires exact bytes/media/config/layer descriptors/digest; diffID and external replay/source joins remain distinct.

Fatal or ambiguous mutations are never retried. The one reconciliation slot is reserved, but this worker chooses a bounded negative instead of continuing an ambiguous mutation. All initiated IDs and successful step references remain cleanup obligations. Root handles termination/reconciliation/custody/cleanup/two censuses and any missing final without restarting.

## Budgets and receipt custody

| Allocation | Bound |
| --- | ---: |
| Normal worker exchanges |116|
| Registry redirects |9|
| Credential/discovery extras |2|
| Guaranteed reconciliation slot |1|
| Absolute worker exchanges |128|
| Root/provider controls, separate |160|
| Parts for actual inputs at5MiB /20MiB |65 /21|
| Hard address space / new disk / joint |268,435,456 /8,388,608 /276,824,064 bytes|
| Evidence / step / final / runtime facts |1,048,576 /49,152 /262,144 /65,536 bytes|
| Worker / carrier / start cutoff / closure reserve |300 /600 /120 /180 seconds|

The new separate read reservation is8,416,415,151 below8,589,934,592, leaving173,519,441. Categories exactly: replay1,222,768,843; local upload301,096,124; streamed source301,096,124; complete readbacks301,096,124; additional copy/hash/SDK/HTTP20B6,021,922,480; generated/runtime/source/receipt/control268,435,456. Root must retain unique allocation/full conservative reservation/disposition before reads; no Task1 history is reset. Worker source/readback/copy/preflight counters reserve before reads. EOF probes and rejected unexpected bytes use bounded preflight work. A32MiB fixed conservative metadata-copy reserve plus generated largest-part28/3 work and actual raw-control/runtime charges fit the256MiB logical-work category. This category is distinct from the256MiB hard address-space cap.

Only exact immutable `<prefix>steps/0.json`..`steps/8.json` and `<prefix>final.json`, conditionally SSE-AES256, are allowed. Step bodies retain exact input version/hash/size, initiation/parts/completion/readback/counters. Final binds steps, runtime, source/replay/allocation and manifest/config/diffID joins, bounded redacted semantic SDK originals and outcome. SDK datetime values use ISO strings; unsafe headers/auth fields are redacted. Original semantic response completeness is bounded; overflows yield negative/incomplete rather than excerpt-only success.

The final body records counters before its own PUT and explicitly reserves that final exchange, avoiding a self-acknowledgement cycle. The returned `observed_counters` includes its actual final attempt. Final write failure/ambiguity/late persistence leaves outcome incomplete. Root must read/retain the actual exact-key object and provider terminal state. Stdout is a fixed <=256-byte nonauthoritative status token. No separate logs/artifact/diagnostic files duplicate the evidence.

The worker requires start<=carrierStart+120, deadline=min(workerStart+300,carrierDeadline-180), with carrierDeadline=carrierStart+600. Before each blob it checks remaining exchange/stream schedule, using one second per exchange and4MiB/s for each stream leg as explicit planning premises. Actual timing remains unproved; the alarm/deadline bounds overruns and Root owns independent stop/closure reserves.

## Tests and commands

Initial RED command, exit1: `python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v`. The generated initial15-test fixtures were written before either implementation module existed; discovery reported two import errors. Full output is `supportfixtures/red.log`. This is an import-stage RED, not a claim that every later expanded assertion individually failed against an earlier behavioral implementation.

After implementing,15 tests passed. Expansion to48 found one fake raw-stream stub lacking the urllib3 keyword signature; the stub was corrected. Expansion to51 passed. Intermediate full logs and accurate commands/results are indexed in `supportfixtures/commands.json`. The initial RED-created two bytecode files were removed from this private directory; all subsequent commands disable bytecode writes.

Final GREEN command, exit0: `PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v`. **51 tests passed**, full output `supportfixtures/green.log`,51 tests in0.322seconds. Tests include generated exact5/20MiB nonfinal+1-byte final payloads, tiny preflight order, returned10MiB acceptance, one-over/boolean/noninteger part sizes, worst-case65/21 counts, source/hash/order/config/diffID/manifest/media joins, source/version/truncation/overlong/hash failures, short reads, credential expiry/mechanism/counts, SDK fixed credentials/retry configuration/endpoints/wire cap, safe/unsafe/second redirects/no auth forwarding/no URL logs, control/evidence/read/disk/deadline/memory/runtime guards, startup limit/alarm ordering, source ZIP/tree tampering, negative secret sanitization, early-stop/late receipt/ambiguous upload/PutImage/step/final persistence and closure behavior. Every SDK/HTTP/runtime seam is fake or mocked; no credential or real provider library was loaded for a request.

Freeze command, exit0: `PYTHONDONTWRITEBYTECODE=1 python /workspace/scratch/retained-image-ecr-transport/supportfixtures/freeze.py`. It builds only generated fake packet inputs, deterministic ZIP and exact review inventory/diff. Do not upload the fake packet. Root must produce and externally freeze the actual source ZIP/input/project/start from reviewed actual metadata before mutation.

## Frozen review subjects

Private root: `/workspace/scratch/retained-image-ecr-transport/`.

| Subject | Bytes | SHA256 |
| --- | ---: | --- |
| transport.py |43042|8d2306a6575f19883696dc5033699ca0d205afeb58e96eed6fec3121d66ca422|
| test_transport.py |26130|89a604c223225a44d5ce0cf61c6788231cb43f263bd487f3fb4ed5ae0ed715b3|
| packet.py |6150|007a46cf718522174b90b6a438881d9693b867842ae718e487e893767d6709ca|
| test_packet.py |8341|567f87ace5dbd33050439438e0556fd590a4dade6c1ae1a8ae888381b875e8e3|
| README.md |13195|5feb5afbcab11a98611dd855c2fc50176e42b6f168b3c19a7d39c87e8a2dba38|
| supportfixtures/review-subjects.json |3086|e6dc4b502984daf38771c5dab105c9acdc12acbfdd2e4ea7713287360d5c20dd|
| supportfixtures/task-1.diff |184037|d527f6a03a85b5abc8a2d3eb542702609a6d90d7ae24262cfd8294a7c19de9b9|
| supportfixtures/fixture-source.zip |15809|bf90a2b7523c42b7afb25f0763a386789ce2fa977abbbf6ac92aac7a6557f239|
| supportfixtures/fixture-input.json |5735|80efa6d5e5c206ebc0740d6a000503dc542a304d689da2b30a2aa94a76dad588|
| supportfixtures/green.log |6694|fb6a28712fe164cb134a6b50477332d81e46dc765eeb9c7719c42f0c419adcfc|
| supportfixtures/red.log |1941|3debb17f29bdd9564f2101ff50804caaf729d1d9e318965f001fc355c2e58095|

The inventory pins every primary/support helper/fixture/command/log subject. The full new-file unified diff contains all source/tests/README/support text and the exact fake ZIP as base64. The inventory/diff are externally pinned by this report, avoiding self-hash cycles. No Git diff/commit was made because the task explicitly forbids Git operations and old repo edits.

## Remaining observations and authority

Independent SPEC/QUALITY review is required before Root readiness. Actual managed SDK API/source shapes, credentials, serialization/memory fit, real config/tiny acceptance, provider TLS/redirects/network throughput, final custody, termination/cleanup and fresh all-in<=1USD reservation remain unobserved. These are expected trial facts, not fake-test approvals. No new resource/spend reservation/allocation execution occurred. No K/A/native/loader/provenance/measurement approval follows.
