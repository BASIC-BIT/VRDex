# Versioned input custody amendment — proposed for Root review

2026-10-27. Design only; no provider calls, implementation, corpus reads, paid reservation or launch. Read the governing transport design, plan and task-1 brief. This proposal requires independent Root review before action.

## Next action: establish SDK support before staging

Root reports that the current helper direction honestly rejects every real SDK as unestablished before image reads; actual managed SDK sources are not yet possessed. **Resolve that known blocker before uploading300MB, creating ECR, or preparing the input bucket.** Prefer an already available read-only source-acquisition path.

If unavailable, consider a separately reviewed, finite **SDK-inspection-only CodeBuild diagnostic**: standard7.0/Python3.12, nonprivileged SMALL, NO_SOURCE with externally frozen inline buildspec, no image/native reads, downloads, installs, ECR, secondary sources, cache, artifacts or build logs. Inspect a predeclared finite set of installed SDK/Python source ranges, versions/import origins and event/serialization hooks; write one complete <=64KiB diagnostic to one nonce key in the existing private artifact bucket. Verify actual returned bytes; source excerpts do not prove complete modules, TLS/wire behavior or real ECR acceptance. Fail on overflow rather than silently truncate.

That diagnostic would be a **separately authorized one-job observation**, not another build hidden inside transport's one-job rule. Before role/project creation, Root must freeze its exact source, finite API/read/receipt/cleanup schedule, justify why <=64KiB is sufficient, and reserve cost within the authorized$20. Apply <=300s worker/600s carrier/120s start/180s closure ceilings, no retry and exact private cleanup. It cannot borrow/reset a consumed transport attempt. If insufficient, keep transport blocked. No diagnostic implementation or launch is part of this amendment.

## Custody decision

After SDK support, helper review and other readiness are complete, use **one new nonce private disposable S3 input bucket, account079358094174, us-east-1**. The intended `vrdex-restream-worker-079358094174-artifacts` bucket has AES256/OwnerEnforced/seven-day lifecycle but is unversioned. Other owned candidates are unversioned; the checked CodePipeline bucket additionally lacks public-block/ownership/lifecycle controls. The versioned Terraform state bucket is inappropriate. Do not mutate or borrow them.

The new bucket holds **only nine exact image blobs plus one exact source ZIP**: B=301,096,124 bytes plus ZIP<=1,048,576 = **302,144,700 bytes maximum**, conservatively below302MiB. No test objects, folder markers, receipt objects, overwrites, duplicate versions or multipart uploads. Require AES256, all four public-access-block flags true, BucketOwnerEnforced, versioning Enabled, and no bucket policy. Lifecycle: current expiration7d, noncurrent expiration7d, abort incomplete multipart1d, plus a separate compatible expired-delete-marker rule. No public ACL/policy, Object Lock, replication or logging destination. Lifecycle is a backstop, not deletion proof.

## Explicit new empty-bucket clock

AWS recommends waiting15minutes after first enabling versioning before object PUT/DELETE activity ([official workflow](https://docs.aws.amazon.com/AmazonS3/latest/userguide/versioning-workflows.html)). `Enabled` alone cannot prove elapsed propagation time. An empty readiness proof cannot prove future VersionIds.

This is a **new <=20-minute custody preparation phase**, outside the old600s carrier and old20-minute whole paid preparation attempt. Acceptance explicitly adds this phase: composed maximum is20minutes custody preparation followed by the original20-minute paid preparation attempt, retaining its ECS/readback reservations. It does not reset either existing clock.

1. Before mutation, freeze nonce identities, account/region, configuration, API/read/C ledger allocations and <=$0.01 hold; verify identity and bucket absence. Collision/403/unknown ownership fails without another name attempt. Only begin when all non-bucket readiness, including helper review, is complete.
2. `custodyStart` is monotonic time immediately before the sole CreateBucket dispatch, recorded also in UTC; deadline=`start+1200s`, including failures/ambiguity. Complete controls and initial empty snapshot by`start+120s`. Set `versioningAck` only upon complete success response to the sole PutBucketVersioning; require it by120s. Missing acknowledgement or mismatched controls fails. No object, compute, role/policy, project, ECR repository or job is created in this phase.
3. While empty, wait until at least`versioningAck+900s`, retaining monotonic/UTC checkpoints. No active wait>60s; at most16 waits are sufficient, with user updates and no polling API calls. Scheduling delay consumes the absolute deadline. No synthetic/fixture/null VersionId and no later observation substitutes for acknowledgement.
4. After the full interval, repeat the complete snapshot and validate it by`start+1080s`, reserving120s for negative cleanup. Each snapshot uses GetBucketLocation, GetBucketEncryption, GetPublicAccessBlock, GetBucketOwnershipControls, GetBucketVersioning, GetBucketLifecycleConfiguration, GetBucketPolicy, ListObjectVersions and ListMultipartUploads. Require exact controls, empty version/upload lists, and specific `NoSuchBucketPolicy`; null LocationConstraint means us-east-1. Other errors/truncation/unknown items fail.
5. Successful `custodyEnd` is when Root validates and retains the second actual snapshot plus elapsed-wait proof. On failure, it is confirmed deletion/absence or final incomplete-cleanup negative, no later than1200s. Use finite request timeouts and remaining-time checks; hanging/ambiguous calls do not extend deadlines. No automatic second phase.
6. Start the carrier immediately after readiness. If a remaining readiness issue prevents that, delete the empty bucket within the original custody deadline; no unattended hold. Once started, bucket cleanup uses the carrier deadline, with no extra teardown clock. Expired incomplete cleanup stays negative with exact residual identities and requires Root's separately reviewed remediation before proceeding.

`carrierStart` remains the timestamp before the first **post-readiness resource mutation**, normally first image PUT. Its600s hard deadline,120s work-start cutoff, <=300s worker,180s closure reservation, one job/no retry and original whole paid attempt deadline remain. All image/source upload, role/project/ECR creation, queue/runtime, input deletion and bucket teardown fit this carrier. No clock may be restarted because staging or cleanup was late.

## Actual versions and evidence

Before the first blob PUT require accepted helper/packet reviews, both bucket snapshots, a proven bounded local upload path and the existing all-reader reservation. Use one single-part PutObject per key, AES256, expected owner where supported, exact size and service-validated SHA256 where the reviewed uploader supports it; hash exact local bytes under the ledger. Disable retries/overwrites. Ambiguous PUT is not retried: reconcile at most once through exact-key version census plus version-specific HeadObject only if existing Root160 slots permit; otherwise stop.

Record actual PutObject responses and nonempty VersionIds other than literal`null`. HeadObject each **explicit version**, checking returned version, size, encryption and any checksum under its documented semantics; ETag is not SHA256. The nine bucket/key/version/size/SHA256 identities enter the input manifest. Freeze source ZIP afterward, then externally pin its bytes/hash and actual VersionId, avoiding self-reference. Worker GetObject uses exact VersionIds; CodeBuild's reviewed sourceVersion/start selects the exact ZIP version and provider readback preserves that join. Desired fields, fixture versions, timestamps or unversioned GETs are not actual custody proof.

Root's API-only tool can prove returned API facts and complete response originals, **not HTTP-wire behavior, hidden retry counts, TLS or bulk-body possession**. Record these as API invocations, disable exposed retries, capture underlying attempts if exposed, and leave unobservable wire behavior unproved. This does not waive the existing exchange-count requirement: resolve any inability to enforce that requirement before launch.

## New finite bucket allocation

Propose a **new40-invocation Root bucket ledger**, independent of Root160 carrier and worker128. This explicitly adds bucket controls; it is not40 spare carrier calls. Combined Root maximum200 API invocations; worker128 remains separate. Count every attempted dispatch before sending, including errors/ambiguity. No retry/page loop/replacement bucket; unused category slots are not fungible.

| Bucket-only operations | Max |
| --- | ---: |
| STS GetCallerIdentity + S3 HeadBucket collision check | 2 |
| CreateBucket + PutPublicAccessBlock + PutBucketOwnershipControls + PutBucketEncryption + PutBucketLifecycleConfiguration + PutBucketVersioning, once each | 6 |
| Initial nine-operation snapshot | 9 |
| Delayed nine-operation snapshot | 9 |
| Teardown: two ListObjectVersions, two ListMultipartUploads, one DeleteBucket, two HeadBucket absence checks, one AbortMultipartUpload only for an exactly attributable anomalous upload | 8 |
| Read-only reconciliation: two HeadBucket, two GetBucketVersioning, one ListObjectVersions, one ListMultipartUploads | 6 |
| **Total** | **40** |

All ten object PUTs/HEADs, service source GET, packet reads, object-version deletion, receipt and compute/IAM/ECR calls stay in **Root160**, with its existing category limits. Exact-version DeleteObjects receives at most two batches within its existing18-call cleanup category; second only for exact versions proved to survive the first, never a blind retry. Freeze actual APIs for the remaining16 cleanup slots before launch. No object work borrows bucket40 slots; no bucket setup borrows carrier slots. Abort authorizes no multipart creation; unknown provenance or multiple uploads makes closure incomplete.

Responses<=64KiB, requests<=16KiB. List calls use MaxKeys/MaxUploads11; positive path allows at most10 exact allowlisted versions, zero markers/uploads. Truncation, an eleventh item, unknown key/version or oversized response is a negative, with no next-page loop. Reserve **256KiB complete bucket originals/ledger**, including>=32KiB negative/closure, from existing C<=8MiB outside transport1MiB. Retain actual API names/arguments, timestamps, request IDs, statuses/errors and complete bounded responses once, with real version/upload/marker IDs; no credentials or signed URLs. Overflow is incomplete evidence, not permission to replace originals with excerpts.

Reserve <=8MiB logical control-read work within the existing256MiB metadata/control portion of the transport8GiB allocation. No new all-reader allocation: full8,416,415,151-byte reservation,20B extra-copy hold, historical Task1 and separate vendor3GiB accounting remain distinct. Source ZIP1MiB/expanded4MiB, parser/image pins, remote256MiBAS+8MiBdisk, local805,306,368 staging, Task1 resolver128MiB and other qualification limits remain unchanged.

## Exact cleanup and cost

After build terminal reconciliation, DeleteObjects uses **Key plus VersionId** for all ten inputs including ZIP; retain per-entry Deleted/Errors originals. Never key-only delete or suspend versioning. Ambiguous writes require actual exact-owned version discovery under the finite schedule. Owned unexpected markers require their actual IDs in the same bounded batch; unrelated/unknown items are not deleted. No recursive/force/account-wide cleanup.

The two fresh bucket teardown censuses each prove no versions/markers or multipart uploads before the sole DeleteBucket. Two HeadBucket observations must establish specific absence, not403/generic failure. An ambiguous delete is reconciled through reserved reads, not blindly repeated. Partial setup follows this path without object deletion because none was authorized. If bounded cleanup cannot establish absence by its deadline, record exact residuals and incomplete closure; lifecycle is not proof of removal and ECS must not proceed.

Propose a distinct **<=$0.01 storage/request hold within authorized$20**, recorded before CreateBucket, alongside and without enlarging the original all-in<=$1 carrier reservation. Each fee has one category; input request fees already in carrier accounting are not charged twice. Root must verify current us-east-1 pricing, <=302,144,700 bytes/ten objects, all bucket requests and the lifecycle retention tail before acceptance. Current expiry can leave a noncurrent version for a further7days; deletion timing is not guaranteed by lifecycle. If the bound cannot be justified, stop before mutation. No new compute/NAT/egress/shared-bucket mutation is granted here.
