# Transport read-work amendment review

2026-10-27. **SPEC: PASS. QUALITY: PASS — resource-only design amendment.** No required correction found; no architecture re-review performed.

Reviewed the final resource section, its focused diff/report and the preserved prior allocation text. All three artifact SHA256s match the freeze report; the preserved body matches the previously reviewed design hash. Current design SHA256: `e941406bd5b4ef0979a72aedab6d92765072e6ea8e3e86d9d160174aa7f817ca`. No code, tests, AWS calls, downloads, native/corpus reads or subagents; only this report was written.

Arithmetic is correct:

- Base: 1,222,768,843 + 3 × 301,096,124 + 268,435,456 = **2,394,492,671** bytes.
- Additional work: 20 × 301,096,124 = **6,021,922,480** bytes.
- Total: **8,416,415,151** bytes; **173,519,441** bytes remain below the separate **8,589,934,592-byte** allocation.
- Historical-plus-transport upper bound: 68,296,145,168 + 8,589,934,592 = **76,886,079,760** bytes.

The new allocation explicitly supersedes the transport4 GiB/6B proposal without resetting or releasing Task1 history. Unique allocation identity, full conservative reservation and disposition are required before reads; interruption grants no restart. The combined historical number is not an individual ceiling. Vendor3 GiB remains separate and excluded from that stated sum.

The20B bound is an allowance to establish against the finite implementation before bulk transfer, not a claimed SDK measurement. Full logical passes/copies and expansion remain charged. The256 MiB logical-work allowance does not enlarge metadata output, memory or storage. Root-local805,306,368-byte staging, remote256 MiB address space plus8 MiB disk, and all call/network/time/control/qualification/cost limits remain unchanged. There is no additional job or retry.

Implementation/accounting validation, custody and fresh all-in <=$1 readiness remain required. This verdict establishes neither runtime fit nor provider acceptance and makes no paid reservation.
