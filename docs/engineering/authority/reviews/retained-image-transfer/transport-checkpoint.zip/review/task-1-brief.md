# Retained image ECR transport implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development. Execute the single deliverable with independent review before Root readiness.

**Goal:** Copy the nine exact retained image blobs to one nonce private ECR repository through a finite CodeBuild worker, without rebuilding or executing the image.

**Architecture:** One standard-library Python worker uses the explicitly trusted managed boto3 runtime. Root freezes a small source packet and nine exact S3 inputs. The worker performs bounded same-attempt capability checks, uploads exact parts and independently reads every registry blob; Root alone creates, starts, reconciles and deletes resources.

**Tech stack:** Python3.12 standard library and preexisting provider boto3/botocore; generated unittest fixtures.

**Spec:** /workspace/scratch/retained-image-ecr-transport-design.md, governing amendment at line177 and subsequent Root final rulings; accepted review /workspace/scratch/transportdesign-review-round1.md. Earlier contradictory proposals are historical, not current requirements.

## Global Constraints

- Private helper only. Existing source builder/packet and revision gates, production publishing and qualification APIs/counts/caps are unchanged.
- Same baseline config9ff28822297fe7989bd62e1244edfcb16c72928fb84b0a74a92834eeb4eee0d4/source db9abbcd59a30d206d85c0dcb2f407150e31dd9e; eight existing compressed blobs in actual manifest order, plus exact8177-byte config. No rebuild, recompression, Docker or target execution.
- Selected CodeBuild standard7.0/Python3.12 provider-runtime trust; no worker dependency installation, Docker, subprocess, background threads, transfer manager, services or alternate transport surface. Nonprivileged SMALL, logs disabled, NO_ARTIFACTS/NO_CACHE.
- Remote-only hard RLIMIT_AS268435456 plus8388608 new disk, joint276824064. Root local staging805306368 and Task1 resolver134217728 are unchanged.
- Returned ECR partSize must be integer5242880..20971520, exact returned nonfinal parts/final unchanged, calculated maximum65 parts for actual nine inputs; no padding. Tiny/config acceptance remains actual same-attempt preflight, not fake-provider proof.
- Worker128 exchanges including credential HTTP/redirects/reconciliation, Root160 separately; new eight-GiB transport allocation and exact conservative ledger in governing design; transport evidence1048576 including65536 negative reserve, C aggregate8388608 shared with ECS.
- Worker<=300s, carrier<=600s including setup/queue/custody/cleanup, work-start cutoff120s and180s closure reservation. No actual launch from this task; Root fresh all-in<=1USD reservation inside user20USD required later.
- Actual provider acceptance, runtime fit, TLS/network/client behavior and cleanup remain open until observed. No K/A/native/provenance/loader/measurement approval.

## Review Focus

- Default SDK credential fetches/retries are real requests and cannot bypass128; retries and redirects have explicit count/deadline guards.
- A config or tiny blob can fail on the actual provider; initial four-blob preflight retains bounded negatives before bulk reads, without an extra job or retry.
- A redirect must never receive ECR Authorization or leak a signed URL; endpoint/host validation precedes the request.
- Memory/copy/read accounting includes serialization, source fetch, retained buffers and failures; no full image/body buffer or disk copy.
- Missing final evidence, ambiguous uploads, late receipts and failed cleanup stay incomplete; no automatic restart or fake success.

### Task 1: Finite worker, source packet and tests

**Files:** create /workspace/scratch/retained-image-ecr-transport/transport.py, test_transport.py, packet.py, test_packet.py, README.md. Support fixtures/artifact generation in the same private directory; no old helper or repo source edits.

**Interfaces:** transport.run_transport(input_manifest, io) -> finite outcome, with fake IO for tests; real entrypoint reads only the exact fixed input.json, validates packet/input/schema/source pins and sets hard guards before SDK import/data. packet.prepare_packet(owned_inputs, blob_metadata, support_pins) -> exact source ZIP/buildspec/input manifest, source/manifest/code refs, predicted request inputs and budgets; no AWS calls or image-body reads in the packet builder. Root will construct actual resource identities/deadlines later. Freeze actual public API names in report if minor idiomatic adaptation is needed.

- [ ] Write failing generated fixtures and capture RED for all Review Focus and governing design required cases, including exact5/20MiB/nonfinal/final/one-over, source/manifest/order/hash joins, credential/call/read/memory/disk/deadline guards, safe redirects/no secrets, SDK retries disabled, early/late evidence and ambiguous closure.
- [ ] Implement finite worker, strict manifest/source inventory, runtime metadata/trust premise and controlled IO. Use one stream/part at a time. Preserve all nine exact input identities and complete blob EOF/hash readbacks, upload/source/registry config/diffID/manifest distinction, fixed nonce/account/region/repository and output keys. Initial config+three smallest blobs are normal required operations, not extra tests.
- [ ] Implement deterministic finite packet and one exact CodeBuild project/start configuration. Avoid source/input/buildspec self-hash cycles: externally pinned ZIP binds the finite members; manifest does not depend on future image/provider hashes. No arbitrary commands or inputs. Packet fixtures are explicitly fake; actual source payload/hash frozen before mutation by Root.
- [ ] Run python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v; GREEN required. No real SDK credentials/calls, corpus/native/layer reads, dependencies/tools installation or old suites.
- [ ] Freeze full code/test/README/packet review subjects, exact source/helper/fixture refs, RED/GREEN logs/commands/exits, full diff packet and budgets. Report /workspace/VRDex/.superpowers/sdd/retained-image-ecr-transport/task-1-report.md. Independent SPEC/QUALITY review required before Root readiness. No commits/push/AWS operations by implementer.

## Governing read-work amendment

Accepted /workspace/scratch/transportdesign-read-work-review.md SPEC/QUALITY PASS. NEW transport allocation8589934592 bytes (8GiB), not a reset or loan from Task1. Conservative additional logical SDK/input/hash/base64/JSON/HTTP work<=20B=6021922480 and source/runtime/generated-preflight/receipt logical work<=268435456. Remaining base categories sum2126057215; total base2394492671 plus20B=8416415151, leaving173519441. Hold full20B regardless of smaller observed path. This supersedes previous4GiB/6B/128MiBwork-category proposals only. Emitted metadata64KiB, source1MiBZIP/4MiBexpanded, remote256MiBAS+8MiBdisk, local staging805306368, network/call/time/control/cost/qualification limits stay unchanged. HistoricalTask1upper68296145168 is retained; oldupper+newtransport=76886079760. Vendor3GiBallocation remains separate. No actual trial/read allocation invocation or dollar reserve yet.
