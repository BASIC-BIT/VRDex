# Task 1 round1 scoped independent review

2026-10-27. **SPEC: PASS for the three corrections and permitted unsupported-path negative. QUALITY: PASS for the scoped fix.** All three original findings are ADDRESSED. No new actionable breakage was found in the fix diff. This verdict does not establish a working real retained-image transport: this revision accepts zero real SDK profiles and cannot upload the image. Root's readiness gap remains open.

Reviewed the original findings, task brief, applicable governing read-work/negative rules, appended report, primary-file changes and new support evidence in the round1 diff. No implementation edits, provider/network/corpus operations, subagents or test executions were performed. The existing GREEN is retained; tests were not rerun. Untouched behavior was consulted only where necessary to follow the changed paths, not broadly re-reviewed.

## Frozen subjects and evidence

Independently matched these supplied SHA256 values with the files read:

| Subject | SHA256 |
| --- | --- |
| `task-1-report.md` | `f590a513ac1e26fd77d92fc8fb398bbb26ee854c29e5a477b9ed6eee3bf11e56` |
| `supportfixtures/round1-fix.diff` | `e9eba6a6d1156019ae3784d80e26ed1a68a487b60ab329d25c63fae4cc4cf2f9` |
| `supportfixtures/round1-review-subjects.json` | `d93647fdaaca99cfed4b058e56091716bb5979915b7c2b9fb6fc335488a4171f` |

Current implementation subjects pinned by that inventory and diff: `transport.py` SHA256 `b4cf9e720ca27ff2d8a9a88ccf3911a2d38be6e349c92c3999a4b50134e71bba`; `packet.py` SHA256 `935710100ddde70e2b87939b58b1fa1bc72332fcfe8cae018de18d42d7119ef2`. Root supplied verification of all19 current subjects with zero mismatches; the worker reports all28 originals preserved. Those exhaustive checks were not repeated here.

The report records the exact bytecode-disabled unittest command and exit0; the retained `round1-green.log` ends `Ran 62 tests in 0.502s` / `OK`. Its inventory SHA256 is `f8a51a799a8f06c1f4b188cfc1e4969e0e60a1efb28e68774a99ce68ca261e6b`. This is generated/mock evidence, not actual SDK/provider acceptance or memory-fit evidence.

## Original finding1: S3 error response guards — ADDRESSED

**SPEC: PASS. QUALITY: PASS.** `transport.py` now grants source-stream treatment only when the active operation is GetObject and the HTTP status is exactly integer200. Errors and other statuses use the64KiB control cap. `BoundedRaw.read` reserves the attempted read before the underlying call, retains that charge on short reads/EOF/exceptions, and charges the overflow probe before rejection. Budget exhaustion prevents the underlying read.

The added regressions cover403/500/206/301 parser streams,65537 attempted/charged bytes for overflow, underlying exceptions, exhausted work allowance and retained successful streaming. The ordinary success stream still relies on the outer source accounting. The exchange and memory ceilings are unchanged by this fix.

## Original finding2: Unestablished SDK work bound accepted — ADDRESSED

**SPEC: PASS under the required unknown-path negative rule. QUALITY: PASS.** The unconditional real acceptance and28/3 estimate have been removed. `RealIO.serialization_preflight` has no supported branch: after bounded diagnostic collection it raises `unsupported_sdk_path`, before generated SDK serialization, token acquisition or image reads. The existing runner retains initiated upload obligations and attempts the bounded final negative. The added runner test checks the pre-image stop, nine upload obligations and final persistence through fake IO.

This is a valid resolution of the unsafe acceptance because the governing amendment explicitly requires stopping when the finite path cannot be bounded. It does not fulfill a successful real transport capability or establish the selected managed SDK's reader closure. A later real support branch still requires the full operation/shape, handler/checksum, request/HTTP/readback and rounding/overhead derivation and focused review before acceptance.

The11 diagnostic roles have bounded bytecode/module-source reads and hashes, charges before consumption, a3072-byte facts cap and explicit unestablished closures. Source hashes confer no support. Generated same-shape serializers with and without an extra reader are both rejected before invocation. The itemized14B candidate and separately calculated generated work are expressly fake-only; tests check5/20MiB arithmetic and runner charging. They supply no real SDK bound. The full20B reservation remains held. Documentation and report disclose this limitation consistently.

## Original finding3: Mutable/non-string code version — ADDRESSED

**SPEC: PASS. QUALITY: PASS.** `packet.py` now requires a nonempty string of at most256 characters and rejects `"null"`. Regressions cover null, empty, None, list, dict, integer, boolean, bytes and oversize values, plus exact valid-version propagation into both project and StartBuild inputs.

This validates the input boundary; Root must still bind an actual immutable source version. The previously reported unversioned intended bucket remains incompatible with the required immutable input/source versions. This fix neither changes that bucket nor supplies a replacement custody design.

## Scope of the pass

No fix-induced blocker was identified. The frozen fixture budget retains256MiB address space,8MiB newly owned disk,128 worker exchanges,8GiB logical allocation and8,416,415,151 reserved bytes including full20B. The scoped pass closes the original three review defects only. Actual real-path support, source custody, provider/runtime/TLS/memory observations, launch/spend readiness, cleanup and qualification remain Root's subsequent work; no such approval follows from this review.
