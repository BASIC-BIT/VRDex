# Task 1 implementation report

2026-10-27. **DONE for independent SPEC/QUALITY review.** No AWS/network/Docker/native/corpus/layer read, resource creation, dependency/tool installation, old helper/repository-source edit, Git command, commit or subagent was used. All generated payloads are fake. Actual provider/runtime acceptance remains open by design. Root alone authorizes and runs any later paid candidate.

Requirements read first: `/workspace/VRDex/.superpowers/sdd/retained-image-ecr-transport/task-1-brief.md`. Governing design is `/workspace/scratch/retained-image-ecr-transport-design.md`, amendment at177 and final resource-only8GiB/20B/256MiB-work amendment. Design SHA256 `e941406bd5b4ef0979a72aedab6d92765072e6ea8e3e86d9d160174aa7f817ca`. Accepted design reviews are `/workspace/scratch/transportdesign-review-round1.md` and `/workspace/scratch/transportdesign-read-work-review.md`. These supersede historical4GiB/6B/128MiB logical-work and56MiB/128MiB remote proposals. Root separately confirmed that the worker binds Root's fresh replay receipt without repeating gzip replay/decompression.

## Delivered interfaces and source boundary

Created only the five requested private source/test/README files plus their own generated support fixtures and this assigned report. The public APIs are exactly `transport.run_transport(input_manifest, io)` and `packet.prepare_packet(owned_inputs, blob_metadata, support_pins)`. `README.md` specifies exact argument/return schemas and Root duties.

The packet is deterministic and contains exactly `transport.py`, `input.json`, `buildspec.yml`. The input pins the worker; the buildspec embeds input SHA256; Root externally pins ZIP/member bytes, avoiding any self-hash cycle. No arbitrary command, installer, dynamic source member or generic registry dispatch is accepted. ZIP and startup tree validations reject duplicates, extras, links/traversal, wrong size/hash and fixtures at the real entrypoint.

The packet's `owned_inputs` includes `allocation_id` and `allocation_receipt_sha256`, binding `transport-read-<nonce>` to the unique separate8GiB ledger reservation. No allocation is actually created by this report. Root must supply actual nine version-bound S3 identities and reviewed fresh replay/custody/allocation references later. `blob_metadata` binds exact configUTF8, compressed descriptors/order/diffIDs and Root replay SHA256. Real baseline constants fix source/config/nine sizes/names/B. Fixture mode bypasses baseline byte identities solely for tests and cannot pass real startup.

`project` and `start` are exact finite request dictionaries for standard7.0/Python3.12, LINUX_CONTAINER/SMALL, nonprivileged, versioned S3 source, NO_ARTIFACTS/NO_CACHE, disabled CloudWatch/S3 logs, five-minute service/queue ceilings and no VPC or secondary inputs. Root must compare provider-returned project/start/build configuration before image transfer under its separate160-control schedule. The worker additionally checks observed managed image and account/project/build identifiers. No real project request was sent.

## Worker behavior and enforcement

Before boto3 import the launcher sets/verifies256MiB soft/hard RLIMIT_AS and starts an absolute alarm. A monotonic elapsed clock is joined to the fixed wall deadline. Remote disk reserves sourceZIP<=1MiB plus exact expanded source<=4MiB, under8MiB total/264MiB joint; no image/output/temporary file is written. Python `-I -B`, no thread/subprocess/transfer manager/installation, one stream and one exact part plus bounded serialization buffers.

Managed boto3/botocore are an explicit provider-runtime trust premise. Actual Python3.12/executable/platform/machine/service image, SDK versions/origins, SSL/urllib and installed dependency closure are captured before source reads, <=32 distributions/64KiB. Writable packet/tmp/user-site imports, unexpected dependency names/API shapes, metadata overflow, missing imports or incompatible runtime produce a same-attempt negative. There is no invented expected patch version or package-byte authentication claim.

Credential HTTP cannot bypass the counter. Only one fixed AWS-container relative-URI request is accepted, no redirects/proxy/default provider chain/auth token/file. Its bounded credential body remains in memory and must expire after deadline+60seconds. Explicit credentials go to boto3; no refresh chain is present. Config total_max_attempts1, one pool connection, one-second connect/read timeouts, no proxies, fixed S3 path addressing; endpoint retries disabled and lower SDK sends counted/endpoint-validated. The selected HTTP implementation's explicit Retry(False)/redirect=False are inspected. Control response bodies are bounded before SDK parsing. No secrets, signed URL/query or raw external exception text enters receipts.

The worker checks fresh-repository availability, initiates nine uploads once and records IDs even when a returned part size fails. Returned integer5..20MiB sizes are used unchanged, computed total<=65, then one largest-size SDK serialization preflight. Source inspection records selected serializer/signing/preparation/HTTP function identities. The selected finite path's conservative estimate28/3 is below20; the full20B is nevertheless held. Generated serialization and runtime/source/receipt work are separately charged. Unsupported shapes or unestablished bounds stop before source reads.

The normal first four blobs are config and three smallest layers. They must each pass exact S3 version/length/hash/EOF, unchanged parts/inclusive integer acknowledgements, complete digest and independent full fixed registry readback before bulk. Short reads are gathered with actual-byte accounting. ContentLength, exact length/EOF/hash and config bytes are checked. One exact allowlisted regional S3 redirect may follow each fixed ECR GET, with a fresh unauthenticated request and no second redirect. TLS verification and identity encoding remain enabled. Manifest publication/readback requires exact bytes/media/config/layer descriptors/digest; diffID and external replay/source joins remain distinct.

Fatal or ambiguous mutations are never retried. The one reconciliation slot is reserved, but this worker chooses a bounded negative instead of continuing an ambiguous mutation. All initiated IDs and successful step references remain cleanup obligations. Root handles termination/reconciliation/custody/cleanup/two censuses and any missing final without restarting.

## Budgets and receipt custody

| Allocation | Bound |
| --- | ---: |
| Normal worker exchanges |116|
| Registry redirects |9|
| Credential/discovery extras |2|
| Guaranteed reconciliation slot |1|
| Absolute worker exchanges |128|
| Root/provider controls, separate |160|
| Parts for actual inputs at5MiB /20MiB |65 /21|
| Hard address space / new disk / joint |268,435,456 /8,388,608 /276,824,064 bytes|
| Evidence / step / final / runtime facts |1,048,576 /49,152 /262,144 /65,536 bytes|
| Worker / carrier / start cutoff / closure reserve |300 /600 /120 /180 seconds|

The new separate read reservation is8,416,415,151 below8,589,934,592, leaving173,519,441. Categories exactly: replay1,222,768,843; local upload301,096,124; streamed source301,096,124; complete readbacks301,096,124; additional copy/hash/SDK/HTTP20B6,021,922,480; generated/runtime/source/receipt/control268,435,456. Root must retain unique allocation/full conservative reservation/disposition before reads; no Task1 history is reset. Worker source/readback/copy/preflight counters reserve before reads. EOF probes and rejected unexpected bytes use bounded preflight work. A32MiB fixed conservative metadata-copy reserve plus generated largest-part28/3 work and actual raw-control/runtime charges fit the256MiB logical-work category. This category is distinct from the256MiB hard address-space cap.

Only exact immutable `<prefix>steps/0.json`..`steps/8.json` and `<prefix>final.json`, conditionally SSE-AES256, are allowed. Step bodies retain exact input version/hash/size, initiation/parts/completion/readback/counters. Final binds steps, runtime, source/replay/allocation and manifest/config/diffID joins, bounded redacted semantic SDK originals and outcome. SDK datetime values use ISO strings; unsafe headers/auth fields are redacted. Original semantic response completeness is bounded; overflows yield negative/incomplete rather than excerpt-only success.

The final body records counters before its own PUT and explicitly reserves that final exchange, avoiding a self-acknowledgement cycle. The returned `observed_counters` includes its actual final attempt. Final write failure/ambiguity/late persistence leaves outcome incomplete. Root must read/retain the actual exact-key object and provider terminal state. Stdout is a fixed <=256-byte nonauthoritative status token. No separate logs/artifact/diagnostic files duplicate the evidence.

The worker requires start<=carrierStart+120, deadline=min(workerStart+300,carrierDeadline-180), with carrierDeadline=carrierStart+600. Before each blob it checks remaining exchange/stream schedule, using one second per exchange and4MiB/s for each stream leg as explicit planning premises. Actual timing remains unproved; the alarm/deadline bounds overruns and Root owns independent stop/closure reserves.

## Tests and commands

Initial RED command, exit1: `python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v`. The generated initial15-test fixtures were written before either implementation module existed; discovery reported two import errors. Full output is `supportfixtures/red.log`. This is an import-stage RED, not a claim that every later expanded assertion individually failed against an earlier behavioral implementation.

After implementing,15 tests passed. Expansion to48 found one fake raw-stream stub lacking the urllib3 keyword signature; the stub was corrected. Expansion to51 passed. Intermediate full logs and accurate commands/results are indexed in `supportfixtures/commands.json`. The initial RED-created two bytecode files were removed from this private directory; all subsequent commands disable bytecode writes.

Final GREEN command, exit0: `PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v`. **51 tests passed**, full output `supportfixtures/green.log`,51 tests in0.322seconds. Tests include generated exact5/20MiB nonfinal+1-byte final payloads, tiny preflight order, returned10MiB acceptance, one-over/boolean/noninteger part sizes, worst-case65/21 counts, source/hash/order/config/diffID/manifest/media joins, source/version/truncation/overlong/hash failures, short reads, credential expiry/mechanism/counts, SDK fixed credentials/retry configuration/endpoints/wire cap, safe/unsafe/second redirects/no auth forwarding/no URL logs, control/evidence/read/disk/deadline/memory/runtime guards, startup limit/alarm ordering, source ZIP/tree tampering, negative secret sanitization, early-stop/late receipt/ambiguous upload/PutImage/step/final persistence and closure behavior. Every SDK/HTTP/runtime seam is fake or mocked; no credential or real provider library was loaded for a request.

Freeze command, exit0: `PYTHONDONTWRITEBYTECODE=1 python /workspace/scratch/retained-image-ecr-transport/supportfixtures/freeze.py`. It builds only generated fake packet inputs, deterministic ZIP and exact review inventory/diff. Do not upload the fake packet. Root must produce and externally freeze the actual source ZIP/input/project/start from reviewed actual metadata before mutation.

## Frozen review subjects

Private root: `/workspace/scratch/retained-image-ecr-transport/`.

| Subject | Bytes | SHA256 |
| --- | ---: | --- |
| transport.py |43042|8d2306a6575f19883696dc5033699ca0d205afeb58e96eed6fec3121d66ca422|
| test_transport.py |26130|89a604c223225a44d5ce0cf61c6788231cb43f263bd487f3fb4ed5ae0ed715b3|
| packet.py |6150|007a46cf718522174b90b6a438881d9693b867842ae718e487e893767d6709ca|
| test_packet.py |8341|567f87ace5dbd33050439438e0556fd590a4dade6c1ae1a8ae888381b875e8e3|
| README.md |13195|5feb5afbcab11a98611dd855c2fc50176e42b6f168b3c19a7d39c87e8a2dba38|
| supportfixtures/review-subjects.json |3086|e6dc4b502984daf38771c5dab105c9acdc12acbfdd2e4ea7713287360d5c20dd|
| supportfixtures/task-1.diff |184037|d527f6a03a85b5abc8a2d3eb542702609a6d90d7ae24262cfd8294a7c19de9b9|
| supportfixtures/fixture-source.zip |15809|bf90a2b7523c42b7afb25f0763a386789ce2fa977abbbf6ac92aac7a6557f239|
| supportfixtures/fixture-input.json |5735|80efa6d5e5c206ebc0740d6a000503dc542a304d689da2b30a2aa94a76dad588|
| supportfixtures/green.log |6694|fb6a28712fe164cb134a6b50477332d81e46dc765eeb9c7719c42f0c419adcfc|
| supportfixtures/red.log |1941|3debb17f29bdd9564f2101ff50804caaf729d1d9e318965f001fc355c2e58095|

The inventory pins every primary/support helper/fixture/command/log subject. The full new-file unified diff contains all source/tests/README/support text and the exact fake ZIP as base64. The inventory/diff are externally pinned by this report, avoiding self-hash cycles. No Git diff/commit was made because the task explicitly forbids Git operations and old repo edits.

## Remaining observations and authority

Independent SPEC/QUALITY review is required before Root readiness. Actual managed SDK API/source shapes, credentials, serialization/memory fit, real config/tiny acceptance, provider TLS/redirects/network throughput, final custody, termination/cleanup and fresh all-in<=1USD reservation remain unobserved. These are expected trial facts, not fake-test approvals. No new resource/spend reservation/allocation execution occurred. No K/A/native/loader/provenance/measurement approval follows.


## Round1 remediation, resumed after environment restart

2026-10-27. **Implementation corrections complete for focused independent re-review; no Root readiness or real transport success is claimed.** Read the brief, preceding persistent report and all three review findings before editing, then the governing design including the final8GiB amendment. Compared current primary files with `supportfixtures/round1-before`: no partial source edits survived. All28 preserved files, including the original report, original full diff/inventory, logs, fixtures and helper, remain unchanged. No Git/provider/network/dependency/native/corpus/image-body operation or subagent was used in this fix round. Only the assigned five private primary files, their own new round1 support files and this report appendix changed.

Finding1 correction: `bounded_sdk_send` gives the image-size/raw-source treatment only to an exact integer HTTP200 GetObject response. Non200 responses, including403/500/206/301, receive the64KiB parser/control cap. `BoundedRaw.read` reserves the attempted control bytes before the underlying read and keeps that conservative charge on short reads, EOF, overflow or exception. Overflow's extra byte is charged; an exhausted logical-work budget prevents the next read entirely. Successful GetObject streaming remains charged by the outer guarded source loop. The generated70000-byte403 regression now stops after65537 bytes with65537 preflight bytes charged and zero source bytes. The128-exchange guard is unchanged.

Finding2 correction: removed the unconditional real `supported=True`, selected28/3 estimate, source-string retry predicate and generated SDK serialization. **There is no accepted real managed-SDK profile and no real acceptance branch in this revision.** Real preflight retains bounded redacted diagnostic method bytecode and regular module-source hashes when available, with unavailable/oversize sources explicit. These identities do not authenticate packages or prove a logical-pass bound. Diagnostics explicitly mark request closure, SDK events, checksums and readback closure unestablished. Source/hash work reserves before consumption; facts are<=3072 bytes and fit the existing4096-byte observations cap. Then `unsupported_sdk_path` stops before generated serialization, token acquisition or any image read. All previously initiated IDs remain cleanup obligations; the normal bounded final negative is still attempted. Earlier runtime/credential/provider failures can of course stop sooner.

The shared `logical_work_model` is an unaudited candidate calculation used by generated FakeIO only. Its itemized additional consumers, in thirds of an input byte, are source HTTP3, assembly3, source SHA2563, base64 encode3, base64 text4, JSON scan4, JSON UTF8 encoding4, signing payload4, request preparation4, HTTP send4, readback HTTP3 and readback SHA2563. Their sum42/3=14B is calculated rather than asserted28/3. Separate source and readback B categories remain held. Generated fake preflight uses allocation3, base64 encode3, base64 text4, JSON scan4 and JSON UTF8 encoding4, totaling18/3=6 times maximum returned part, with each consumer rounded upward. Tests verify both5/20MiB calculations and that the calculated14B factor drives worker copy charging. Full20B is still held in the resource ledger regardless of the fake model. This model has no enabled checksum/event reader contract and does not authorize any actual SDK; a future support change must review complete operation/shape/reader/event/checksum/HTTP/readback closure plus rounding and bounded JSON overhead. Both a generated same-shape serializer and one with an extra payload reader are rejected by the real preflight before either is invoked. No stock SDK/version behavior is invented.

Finding3 correction: `code_version` now requires a nonempty string<=256 characters and rejects `"null"`, matching immutable blob-version validation. Regression cases cover mutable null, empty, None, list, dict, int, bool, bytes and oversize strings, plus exact propagation of a valid immutable string into project and StartBuild requests.

All resource limits are unchanged: the separate8GiB ledger holds8,416,415,151 bytes including full20B=6,021,922,480 and268,435,456 logical metadata/generated/control work; remote268,435,456 AS plus8,388,608 disk; worker128 exchanges. The intended unversioned-bucket incompatibility remains Root's custody/design decision. No bucket mutation, fabricated version or launch was performed.

### Round1 commands and exact outputs

New regressions were written first. RED command, exit1:

`PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v > /workspace/scratch/retained-image-ecr-transport/supportfixtures/round1-red.log 2>&1`

Exact full output is `supportfixtures/round1-red.log`; terminal summary is `Ran 60 tests in 0.525s` and `FAILED (failures=8, errors=5)`. The existing51 tests passed; failures reproduced the reviewed guards and errors included missing new calculation/diagnostic APIs plus the original integer/bool length exception. This is not a claim that every new assertion was individually behavior-RED.

First GREEN used the identical command with output path `supportfixtures/round1-green-attempt1.log`, exit0. Its exact full output is retained: `Ran 60 tests in 0.526s`, `OK`. Two additional verification tests then checked calculated worker charging and an actual generated extra-reader function; no separate RED is claimed for those later tests.

Final GREEN command, exit0:

`PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/retained-image-ecr-transport -p 'test_*.py' -v > /workspace/scratch/retained-image-ecr-transport/supportfixtures/round1-green.log 2>&1`

Exact full output is `supportfixtures/round1-green.log`, ending:

```text
----------------------------------------------------------------------
Ran 62 tests in 0.502s

OK
```

Freeze command, exit0, generated fake packet only:

`PYTHONDONTWRITEBYTECODE=1 python /workspace/scratch/retained-image-ecr-transport/supportfixtures/round1-freeze.py`

The helper creates fresh `round1-fixture-*` files without overwriting the initial fake packet. Its source/test/README diff uses the preserved original as the baseline, includes new round1 text/fixture subjects in full and includes the exact new fake ZIP as base64. It verifies every inventoried current subject and all28 preserved originals. Commands/results are retained in `supportfixtures/round1-commands.json`. Final freeze output:

```text
round1-review-subjects.json bytes=2438 sha256=d93647fdaaca99cfed4b058e56091716bb5979915b7c2b9fb6fc335488a4171f
round1-fix.diff bytes=113829 sha256=e9eba6a6d1156019ae3784d80e26ed1a68a487b60ab329d25c63fae4cc4cf2f9
round1-original-inventory.json bytes=3427 sha256=460c3f41f6859bec2a5522762f588bf21cda7bc6cf2a5001b5f014e180b453aa
verified 19 current subjects and 28 preserved originals
```

### Round1 frozen subjects and remaining concerns

The following replace the earlier primary-file refs for this review. The initial inventory/diff/fixtures remain preserved historical subjects; use the new round1 inventory/diff for the corrected implementation. This appended report externally pins the new inventory/diff, avoiding self-reference.

| Subject | Bytes | SHA256 |
| --- | ---: | --- |
|transport.py|46468|b4cf9e720ca27ff2d8a9a88ccf3911a2d38be6e349c92c3999a4b50134e71bba|
|test_transport.py|33218|3fb82587dba7d2eac9bdd3f394a0d9cda4f34984552a6c6b61d5dd4e6a4db6c5|
|packet.py|6198|935710100ddde70e2b87939b58b1fa1bc72332fcfe8cae018de18d42d7119ef2|
|test_packet.py|9131|4bf5cf19185e673b6821dcc441eccd5e757f5165adcd15f5b36ecf900972dc46|
|README.md|14905|9c736f97a6524989405b693435830e696a4a969fbdaa9ce8440ac8e2301c26d2|
|supportfixtures/round1-fixture-source.zip|16906|422588acbfb136bcc384366754c79cedec7c84763697d07421f60bd61127d78e|
|supportfixtures/round1-green.log|8530|f8a51a799a8f06c1f4b188cfc1e4969e0e60a1efb28e68774a99ce68ca261e6b|

Focused independent SPEC/QUALITY re-review remains required. An actual attempt with this exact revision can only yield a useful unsupported negative before image reads if runtime/credentials/control setup reach preflight; it cannot upload the retained image. Root decides whether that paid negative would add useful evidence. Real SDK support requires a later reviewed implementation with possessed/audited reader closure, not an unknown source hash, a larger reservation or fake arithmetic. Actual provider control acceptance, memory/TLS/runtime fit, final custody and cleanup remain unobserved. This fix grants no launch/spend/readiness, K/A, loader, provenance, native or measurement approval.
