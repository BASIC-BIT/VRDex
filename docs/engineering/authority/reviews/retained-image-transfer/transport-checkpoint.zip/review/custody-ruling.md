# Root input custody disposition

Accept the scoped design in `/workspace/scratch/versioned-input-custody-amendment.md`, SHA256 `3c5e5185d11ae4ff098cd9573fd8abcf0a6f4419b435f935abec55f950472810`, following independent SPEC/QUALITY PASS in `/workspace/scratch/versioned-input-custody-review.md`. This is design acceptance only; no resource allocation, bucket mutation, cost hold or launch occurs here.

The review sequencing clarification is binding. Review the deterministic packet generator and exact source/buildspec template before bucket preparation. Real image PUTs and their verified VersionIds necessarily precede instantiation of the final source ZIP. Freeze and inspect that complete instantiated ZIP before its upload, project creation and StartBuild. A template pin is never the final ZIP pin. The externally returned source VersionId is then bound in actual project/start requests; it does not alter ZIP contents.

Version-specific IAM must use `s3:GetObjectVersion` for exact input/source versions and `s3:DeleteObjectVersion` for Root deletion, with exact bucket/key scope. Bucket configuration/list permissions and CodeBuild sourceVersion semantics remain concrete prelaunch checks. No generic GetObject permission is substituted as proof of version-specific access.

The SDK support gap takes precedence. Do not create the input bucket, stage image data or create ECR while real SDK support is absent. First design and independently review a finite source-inspection job that can obtain complete selected source bodies and consumer facts. Hashes alone do not establish a reader closure. Diagnostic sizing and its separate attempt/cost/read allocation must be concrete before action.

The proposed custody allocation remains conditional. The 40 bucket API calls, 20-minute empty preparation phase and proposed one-cent storage/request hold are explicit new allocations, with all existing carrier and qualification limits retained. Fresh cost/cleanup/sufficiency checks and all named readiness gaps remain open. No production admission, capacity measurement or native approval follows.
