# Task 1 implementation report

Status: DONE for Task 1 implementation; frozen for independent peer review. No commit or push made. Root owns Task 2, broader verification, local function analysis and integration.

## Changes

- Added the exact JSDoc CapacityInput and CapacityResolver contracts, entries/result types, explicit inner input annotation, production resolver annotation and measured-snapshot resolver parameter annotation. The production measured map remains empty; this production capacity module changed only in JSDoc.
- Wrapped the complete schedule mutation registration in createScheduleEventMediaWorker, preserving inference. Fresh allocation and validateMeasuredSnapshot(validateAllocationSnapshot(...), resolveAllocation) use the same explicit dependency. The deployed scheduleEventMediaWorker still binds resolveWorkerAllocation. The ordinary factory stays in events.ts.
- Added the single named loadEventsWithFixtureCapacity loader, which spreads real exports and replaces only scheduleEventMediaWorker. Seven listed scheduling fixture maps opt in without changing other entries. Existing authorization, time, account, session, immutable-settings, frozen-membership, destination and resource assertions remain intact.
- Added a test-only resolver covering all VIDEO_PROFILES keys and both simulcast states with exactly {cpuUnits:4096,memoryMiB:8192,evidenceId:"fixture-capacity-v1"}. allocatedSession uses that resolver. Its options now have an explicit JSDoc type to preserve the concrete preset contract.
- Added four named admission tests. Fresh production rejection compares complete session/program/command/audit contents before and after. Persisted rejection creates a real scheduled fixture session via a test-module-only alias while retaining the default production registration in the same convexTest database, then proves production rejection preserves all existing rows. The separate-instance isolation test proves fixture admission does not affect default rejection. Evidence and destination-profile tampering separately hit the two real validators and preserve complete state on rejection.
- event-broadcast-output has no scheduling loader. Its two existing taskDefinitionFor calls now explicitly receive fixtureCapacityResolver as the existing third argument because their allocatedSession snapshots are synthetic. The same caller-specific change applies to the existing taskDefinitionFor call in event-media-worker. Root confirmed this caller migration is within Task 1. All prior assertions remain.
- The narrow direct-seeded event-broadcast-control fixture and generated API are unchanged. No bridge production source, migration contract/fixture/receipt, schema, environment, CI or packaging changes.

## RED and GREEN evidence

Every shell activated /workspace/vrdex-env.sh. Meaningful Node child tests and the normal typecheck guard ran with require_escalated due the documented sandbox piped-stdio corruption. Toolchain observed Node v24.19.0 and pnpm 10.15.1.

| Command | Exit | Result | Log |
| --- | --- | --- | --- |
| node --conditions=import --import tsx --test tests/backend/event-broadcast-capacity-admission.test.ts | 1 | RED before production changes: 4 tests, 1 pass, 3 failures, 0 skipped. The default rejection passed; missing createScheduleEventMediaWorker and missing loader caused the expected failures. No bootstrap/type failure. | task-1-red.log, task-1-red.exit |
| node --conditions=import --import tsx --test tests/backend/event-broadcast-capacity-admission.test.ts tests/backend/event-broadcast-settings.test.ts tests/backend/event-output-authorization.test.ts | 0 | 32 tests, 32 pass, 0 fail, 0 skipped. | task-1-green.log, task-1-green.exit |
| pnpm typecheck:backend | 0 | Normal pretypecheck guard and tsc --noEmit --project convex/tsconfig.json passed. | task-1-typecheck.log, task-1-typecheck.exit |
| node --conditions=import --import tsx --test tests/backend/event-broadcast-capacity-admission.test.ts | 0 | Final admission-only check: 4 tests, 4 pass, 0 fail, 0 skipped. After the 32-test GREEN, replaced the temporary RED-phase dynamic loader wrapper with a direct import/use of the required named loader. This changed only this test file and justified the narrow rerun. Production files did not change after the typecheck. | task-1-final-admission.log, task-1-final-admission.exit |

All logs and exit files are next to this report. No broad suites were run, per the explicit task instruction reserving those for Root after Task 2.

## Inspection and remaining verification

- git diff --check passed. git diff --exit-code -- convex/_generated tests/backend/event-broadcast-control.test.ts passed.
- Compared production capacity runtime text with HEAD after removing comments/whitespace: identical. Inspected empty measured map, unchanged production default binding, both real nested validators and resolver use at both sites, and absence of production fixture imports. Source has one default exported scheduler registration. This is a source inspection, not deployment analysis.
- TypeScript compiler inspection confirmed the inner resolve input has type CapacityInput and its explicit @param tag is recognized.
- No new any, casts, public arguments, environment capacity authority, mutable setters, module mocks, packages or generic fixture framework.
- Root must still run the planned affected-file/full backend and script verification, including the unchanged control fixture, MCP checks, and supported local analyzed-function query. Do not infer deployed function names from unchanged generated files. No services, network/provider/AWS/Docker/native/hosted operations were run here.
- Positive production admission remains blocked by missing measurements. The unchanged actual-admission migration gate remains red; these unit results establish no whole-flow/CI readiness.

Exact source subjects, bytes, modes and SHA-256 values are frozen in task-1-worktree-hashes.json. It also hashes this report and the verification evidence. No unresolved implementation concern found within Task 1; peer review and later verification remain pending.
