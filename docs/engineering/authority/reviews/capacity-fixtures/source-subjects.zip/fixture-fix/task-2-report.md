# Task 2 implementation report

Status: DONE for Task 2 implementation; four-file subject frozen for independent review. No commit or push. Base and HEAD at handoff: `dc249a52a9463d7f38be2db8a2935bba202a20c8`.

## Changes

- Added the explicit resolver option to public `runBridge` and appended dependency options to `claimAndProcess`, preserving existing positional arguments and production defaults. The same resolver passes through `runBridge -> claimAndProcess -> startCommand -> registerTaskDefinition -> taskDefinitionFor`. New annotations reuse the JSDoc-imported `CapacityResolver`; existing clock, signal and wait options keep inference from their defaults.
- Production admission, both snapshot validators, release/error reporting, launch marker, RunTask, ownership and cleanup behavior are unchanged. There are no config/parser/environment authority changes or Lambda production changes.
- Added `default bridge releases rejected synthetic snapshot without launch`. A structurally valid synthetic command receives admission on the real default bridge path, produces no AWS calls, keeps its assigned dispatch identity, calls the exact release identity, and emits exactly the existing `event_media_ecs_dispatch_failed` session event via a test-scoped Node console mock. The complete mutation sequence excludes both `markLaunchAttempt` and fallback `recordEventMediaWorkerBridgeTaskStatus`.
- Lifecycle scheduling uses Task 1's `loadEventsWithFixtureCapacity` TS module loader. Positive direct calls and loop options receive `fixtureCapacityResolver`. The actual registered JSON independently asserts task CPU `"4096"`, memory `"8192"`, container CPU `4096` and memory `8192`, preserving RunTask ownership-tag assertions.
- Lambda launch uses an explicit `createLambdaHandler` runBridge wrapper that spreads the Lambda options and injects the resolver into the real bridge. Its expected definition uses the same resolver, with four literal resource assertions plus full serialized registration equality. Existing dispatch/marker ordering, client token, no overrides, environment equality and registration assertions remain.
- Capacity tests consume shared `allocatedSession` and `fixtureCapacityResolver`, retain independent literal allocation expectations and strict malformed input/allocation/evidence/profile tests, and expand production rejection to all six presets and both simulcast states.

## Test-first evidence and fixture debugging

All test commands used the pinned environment and `require_escalated` because of the documented sandbox child-process pipe corruption. Each command redirects complete output and stores its actual exit in the paired `.exit` file.

Two-file RED command:

`node --import tsx --test tests/scripts/event-media-bridge-lifecycle.test.mjs tests/scripts/event-media-lambda-bridge.test.mjs`

Four-file acceptance command:

`node --import tsx --test tests/scripts/event-broadcast-capacity.test.mjs tests/scripts/event-media-bridge-lifecycle.test.mjs tests/scripts/event-media-lambda-bridge.test.mjs tests/scripts/event-broadcast-migration-rehearsal.test.ts`

| Run | Exit | Counts and result | Evidence |
| --- | --- | --- | --- |
| Initial two-file RED attempt, before production changes | 1 | Interrupted lifecycle child after 42 seconds because its existing final launch-marker test could loop indefinitely when missing resolver propagation prevented the marker that advances its test clock. Only this owned child received SIGTERM; the test parent then completed. Reporter recorded 17 test/file results, 15 pass and 2 fail (terminated lifecycle file and Lambda missing registration). These are incomplete lifecycle counts, not a completed RED suite. | `task-2-red-interrupted.log`, `task-2-red-interrupted.exit` |
| Completed two-file RED, still before production changes | 1 | 40 tests, 36 pass, 4 fail, 0 cancelled/skipped. New default rejection passes. Expected failures: positive direct task registration absent, registration-deadline boundary cannot progress, accepted-marker fixture cannot reach marker, Lambda registration absent. Dispatch-failed logs show production rejection; no bootstrap/import failure. | `task-2-red.log`, `task-2-red.exit` |
| First four-file acceptance after propagation | 1 | 124 tests, 123 pass, 1 fail, 0 cancelled/skipped. Accepted-marker lifecycle fixture still could not finish registration/drain. | `task-2-green-incomplete-fixture.log`, `task-2-green-incomplete-fixture.exit` |
| Final four-file acceptance | 0 | 124 tests, 124 pass, 0 fail/cancelled/skipped. Externally bounded with `timeout 60s` around the exact acceptance command above. | `task-2-green.log`, `task-2-green.exit` |

The initial RED exposed an unbounded test loop. Added a test-only bounded wait assertion to the existing accepted-marker fixture. It throws from the wait awaited inside `runBridge`, so the real bridge's existing `finally` removes signal listeners and the caller awaits that same rejected promise; there is no raced background loop or abandoned bridge promise. All original launch-order and cleanup assertions remain.

The first acceptance failure exposed a second, pre-existing fixture omission: lifecycle shared config lacked `region`. Real `startCommand` sends `computeRuntime.region = config.region`, while `recordDispatchedTask` requires a string through `computeRuntimeValidator`. Previously capacity rejection hid that later boundary. Root reviewed the concrete mismatch and authorized adding `region: 'us-east-1'` only to the test config. No production fallback or validator change. That single fixture completion produced final 124/124 GREEN.

## Scope and remaining verification

- `git diff --check` passed. `git status --short` contains only the four listed source/test paths. The hash manifest freezes their exact bytes/modes/SHA-256 and this report plus all run evidence.
- No changes to the production measured map/default scheduler, generated API, migration driver/tests/fixture/receipt, direct-seeded control fixture, environment definitions, CI, packages, or packaging. Synthetic capacity remains the Task 1 shared test allocation. No new casts, `any`, module mocks, mutable authority or public RPC arguments.
- The unchanged migration unit contract passed, including failed protocol-lifecycle receipt, no real-admission and successful cleanup while production map stays empty. No actual whole-flow rehearsal was run. Positive production admission remains blocked on measurements and the original CI migration gate remains red.
- Root owns full backend/scripts suites, normal typechecks and local analyzed-function verification after review/commit. No broad suite or redundant acceptance run beyond the failed-fixture correction was performed here. Focused unit success does not establish merge or whole-flow readiness.
- No actual network/AWS/provider/Docker/native-media/services/hosted operations. Existing tests use their offline HTTP/AWS fakes and local Node subprocess fixtures.
- Process deviation: the two initial read-only orientation shells (`pwd`/file discovery, then reading AGENTS/brief) ran before I loaded the brief's pinning requirement and did not source the environment. Every later shell, all edits and all tests sourced `/workspace/vrdex-env.sh`. No test evidence relies on those initial shells.

No unresolved implementation concern within Task 2. Peer review and Root's later verification remain pending.

## Verification fix round 1 of 5

Status: DONE; three-file test-only fix frozen for independent review. Base/HEAD `b6b338a664630c9fa4237e43932ef2b36cbbc372`. Root explicitly paused the native-helper writer and authorized this sole implementation writer. No commit or push.

Root's ruling in `progress.md` extends scope to three backend test files. Detailed pre-edit causes and exact affected callers are recorded in `verification-fixture-findings.md`.

- `event-broadcast-control.test.ts`: opted only its existing events module entry into `loadEventsWithFixtureCapacity`, preserving every other module entry. Compared the full nested direct-seeded `schedule` helper against BASE programmatically: byte-for-byte identical. The four later real replacement/new-event schedule paths now receive explicit synthetic authority while retaining their existing control/idempotency/migration assertions.
- `event-broadcast-worker.test.ts`: imported the existing fixture resolver and supplied it through the existing fifth bridge argument at all eight listed start/retry call sites. F1 retains its real default offline fake-CLI runner through an explicit `undefined` third argument; no real AWS command is used. Completed exactly three successful-launch test configs with `region: 'us-east-1'` so real compute-runtime validation reaches the intended record boundary. Stop-only and denied/unknown admission callers remain unchanged.
- The competing-bridge test now races registration against an explicit rejection if its first claim finishes before registration. A `finally` always releases its owned registration hold and awaits that same first claim, including if the second claim fails. Original exactly-one-RunTask, winner definition/task, losing-definition cleanup and cleanup audit assertions remain unchanged. No timeout race abandons an owned bridge promise.
- `event-media-worker.test.ts`: retained the original pre-revocation `hasPublicUrl === true` assertion, captures the former source/key, requires exact empty choices after revocation, and verifies a real stale-key command rejects `/unavailable/i` without refreshing the worker. This replaces a dereference of the intentionally removed row and strengthens the source-authority rejection check.

RED evidence is the existing `verification-01-backend.log` and paired `verification-01-backend.exit.json`, plus `verification-backend-interruption.json`: `pnpm test:backend`, exit 1, reported 1999 tests / 1984 pass / 15 fail / 0 cancelled/skipped. Root terminated the sole stalled owned worker test child; this is an interrupted broad baseline with incomplete post-stall coverage. The detailed fifteen failures and stalled handshake were retained; no stalled RED or broad suite was repeated for this fix.

GREEN command (sourced `/workspace/vrdex-env.sh`, `require_escalated` for the known sandbox child-pipe issue):

`timeout 120s node --conditions=import --import tsx --test tests/backend/event-broadcast-control.test.ts tests/backend/event-broadcast-worker.test.ts tests/backend/event-media-worker.test.ts`

Result: exit 0, 288 tests / 288 pass / 0 fail / 0 cancelled/skipped/todo, 2556.913731 ms. Full output: `verification-fix1-focused.log`; actual exit: `verification-fix1-focused.exit`. Verified named passing results for all eighteen impacted logical cases, including the formerly false-positive config case, stalled competing case and previously blocked duplicate-marker case. No additional test run was necessary.

`git diff --check` passed. `git status --short` shows exactly the three authorized backend test files. No production/shared-helper/environment/CI/schema/migration source changes, package changes, new casts/any or production authority changes. The production negative tests and shared 4096/8192 synthetic allocation are unchanged. Root owns subsequent full backend verification after review; this focused result is not a claim of whole-flow, merge or CI readiness.

Exact source bytes/modes/hashes, BASE blob identities, report and RED/GREEN evidence hashes are frozen in `verification-fix1-worktree-hashes.json`. Earlier `task-2-worktree-hashes.json` remains the historical original Task 2 handoff manifest; this appended report's current hash belongs to the new fix manifest. No unresolved concern within this authorized fix.
