# Verification fixture findings

Read-only diagnosis of the interrupted backend verification. No source edits and no additional test runs were performed in this investigation. Root retains the sole-writer coordination; implementation is not started here.

## Evidence and result limits

- Actual log: `.superpowers/sdd/capacity-unit-test-seam/verification-01-backend.log`; exit metadata: `verification-01-backend.exit.json`; owned-child termination receipt: `verification-backend-interruption.json`.
- Command `pnpm test:backend` exited 1. Reporter: 1999 tests, 1984 pass, 15 fail, 0 cancelled/skipped. Four control failures, ten bridge-worker assertion failures and one media-worker TypeError are named in the log. Root stopped the sole stalled `event-broadcast-worker.test.ts` child at 294 seconds. Tests after that stall do not have complete execution evidence; do not call this a completed backend baseline or infer later cases pass.
- `verify_capacity_seam_host` confirmed this was one broad run followed by the Root-authorized SIGTERM, with no targeted reproductions. Log and source trace are sufficient for the causes below; no redundant run was needed.
- Line numbers below refer to the source observed during this read-only investigation.

## 1. Control replacement scheduling still uses production capacity

Path: `tests/backend/event-broadcast-control.test.ts`.

The modules map at lines 15–23 still loads ordinary `../../convex/events` (line 17). `setupFixture` uses this map (line 29). Its narrow `schedule` helper directly seeds a control session at lines 87–137, so most control tests avoid capacity as designed. Four tests later deliberately call the real scheduler:

| Call line | Test | Observed failure |
| --- | --- | --- |
| 907 | idempotency scopes stable actors and replacement sessions | Unproved broadcast configuration |
| 1329 | migration never revives removed public profile links or old commands | Unproved broadcast configuration |
| 1329 | migration never revives hidden public profile links or old commands | Unproved broadcast configuration |
| 1419 | idempotency keys do not collide between events | Unproved broadcast configuration |

Each exact stack reaches `convex/events.ts:3815`, fresh allocation. The production registration at `convex/events.ts:3914` binds `resolveWorkerAllocation`, whose measured map is empty. This is a missing fixture opt-in, not a scheduling validator defect.

Minimal test-only fix: import the existing `loadEventsWithFixtureCapacity` and use it for the events entry in this file's modules map, matching the existing worker/media-worker maps and Task 1 pattern. Keep the entire narrow direct-seeded schedule helper unchanged. The replacement/new-event calls then exercise real scheduling, both real validators, authorization and original control/idempotency/migration assertions with explicit synthetic authority. Do not replace these four calls with additional seeding or edit migration production/receipt behavior.

## 2. Backend bridge start callers omit the new explicit dependency

Path: `tests/backend/event-broadcast-worker.test.ts`.

Scheduling already uses `loadEventsWithFixtureCapacity` at line 16, so the command session snapshots contain the valid synthetic allocation. This file imports only `claimAndProcess` at line 477 and never imports/passes `fixtureCapacityResolver` to its bridge starts.

Deterministic trace: `claimAndProcess` defaults to production at `scripts/event-media-ecs-bridge.mjs:476`; admitted start sets dispatch identity at 366 and calls registration at 377; registration constructs the task JSON at 307 through the real `taskDefinitionFor`; that calls structural and measured validation. The production measured resolver rejects synthetic capacity before the AWS runner is invoked. The catch at lines 380–384 calls real `releaseUnlaunchedDispatch`, which clears the persisted session dispatch. Consequently tests targeting later launch ambiguity instead observe a safely released prelaunch session. The log's dispatch-failed event is the unchanged ambiguity-safe reporting path, not evidence that their intended later boundary was reached.

| Call site(s) | Cases and observed effect | Minimal change |
| --- | --- | --- |
| 617; same-test retry at 624 | F1 admitted run-task and registration-response failures (2 failures at 619: missing dispatchId) | Pass fixture resolver through fifth dependency argument; retain default CLI runner with explicit `undefined` third argument and normal draining callback. Apply same dependency to retry for consistency. |
| 1647 | R8 config/register failures (register case fails at 1648 because runner never called) | Inject fixture resolver for both variants. Config variant currently passes for the wrong earlier capacity reason; fixture resolver restores the intended missing-secret error before AWS. |
| 1689 | R8 ambiguous before/after/malformed/unknown/run/record (6 failures at 1693: missing dispatchId) | Pass same fixture resolver through existing fake runner call. Keep all marker, release-count, RunTask-count and persisted-task assertions. |
| 1698 | R8 Stop before marker (failure at 1702: cleanup flag undefined) | Inject fixture resolver so registration can issue the controlled stop and real marker/release/cleanup logic runs. |
| 1719 and 1721 | R8 reclaimed competing bridges; sole stalled test | Inject fixture resolver in both competing claims. Otherwise first never enters fake registration and `registered` never resolves. |
| 1729 | R8 duplicate marker (after the stalled case, not reported as executed) | Inject fixture resolver so duplicate marker actually runs and recorded winner definition can be asserted. |

These are eight start/retry call sites and thirteen logical test cases including one currently passing for the wrong reason and two blocked by/at the stall. Stop-only calls elsewhere and tests stopping at explicit denied/unknown/malformed admission do not build a task definition; they need no capacity authority change. No generic wrapper or mutable resolver setter is needed.

### Hidden next-boundary fixture omission: region

The same three successful-launch configurations omit `region`:

- F1 config at line 615 (needed in registration-response variant; completing shared config for both variants is appropriate).
- R8 ambiguity config at line 1689 (needed in record-response-loss variant).
- Competing config at line 1710 (needed by the winning bridge).

Real bridge `startCommand` always sends `computeRuntime.region = config.region` at line 407. `convex/eventMediaWorker.ts:552` validates through `computeRuntimeValidator`, whose `region` is a required string at `convex/_eventBroadcastResources.ts:20`. Undefined fails before the intended record-side effect and would leave these assertions red after resolver injection. The existing Task 2 lifecycle fixture was fixed identically with `region: 'us-east-1'`. Complete these test configs with that literal; do not add any production fallback or weaken compute-runtime validation. Other prelaunch-only configs can remain as-is because they never reach this boundary.

### Make the competing fixture fail without abandoning its owned claim

The existing code at 1708–1722 starts `first`, awaits a separate `registered` promise indefinitely, and only later releases its owned `firstHeld` promise. Capacity rejection lets `first` finish but never resolves `registered`, explaining the sole child stall.

Preserve all winner/loser/cleanup/audit assertions. Have the registration handshake also fail if the first claim completes before registration (for example, race `registered` with a rejecting continuation of `first`). Enclose the ownership sequence in `try/finally` that always invokes `firstRelease()` and awaits the owned first claim, including if the second claim/assertion fails. Use an external bounded test-command deadline too. Avoid adding a timeout race that abandons an unresolved owned bridge promise. This is test failure/cleanup robustness, not production launch behavior.

## 3. Revoked projected source is removed from operator choices

Path: `tests/backend/event-media-worker.test.ts`, `operator_stops_offering_revoked_profile_source_before_worker_refresh`, lines 361–375.

Observed error at 373 is `Cannot read properties of undefined (reading 'hasPublicUrl')`, after the test removes the profile's outbound link at 371. This is unrelated to capacity.

The status query uses `listUsableEventMediaSources` at `convex/events.ts:2434`. That helper filters every source through `eventMediaSourceProjectionAvailable` (`convex/_eventBroadcastSources.ts:110–154`). With outboundLinks removed, the projected slot has no resolved public input (125–133); its stale persisted source row is excluded at 147. The correct result for this single-source fixture is `after.sources = []`, not an unavailable row. The mutation already rejects a stale projected source through the explicit `Event media source is unavailable.` guard at `convex/events.ts:2589`.

Minimal test-only correction: retain the usable pre-removal source/key from `before.sources[0]` and its existing `hasPublicUrl === true` assertion; after revocation assert exact empty source choices (`assert.deepEqual(after.sources, [])`); submit `switch_source` using the captured former key and assert rejection `/unavailable/i`. This strengthens the stated contract: removed choice plus rejection of the stale formerly valid key. It does not loosen source authority or silently accept an empty index. Keep acquisition before revocation and do not refresh the worker before testing status/command rejection.

## Required implementation scope and verification

Only these three test files need source changes. No production code, measured map, scheduler/default registration, migration contract/fixture/receipt, schema, dependencies, environment, CI or deployment changes are required. Keep the existing synthetic 4096/8192 allocation/evidence and direct-seeded control helper unchanged. No assertion removal, broader rejection matcher, casts, `any`, generic fixture framework or module mocking is needed.

Root should authorize one source writer after the native-helper work is paused. Preserve the recorded full-backend failures as RED evidence, then run a bounded targeted selection covering these four control cases, all F1/R8 bridge starts listed above (including config and post-stall duplicate marker), and the one media-worker source case. Meaningful Node child tests require `require_escalated` and the pinned `/workspace/vrdex-env.sh` environment. A full backend rerun belongs to Root's subsequent verification after reviewed fixes; do not run another broad suite to rediscover these deterministic fixture gaps.

Observed artifact hashes:

| Path | SHA-256 |
| --- | --- |
| `tests/backend/event-broadcast-control.test.ts` | `d2115e62659d9bf96b63161cca7b2b4803b5fdf716587c2b5a91984f63b1dcf6` |
| `tests/backend/event-broadcast-worker.test.ts` | `d85170ec11979f7fd55dcfc0ed6e45767a9735d02d6eaa1f8b0444197f384bd3` |
| `tests/backend/event-media-worker.test.ts` | `9fab0d937855d5b1d9d1df2d07d985312e397a1dbc8012e0459551f14aff9475` |
| `.superpowers/sdd/capacity-unit-test-seam/verification-01-backend.log` | `69d5cfa21a7dba9dd92728a16c276c6653755ef86a1bc0107fd0efd44e24936f` |
