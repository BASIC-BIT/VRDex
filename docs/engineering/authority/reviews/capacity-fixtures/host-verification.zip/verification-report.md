# Capacity seam full verification report

Current result: **backend 2019/2019 passed** at `032307dd76ed56a977c7b6458fc5df8587f1f775`. Scripts passed with **979 passes and six skips**; MCP verification and both Temporal commands passed. Real production admission and the whole-flow migration gate remain open, blocked on measured production capacity.

## Current verified result after fixture corrections: PASS

The corrected backend suite passes completely. The initial interrupted run, its failures, logs, and intervention record are preserved in the historical sections below.

- Current verified HEAD: `032307dd76ed56a977c7b6458fc5df8587f1f775`, branch `codex/recoverable-stream-qualification`, clean working tree before and after the rerun.
- Only three backend test files changed from the prior verified subject `b6b338a664630c9fa4237e43932ef2b36cbbc372`; no production/shared-helper/script/Temporal file changed.
- Command: `pnpm test:backend`, once, pinned environment activated, host escalation for Node piped-stdio behavior, 1200-second watchdog.
- UTC start `2026-10-26T22:02:22.363696+00:00`; end `2026-10-26T22:03:02.643849+00:00`.
- Actual parent exit **0**, watchdog **not fired**, no interruption.
- **2019 tests, 133 suites, 2019 passes, 0 failures, 0 cancelled, 0 skipped, 0 todo**; reported duration 40019.986343 ms.
- Full output `verification-07-backend-fixed.log`; exact exit metadata `verification-07-backend-fixed.exit.json`; all tracked-file identities in `verification-07-backend-fixed.subject-before.json` and `verification-07-backend-fixed.subject-after.json`. Every tracked byte remained identical across this rerun.

Corrected backend test file SHA256:

- `tests/backend/event-broadcast-control.test.ts`: `1f3a0fd7c485395004026a5f8f2a0294ad32a58a4cbb38225d8f09d99e567eb0`
- `tests/backend/event-broadcast-worker.test.ts`: `a8783b8ceedad6b8da669b3f9894bec7bcfeaad7617a77497fa4a3af57d88cd9`
- `tests/backend/event-media-worker.test.ts`: `7215f4ab5a3af9cd710dcfb215d82681e9b48f4a315304f09b82b4610ad62ab0`

Current verification conclusion: the final backend suite passes completely. Prior MCP/typecheck-MCP, scripts, Temporal-runtime, Temporal-inference, local stdio/client-matrix and whitespace evidence is retained; their source subjects are unchanged, so no redundant reruns were performed. The six script skips, hosted HTTP smoke skip and matrix follow-up states remain exactly as documented in the initial phase history below. Root's earlier actual Convex/API analysis and backend typing evidence are separately owned; no local service analysis was repeated here. Production admission and whole-flow migration remain blocked on measured production capacity and are not certified by these unit results.

## Initial phase history: interrupted backend run

Result: **not accepted**. The backend suite failed and required an explicitly authorized interruption of one stalled child. Independent MCP, scripts, Temporal and whitespace checks passed. This is not a complete passing backend run, production-admission proof, whole-flow migration proof, or CI-readiness claim.

### Initial phase subject and source freeze

- Branch: `codex/recoverable-stream-qualification`.
- Initial phase starting HEAD: `dc249a52a9463d7f38be2db8a2935bba202a20c8` (Task 1).
- Initial stage final HEAD: `b6b338a664630c9fa4237e43932ef2b36cbbc372` (Root committed frozen Task 2 during verification).
- Initial uncommitted binary diff SHA256: `737a2cf281de1eeb4618c2cf74c5ca8232b39b7e05d3a7f941c64d7121314079`.
- Initial stage ended with a clean working tree; every tracked file's bytes identical before/after (`changed_tracked_bytes={}`). Full file identities in `verification-subject-before.json` and `verification-subject-after.json`.
- Node `v24.19.0`, pnpm `10.15.1`, `Python 3.12.14`; every shell activated `/workspace/vrdex-env.sh`.
- Node test commands ran with host escalation for documented sandbox piped-stdio behavior. All checks ran sequentially and once, except the explicitly required standalone scripts suite intentionally overlaps MCP's nested scripts stage. No source edits, commits by this verifier, service starts, provider operations, baseline acquisition or opt-in playback activation.

Task 2 exact source SHA256:

- `scripts/event-media-ecs-bridge.mjs`: `3b1d3bf0eab43479f0100a984711cb2d100695cd93826e9e18863529e677efd7`
- `tests/scripts/event-broadcast-capacity.test.mjs`: `50f99ffd727df33556c5fc13fd831aec33b4e948f1d6b7d718bc449a279a30c6`
- `tests/scripts/event-media-bridge-lifecycle.test.mjs`: `ffb9237df0ad83fb742dd3f5bf88c7efe943cc3d0acb1c7cfbe8d67c7849594d`
- `tests/scripts/event-media-lambda-bridge.test.mjs`: `7c5c4bcbe620b4d601190e53165971bbdc666a74dc99cce6a1d6c06f6601ee51`

### Initial phase: commands and bounded exits

| Command | Actual parent exit | External watchdog fired | UTC interval |
| --- | ---: | --- | --- |
| `pnpm test:backend` | 1 | no | 2026-10-26T21:43:57.998852+00:00 to 2026-10-26T21:48:53.095731+00:00 |
| `pnpm verify:vrdex-mcp` | 0 | no | 2026-10-26T21:49:15.371049+00:00 to 2026-10-26T21:52:02.341540+00:00 |
| `pnpm test:scripts` | 0 | no | 2026-10-26T21:52:17.876300+00:00 to 2026-10-26T21:55:02.254698+00:00 |
| `pnpm test:temporal-runtime` | 0 | no | 2026-10-26T21:55:10.998466+00:00 to 2026-10-26T21:55:12.317557+00:00 |
| `pnpm test:temporal-inference` | 0 | no | 2026-10-26T21:55:27.356680+00:00 to 2026-10-26T21:55:27.671068+00:00 |
| `git diff --check` | 0 | no | 2026-10-26T21:55:36.592594+00:00 to 2026-10-26T21:55:36.596076+00:00 |

Backend/MCP/scripts bounds: 1200 seconds each; Temporal bounds: 300 seconds each; diff bound: 60 seconds. Watchdog status is separate from test failure status. No watchdog fired. Backend child SIGTERM was an explicit early intervention, recorded separately in `verification-backend-interruption.json`.

### Initial phase: counts and stages

- Backend: reported 1999 tests, 133 suites, 1984 passes, 15 failures, 0 cancelled, 0 skipped, 0 todo; 294813.300344 ms. **Interrupted/incomplete**: counts cover reported outcomes, not all planned worker-file tests.
- MCP chain: typecheck passed; MCP unit suite 12/12; nested scripts 985 tests, 35 suites, 979 passes, 0 failures, 6 skipped, 0 cancelled/todo. Reached and passed local stdio compatibility smoke and client-matrix command.
- Standalone scripts: 985 tests, 35 suites, 979 passes, 0 failures, 6 skipped, 0 cancelled/todo; 164138.09156 ms. Contains passing negative migration contract; no actual migration rehearsal executed.
- Temporal runtime: 14 tests, 1 suite, 14 passes, no failures/skips/cancellations/todo.
- Temporal inference: 7 tests, `OK`, no skips/failures reported.
- `git diff --check`: exit 0, empty output.

### Initial phase: backend interruption and failures

The backend log stopped progressing with only child PID 247519, parent 246527, `tests/backend/event-broadcast-worker.test.ts` remaining. Root authorized early termination solely of that owned stalled child. `/proc` PID/PPID/start ticks and exact child/parent command identities were rechecked before SIGTERM at 2026-10-26T21:48:52.998134+00:00. Parent then exited normally with status 1 and emitted full failure summaries. See `verification-backend-interruption.json`.

Source inspection identifies an unbounded `await registered` in `R8 reclaimed competing bridges issue exactly one RunTask and never overwrite winner definition`, after default `claimAndProcess` at line 1719. This is a plausible stall location, not a runtime stack proof. Subsequent tests from that file are not certified executed. No backend broad rerun occurred. Separate read-only diagnosis is in `verification-fixture-findings.md`.

All 15 reported failures and first causes:

- **idempotency scopes stable actors and replacement sessions (7.509847ms)**: Error: Unproved broadcast configuration  ``
- **migration never revives removed public profile links or old commands (8.248558ms)**: Error: Unproved broadcast configuration  ``
- **migration never revives hidden public profile links or old commands (8.387847ms)**: Error: Unproved broadcast configuration  ``
- **idempotency keys do not collide between events (6.366593ms)**: Error: Unproved broadcast configuration  ``
- **F1 admitted run-task failure retains reservation and cannot start twice (22.264146ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:619:16)`
- **F1 admitted registration-response failure retains reservation and cannot start twice (9.824298ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:619:16)`
- **R8 actual bridge register failure releases provably unlaunched admission (5.963602ms)**: AssertionError [ERR_ASSERTION]: Expected values to be strictly equal: false !== true `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1648:246)`
- **R8 actual bridge ambiguous before retains reservation and never releases (5.712136ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1693:71)`
- **R8 actual bridge ambiguous after retains reservation and never releases (5.564587ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1693:71)`
- **R8 actual bridge ambiguous malformed retains reservation and never releases (5.095127ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1693:71)`
- **R8 actual bridge ambiguous unknown retains reservation and never releases (14.745786ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1693:71)`
- **R8 actual bridge ambiguous run retains reservation and never releases (5.296287ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1693:71)`
- **R8 actual bridge ambiguous record retains reservation and never releases (5.139202ms)**: AssertionError [ERR_ASSERTION]: The expression evaluated to a falsy value: assert.ok(session?.dispatchId) `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1693:71)`
- **R8 Stop before marker releases and durable cleanup retries without capacity leak (5.658988ms)**: AssertionError [ERR_ASSERTION]: Expected values to be strictly equal:  `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-broadcast-worker.test.ts:1702:115)`
- **operator_stops_offering_revoked_profile_source_before_worker_refresh (7.560492ms)**: TypeError: Cannot read properties of undefined (reading 'hasPublicUrl')  `at TestContext.<anonymous> (/workspace/VRDex/tests/backend/event-media-worker.test.ts:373:33)`

Complete actual stacks/assertion values and locations are retained in `verification-backend-failures.txt` and the full backend log. The four control failures reach the production resolver at `broadcast-capacity.mjs:23` / `events.ts:3815`; no authority was changed to force them green.

### Initial phase: every skip and outstanding matrix state

The same six script skips occurred in both script executions:

- ﹣ R93 retained-source complete encoder/output/local argv, defaults, getters and factory errors (0.10063ms) # SKIP
- ﹣ R93 retained-source capacity fixture and native noise complete argv with independent fake probe/capture (0.073269ms) # SKIP
- ﹣ R93 retained-source six hold frames compare every byte, isolated backing stores and per-instance reuse (0.058928ms) # SKIP
- ﹣ R93 retained-source input factory omitted/undefined/null and supplied quality late reads (0.111496ms) # SKIP
- ﹣ R93 retained-source full PCM families/defaults/boundaries and unchanged 636-frame canary (0.045678ms) # SKIP
- ﹣ proof servers own isolated media and cleanup while another server streams (0.59044ms) # SKIP

The first five require an original retained source tree through `R93_BASELINE`; none was supplied or fabricated. The last requires explicit `EVENT_PLAYBACK_PROOF=true`; it remained disabled as instructed.

MCP hosted Streamable HTTP smoke skipped: no `--hosted-url` / `VRDEX_MCP_SMOKE_URL`. Local stdio initialize, tool list and all curated read tool calls passed.

The matrix command passed its selected launch checks. Its existing table still reports Claude Code hosted-anonymous-read **fail**, hosted OAuth **pending** for Claude Code/Gemini CLI/VS Code/OpenAI surfaces, and Claude Desktop/Cursor/Codex/Devin-Windsurf not selected with pending follow-ups. Codex OAuth CLI startup remains pending. MCP Inspector's three selected checks pass; all three required hosted-readiness rows pass. These are matrix evidence states, not newly executed hosted probes.

### Initial phase: scope and artifact integrity

Root's prior actual local Convex bundle/function-spec analysis and backend typecheck were not repeated. Root supplied PASS evidence for 572 analyzed functions, exactly one public scheduling Mutation, no factory/fixture endpoint, unchanged generated files, exact environment restoration, and empty owned-port censuses; those are separately owned evidence, not checks performed here.

The production measured map remains empty by design. Actual production admission and the original whole-flow migration gate remain blocked on measurements; unit results do not alter that conclusion.

Full bounded logs are `verification-01-backend.log` through `verification-06-diff-check.log`; each has an adjacent `.exit.json`. `verification-artifacts.sha256` records every verifier artifact, including this report, excluding the manifest itself. This report and artifacts are internal verification evidence only.
