# Capacity seam full verification

Repository /workspace/VRDex, branch codex/recoverable-stream-qualification. Task1 committed dc249a5; Task2 four source/test files frozen, peer review running. No source edits allowed. Read AGENTS and canonical capacity-unit-test-seam design/plan, then run this check stage. No subagents, commits, push, network/provider/AWS/Docker/native media/hosted/service operations. Existing suites use their ordinary mock/test boundaries; do not activate opt-in real playback tests or historical baseline without possessed original.

Activate /workspace/vrdex-env.sh in every shell. Meaningful Node subprocess testing requires require_escalated for documented sandbox piped-stdio bug. Capture full bounded logs and actual exits/counts under this SDD directory. Run commands sequentially, once each; report failures by name with exact first causes, continue independent listed checks even after failure. Do not patch failures or alter fixture authority to make green.

1. pnpm test:backend
2. pnpm verify:vrdex-mcp
3. pnpm test:scripts (explicit parent host-chain requirement after MCP; note overlap with nested MCP script stage)
4. pnpm test:temporal-runtime
5. pnpm test:temporal-inference
6. git diff --check

Keep each command bounded with an appropriate external timeout; preserve watchdog exits separately from test failures. No backend typecheck repeat is needed: Task1 typecheck passed and Task2 does not affect its graph; Root actual anonymous local bundle/analysis also passed. Root performed local function-spec:572functions, exactly1public scheduler Mutation, no factory/fixture endpoint, generateddiff0, exactenvironmentrestore and2emptyportcensuses. Do not rerun local service analysis or actual migration rehearsal. Current real migration gate requires measured production admission and intentionally remains blocked; the existing unit negative contract must remain valid.

Report .superpowers/sdd/capacity-unit-test-seam/verification-report.md with command/exits/counts/stages reached, every failure/skip, exact subject identities and all artifact hashes. Source code must remain unchanged. Root will handle newly exposed issues through review/fix; don't guess all192previous failures resolved until actual results. Return concise status/results/pointers.
