# Final MDX link fix

Changed only the two review citations to MDX-compatible labeled links and updated their retained byte counts and SHA256 values. The retention record preserves both previous identities, the prior full commit, the original references, and the explanation: “MDX-compatible link syntax only; substantive review unchanged”.

`pnpm exec markdownlint-cli2 docs/engineering/authority/reviews/rebaseline-ci-triage.md docs/engineering/authority/reviews/rebaseline-whole-branch-source-review.md` passed with 0 errors. Root owns the full docs-build rerun.

Changed-file hashes:
- `docs/engineering/authority/reviews/rebaseline-ci-triage.md`: 6049 bytes, SHA256 `f4b060d3615ae79a352cb5395509dbad2b84692c17c4e36e80196ab82a0da9ba`
- `docs/engineering/authority/reviews/rebaseline-whole-branch-source-review.md`: 16263 bytes, SHA256 `f40bd93f4e823515663e4e0a115af679e0ea41770f3034bc7a37c40a2cbf9e08`
- `docs/engineering/authority/reviews/ci-subjects/review-retention.json`: 2883 bytes, SHA256 `753cb430a923c3b0f55b77f4b2939020fa5ad9b744fca99d09d1cb0ab68c7f0c`

`final-mdx-fix.diff` contains the scoped diff for exactly these three files.
