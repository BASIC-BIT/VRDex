"""One owned anonymous-local API analysis; preserve exact environment files."""
import hashlib, json, os, signal, socket, stat, subprocess, time, uuid
from pathlib import Path

ROOT=Path('/workspace/VRDex')
OUT=ROOT/'.superpowers/sdd/capacity-unit-test-seam'/('local-analysis-'+uuid.uuid4().hex[:8])
OUT.mkdir(mode=0o700)
os.umask(0o077)
groups=[]; snapshots=[]
receipt={'scope':'anonymous loopback API analysis','directory':str(OUT),'status':'incomplete'}
deadline=time.monotonic()+240

def active(port):
    with socket.socket() as s:
        s.settimeout(.2)
        return s.connect_ex(('127.0.0.1',port))==0

def terminate(group):
    try: os.killpg(group,signal.SIGTERM)
    except ProcessLookupError: return
    for _ in range(30):
        try: os.killpg(group,0)
        except ProcessLookupError: return
        time.sleep(.1)
    try: os.killpg(group,signal.SIGKILL)
    except ProcessLookupError: pass

def launch(args,label):
    stdout=(OUT/(label+'.stdout')).open('xb')
    stderr=(OUT/(label+'.stderr')).open('xb')
    env=dict(os.environ,CONVEX_LOCAL_BACKEND_VERSION='precompiled-2026-09-28-5c7cb5b',
             CONVEX_LOCAL_DEPLOYMENT_NAME='anonymous-agent',CONVEX_DEPLOYMENT='local:anonymous-agent',
             CONVEX_URL='http://127.0.0.1:3210',CONVEX_DEPLOY_KEY='',
             CONVEX_SELF_HOSTED_ADMIN_KEY='',CONVEX_SELF_HOSTED_URL='',NO_COLOR='1')
    p=subprocess.Popen(args,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True)
    stdout.close();stderr.close();groups.append((p,p.pid))
    receipt.setdefault('commands',[]).append({'label':label,'argv':args,'pid':p.pid,'pgid':p.pid})
    return p

def finish(p,timeout):
    return p.wait(timeout=max(.1,min(timeout,deadline-time.monotonic())))

def selectors():
    for path,key in [(ROOT/'.env.local','CONVEX_URL'),(ROOT/'apps/web/.env.local','NEXT_PUBLIC_CONVEX_URL')]:
        vals=[line.partition('=')[2].strip().strip('"\'').split('#')[0].strip()
              for line in path.read_text().splitlines() if line.startswith(key+'=')]
        if vals!=['http://127.0.0.1:3210']: raise RuntimeError('non-local or duplicate URL selector')

def interrupted(signum,frame): raise RuntimeError('analysis interrupted')
signal.signal(signal.SIGTERM,interrupted)
signal.signal(signal.SIGINT,interrupted)

try:
    if any(active(p) for p in (3210,3211)): raise RuntimeError('loopback ports already occupied; no action taken')
    for n,path in enumerate([ROOT/'.env.local',ROOT/'apps/web/.env.local']):
        if path.is_symlink(): raise RuntimeError('environment path is a symlink')
        exists=path.exists();body=path.read_bytes() if exists else b''
        if len(body)>1048576: raise RuntimeError('environment snapshot too large')
        mode=stat.S_IMODE(path.stat().st_mode) if exists else None
        backup=OUT/('private-env-'+str(n));backup.write_bytes(body)
        snapshots.append((path,exists,body,mode))
    (ROOT/'.env.local').write_text('CONVEX_DEPLOYMENT=local:anonymous-agent\nCONVEX_URL=http://127.0.0.1:3210\n')
    (ROOT/'apps/web/.env.local').write_text('NEXT_PUBLIC_CONVEX_URL=http://127.0.0.1:3210\n')
    bootstrap=launch(['pnpm','verify:backend:local'],'bootstrap')
    receipt['bootstrapExit']=finish(bootstrap,150)
    if receipt['bootstrapExit']!=0: raise RuntimeError('local bootstrap failed; inspect private logs')
    if not active(3210):
        dev=launch(['node','scripts/run-convex-local.mjs','dev','--local','--tail-logs','disable'],'owned-dev')
        end=min(deadline,time.monotonic()+60)
        while not active(3210):
            if dev.poll() is not None: raise RuntimeError('owned local dev exited before ready')
            if time.monotonic()>end: raise RuntimeError('owned local dev readiness deadline')
            time.sleep(.2)
    selectors()
    selector=OUT/'analysis-local.env'
    selector.write_text('CONVEX_DEPLOYMENT=local:anonymous-agent\nCONVEX_URL=http://127.0.0.1:3210\nCONVEX_DEPLOY_KEY=\nCONVEX_SELF_HOSTED_ADMIN_KEY=\nCONVEX_SELF_HOSTED_URL=\n')
    spec=launch(['node','scripts/run-convex-local.mjs','function-spec','--env-file',str(selector)],'function-spec')
    receipt['functionSpecExit']=finish(spec,45)
    if receipt['functionSpecExit']!=0: raise RuntimeError('function-spec failed; inspect private logs')
    raw=(OUT/'function-spec.stdout').read_bytes()
    if len(raw)>16777216: raise RuntimeError('function-spec output cap')
    result=json.loads(raw)
    if result.get('url')!='http://127.0.0.1:3210': raise RuntimeError('function-spec deployment URL mismatch')
    funcs=result['functions']; ids=[x.get('identifier','') for x in funcs]
    selected=[x for x in funcs if x.get('identifier','').replace('.js:',':')=='events:scheduleEventMediaWorker']
    if len(selected)!=1: raise RuntimeError('schedule API count mismatch')
    if any('createScheduleEventMediaWorker' in s or 'fixtureScheduleEventMediaWorker' in s or 'loadEventsWithFixtureCapacity' in s for s in ids): raise RuntimeError('helper leaked into analyzed API')
    receipt.update(status='passed',functionCount=len(funcs),scheduler=selected[0],url=result['url'])
    selectors()
except Exception as error:
    receipt.update(status='failed',errorType=type(error).__name__,error=str(error))
finally:
    for p,group in reversed(groups):
        terminate(group)
        try:p.wait(timeout=5)
        except subprocess.TimeoutExpired:pass
    restored=[]
    for path,exists,body,mode in snapshots:
        if exists:path.write_bytes(body);path.chmod(mode)
        else:path.unlink(missing_ok=True)
        restored.append((path.exists()==exists) and (not exists or (path.read_bytes()==body and stat.S_IMODE(path.stat().st_mode)==mode)))
    receipt['environmentRestoredExactly']=len(restored)==2 and all(restored)
    receipt['emptyPortCensuses']=[]
    for _ in range(2):
        receipt['emptyPortCensuses'].append({str(p):not active(p) for p in (3210,3211)})
        time.sleep(.2)
    receipt['generatedDiffExit']=subprocess.run(['git','diff','--exit-code','--','convex/_generated'],cwd=ROOT,stdout=subprocess.DEVNULL).returncode
    (OUT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='commands'}))
    if not receipt['environmentRestoredExactly'] or any(not all(r.values()) for r in receipt['emptyPortCensuses']):raise SystemExit(2)
    if receipt['status']!='passed' or receipt['generatedDiffExit']!=0:raise SystemExit(1)
