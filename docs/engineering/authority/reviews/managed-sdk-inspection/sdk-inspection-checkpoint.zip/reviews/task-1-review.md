# Task 1 independent SPEC and QUALITY review

2026-10-27. **SPEC: REQUEST CHANGES. QUALITY: REQUEST CHANGES.** Three concrete enforcement findings below prevent acceptance of this revision. The current control-response envelope also remains a separate Root launch-readiness blocker. These findings concern this finite diagnostic only, not the earlier transport pipeline or full SDK/native semantics.

## Pinned review subjects and authority

- Task report `/workspace/VRDex/.superpowers/sdd/managed-sdk-inspection/task-1-report.md`: SHA256 `44997ed57197a22387eb019dd221292208f634523a95544f090dd37ae13e2872`.
- Full new-file diff `/workspace/scratch/managed-sdk-inspection/full-new-files.diff`: SHA256 `65d1ce171837dba6bd3f3dc31a48e7e00e3fed2f657691191ab9d6f5c7f1e57f`.
- Content inventory `/workspace/scratch/managed-sdk-inspection/inventory.json`: SHA256 `a35a610d23023d24572706588e69e1ea35055168a9ee639f0d20e7ddafde9831`.
- Collector `inspect_sdk.py`: SHA256 `c8c48bca85972b414623cf61a1af7ec09f83996b43ac42e8b15e33784c5f1691`.
- Binding design `/workspace/scratch/managed-sdk-inspection-design.md`: SHA256 `5251e913aaf88bd9cfac0dc8c2e61c34c348fe890de4e3d69ed4fa124b80b0be`.
- Root rulings `/workspace/VRDex/.superpowers/sdd/managed-sdk-inspection/root-rulings.md`: SHA256 `9469db0b5ad28843592caf2d05adc8e103366ed81559c11522b71faa9b250cc6`.

The Root 128 MiB diagnostic logical-work amendment supersedes the exploratory 32 MiB term. It does not change the 256 MiB address space, 16 MiB disk, 8 MiB source, 1 MiB ZIP, 64 KiB metadata, 4.5 MiB diagnostic evidence within C8 MiB, individual log/control allowances, or time/API limits. Root's $0.10 prospective hold supersedes $0.05. Root's read-only ambiguous-Start reconciliation slot remains within 74 calls and is not a mutation retry.

Read the brief, design, rulings, implementation/report/README, all three test files, freeze helper, generated fixtures and retained green output. Independently checked every one of the 76 inventory entries: no byte/hash mismatch. Reconstructed the full diff from all inventoried bodies plus inventory: exact match. No implementation files changed, passing tests rerun, provider/network calls made, installed SDK bodies read, corpus inspected, or subagents used. Only new, narrow generated-data probes were executed; their observations appear below.

## Concrete blockers

### B1 — Unsupported direct model readers escape the model-work limit

**High priority.** `inspect_sdk.py:90`, especially lines 129–145, intercepts `builtins.open`, `io.open`, and two gzip methods. It neither rejects nor charges `io.FileIO` or `os.open`/`os.read` on JSON model files. This contradicts the README/report claim that unsupported direct read variants become negative and leaves the 64 MiB intentional model-work reservation unenforced for those reader shapes.

A new generated-only probe created a 128-byte `generated.json` in a temporary directory, entered `model_read_guard(64)`, then independently read it through each of those two routes. Actual output:

```text
generated FileIO read bytes: 128 weighted counter: 0 limit: 64
generated os.read bytes: 128 weighted counter: 0 limit: 64
```

Both reads completed without a negative despite exceeding the test limit before decode/parse costs. No actual SDK reader is claimed to use these routes; the finding is that an unsupported route is silently accepted by the declared guard. This is a narrow local boundary defect, not a demand to prove every SDK/native reader before the diagnostic.

Required correction: make the permitted model-file read boundary explicit, charge supported access and reject unrecognized direct access before it can read model bytes. Add generated cases for the demonstrated FileIO and descriptor routes, including any descriptor escape exposed by a wrapped reader. Preserve the declared managed-import trust premise without turning intentional unobserved model reads into zero work. Re-freeze source/buildspec/accounting after the fix.

### B2 — The combined 256-callback ceiling counts display identities rather than callbacks

**Medium priority.** `event_facts` checks object identities within each service, but `ManagedRuntime.facts` at lines 375–376 combines services using only `(module, qualname)`. Distinct callback objects, including different bound owners or function instances sharing a qualified name, collapse into one count. Two individually acceptable services can therefore exceed the overall 256-unique-callback ceiling.

A new generated probe made 129 distinct functions for each service, each with the same short module/qualified-name identity. They were registered under `before-call`, never executed, and inspected through the actual `event_facts` function. Actual output:

```text
distinct actual callbacks: 258 global implementation count: 1 registrations: 258 event JSON bytes: 36279
```

Both per-service scans pass; the exact combined predicate used by `ManagedRuntime.facts` also passes. The registration ceiling and event/metadata-size envelope do not rescue the unique-callback invariant for this case.

Required correction: preserve a private shared identity set, or equivalent exact callback accounting, across both service scans. Do not substitute human-readable identities for object uniqueness. Keep published identities deterministic, and add a generated cross-client case with more than 256 distinct callbacks sharing display identities.

### B3 — Worker admission does not enforce the latest worker-start time

**Medium priority.** `main` at lines 414–419 sets `deadline=min(now+300,carrier_deadline-180)` and requires only that the resulting deadline is in the future. It never checks the latest worker start, derivable as `carrier_deadline-480` (carrierStart+120).

For example, with carrierStart=0 and deadline=600, a worker entering at time 200 is admitted until time 420, permitting 220 seconds of inspection after the specified start cutoff. This is a static arithmetic/control-flow finding; the reviewer did not run `main` or install its process-global limits/audit hooks.

The design separately assigns Root the duty to observe a missed start and stop once. That monitoring duty remains necessary; an earlier check before submitting StartBuild does not establish the eventual worker start time. Root stop observation can race a queued worker starting. The worker already receives enough information to reject locally before managed imports/fact collection.

Required correction: enforce the derived +120 start cutoff before `collect(ManagedRuntime(), {})`, retain the current work/closure deadline, and add a generated clock case that proves a late start emits a bounded negative without entering collection. No new job, clock reset or expanded time allocation follows.

## SPEC assessment

The delivered scope and most bounded behavior match the design. The exact 37-module list is present. Source size admission precedes intentional source-body collection; paths use no-follow traversal and regular-file/inode/size/time checks; success includes complete selected bytes and canonical metadata. The managed adapter has real configuration/model/event inspection code, while generated fixtures and runtime trust are labelled honestly. It does not claim that generated compatibility proves actual SDK support.

Model and event output limits, explicit unknown-shape negatives, alias resolution, local callback-order observation and registration-multiset checking are present. The two blockers above concern enforcement holes in the intended limits, not a request to broaden the source set or execute handlers.

The network guard and worker audit reject the covered socket creation/connect/DNS/send paths, process dispatch and new threads; SDK send is replaced before client construction and dummy credentials are explicit. There is no publisher, dependency installer, service-operation trial or alternate worker output channel in this deliverable. This is a managed-runtime guard assessment, not native-code/network closure certification.

The frame protocol binds nonce, ordered frame count, whole ZIP length/hash and metadata hash; archive verification checks the selected inventory, complete per-source hashes, entry types, local-layout accounting and bounded expansion. Both full semantic-response traversals require charged stable-token EOF and matching events/archives; build and stream joins are present. The `complete-semantic-response-json` label correctly avoids claiming HTTP-wire originals. Chronology remains a Root receipt assertion and two EOFs/stable timestamps do not claim absolute finality. The success result says selected sources are complete, not that resources are closed or transport is approved.

The packet is deterministic and provider-free, with the intended fixed NO_SOURCE standard7.0/Python3.12 SMALL project, CloudWatch-only logs, pinned inline source and exact logs-only role scope. Resource and clock refs are supplied for Root. The missing worker-start admission in B3 still needs correction.

## QUALITY assessment and test evidence

Retained `green.log` and `green.exit` show the reported command completed with exit 0, `Ran 43 tests in 0.087s`, `OK`. The suite was not rerun. The initial/intermediate failures are documented without inventing RED history. Generated sources and provider examples are consistently labelled; the freeze artifacts bind their complete bodies.

The tests cover many useful rejection paths, but the green count does not cover the blockers. Existing model tests exercise wrapped `open` and gzip only. The callback count tests do not exercise the global identity collision. The suite has no late-worker-start case. Also, `test_exact_original_raw_bytes_cap` inserts an unsupported `raw_pages` field, so it fails the schema check rather than proving the byte boundary for `response_original`; replace that assertion with an oversized actual response string when touching that coverage. The similarly named `test_callback_cap` only repeats an unknown-registry-shape failure. These are coverage-quality gaps, not evidence that the already recorded test run failed.

## Separate Root launch-readiness gaps

1. **Current control envelope remains blocked.** Frozen estimate 307,477/314,572 bytes assumes fourteen returned-source copies and a strict 3,072-byte wrapper per copy, leaving 7,095 bytes. This is transparently identified as unmeasured, not fake provider proof. During review Root reported fresh analysis of already possessed owned metadata: an earlier compact poll response was 3,088 bytes and terminal response 4,722 bytes. Those old-job responses differ in configuration, so they are not a measured replacement wrapper for this diagnostic. They nevertheless provide concrete contrary evidence to treating 3 KiB as established capacity. Root's proposed six normal polls, ten returned-source copies and 6 KiB wrappers gives 291,881 bytes at the current source size; that remains a proposal until a revised concrete packet/remaining-capacity ledger and full request/response allowance are frozen. Source changes for B1–B3 can change that arithmetic. Preserve complete originals and the 64 KiB closure reserve; no evidence borrowing or projection.
2. **Root execution packet and custody remain prospective.** Instantiate actual resource identities/deadline, re-freeze exact source/buildspec/request bytes and establish remaining C/control/disk/logical headroom. Freeze the read-only `ListBuildsForProject` ambiguity branch and its slot/request under the Root amendment. Keep one StartBuild/at-most-one StopBuild and no retry/replacement. Cleanup and actual terminal/chronological receipts are Root obligations, not behavior proved by this offline verifier.
3. **Actual runtime fit remains unknown by design.** Installed source sizes, managed model/registry shapes, capacity fit and complete managed log delivery have not been observed. A bounded negative on unsupported shapes is acceptable. Full SDK semantic/native/source-authentication closure, transport qualification and image transfer remain outside this deliverable.
4. **The prospective $0.10 hold has not been invoked by this review.** Root must retain the required pricing/billing evidence and account for submit-to-termination duration, rounding and logs within standing authority, preserving uncertainty after ambiguous stop/termination.

Acceptance requires resolving B1–B3 with focused generated verification and a new frozen subject. Launch additionally requires the separate readiness conditions above. No provider execution or approval is given by this review.
