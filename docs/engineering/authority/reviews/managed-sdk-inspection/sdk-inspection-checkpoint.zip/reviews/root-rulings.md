# Root SDK diagnostic design dispositions

Accept design SHA256 `5251e913aaf88bd9cfac0dc8c2e61c34c348fe890de4e3d69ed4fa124b80b0be` following independent SPEC/QUALITY PASS in `/workspace/scratch/managed-sdk-inspection-design-review.md`. Acceptance is for implementation; no paid resource or cost hold has been invoked.

- Proposed diagnostic cost reservation is $0.10 within the standing $20 authorization, replacing the exploratory $0.05 proposal. Submit-to-termination billing and rounding count. A failed stop/late terminal observation remains residual cost uncertainty, never a claim that billing ended at the action cutoff. Fresh prices and billing documentation are retained under `/workspace/scratch/managed-sdk-inspection-readiness/`.
- CarrierStart precedes the first mutation of any owned role, log group, retention, policy or project. Every setup step consumes the same 600 seconds. There is no separate logging setup clock.
- Keep the existing 0.3MiB complete control-original allowance and 64KiB closure reserve. Implement a compact pinned inline launcher, preferably compressed collector bytes with deterministic decoding, and report its exact complete request/response repetition estimate. Limit planned normal build polls to at most12, at least15 seconds apart. The original32-poll design ceiling is not permission to exceed the control-original allowance. No unused poll slots may become mutations. Freeze exact polling intervals and response capacity before launch; unknown response size or insufficient remaining capacity is a negative. Provider originals remain complete, never projected status excerpts.
- The implementation report must itemize actual logical consumers within5U+16Zmax+4MiB and state any conservative gap before review. Whole archive hashes, both original log traversals and both frame reconstructions count. No implicit new allocation or source/body substitution.
- The cloud skill's script resource was unavailable through skills.read, and no local sdd-workspace/task-brief executable was found. Root created the task workspace and ledger directly and will generate the brief from the plan's exact Global Constraints, Review Focus and Task1 text. This is an orchestration-tool fallback, not a bypass of task review.

Existing C8MiB and every transport/native qualification limit remain unchanged. No real SDK support or transport launch follows from this implementation design.

## Diagnostic logical-work amendment

The implementation identified intentional managed service-model loading as additional work beyond the exploratory4MiB fact category. A complete S3 model can exceed that category when decompressed and parsed. Requiring this diagnostic to prove the SDK's full internal reader closure before obtaining its source would defeat its purpose.

For this separately labelled diagnostic only, replace the proposed32MiB logical-work ceiling with128MiB, including an explicit bounded model/facts category and margin. Preserve the5U source and16Z archive/log consumer accounting and itemize the additional actual model/input/decode/inspection reservation before independent implementation review. Managed SDK import/client construction remains an explicit provider-runtime trust premise; intentional model/source inspection is not free, and unknown/unbounded work cannot be assigned zero.

This is a new exploratory local/diagnostic work allocation, not a reset of historical work or a change to transport8GiB, native/qualification caps,256MiB hard address space,16MiB new disk,1MiB ZIP, metadata64KiB, evidence4.5MiB/C8MiB, API/cost/time limits. Cost if insufficient is a bounded negative with no automatic second job. No actual allocation invocation or paid launch has occurred. Independent task review must assess the exact implemented disposition before Root action.

## Ambiguous StartBuild reconciliation

Before paid execution, assign one of the32 originally proposed normal polling slots to one read-only `ListBuildsForProject` invocation for the exact newly owned project. The implementation already plans at most12 normal polls, so this leaves the total Root74 ceiling unchanged and does not borrow any mutation slot. This is an explicit diagnostic schedule adjustment, not a transport allowance or mutation retry. It is needed only when StartBuild is ambiguous and returns no build ID, so BatchGetBuilds cannot yet reconcile it. Do not repeat StartBuild.

The exact nonce project must have been proven absent before creation. The bounded list must be nonpaginated and identify at most one attributable build. Use the already reserved BatchGetBuilds/StopBuild slots for that actual ID, preserve incomplete evidence, confirm terminal state before cleanup, and do not proceed to a second attempt. Multiple/foreign builds, truncation or unknown ownership stay incomplete and cannot authorize broad stops or deletion. This requires a Root request template/schedule, not a generic provider driver in the private helper.

## Complete-response capacity disposition

Already possessed owned CodeBuild originals show complete compact returned mappings of3088 bytes early and4722 bytes at terminal, before any inline-source addition. The prior job configuration differs, so these are contrary evidence to a3KiB wrapper assumption, not measurements of the new job. Their exact refs and derived sizes are in `/workspace/scratch/managed-sdk-inspection-readiness/prior-response-size-facts.json`.

Revise the deterministic packet to at most six normal polls and ten repeated returned-source copies, reserving6144 bytes per complete response wrapper. This trades unused status polling for response capacity within the same314572-byte complete-control allowance, including the65536-byte closure reserve, without increasing C, API calls or time. Freeze the revised exact source/buildspec sizes and arithmetic after B1–B3 fixes. If they do not fit, report the concrete remaining conflict before any launch rather than lowering wrappers or dropping originals.

Poll offsets and wait chunks must keep all active waits at most60 seconds and remain subordinate to the same latest-start/worker/carrier deadlines. Root may use shorter deadline checks without extra provider polls. A wrapper is still an admission envelope, not a claim about unobserved responses; actual overflow stays a bounded negative with complete-original custody and closure accounting.
