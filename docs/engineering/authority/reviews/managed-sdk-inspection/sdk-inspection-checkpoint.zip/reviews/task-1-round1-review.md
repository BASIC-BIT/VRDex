# Task 1 round 1 scoped independent review

2026-10-27. **SPEC: PASS within the requested re-review scope. QUALITY: PASS within that scope. B1, B2 and B3: ADDRESSED.** No remaining implementation blocker was identified in these fixes. The revised response packet satisfies Root's disposition as a concrete offline allocation; actual launch readiness remains Root's responsibility.

Scope was limited to the three initial findings, their associated two ineffective tests, the response-capacity disposition, and breakage introduced by those changes. The original review remains the record for unchanged implementation. No implementation edits, provider/network calls, corpus or installed SDK-body reads, subagents, or test-suite reruns occurred. This review used static inspection, retained test output and independent byte/hash/accounting checks.

## Pinned subjects

| Subject | SHA256 |
| --- | --- |
| Appended task-1-report.md | `e38dd4350ccd8bbaacceb6d3ef240d5672a4e9b6e17be07cc7767e5acd5d373e` |
| round1-scoped-fix.diff | `226ee911bce8904b43df0b03e553e927e90dfa71930325cd1c263c7555b7f4e3` |
| round1-freeze.json | `43f347d1bf974b58cc7c558e54d3f85826b9ca89f8e646de491f32099854bab0` |
| Current inventory.json | `887c89bded871804b11a1def0b291f1143ff03abc988b7a283944714be8d5674` |
| inspect_sdk.py, 27,557 bytes | `3041afb0a4e347fba039d3f20d22c4679a5b3805399bdff6ef5c951d9fa85931` |
| fixtures/buildspec.yml, 12,171 bytes | `3b7ad02e0ea2e0fad7b8233dca68981c34754180f02d29839bade6e591b80642` |
| Latest Root rulings | `9e65bc212eb5ad0069f9d4f86c57e9f0392fba2a62e225b616842498c86faeb0` |

All subject hashes above were checked. Independent manifest verification found zero mismatches across the 85 current content files and all 80 preserved original subjects. The appended report retains its original report prefix byte-for-byte. The unchanged binding design is the subject pinned by the initial review; current Root rulings supply the 128 MiB logical-work amendment, $0.10 prospective cost disposition, read-only ambiguous-Start slot and revised complete-response allocation.

## Finding dispositions

**B1 — ADDRESSED.** The model guard now establishes an explicit wrapped-open boundary. An active CPython open audit rejects JSON/gzip path opens outside that boundary; exported `io.FileIO` and `_io.FileIO` routes reject model paths and model descriptors. Guarded descriptor readers cover `os.read`, `pread`, `readv` and `preadv`, identifying existing descriptors through `/proc/self/fd`. The JSON wrapper no longer exposes its backing stream or fileno/buffer/raw/detach/peek routes; its supported reads retain bounded charging. Replaced functions are restored on exit and the audit closure becomes inactive. Nonmodel managed import reads retain the declared trust premise.

The retained new tests exercise the originally demonstrated FileIO and os.open/os.read paths, preexisting descriptor routes, wrapper escapes, and preservation of nonmodel reads. Existing plain JSON charging and gzip expansion cases remain green. This addresses the identified finite Python reader routes; it does not certify hostile Python introspection, arbitrary native I/O or full SDK reader closure, and the revised README states that boundary accurately.

**B2 — ADDRESSED.** A private identity-to-object dictionary is shared across both client event scans. The guard counts actual callback identities and retains strong references, preventing id reuse during the scans. The combined limit uses that same dictionary rather than collapsing `(module, qualname)` display names. Published callback identities remain deterministic. New generated tests pass through the managed fact adapter: 258 distinct callbacks with colliding display identities are rejected, while exactly 256 are admitted. No handler invocation is needed.

**B3 — ADDRESSED.** `main` captures `started`, derives its work deadline from that value, and requires `started <= carrier_deadline - 480` before constructing ManagedRuntime or entering collection. It retains the existing 300-second work/180-second closure deadline. The generated late-start test at carrier+200 checks a bounded `time_limit` H/T pair and verifies that neither runtime construction nor collection occurred. The exact +120 boundary test reaches collection. Root's independent deadline monitoring and at-most-one stop duty remain in force.

**Associated test gaps — ADDRESSED.** `test_exact_original_raw_bytes_cap` now enlarges the actual `response_original` string and asserts `log_original_limit`; it no longer obtains a schema rejection from an invented field. `test_callback_cap` now supplies 257 distinct callback objects and asserts `event_limit`, rather than repeating the unknown-registry test. These changes test the intended invariants.

## Retained verification and quality conclusion

Read the covering command, full retained round-1 RED and final GREEN output. RED records 53 tests with 11 failures, including subtest failures, at the unfixed revision. Final GREEN records the same discovery command, exit 0, `Ran 53 tests in 0.102s`, `OK`. These are retained implementer executions, not reviewer reruns or real managed-runtime observations.

The scoped changes resolve the initial concrete failures with appropriate generated boundary cases, preserve original evidence and update the README/report/packet consistently. No new blocking defect was found in the reviewed fix diff. The initial transport/native/source-authentication exclusions and generated-only labels remain intact.

## Response packet and remaining readiness

**Root response-capacity disposition: ADDRESSED in the offline packet.** It now plans six normal polls, ten returned-source copies and 6,144 bytes per complete response wrapper. Independently checked the frozen arithmetic:

```text
12,887 + 10*12,215 + 10*6,144 + 24,576 + 65,536
= 286,589 <= 314,572 bytes
remaining = 27,983 bytes
```

The 65,536-byte closure reserve is included. No control/log evidence allowance is enlarged and no complete original is replaced with a projection. Poll offsets are 15,45,90,150,225,300 seconds; intervals are 15,30,45,60,75,75. Explicit wait chunks split the two 75-second intervals into 60+15, so each active wait is at most 60 seconds. Root must subordinate each chunk to earlier start/work/carrier deadlines as specified; shorter deadline checks do not authorize extra provider polls or mutations.

The 6 KiB wrapper remains an admission envelope, not a measured new-job response size. The earlier owned response evidence explains the revised allocation without being mislabelled as proof of the new runtime. Actual identities/deadline/request-byte freeze, remaining C/control headroom, complete-original custody, chronological receipts, pricing and the prospective $0.10 hold remain Root gates. The assigned read-only ambiguous-Start reconciliation slot still needs its actual request instantiated under the unchanged 74-call ceiling; no replacement StartBuild is authorized.

This review removes the three scoped implementation blockers. It does not claim that a managed job has run, that actual responses/runtime/logs fit, that resources have closed, or that SDK/transport/native support is approved.
