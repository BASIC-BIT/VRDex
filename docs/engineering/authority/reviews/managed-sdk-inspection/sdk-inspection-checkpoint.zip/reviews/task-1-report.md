# Managed SDK inspection task1 implementation report

2026-10-27. Implementation is frozen for independent SPEC/QUALITY review. The covering generated-only suite passes 43 tests. No provider call, actual SDK import/source acquisition, network attempt, image/corpus read, Git edit or commit occurred. No actual managed-runtime compatibility, source possession, resource closure or SDK support is claimed.

## Deliverables

Private root `/workspace/scratch/managed-sdk-inspection/` contains `inspect_sdk.py`, `packet.py`, `verify.py`, three `test_*.py` files, `README.md`, finite `freeze.py`, generated source/model/provider examples, exact generated packet/buildspec, complete test logs, content hash inventory and a full new-file diff. Only this explicitly requested SDD report is outside that private root.

- Collector resolves exactly 37 selected module files before source-body reads, admits sizes, uses no-follow directory and final-file descriptors, checks regular/non-symlink/trusted origin/stable identity, hashes and archives complete sources. No partial success archive is published.
- Managed adapter has actual bounded model/config/method/auth/event paths rather than a fake supported profile. Generated tests exercise these paths through generated modules only. Unknown internals/caps become fixed negative reasons. Registry aliases and wildcard matches use observed local prefix_search ordering with registration-multiset checks; no handler executes.
- Worker entrypoint sets hard/soft 256 MiB address space, 16 MiB file limit, no core dumps and the absolute deadline before SDK import. It rejects socket construction/connect/DNS/send, SDK send, subprocess/fork and thread creation. Separate sessions receive fixed dummy credentials. There is no service operation, serializer payload trial, credential chain, signer implementation, upload or secondary output channel.
- Packet deterministically fixes standard7.0/Python3.12 SMALL, nonprivileged NO_SOURCE/NO_ARTIFACTS/NO_CACHE, pinned inline source, CloudWatch-only logs, one-day group retention requests, exact role trust/log-only policy, one StartBuild request and Root gates. It dispatches nothing.
- Verifier retains complete serialized semantic provider responses, requires two independent complete traversals with stable-token EOF, terminal/identity joins and one stable owned stream, compares exact event sets and both whole ZIP reconstructions, validates canonical names/types/counts/ZIP layout and each full source size/hash, and returns one archive. It rejects malformed/foreign/duplicate/reordered/altered frames, incomplete EOF and changing observations. It makes no HTTP-wire or absolute finality claim.

The exact schemas and concrete generated examples are frozen in `README.md`, `fixtures/owned.json`, `fixtures/packet.json`, `fixtures/capture.json` and `fixtures/expected.json`. Provider strings are complete returned SDK/tool semantic mappings serialized as JSON, not original wire JSON. Real Root capture must retain all returned fields and explicit date/time serialization conventions. `after_terminal` is Root's chronological receipt assertion, not independent clock authentication.

## Actual tests

Command:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/managed-sdk-inspection -p 'test_*.py' -v
```

Initial actual RED was exit 1, 29 failures for missing implementation, retained in `red.log`/`red.exit`. It was run before implementation. Later self-review RED runs are also retained. `red-hardening.log` includes three genuine failures and one sandbox socket error; imported TestCase duplication made that intermediate run report 51 tests and was removed. `red-model-budget.log` records two missing-guard AttributeErrors. These are actual outputs, not manufactured earlier failures. Some later review tests passed when first added; no prior RED is claimed for them.

Intermediate implementation attempts are preserved in `green-attempt-1` through `green-attempt-6` logs/exits. Attempt1 exposed forbidden socket creation in this sandbox and the initial packet exceeding control capacity. Attempt4 exposed growth exceeding the then-current control estimate. These led to a test that directly calls the blocked dispatch entry and a ten-poll packet. Other intermediate green runs remain honest observations at those revisions.

Final `green.log`/`green.exit`: exit 0, 43 tests, 0 failures/errors, `Ran 43 tests in 0.087s`, `OK`. Coverage includes complete/deterministic inventory, missing/source-less/symlinked/untrusted/changed/oversize source, before-read admission, archive/metadata/model/event limits, alias/wildcard order without handler execution, network/socket rejection, unknown event/model shapes, generated managed-adapter configuration/models/auth, raw-response limits, ZIP traversal/unreferenced data, frame alteration/order/count/nonce, two-read EOF/identity/stream joins, and changing delivery.

`offline-freeze-check.log` independently records exact launcher shell-argument parsing, compressed collector byte round-trip without executing the launcher, and generated two-original/one-archive re-verification. Generated archive size is 9,491 bytes and inventory count is 37. These are generated sources, not possessed SDK originals.

## Exact packet/control freeze

Example account/nonce/deadline remain generated placeholders. Actual Root instantiation changes bytes/hashes and must re-freeze them before mutation.

| Item | Frozen example |
| --- | ---: |
| Collector bytes | 25,583 |
| Inline buildspec UTF-8 bytes | 11,535 |
| Complete buildspec JSON string bytes including escapes | 11,579 |
| Complete canonical CreateProject request bytes | 12,251 |
| Returned buildspec copies reserved | 14 |
| Full-response wrapper envelope per copy | 3,072 bytes |
| Other setup/control envelope | 24,576 bytes |
| Closure reserve | 65,536 bytes |
| Estimated complete control originals | 307,477 bytes |
| Fixed control limit | 314,572 bytes |
| Unallocated headroom | 7,095 bytes |

The exact estimate is `12251 + 14*11579 + 14*3072 + 24576 + 65536 = 307477`. Fourteen source repetitions cover CreateProject response, BatchGetProjects readback, StartBuild response, ten normal build polls and one reconciliation response. No returned original is replaced by request bytes/status summaries. The 3 KiB wrapper envelope is a strict prelaunch/dispatch gate, not measured real provider output. Root must prove actual remaining capacity and retain complete originals. Any unknown/oversized envelope is negative; no borrowing from log traversals/closure.

Ten poll offsets are 15,30,60,90,120,150,180,225,270,300 seconds after StartBuild. These are at least 15 seconds apart with waits <=45 seconds. Unused slots cannot become writes. CarrierStart precedes the first owned mutation including logging; all setup consumes the same 600 seconds. Start/worker/closure remain 120/300/180 seconds, with no retry/replacement and one StopBuild maximum.

Collector SHA256 `c8c48bca85972b414623cf61a1af7ec09f83996b43ac42e8b15e33784c5f1691`.

Buildspec SHA256 `81206e9b4145e0842d7c904f2dd76d4af6cc99f3fcd5142d743bee291e05177e`.

## Narrow resource amendment and actual read categories

Root explicitly amended only this diagnostic's new logical allocation from 32 MiB to 128 MiB during implementation, now recorded in Root rulings. Source 8 MiB, ZIP 1 MiB, metadata 64 KiB, selected model metadata 16 KiB/128 shapes, worker stdout 1.5 MiB, each traversal 1.6 MiB, owned disk 16 MiB and hard/soft address space 256 MiB stay unchanged. Packet refs and README carry the amendment.

Admission is `5U + 16*Zmax + 64 MiB bounded model reserve + 8 MiB margin <=128 MiB`. With maximum U=8 MiB and Zmax=1 MiB, 40+16+64+8=128 MiB. There is no new qualification/transport allocation.

The 5U terms are worker full read/hash/compression input and one Root expanded extraction/hash. Sixteen Zmax covers worker whole-ZIP hash and encoding consumers, both independently retained original-log parses, both frame parses/base64 decodes/whole-ZIP hashes and exact comparison, plus ZIP compressed-input validation/container slack. Both original traversals and both reconstructions are charged. Direct data-frame formatting and pad-bit checks avoid repeated generic data-frame serialization/base64 re-encoding. Up to 5 MiB of bounded slicing/ASCII formatting/output/response-size copies use the 8 MiB margin; the remaining 3 MiB covers bounded model/event selection/identity/package traversal and metadata/control/negative copies. This is conservative logical consumer accounting, not a claim to observe each native/runtime microinstruction.

Managed JSON model construction is explicitly declared activity. During fact construction, bounded local JSON/gzip readers charge compressed bytes once plus plain/decompressed bytes three times for read/output, decoding and parsing, with a hard 64 MiB weighted cap before unbounded reads/expansion. Published `model_io` counters report actual observed weighted work for that runtime. They are zero only in the generated no-model-file fixtures. Unsupported text-mode/direct read variants are negative. Full selected model bodies are not dumped; selected trait graph output remains capped. SDK import machinery is declared managed-runtime infrastructure; no installed bodies were inspected locally to invent a zero cost.

Worker source/ZIP processing is memory-only, with no expanded source staging. Disk 16 MiB covers one ZIP, two original traversal sets, possible <=8 MiB expanded originals and bounded control transients. Diagnostic C evidence remains <=4.5 MiB inside existing C8 MiB: 3.2 MiB two traversals +1 MiB one ZIP +0.3 MiB complete control including closure. No real capacity hold has been invoked by implementer.

## Frozen diff and custody

`inventory.json` contains hashes/lengths of 76 new private content files, totaling 254,352 bytes, including source/tests/README/fixtures/generated packet and all logs. `full-new-files.diff` contains every such new-file body plus inventory; no patch excerpts were substituted. Closing inventory/diff/summary receipts exclude themselves as documented to avoid circular hashes.

- Inventory SHA256 `a35a610d23023d24572706588e69e1ea35055168a9ee639f0d20e7ddafde9831`.
- Full diff bytes 271,759; SHA256 `65d1ce171837dba6bd3f3dc31a48e7e00e3fed2f657691191ab9d6f5c7f1e57f`.
- `freeze-summary.json` binds both and records exact scope. This external report is not part of its own inventory.

## Remaining readiness gaps

Independent SPEC/QUALITY review follows. No managed SDK fit, installed module sizes, actual hook/model shape, upstream authentication, model-read allowance fit or log-delivery closure has yet been observed. Unknown managed-runtime behavior produces a bounded negative, not fake support. Callback owners outside the 37 files remain explicit review gaps.

Root must instantiate actual identities/deadline, freeze real request bytes/hash, establish actual C/control response capacity and chronological receipts, retain fresh pricing/billing evidence and take the prospective $0.10 hold under standing user $20 authority. This includes submit-to-termination billing/rounding/logging and residual uncertainty if stop/termination is ambiguous. Cleanup remains Root-only after durable custody. The packet has no provider driver.

Root additionally identified an ambiguous StartBuild-without-id path: BatchGetBuilds requires a known id. Before paid execution, freeze an explicit bounded ListBuildsForProject reconciliation slot/request for the unique owned project, or leave that negative path blocked. No restart/retry is authorized. This report records the gap; no generic provider orchestration framework was added.


## Round1/5 scoped review fixes

2026-10-27. B1, B2 and B3 from task-1-review.md are addressed in this new frozen subject for independent scoped re-review. No actual managed SDK compatibility, provider observation/closure, transport approval or paid action is claimed. Sole code writer; no subagents, provider/network/corpus/installed-SDK reads, Git changes or commits.

Before any edits, preserved all 76 initial inventoried content subjects plus initial inventory, full diff, freeze summary and this initial report. All 80 copies are under `/workspace/scratch/managed-sdk-inspection/preserved-round0/`, independently bound in `round1-preservation-proof.json`. The initial report above remains byte-for-byte unchanged. No initial test/log output was overwritten.

B1 correction makes the permitted binary builtins.open/io.open model-file boundary explicit. During the active guard, CPython open auditing rejects unrecognized direct model-path opens before bytes are read. Direct io.FileIO/_io.FileIO and model-descriptor os.read/pread/readv/preadv are rejected, including descriptors that existed before the guard. Model descriptors are identified using the declared managed Linux /proc/self/fd premise. The wrapper retains its backing reader only in private guard state and exposes no fileno/backing/buffer/raw/detach/peek escape; only bounded readers and safe close/position/metadata operations are public. Existing supported binary/gzip reads remain charged by the same 64 MiB weighted counter. Nonmodel managed-import paths remain permitted. This is a finite Python model-reader boundary, not all-native or hostile-introspection closure proof.

B2 correction shares a private actual-id-to-callback-object dictionary across both real client scans. Strong references prevent id reuse while scanning, and the global cap checks actual objects rather than module/qualname labels. Published callback identities/order remain deterministic. A generated actual-adapter case rejects 258 distinct functions sharing one display identity across two individually acceptable clients; exactly 256 is admitted. No handler executes.

B3 correction checks worker entry time <= carrier_deadline-480 before ManagedRuntime construction or collection, preserving min(entry+300,carrier_deadline-180). A generated clock case at carrierStart+200 emits two bounded time_limit negative frames with zero runtime construction/collection. Entry exactly +120 reaches injected collection. Tests patch process-global limits/audit/clock hooks and never set actual address-space limits or import SDK bodies.

The two vacuous tests were replaced: test_exact_original_raw_bytes_cap now appends 1,700,000 whitespace bytes to an actual response_original string and requires log_original_limit, while test_callback_cap supplies 257 real callbacks to a recognized registry and requires event_limit.

The packet implements Root's complete-response disposition: six normal polls, ten returned-source copies, 6,144-byte full wrappers, fixed 314,572-byte control allowance and 65,536-byte closure reserve. Poll offsets are 15,45,90,150,225,300 seconds; intervals are 15,30,45,60,75,75. Explicit active wait chunks are [15],[30],[45],[60],[60,15],[60,15], with latest-start/worker/carrier deadline checks before every <=60-second chunk and no additional provider polls. No provider driver/framework was added. All source/archive/128 MiB logical/256 MiB address-space/16 MiB disk and other caps are unchanged.

### Round1 actual verification

Exact covering command, used for both RED and GREEN:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/managed-sdk-inspection -p 'test_*.py' -v
```

Actual RED stdout/stderr is retained in round1-red.log, exit 1 in round1-red.exit: 53 tests, 11 assertion failures. It was executed after adding regressions and before implementation corrections. Full actual output follows, including subtest failures and all passing cases. No earlier failure is invented for tests that passed immediately.

```text
test_append_zip_local_member_rejected (test_hardening.HardeningTests.test_append_zip_local_member_rejected) ... ok
test_exact_original_raw_bytes_cap (test_hardening.HardeningTests.test_exact_original_raw_bytes_cap) ... ok
test_frame_schema_bool_not_int (test_hardening.HardeningTests.test_frame_schema_bool_not_int) ... ok
test_guard_blocks_socket_construction (test_hardening.HardeningTests.test_guard_blocks_socket_construction) ... ok
test_negative_frame_is_bounded_known_reason (test_hardening.HardeningTests.test_negative_frame_is_bounded_known_reason) ... ok
test_sibling_source_symlink_parent (test_hardening.HardeningTests.test_sibling_source_symlink_parent) ... ok
test_simple_caps_nested_total_before_allocation (test_hardening.HardeningTests.test_simple_caps_nested_total_before_allocation) ... ok
test_source_change_during_read (test_hardening.HardeningTests.test_source_change_during_read) ... ok
test_gzip_expansion_is_bounded (test_hardening.ModelReadBudgetTests.test_gzip_expansion_is_bounded) ... ok
test_plain_json_actual_read_is_charged_and_bounded (test_hardening.ModelReadBudgetTests.test_plain_json_actual_read_is_charged_and_bounded) ... ok
test_direct_descriptor_open_is_rejected_before_read (test_hardening.ReviewModelBoundaryTests.test_direct_descriptor_open_is_rejected_before_read) ... FAIL
test_direct_fileio_is_rejected_before_read (test_hardening.ReviewModelBoundaryTests.test_direct_fileio_is_rejected_before_read) ... FAIL
test_existing_descriptor_fileio_is_rejected (test_hardening.ReviewModelBoundaryTests.test_existing_descriptor_fileio_is_rejected) ... FAIL
test_existing_descriptor_read_is_rejected (test_hardening.ReviewModelBoundaryTests.test_existing_descriptor_read_is_rejected) ... FAIL
test_nonmodel_managed_import_reads_remain_permitted (test_hardening.ReviewModelBoundaryTests.test_nonmodel_managed_import_reads_remain_permitted) ... ok
test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) ... 
  test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='fileno') ... FAIL
  test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='wrapped') ... FAIL
  test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='detach') ... FAIL
  test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='peek') ... FAIL
test_admission_before_body_reads (test_inspection.CollectorTests.test_admission_before_body_reads) ... ok
test_alias_wildcard_callback_order (test_inspection.CollectorTests.test_alias_wildcard_callback_order) ... ok
test_archive_and_metadata_caps (test_inspection.CollectorTests.test_archive_and_metadata_caps) ... ok
test_callback_cap (test_inspection.CollectorTests.test_callback_cap) ... ok
test_changed_before_open (test_inspection.CollectorTests.test_changed_before_open) ... ok
test_exact_complete_inventory_and_determinism (test_inspection.CollectorTests.test_exact_complete_inventory_and_determinism) ... ok
test_missing_source (test_inspection.CollectorTests.test_missing_source) ... ok
test_socket_rejection_before_dispatch (test_inspection.CollectorTests.test_socket_rejection_before_dispatch) ... ok
test_source_and_fact_caps (test_inspection.CollectorTests.test_source_and_fact_caps) ... ok
test_source_less (test_inspection.CollectorTests.test_source_less) ... ok
test_symlink_source (test_inspection.CollectorTests.test_symlink_source) ... ok
test_unknown_event_registry_is_negative (test_inspection.CollectorTests.test_unknown_event_registry_is_negative) ... ok
test_untrusted_origin (test_inspection.CollectorTests.test_untrusted_origin) ... ok
test_deterministic_frozen_source_and_no_image_inputs (test_inspection.PacketTests.test_deterministic_frozen_source_and_no_image_inputs) ... FAIL
test_owner_schema (test_inspection.PacketTests.test_owner_schema) ... ok
test_altered_frame (test_inspection.ProtocolTests.test_altered_frame) ... ok
test_archive_traversal (test_inspection.ProtocolTests.test_archive_traversal) ... ok
test_before_terminal (test_inspection.ProtocolTests.test_before_terminal) ... ok
test_changing_logs (test_inspection.ProtocolTests.test_changing_logs) ... ok
test_duplicate_frame (test_inspection.ProtocolTests.test_duplicate_frame) ... ok
test_foreign_nonce (test_inspection.ProtocolTests.test_foreign_nonce) ... ok
test_frame_ceiling (test_inspection.ProtocolTests.test_frame_ceiling) ... ok
test_identity_join (test_inspection.ProtocolTests.test_identity_join) ... ok
test_missing_eof (test_inspection.ProtocolTests.test_missing_eof) ... ok
test_missing_frame (test_inspection.ProtocolTests.test_missing_frame) ... ok
test_reordered_frames (test_inspection.ProtocolTests.test_reordered_frames) ... ok
test_second_stream (test_inspection.ProtocolTests.test_second_stream) ... ok
test_two_complete_traversals (test_inspection.ProtocolTests.test_two_complete_traversals) ... ok
test_unstable_stream (test_inspection.ProtocolTests.test_unstable_stream) ... ok
test_global_actual_callback_objects_not_display_names (test_runtime.ReviewCallbackIdentityTests.test_global_actual_callback_objects_not_display_names) ... FAIL
test_global_exact_256_distinct_callbacks_admitted (test_runtime.ReviewCallbackIdentityTests.test_global_exact_256_distinct_callbacks_admitted) ... ok
test_exact_latest_start_reaches_collection (test_runtime.ReviewWorkerStartTests.test_exact_latest_start_reaches_collection) ... ok
test_late_worker_is_negative_before_runtime_construction (test_runtime.ReviewWorkerStartTests.test_late_worker_is_negative_before_runtime_construction) ... FAIL
test_callback_count_is_enforced_without_execution (test_runtime.RuntimeAdapterTests.test_callback_count_is_enforced_without_execution) ... ok
test_missing_managed_source_resolution_is_negative_without_import (test_runtime.RuntimeAdapterTests.test_missing_managed_source_resolution_is_negative_without_import) ... ok
test_real_fact_adapter_on_generated_runtime (test_runtime.RuntimeAdapterTests.test_real_fact_adapter_on_generated_runtime) ... ok
test_unknown_model_type_is_negative (test_runtime.RuntimeAdapterTests.test_unknown_model_type_is_negative) ... ok

======================================================================
FAIL: test_direct_descriptor_open_is_rejected_before_read (test_hardening.ReviewModelBoundaryTests.test_direct_descriptor_open_is_rejected_before_read)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 106, in test_direct_descriptor_open_is_rejected_before_read
    with self.assertRaisesRegex(ValueError,'model_io_limit'):
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: ValueError not raised

======================================================================
FAIL: test_direct_fileio_is_rejected_before_read (test_hardening.ReviewModelBoundaryTests.test_direct_fileio_is_rejected_before_read)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 100, in test_direct_fileio_is_rejected_before_read
    with self.assertRaisesRegex(ValueError,'model_io_limit'):
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: ValueError not raised

======================================================================
FAIL: test_existing_descriptor_fileio_is_rejected (test_hardening.ReviewModelBoundaryTests.test_existing_descriptor_fileio_is_rejected)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 122, in test_existing_descriptor_fileio_is_rejected
    self.assertRaisesRegex(ValueError,'model_io_limit',io.FileIO,fd,'rb',closefd=False)
AssertionError: ValueError not raised by FileIO

======================================================================
FAIL: test_existing_descriptor_read_is_rejected (test_hardening.ReviewModelBoundaryTests.test_existing_descriptor_read_is_rejected)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 115, in test_existing_descriptor_read_is_rejected
    self.assertRaisesRegex(ValueError,'model_io_limit',os.read,fd,128)
AssertionError: ValueError not raised by read

======================================================================
FAIL: test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='fileno')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 130, in test_wrapped_reader_exposes_no_descriptor_or_backing_reader
    self.assertRaisesRegex(ValueError,'model_io_limit',getattr,f,name)
AssertionError: ValueError not raised by getattr

======================================================================
FAIL: test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='wrapped')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 130, in test_wrapped_reader_exposes_no_descriptor_or_backing_reader
    self.assertRaisesRegex(ValueError,'model_io_limit',getattr,f,name)
AssertionError: ValueError not raised by getattr

======================================================================
FAIL: test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='detach')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 130, in test_wrapped_reader_exposes_no_descriptor_or_backing_reader
    self.assertRaisesRegex(ValueError,'model_io_limit',getattr,f,name)
AssertionError: ValueError not raised by getattr

======================================================================
FAIL: test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) (name='peek')
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_hardening.py", line 130, in test_wrapped_reader_exposes_no_descriptor_or_backing_reader
    self.assertRaisesRegex(ValueError,'model_io_limit',getattr,f,name)
AssertionError: ValueError not raised by getattr

======================================================================
FAIL: test_deterministic_frozen_source_and_no_image_inputs (test_inspection.PacketTests.test_deterministic_frozen_source_and_no_image_inputs)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_inspection.py", line 185, in test_deterministic_frozen_source_and_no_image_inputs
    self.assertEqual(a['refs']['planned_polls'],6)
AssertionError: 10 != 6

======================================================================
FAIL: test_global_actual_callback_objects_not_display_names (test_runtime.ReviewCallbackIdentityTests.test_global_actual_callback_objects_not_display_names)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_runtime.py", line 128, in test_global_actual_callback_objects_not_display_names
    self.assertRaisesRegex(ValueError,'event_limit',self.run_generated_fact_adapter,groups)
AssertionError: ValueError not raised by run_generated_fact_adapter

======================================================================
FAIL: test_late_worker_is_negative_before_runtime_construction (test_runtime.ReviewWorkerStartTests.test_late_worker_is_negative_before_runtime_construction)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "/workspace/scratch/managed-sdk-inspection/test_runtime.py", line 157, in test_late_worker_is_negative_before_runtime_construction
    self.assertEqual(frames[0]['reason'],'time_limit')
AssertionError: 'model_shape' != 'time_limit'
- model_shape
+ time_limit


----------------------------------------------------------------------
Ran 53 tests in 0.098s

FAILED (failures=11)
```

An intermediate corrected run, round1-green-attempt1.log/exit, passed all 53 tests. The final covering run is round1-green.log/exit, exit 0, 53 tests, 0 failures/errors. Full actual final output follows.

```text
test_append_zip_local_member_rejected (test_hardening.HardeningTests.test_append_zip_local_member_rejected) ... ok
test_exact_original_raw_bytes_cap (test_hardening.HardeningTests.test_exact_original_raw_bytes_cap) ... ok
test_frame_schema_bool_not_int (test_hardening.HardeningTests.test_frame_schema_bool_not_int) ... ok
test_guard_blocks_socket_construction (test_hardening.HardeningTests.test_guard_blocks_socket_construction) ... ok
test_negative_frame_is_bounded_known_reason (test_hardening.HardeningTests.test_negative_frame_is_bounded_known_reason) ... ok
test_sibling_source_symlink_parent (test_hardening.HardeningTests.test_sibling_source_symlink_parent) ... ok
test_simple_caps_nested_total_before_allocation (test_hardening.HardeningTests.test_simple_caps_nested_total_before_allocation) ... ok
test_source_change_during_read (test_hardening.HardeningTests.test_source_change_during_read) ... ok
test_gzip_expansion_is_bounded (test_hardening.ModelReadBudgetTests.test_gzip_expansion_is_bounded) ... ok
test_plain_json_actual_read_is_charged_and_bounded (test_hardening.ModelReadBudgetTests.test_plain_json_actual_read_is_charged_and_bounded) ... ok
test_direct_descriptor_open_is_rejected_before_read (test_hardening.ReviewModelBoundaryTests.test_direct_descriptor_open_is_rejected_before_read) ... ok
test_direct_fileio_is_rejected_before_read (test_hardening.ReviewModelBoundaryTests.test_direct_fileio_is_rejected_before_read) ... ok
test_existing_descriptor_fileio_is_rejected (test_hardening.ReviewModelBoundaryTests.test_existing_descriptor_fileio_is_rejected) ... ok
test_existing_descriptor_read_is_rejected (test_hardening.ReviewModelBoundaryTests.test_existing_descriptor_read_is_rejected) ... ok
test_nonmodel_managed_import_reads_remain_permitted (test_hardening.ReviewModelBoundaryTests.test_nonmodel_managed_import_reads_remain_permitted) ... ok
test_wrapped_reader_exposes_no_descriptor_or_backing_reader (test_hardening.ReviewModelBoundaryTests.test_wrapped_reader_exposes_no_descriptor_or_backing_reader) ... ok
test_admission_before_body_reads (test_inspection.CollectorTests.test_admission_before_body_reads) ... ok
test_alias_wildcard_callback_order (test_inspection.CollectorTests.test_alias_wildcard_callback_order) ... ok
test_archive_and_metadata_caps (test_inspection.CollectorTests.test_archive_and_metadata_caps) ... ok
test_callback_cap (test_inspection.CollectorTests.test_callback_cap) ... ok
test_changed_before_open (test_inspection.CollectorTests.test_changed_before_open) ... ok
test_exact_complete_inventory_and_determinism (test_inspection.CollectorTests.test_exact_complete_inventory_and_determinism) ... ok
test_missing_source (test_inspection.CollectorTests.test_missing_source) ... ok
test_socket_rejection_before_dispatch (test_inspection.CollectorTests.test_socket_rejection_before_dispatch) ... ok
test_source_and_fact_caps (test_inspection.CollectorTests.test_source_and_fact_caps) ... ok
test_source_less (test_inspection.CollectorTests.test_source_less) ... ok
test_symlink_source (test_inspection.CollectorTests.test_symlink_source) ... ok
test_unknown_event_registry_is_negative (test_inspection.CollectorTests.test_unknown_event_registry_is_negative) ... ok
test_untrusted_origin (test_inspection.CollectorTests.test_untrusted_origin) ... ok
test_deterministic_frozen_source_and_no_image_inputs (test_inspection.PacketTests.test_deterministic_frozen_source_and_no_image_inputs) ... ok
test_owner_schema (test_inspection.PacketTests.test_owner_schema) ... ok
test_altered_frame (test_inspection.ProtocolTests.test_altered_frame) ... ok
test_archive_traversal (test_inspection.ProtocolTests.test_archive_traversal) ... ok
test_before_terminal (test_inspection.ProtocolTests.test_before_terminal) ... ok
test_changing_logs (test_inspection.ProtocolTests.test_changing_logs) ... ok
test_duplicate_frame (test_inspection.ProtocolTests.test_duplicate_frame) ... ok
test_foreign_nonce (test_inspection.ProtocolTests.test_foreign_nonce) ... ok
test_frame_ceiling (test_inspection.ProtocolTests.test_frame_ceiling) ... ok
test_identity_join (test_inspection.ProtocolTests.test_identity_join) ... ok
test_missing_eof (test_inspection.ProtocolTests.test_missing_eof) ... ok
test_missing_frame (test_inspection.ProtocolTests.test_missing_frame) ... ok
test_reordered_frames (test_inspection.ProtocolTests.test_reordered_frames) ... ok
test_second_stream (test_inspection.ProtocolTests.test_second_stream) ... ok
test_two_complete_traversals (test_inspection.ProtocolTests.test_two_complete_traversals) ... ok
test_unstable_stream (test_inspection.ProtocolTests.test_unstable_stream) ... ok
test_global_actual_callback_objects_not_display_names (test_runtime.ReviewCallbackIdentityTests.test_global_actual_callback_objects_not_display_names) ... ok
test_global_exact_256_distinct_callbacks_admitted (test_runtime.ReviewCallbackIdentityTests.test_global_exact_256_distinct_callbacks_admitted) ... ok
test_exact_latest_start_reaches_collection (test_runtime.ReviewWorkerStartTests.test_exact_latest_start_reaches_collection) ... ok
test_late_worker_is_negative_before_runtime_construction (test_runtime.ReviewWorkerStartTests.test_late_worker_is_negative_before_runtime_construction) ... ok
test_callback_count_is_enforced_without_execution (test_runtime.RuntimeAdapterTests.test_callback_count_is_enforced_without_execution) ... ok
test_missing_managed_source_resolution_is_negative_without_import (test_runtime.RuntimeAdapterTests.test_missing_managed_source_resolution_is_negative_without_import) ... ok
test_real_fact_adapter_on_generated_runtime (test_runtime.RuntimeAdapterTests.test_real_fact_adapter_on_generated_runtime) ... ok
test_unknown_model_type_is_negative (test_runtime.RuntimeAdapterTests.test_unknown_model_type_is_negative) ... ok

----------------------------------------------------------------------
Ran 53 tests in 0.102s

OK
```

Additional provider-free verification commands:

```sh
PYTHONDONTWRITEBYTECODE=1 python /workspace/scratch/managed-sdk-inspection/freeze.py
PYTHONDONTWRITEBYTECODE=1 python /workspace/scratch/managed-sdk-inspection/freeze.py --freeze
```

The generated packet/accounting command's complete output is retained in round1-packet-accounting.log. The final --freeze output reports the same packet refs plus current inventory/full-diff hashes. An inline standard-library-only check parsed the launcher shell argument and AST literal, compared decompressed bytes to inspect_sdk.py without executing the launcher, reverified the generated two-traversal capture/one ZIP, and checked all 80 preserved copies. Its exact observed output is:

```text
PASS: exact shell argument and compressed collector bytes round-trip; launcher not executed
PASS: generated complete two-traversal capture verifies one archive, 37 full source originals
PASS: all80 original reviewed subjects preserved byte-for-byte, including76 content subjects
No installed SDK source import/read, provider/network/corpus/Git action
```

### Round1 exact packet and frozen subjects

Generated example only; Root must instantiate actual identities/deadline and re-freeze before any mutation. Complete response wrapper capacity remains an admission envelope, not observed new-job output.

| Item | Bytes/count |
| --- | ---: |
| Collector bytes | 27557 |
| Inline buildspec UTF-8 bytes | 12171 |
| Complete JSON-encoded buildspec string bytes | 12215 |
| Complete canonical CreateProject request bytes | 12887 |
| Returned-source copies | 10 |
| Complete wrapper bytes each | 6144 |
| Other setup/control bytes | 24576 |
| Closure reserve bytes | 65536 |
| Estimated complete control bytes | 286589 |
| Control maximum bytes | 314572 |
| Unallocated control bytes | 27983 |

Exact arithmetic: `12887 + 10*12215 + 10*6144 + 24576 + 65536 = 286589 <=314572`. This leaves 27,983 bytes without lowering wrappers, deleting originals or borrowing closure/log evidence. Actual larger/unknown responses remain a bounded negative.

Collector SHA256 `3041afb0a4e347fba039d3f20d22c4679a5b3805399bdff6ef5c951d9fa85931`.

Buildspec SHA256 `3b7ad02e0ea2e0fad7b8233dca68981c34754180f02d29839bade6e591b80642`.

Current inventory: 85 content subjects, 307615 bytes; SHA256 `887c89bded871804b11a1def0b291f1143ff03abc988b7a283944714be8d5674`. Preserved-round0 and closing receipts are excluded and bound separately.

Current full new-file diff SHA256 `f4586b50207d7c822e21c2d7913488661458c76bcd1f668f8753300ddc851b4d`, 327252 bytes.

Scoped fix diff against initial reviewed content: `/workspace/scratch/managed-sdk-inspection/round1-scoped-fix.diff`, SHA256 `226ee911bce8904b43df0b03e553e927e90dfa71930325cd1c263c7555b7f4e3`, 165709 bytes. It includes changed source/tests/README, generated packet/buildspec and new exact logs/proof. Closing inventory/diff/report receipts are separately bound to avoid circular hashes.

Preservation proof SHA256 `98ae3100b1e9e597df4d408c16282e59c138d70c7adf5c5f748911f30764a346`. Initial inventory/diff/report hashes remain those pinned by independent review, with exact originals retained. `round1-freeze.json` binds current inventory/full diff/scoped diff/preservation proof and this appended report.

Remaining Root gates are actual identities/deadline/request freeze, complete response/remaining C headroom, chronological custody, prospective $0.10 cost hold and actual runtime/log observations. Root rulings now assign the read-only ambiguous-Start ListBuildsForProject reconciliation slot; Root must instantiate its exact execution request and preserve the one-start/no-retry/at-most-one-stop path. Independent scoped re-review follows. No source/native/semantic qualification is granted.
