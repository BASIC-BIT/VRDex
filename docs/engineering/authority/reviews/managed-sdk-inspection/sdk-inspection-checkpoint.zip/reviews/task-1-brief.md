# Managed SDK inspection task1 brief

Read the binding design /workspace/scratch/managed-sdk-inspection-design.md and Root dispositions /workspace/VRDex/.superpowers/sdd/managed-sdk-inspection/root-rulings.md.

## Global constraints

- Private files only under `/workspace/scratch/managed-sdk-inspection/`; do not change tracked source or existing helpers. No subagents, provider calls, network requests, corpus reads or commits by implementer/reviewer.
- Standard7.0/Python3.12 SMALL, nonprivileged NO_SOURCE/NO_ARTIFACTS/NO_CACHE; externally frozen inline buildspec at most65,536 UTF-8 bytes. CloudWatch only; no custom signer, credential fetch, uploader, S3 output or dependency installation.
- Exact37 modules and three operation/event/configuration scopes from the spec. Complete source bodies, bounded metadata and honest unknowns; no partial archive labelled complete or support approval from hashes.
- New32MiB all-reader allocation,16MiB disk,256MiB hard/soft address-space limit; admission5U+16MiB+4MiB<=32MiB before selected-source reads. Source8MiB/ZIP1MiB/metadata64KiB ceilings and all spec sublimits apply.
- At most24 data frames of45,000 raw bytes each plus header/trailer. Whole nonce/archive length/hash/count and metadata hash bind exact inventory. Worker zero network calls, dummy inspection credentials only, no arbitrary exception/environment output.
- Two complete independently retained log traversals, each<=6 calls/256 events/1.6MiB, stable forward-token EOF, exact build/stream identity. One retained ZIP, total diagnostic evidence<=4.5MiB within existing C8MiB.
- Root74 API invocations,600s carrier/120s start/300s worker/180s closure; no retries or replacement job. Cost reservation remains Root-only and must include submit-to-termination billing, rounding and logging, within existing user20USD authority.
- No real SDK support, image transfer, source authentication, semantic/native/loader approval or capacity admission follows from this diagnostic.

## Review focus

- Source-less, symlinked, changed, oversize or untrusted-origin modules fail before unbounded reads.
- Unknown event registry/model shapes remain explicit negative facts, with deterministic ordered callback evidence and no handler execution.
- Network attempts fail before socket dispatch; no fallback credential chain or stdout leak.
- Missing, duplicate, reordered, foreign-nonce or altered frames and incomplete/changing log traversals fail verification.
- Byte/time/memory/output limits and negative publication remain enforced before expensive actions; full originals are never replaced by excerpts.

### Task1: Collector, packet and offline verifier

**Files:** Create `inspect_sdk.py`, `packet.py`, `verify.py`, corresponding `test_*.py`, `README.md` and generated support fixtures under the private root. SDD report path is supplied separately. A small shared module is permitted only if the interfaces need it; avoid a generic collection framework.

**Interfaces:** `collect(runtime, limits) -> (metadata, archive_bytes)` supports injected generated source/runtime facts; real entrypoint establishes limits before managed SDK import. `prepare_packet(owned, collector_bytes) -> {buildspec, project, start, refs}` returns deterministic exact offline configuration, with no provider action. `verify_capture(provider_originals, expected) -> {status, archive_bytes, inventory, gaps}` consumes two complete framed provider traversals plus actual build/stream facts and rejects incomplete custody. Freeze exact field schemas in README and fixtures so Root can instantiate them without code edits. Real runtime adaptation may use private helpers, but fake acceptance never stands in for real support.

- [ ] Write generated failing fixtures for the five review-focus classes, frame and module limits, exact source inventory, event alias/wildcard ordering, two-read EOF and provider identity joins. Record the actual RED command/output; do not manufacture prior failures for later tests.
- [ ] Implement the finite collector and deterministic packet, including the exact37-module list, bounded source/model/event inspection, explicit managed-runtime trust, dummy credentials, send/socket rejection and one complete success or bounded-negative output.
- [ ] Implement verifier with strict canonical archive names/types/counts/hash/size and exact whole-archive reassembly from both original traversals. Preserve provider-capture class honestly; no HTTP-wire or finality claim beyond observations.
- [ ] Run `PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/managed-sdk-inspection -p 'test_*.py' -v`; retain command, exit and full output. Do not import actual boto3 or read installed SDK/native/corpus bodies in tests.
- [ ] Self-review spec coverage, then freeze source/test/README/fixture hashes and a full new-file diff, including generated packet and logs. Write the report with exact tests/results, interface schema, bytes/limits and remaining readiness gaps. No provider execution or commits. Independent SPEC/QUALITY review follows.

