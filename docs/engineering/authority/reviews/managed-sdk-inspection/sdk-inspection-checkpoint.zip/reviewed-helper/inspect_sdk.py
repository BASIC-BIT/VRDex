"""Finite managed-runtime source inspection. Never a transport support profile."""
import base64
import builtins
import gzip
import contextlib
import hashlib
import importlib
import importlib.metadata
import importlib.machinery
import io
import _io
import json
import math
import os
from pathlib import Path
import re
import resource
import signal
import socket
import ssl
import stat
import sys
import sysconfig
import time
import threading
import zipfile

MODULES = '''boto3.session botocore.session botocore.client botocore.config botocore.args botocore.model botocore.hooks botocore.handlers botocore.utils botocore.endpoint botocore.signers botocore.auth botocore.awsrequest botocore.serialize botocore.validate botocore.httpchecksum botocore.compress botocore.httpsession botocore.response botocore.parsers botocore.compat urllib3._request_methods urllib3.connection urllib3.connectionpool urllib3.poolmanager urllib3.response urllib3.util.request urllib3.util.retry urllib3.util.timeout urllib3.util.ssl_ urllib3.util.url urllib.request http.client json.encoder base64 ssl socket'''.split()
EVENTS = 'before-parameter-build provide-client-params before-call request-created choose-signer before-sign before-send response-received needs-retry after-call'.split()
MAX = {'source_bytes':8*1024**2, 'zip_bytes':1024**2, 'metadata_bytes':65536, 'model_bytes':16384, 'logical_bytes':128*1024**2}
REASONS = set('inventory source_path source_origin source_changed source_limit admission archive_limit metadata_limit model_limit event_registry event_limit model_io_limit model_shape network_forbidden runtime_shape time_limit output_limit unexpected'.split())

def require(condition, reason):
    if not condition:
        raise ValueError(reason)

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, allow_nan=False).encode('ascii')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def text(value, maximum=512):
    require(isinstance(value, str) and len(value) <= maximum, 'runtime_shape')
    return value

def simple(value, depth=0, budget=None):
    """Bounded JSON facts only; never repr or arbitrary object dictionaries."""
    if budget is None: budget = [65536, 4096]
    budget[1] -= 1
    require(depth <= 8 and budget[1]>=0, 'runtime_shape')
    budget[0] -= len(value) if type(value) is str else 16
    require(budget[0]>=0, 'runtime_shape')
    if value is None or type(value) in (bool, int):
        return value
    if type(value) is str:
        return text(value, 4096)
    if type(value) in (list, tuple):
        require(len(value) <= 256, 'runtime_shape')
        return [simple(x, depth+1, budget) for x in value]
    if type(value) is dict:
        require(len(value) <= 256, 'runtime_shape')
        return {text(k):simple(v, depth+1, budget) for k,v in value.items()}
    raise ValueError('runtime_shape')

def identity(obj):
    if hasattr(obj, '__func__'):
        obj = obj.__func__
    if not hasattr(obj, '__qualname__'):
        obj = type(obj)
    return {'module':text(obj.__module__), 'qualname':text(obj.__qualname__)}

@contextlib.contextmanager
def network_guard():
    """Reject connect, DNS, UDP and direct socket sends before dispatch."""
    def blocked(*args, **kwargs):
        raise ValueError('network_forbidden')
    targets = [(socket, n) for n in ('create_connection','getaddrinfo','gethostbyname','gethostbyname_ex','gethostbyaddr')]
    targets += [(socket.socket,n) for n in ('__init__','connect','connect_ex','send','sendall','sendto','sendmsg') if hasattr(socket.socket,n)]
    targets += [(ssl.SSLSocket,n) for n in ('connect','connect_ex','send','sendall','sendto','sendmsg') if hasattr(ssl.SSLSocket,n)]
    saved = [(obj,n,getattr(obj,n)) for obj,n in targets]
    for obj,n,_ in saved:
        setattr(obj,n,blocked)
    try:
        yield
    finally:
        for obj,n,value in reversed(saved):
            setattr(obj,n,value)

@contextlib.contextmanager
def model_read_guard(limit=64*1024**2):
    """Charge local JSON reads, decode/parse and gzip output conservatively.

    Plain/decompressed JSON bytes cost 3 each for read, decode and parse;
    compressed input bytes cost 1 additionally. No model data is published.
    """
    counters={'weighted_bytes':0,'limit':limit,'compressed_bytes':0,'json_bytes':0}
    original_open=builtins.open; original_io_open=io.open
    original_read=gzip.GzipFile.read; original_read1=gzip.GzipFile.read1
    original_fileio=io.FileIO; original_raw_fileio=_io.FileIO
    descriptor_readers={name:getattr(os,name) for name in ('read','pread','readv','preadv') if hasattr(os,name)}
    active=True; permitted=0; streams={}
    def bound(size,weight):
        remaining=limit-counters['weighted_bytes']
        require(remaining>=0,'model_io_limit')
        maximum=remaining//weight+1
        return maximum if size is None or size<0 else min(size,maximum)
    def charge(data,weight,kind):
        count=len(data)
        counters[kind]+=count; counters['weighted_bytes']+=count*weight
        require(counters['weighted_bytes']<=limit,'model_io_limit')
        return data
    def model_path(path):
        if isinstance(path,int):
            try: path=os.readlink('/proc/self/fd/'+str(path))
            except OSError: raise ValueError('model_io_limit') from None
            path=path.removesuffix(' (deleted)')
        if not isinstance(path,(str,bytes,os.PathLike)): return False
        name=os.fsdecode(path)
        return name.endswith(('.json','.json.gz')) or os.path.realpath(name).endswith(('.json','.json.gz'))
    def audit(event,args):
        if active and event=='open' and not permitted and model_path(args[0]):
            raise ValueError('model_io_limit')
    sys.addaudithook(audit)
    def direct_fileio(original,path,*args,**kwargs):
        require(not model_path(path),'model_io_limit')
        return original(path,*args,**kwargs)
    def direct_read(original,fd,*args,**kwargs):
        require(not model_path(fd),'model_io_limit')
        return original(fd,*args,**kwargs)
    class JSONFile:
        __slots__=('weight','kind')
        def __init__(self,wrapped,compressed):
            streams[id(self)]=wrapped; self.weight=1 if compressed else 3
            self.kind='compressed_bytes' if compressed else 'json_bytes'
        def read(self,size=-1):
            return charge(streams[id(self)].read(bound(size,self.weight)),self.weight,self.kind)
        def readline(self,size=-1):
            return charge(streams[id(self)].readline(bound(size,self.weight)),self.weight,self.kind)
        def readinto(self,buffer):
            data=self.read(len(buffer)); buffer[:len(data)]=data; return len(data)
        def __iter__(self): return self
        def __next__(self):
            value=self.readline()
            if not value: raise StopIteration
            return value
        def __enter__(self): return self
        def __exit__(self,*args): return streams[id(self)].__exit__(*args)
        def __getattr__(self,name):
            require(name in {'name','mode','closed','close','seek','tell','readable','seekable','writable','flush'},'model_io_limit')
            return getattr(streams[id(self)],name)
    def opening(original,path,*args,**kwargs):
        nonlocal permitted
        is_model=model_path(path)
        if is_model:
            require(not isinstance(path,int),'model_io_limit')
            mode=kwargs.get('mode',args[0] if args else 'r')
            require('b' in mode and not any(c in mode for c in 'wa+'),'model_io_limit')
        permitted+=1
        try: wrapped=original(path,*args,**kwargs)
        finally: permitted-=1
        return JSONFile(wrapped,os.path.realpath(os.fsdecode(path)).endswith('.gz')) if is_model else wrapped
    builtins.open=lambda path,*a,**k:opening(original_open,path,*a,**k)
    io.open=lambda path,*a,**k:opening(original_io_open,path,*a,**k)
    io.FileIO=lambda path,*a,**k:direct_fileio(original_fileio,path,*a,**k)
    _io.FileIO=lambda path,*a,**k:direct_fileio(original_raw_fileio,path,*a,**k)
    for name,original in descriptor_readers.items():
        setattr(os,name,lambda fd,*a,_original=original,**k:direct_read(_original,fd,*a,**k))
    gzip.GzipFile.read=lambda obj,size=-1:charge(original_read(obj,bound(size,3)),3,'json_bytes')
    gzip.GzipFile.read1=lambda obj,size=-1:charge(original_read1(obj,bound(size,3)),3,'json_bytes')
    try:
        yield counters
    finally:
        active=False
        builtins.open=original_open; io.open=original_io_open
        io.FileIO=original_fileio; _io.FileIO=original_raw_fileio
        for name,original in descriptor_readers.items(): setattr(os,name,original)
        gzip.GzipFile.read=original_read; gzip.GzipFile.read1=original_read1

class LimitedZip(io.BytesIO):
    def __init__(self, limit):
        super().__init__(); self.limit = limit
    def write(self, data):
        require(self.tell()+len(data) <= self.limit, 'archive_limit')
        return super().write(data)

def zip_info(name):
    z = zipfile.ZipInfo(name, (1980,1,1,0,0,0))
    z.compress_type = zipfile.ZIP_DEFLATED
    z.create_system = 3
    z.external_attr = (stat.S_IFREG | 0o444) << 16
    return z

def checked_path(path, roots):
    p = Path(path)
    require(p.is_absolute() and p.suffix == '.py', 'source_path')
    for part in (p, *p.parents):
        require(not part.is_symlink(), 'source_path')
    try:
        s = p.lstat()
    except OSError:
        raise ValueError('source_path') from None
    require(stat.S_ISREG(s.st_mode), 'source_path')
    matching = [r for r in roots if p.is_relative_to(Path(r['path']))]
    require(bool(matching), 'source_origin')
    require(not s.st_mode & 0o022, 'source_origin')
    return s

def stable(s):
    return (s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns)

def secure_open(path):
    parts = Path(path).parts
    parent = os.open('/', os.O_RDONLY | os.O_DIRECTORY)
    try:
        for part in parts[1:-1]:
            child = os.open(part, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            os.close(parent); parent=child
        return os.open(parts[-1], os.O_RDONLY | os.O_NOFOLLOW, dir_fd=parent)
    except OSError:
        raise ValueError('source_path') from None
    finally:
        os.close(parent)

def collect(runtime, limits):
    lim = dict(MAX)
    require(set(limits) <= set(lim), 'runtime_shape')
    for key,value in limits.items():
        require(type(value) is int and 0 < value <= lim[key], 'runtime_shape')
        lim[key] = value
    paths,roots = runtime.sources()
    require(set(paths) == set(MODULES) and len(paths)==37, 'inventory')
    require(isinstance(roots,list) and 1 <= len(roots) <= 8, 'source_origin')
    originals = {name:checked_path(paths[name], roots) for name in MODULES}
    require(len({(s.st_dev,s.st_ino) for s in originals.values()}) == 37, 'inventory')
    total = sum(s.st_size for s in originals.values())
    require(total <= lim['source_bytes'], 'source_limit')
    require(5*total+16*MAX['zip_bytes']+72*1024**2 <= lim['logical_bytes'], 'admission')
    with model_read_guard() as model_io:
        facts = runtime.facts()
    facts['model_io'] = model_io
    require(len(canonical(facts.get('models',{}))) <= lim['model_bytes'], 'model_limit')
    require(len(canonical(facts)) <= lim['metadata_bytes'], 'metadata_limit')
    metadata = {'schema':1,'status':'complete-selected-sources','modules':[], 'raw_source_bytes':total,'roots':roots,'facts':facts, 'trust':facts.get('trust','unspecified injected runtime'), 'limits':lim}
    out = LimitedZip(lim['zip_bytes'])
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name in MODULES:
            runtime.before_open(name)
            path = paths[name]
            fd = secure_open(path)
            try:
                require(stable(os.fstat(fd)) == stable(originals[name]), 'source_changed')
                h = hashlib.sha256(); count = 0
                member = 'sources/' + name.replace('.', '/') + '.py'
                with archive.open(zip_info(member),'w') as dest:
                    while count < originals[name].st_size:
                        chunk = os.read(fd,min(65536,originals[name].st_size-count))
                        require(bool(chunk), 'source_changed')
                        count += len(chunk); h.update(chunk); dest.write(chunk)
                    require(not os.read(fd,1), 'source_changed')
                require(stable(os.fstat(fd)) == stable(originals[name]), 'source_changed')
                require(stable(checked_path(path,roots)) == stable(originals[name]), 'source_changed')
                metadata['modules'].append({'module':name,'archive':member,'path':path,'bytes':count,'sha256':h.hexdigest()})
            finally:
                os.close(fd)
        body = canonical(metadata)
        require(len(body) <= lim['metadata_bytes'], 'metadata_limit')
        archive.writestr(zip_info('metadata.json'),body)
    return metadata,out.getvalue()

def event_facts(events, service, operations, callback_objects=None):
    """Recognize the local EventAliaser/HierarchicalEmitter/PrefixTrie shape.

    Enumerate its registrations, then observe prefix_search's actual order.
    Matching registration multiset must equal each observed ordered result.
    No callbacks are called and no guessed ordering is substituted.
    """
    emitter = getattr(events,'_emitter',None)
    trie = getattr(emitter,'_handlers',None)
    root = getattr(trie,'_root',None)
    require(type(root) is dict and callable(getattr(trie,'prefix_search',None)) and callable(getattr(events,'_alias_event_name',None)), 'event_registry')
    aliases = simple(getattr(events,'_event_aliases',None))
    require(type(aliases) is dict, 'event_registry')
    registrations=[]; nodes=0; event_bytes=0
    def walk(node, parts):
        nonlocal nodes
        nodes += 1
        require(nodes<=4096 and len(parts)<=16, 'event_limit')
        require(type(node) is dict and set(node)=={'chunk','children','values'} and type(node['children']) is dict, 'event_registry')
        values=node['values']
        if values is not None:
            require(getattr(values,'_fields',None)==('first','middle','last'), 'event_registry')
            for tier in ('first','middle','last'):
                seq=getattr(values,tier)
                require(type(seq) is list and len(seq)<=512, 'event_registry')
                for callback in seq:
                    require(callable(callback), 'event_registry')
                    registrations.append((parts,tier,callback))
                    require(len(registrations)<=512, 'event_limit')
        require(len(node['children'])<=512, 'event_limit')
        for key,child in node['children'].items():
            text(key); walk(child,parts+[key])
    walk(root,[])
    relevant=[]; matches=[]; used=set()
    if callback_objects is None: callback_objects={}
    for op in operations:
        for event in EVENTS:
            requested=event+'.'+service+'.'+op
            resolved=text(events._alias_event_name(requested))
            chunks=resolved.split('.')
            indexes=[i for i,(pattern,_,_) in enumerate(registrations) if len(pattern)<=len(chunks) and all(a=='*' or a==b for a,b in zip(pattern,chunks))]
            ordered=list(trie.prefix_search(resolved))
            require(len(ordered)<=256, 'event_limit')
            require(sorted(id(c) for c in ordered)==sorted(id(registrations[i][2]) for i in indexes), 'event_registry')
            used.update(indexes)
            callback_objects.update((id(c),c) for c in ordered)
            require(len(callback_objects)<=256, 'event_limit')
            entry={'event':requested,'resolved':resolved,'callbacks':[identity(c) for c in ordered]}
            event_bytes+=len(canonical(entry))
            require(event_bytes<=49152, 'event_limit')
            matches.append(entry)
    for i in sorted(used):
        parts,tier,callback=registrations[i]
        entry={'pattern':'.'.join(parts),'tier':tier,'callback':identity(callback)}
        event_bytes+=len(canonical(entry)); require(event_bytes<=49152, 'event_limit')
        relevant.append(entry)
    return {'aliases':aliases,'registrations':relevant,'matches':matches,'observed_order':'local prefix_search; no callback execution'}

TRAITS = {'streaming','payload','httpChecksum','httpChecksumRequired','authType','auth','requestCompression','unsignedPayload','eventstream','event','requiresLength','idempotent','sensitive','jsonvalue'}

def selected_traits(value):
    require(type(value) is dict, 'model_shape')
    return simple({k:v for k,v in value.items() if k in TRAITS})

def model_facts(client, operations):
    model=client.meta.service_model
    result={'protocol':simple(model.metadata.get('protocol')),'operations':{},'shapes':{}}
    queue=[]; model_bytes=0
    for name in operations:
        op=model.operation_model(name)
        result['operations'][name]={'input':getattr(op.input_shape,'name',None),'output':getattr(op.output_shape,'name',None),'traits':selected_traits(op._operation_model),'auth_type':simple(op.auth_type),'http_checksum':simple(op.http_checksum),'has_streaming_input':op.has_streaming_input,'has_streaming_output':op.has_streaming_output}
        queue.extend(s for s in (op.input_shape,op.output_shape) if s is not None)
    while queue:
        shape=queue.pop(0); name=text(shape.name)
        if name in result['shapes']: continue
        require(len(result['shapes'])<128, 'model_limit')
        raw=shape._shape_model
        node={'type':text(shape.type_name),'traits':selected_traits(raw),'serialization':simple(shape.serialization),'metadata':selected_traits(shape.metadata)}
        children=[]
        if shape.type_name=='structure':
            require(len(shape.members)<=128, 'model_limit')
            node['members']={text(k):text(v.name) for k,v in shape.members.items()}; children=list(shape.members.values())
            node['required']=simple(shape.required_members)
        elif shape.type_name=='list': node['member']=text(shape.member.name); children=[shape.member]
        elif shape.type_name=='map': node.update(key=text(shape.key.name), value=text(shape.value.name)); children=[shape.key,shape.value]
        else: require(shape.type_name in {'string','integer','long','float','double','boolean','timestamp','blob'}, 'model_shape')
        model_bytes+=len(canonical(node))+len(name)+4
        require(model_bytes<=16384, 'model_limit')
        result['shapes'][name]=node; queue.extend(children)
    require(len(canonical(result))<=16384, 'model_limit')
    return result

class ManagedRuntime:
    def __init__(self):
        self.paths={}; self.roots=[]
    def sources(self):
        require(sys.version_info[:2]==(3,12), 'runtime_shape')
        for kind,key in [('stdlib','stdlib'),('site-packages','purelib'),('site-packages','platlib')]:
            root=str(Path(sysconfig.get_path(key)).resolve())
            require(root.startswith(('/usr/','/opt/','/root/.pyenv/versions/')), 'source_origin')
            if not any(r['path']==root for r in self.roots): self.roots.append({'path':root,'kind':kind})
        for name in MODULES:
            search=None; prefix=[]; spec=None
            for part in name.split('.'):
                prefix.append(part)
                spec=importlib.machinery.PathFinder.find_spec('.'.join(prefix),search)
                require(spec is not None and isinstance(spec.loader,importlib.machinery.SourceFileLoader), 'source_path')
                search=spec.submodule_search_locations
            require(isinstance(spec.origin,str), 'source_path')
            self.paths[name]=spec.origin
        return self.paths,self.roots
    def before_open(self,name): pass
    def facts(self):
        for name in MODULES:
            module=importlib.import_module(name)
            require(module.__spec__.origin==self.paths[name], 'source_origin')
        import boto3
        from botocore.config import Config
        from botocore.httpsession import URLLib3Session
        def reject(*args,**kwargs): raise ValueError('network_forbidden')
        original_send=identity(URLLib3Session.send)
        URLLib3Session.send=reject
        config=Config(region_name='us-east-1',retries={'total_max_attempts':1,'mode':'standard'},connect_timeout=1,read_timeout=1,max_pool_connections=1,proxies={},parameter_validation=True,s3={'addressing_style':'path'})
        clients={}; models={}; events={}; callback_objects={}; gaps=['selected Python set only; semantic/native/TLS/loader closure unproved','RealIO wrappers remain separately possessed pinned transport source, not executed here']
        for service,ops in [('ecr',['UploadLayerPart']),('s3',['GetObject','PutObject'])]:
            session=boto3.session.Session(aws_access_key_id='INSPECTIONDUMMY',aws_secret_access_key='inspection-dummy-secret',aws_session_token='inspection-dummy-token',region_name='us-east-1')
            endpoint='https://'+('api.ecr' if service=='ecr' else 's3')+'.us-east-1.amazonaws.com'
            client=session.client(service,endpoint_url=endpoint,config=config)
            # No service call, credential lookup, handler call or payload serialization.
            client._endpoint._needs_retry=lambda *a,**k:False
            client._endpoint.http_session.send=reject
            cfg=client.meta.config
            keys='region_name signature_version connect_timeout read_timeout max_pool_connections proxies parameter_validation retries s3 request_checksum_calculation response_checksum_validation request_min_compression_size_bytes disable_request_compression'.split()
            signer=client._request_signer
            clients[service]={'endpoint':endpoint,'configuration':{k:{'present':hasattr(cfg,k),'value':simple(getattr(cfg,k,None))} for k in keys},'client':identity(type(client)),'methods':{k:identity(getattr(obj,k)) for obj,keys in [(client,['_make_api_call','_convert_to_request_dict']+[{'UploadLayerPart':'upload_layer_part','GetObject':'get_object','PutObject':'put_object'}[op] for op in ops]),(client._endpoint,['make_request','create_request']),(client._serializer,['serialize_to_request'])] for k in keys},'original_http_send':original_send,'serializer':identity(type(client._serializer)),'serializer_wrapper':identity(type(getattr(client._serializer,'_serializer',client._serializer))),'http_session':identity(type(client._endpoint.http_session)),'signer':identity(type(signer)),'signature_version':simple(signer._signature_version),'auth_class':identity(signer.get_auth_instance(signer._signing_name,signer._region_name,signer._signature_version)),'inspection_changes':['HTTP send rejected','endpoint retry decision disabled'],'realio_changes':['before-send.*.* bound before_send','endpoint _needs_retry returns False','HTTP send bounded_sdk_send wrapper']}
            models[service]=model_facts(client,ops)
            events[service]=event_facts(client.meta.events,client.meta.service_model.service_id.hyphenize(),ops,callback_objects)
        require(sum(len(v['shapes']) for v in models.values())<=128, 'model_limit')
        require(len(canonical(models))<=16384, 'model_limit')
        callbacks=[c for e in events.values() for m in e['matches'] for c in m['callbacks']]
        require(len(callback_objects)<=256 and sum(len(e['registrations']) for e in events.values())<=512, 'event_limit')
        for c in callbacks:
            if c['module'] not in MODULES:
                gap='callback owner outside selected source set: '+c['module']
                if gap not in gaps: gaps.append(gap)
        packages={}
        for name in ('boto3','botocore','urllib3','s3transfer','jmespath','python-dateutil'):
            dist=importlib.metadata.distribution(name)
            requirements=dist.requires or []
            require(len(requirements)<=64, 'runtime_shape')
            packages[name]={'version':text(dist.version),'origin':text(str(dist.locate_file(''))),'requirements':[text(x,1024) for x in requirements]}
        return {'trust':'AWS-managed installed runtime; not externally authenticated','runtime':{'python':text(sys.version,1024),'executable':text(sys.executable),'platform':text(sys.platform),'ssl':text(ssl.OPENSSL_VERSION),'build_arn':text(os.environ.get('CODEBUILD_BUILD_ARN','')),'image':text(os.environ.get('CODEBUILD_BUILD_IMAGE',''))},'packages':packages,'clients':clients,'models':models,'events':events,'gaps':gaps}

def frame_output(metadata,archive,nonce):
    require(re.fullmatch('[0-9a-z]{32}',nonce) is not None, 'runtime_shape')
    require(0<len(archive)<=MAX['zip_bytes'], 'archive_limit')
    count=math.ceil(len(archive)/45000)
    require(count<=24, 'output_limit')
    common={'schema':1,'nonce':nonce,'archive_bytes':len(archive),'archive_sha256':digest(archive),'frame_count':count,'module_count':37,'metadata_sha256':digest(canonical(metadata))}
    lines=['SDKI1 H '+canonical(dict(common,status='complete-selected-sources')).decode()]
    for seq in range(count):
        data=base64.b64encode(archive[seq*45000:(seq+1)*45000]).decode('ascii')
        lines.append('SDKI1 D {"nonce":"%s","seq":%d,"data":"%s"}' % (nonce,seq,data))
    lines.append('SDKI1 T '+canonical(common).decode())
    require(all(len(s)<65536 for s in lines) and sum(len(s)+1 for s in lines)<=1572864, 'output_limit')
    return lines

class RejectOutput:
    def write(self,data):
        if data: raise ValueError('output_limit')
        return 0
    def flush(self): pass

def main(nonce,carrier_deadline):
    # Hard/soft resource and absolute worker deadline precede managed imports.
    resource.setrlimit(resource.RLIMIT_AS,(256*1024**2,256*1024**2))
    resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024**2,16*1024**2))
    resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    started=time.time()
    deadline=min(started+300,carrier_deadline-180)
    def expired(*args): raise ValueError('time_limit')
    signal.signal(signal.SIGALRM,expired)
    signal.setitimer(signal.ITIMER_REAL,max(0.001,deadline-time.time()))
    try:
        require(started<=carrier_deadline-480 and deadline>time.time(), 'time_limit')
        # The process may not fork, start threads, or dispatch hidden sockets.
        def audit(event,args):
            if event.startswith(('socket.__new__','socket.connect','socket.getaddrinfo','socket.sendto','subprocess.','os.system','os.exec','os.fork','os.posix_spawn')):
                raise ValueError('network_forbidden')
        sys.addaudithook(audit)
        import _thread
        def no_thread(*args,**kwargs): raise ValueError('runtime_shape')
        _thread.start_new_thread=no_thread
        threading._start_new_thread=no_thread
        sys.dont_write_bytecode=True
        with network_guard(),contextlib.redirect_stdout(RejectOutput()),contextlib.redirect_stderr(RejectOutput()):
            metadata,archive=collect(ManagedRuntime(),{})
            lines=frame_output(metadata,archive,nonce)
    except BaseException as exc:
        reason=exc.args[0] if type(exc) is ValueError and len(exc.args)==1 and type(exc.args[0]) is str and exc.args[0] in REASONS else 'unexpected'
        h={'schema':1,'nonce':nonce,'status':'negative','reason':reason,'module_count':0,'frame_count':0,'archive_bytes':0}
        lines=['SDKI1 H '+canonical(h).decode(),'SDKI1 T '+canonical(h).decode()]
    # One publication only, built completely before the first byte.
    for line in lines:
        sys.stdout.write(line+'\n')
    sys.stdout.flush()
