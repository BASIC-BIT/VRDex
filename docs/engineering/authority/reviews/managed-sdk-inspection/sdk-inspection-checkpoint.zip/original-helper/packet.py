"""Deterministic offline request packet. Contains no provider client or dispatcher."""
import base64
import hashlib
import json
import re
import zlib
from inspect_sdk import canonical, require


def prepare_packet(owned,collector_bytes):
    keys={'account','region','project','role','group','prefix','nonce','carrier_deadline'}
    require(type(owned) is dict and set(owned)==keys,'owned_schema')
    require(re.fullmatch('[0-9]{12}',owned['account']) is not None and re.fullmatch('[a-z]{2}-[a-z]+-[0-9]',owned['region']) is not None,'owned_schema')
    require(re.fullmatch('[0-9a-z]{32}',owned['nonce']) is not None,'owned_schema')
    for key in ('project','role','group','prefix'):
        require(type(owned[key]) is str and re.fullmatch('[A-Za-z0-9/_-]{1,128}',owned[key]) is not None,'owned_schema')
    require(owned['nonce'] in owned['project'] and owned['nonce'] in owned['role'] and owned['nonce'] in owned['group'],'owned_schema')
    require(type(owned['carrier_deadline']) is int and owned['carrier_deadline']>0 and type(collector_bytes) is bytes and 0<len(collector_bytes)<=65536,'owned_schema')
    blob=base64.b64encode(zlib.compress(collector_bytes,9)).decode('ascii')
    # All imports are stdlib. A compressed payload keeps echoed/repeated control
    # originals small. Root retains the exact collector and buildspec originals.
    launcher="import base64,zlib;exec(compile(zlib.decompress(base64.b64decode('"+blob+"')),'<frozen-inspection>','exec'));main('"+owned['nonce']+"',"+str(owned['carrier_deadline'])+")"
    command='python -c '+"'"+launcher.replace("'","'\"'\"'")+"'"
    buildspec='version: 0.2\nphases:\n  install:\n    runtime-versions:\n      python: 3.12\n  build:\n    commands:\n      - '+json.dumps(command,separators=(',',':'))+'\n'
    require(len(buildspec.encode())<=65536,'buildspec_limit')
    region=owned['region']; account=owned['account']; project=owned['project']
    role_arn='arn:aws:iam::'+account+':role/'+owned['role']
    project_arn='arn:aws:codebuild:'+region+':'+account+':project/'+project
    group_arn='arn:aws:logs:'+region+':'+account+':log-group:'+owned['group']
    project_request={'name':project,'serviceRole':role_arn,'source':{'type':'NO_SOURCE','buildspec':buildspec},'artifacts':{'type':'NO_ARTIFACTS'},'cache':{'type':'NO_CACHE'},'environment':{'type':'LINUX_CONTAINER','image':'aws/codebuild/standard:7.0','computeType':'BUILD_GENERAL1_SMALL','privilegedMode':False,'imagePullCredentialsType':'CODEBUILD','environmentVariables':[]},'timeoutInMinutes':5,'queuedTimeoutInMinutes':5,'logsConfig':{'cloudWatchLogs':{'status':'ENABLED','groupName':owned['group'],'streamName':owned['prefix']},'s3Logs':{'status':'DISABLED'}}}
    trust={'Version':'2012-10-17','Statement':[{'Effect':'Allow','Principal':{'Service':'codebuild.amazonaws.com'},'Action':'sts:AssumeRole','Condition':{'StringEquals':{'aws:SourceAccount':account},'ArnEquals':{'aws:SourceArn':project_arn}}}]}
    policy={'Version':'2012-10-17','Statement':[{'Effect':'Allow','Action':['logs:CreateLogStream','logs:PutLogEvents'],'Resource':group_arn+':log-stream:'+owned['prefix']+'*'}]}
    # Complete response wrappers have a reserved 3KiB each. This is a prelaunch
    # envelope to be checked against actual originals, never a projected body.
    buildspec_bytes=len(buildspec.encode()); repeated_source_bytes=len(canonical(buildspec)); request_bytes=len(canonical(project_request))
    repetitions=14 # create response, readback, start response, ten polls, reconcile
    setup_other=24576; wrappers=repetitions*3072; closure=65536; control=int(0.3*1024**2)
    estimate=request_bytes+repetitions*repeated_source_bytes+wrappers+setup_other+closure
    require(estimate<=control,'control_capacity')
    refs={'schema':1,'collector_sha256':hashlib.sha256(collector_bytes).hexdigest(),'collector_bytes':len(collector_bytes),'buildspec_sha256':hashlib.sha256(buildspec.encode()).hexdigest(),'buildspec_bytes':buildspec_bytes,'buildspec_json_string_bytes':repeated_source_bytes,'project_request_bytes':request_bytes,'project_arn':project_arn,'role_arn':role_arn,'group_arn':group_arn,'trust_policy':trust,'inline_policy':policy,'create_role':{'RoleName':owned['role'],'AssumeRolePolicyDocument':canonical(trust).decode()},'create_log_group':{'logGroupName':owned['group']},'put_retention':{'logGroupName':owned['group'],'retentionInDays':1},'planned_polls':10,'poll_intervals_seconds':[15,15,30,30,30,30,30,45,45,30],'repeated_buildspec_copies':repetitions,'response_wrapper_bytes_each':3072,'setup_other_bytes':setup_other,'closure_reserve_bytes':closure,'control_original_limit_bytes':control,'estimated_control_bytes':estimate,'control_unallocated_bytes':control-estimate,'logical_bytes':128*1024**2,'disk_bytes':16*1024**2,'address_space_bytes':256*1024**2,'model_io_weighted_limit':64*1024**2,'fact_control_margin_bytes':8*1024**2,'cost_hold_usd':'0.10','carrier_seconds':600,'start_by_seconds':120,'worker_seconds':300,'closure_seconds':180,'first_mutation_clock':'immediately before CreateRole or any earlier owned mutation including logging','prelaunch_gates':['fresh Root-only cost hold and prices/billing rounding','actual remaining C/control/disk/logical headroom','Root binds actual account/role/project/group/nonce and carrier_deadline','complete provider response wrapper sizes <=3072 and ten polls fit remaining capacity','start only when worker300s plus closure180s remain','no retries/replacement; stop once on deadline/budget failure','retain full originals and reconcile/delete exact owned resources after durable custody']}
    return {'buildspec':buildspec,'project':project_request,'start':{'projectName':project},'refs':refs}
