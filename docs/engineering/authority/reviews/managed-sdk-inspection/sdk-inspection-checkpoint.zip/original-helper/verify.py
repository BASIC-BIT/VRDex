"""Offline verification of complete provider-capture originals, never HTTP wire proof."""
import base64
import binascii
import hashlib
import io
import json
import re
import stat
import struct
import zipfile
from inspect_sdk import MODULES, MAX, REASONS, canonical, digest, require


def json_object(body):
    def unique(pairs):
        obj={}
        for key,value in pairs:
            require(key not in obj,'duplicate_json_key'); obj[key]=value
        return obj
    try:
        return json.loads(body,object_pairs_hook=unique,parse_constant=lambda x: (_ for _ in ()).throw(ValueError('json_constant')))
    except (UnicodeError,json.JSONDecodeError):
        raise ValueError('json_shape') from None


def validate_archive(archive_bytes, metadata_sha256, build_arn=None):
    require(type(archive_bytes) is bytes and 0<len(archive_bytes)<=MAX['zip_bytes'],'archive_limit')
    expected=['sources/'+n.replace('.','/')+'.py' for n in MODULES]+['metadata.json']
    try:
        with zipfile.ZipFile(io.BytesIO(archive_bytes)) as archive:
            infos=archive.infolist()
            require(len(infos)==38 and [x.filename for x in infos]==expected,'archive_inventory')
            require(sum(i.file_size for i in infos)<=MAX['source_bytes']+MAX['metadata_bytes'],'source_limit')
            require(archive.comment==b'' and not any(i.extra or i.comment for i in infos),'archive_shape')
            for i in infos:
                require(i.compress_type==zipfile.ZIP_DEFLATED and i.create_system==3 and stat.S_ISREG(i.external_attr>>16) and not i.flag_bits & 1 and not i.is_dir(),'archive_type')
                require(i.date_time==(1980,1,1,0,0,0),'archive_shape')
            mi=infos[-1]
            require(mi.file_size<=MAX['metadata_bytes'],'metadata_limit')
            body=archive.read(mi)
            require(digest(body)==metadata_sha256,'metadata_hash')
            metadata=json_object(body)
            require(canonical(metadata)==body and metadata['schema']==1 and metadata['status']=='complete-selected-sources','metadata_shape')
            if build_arn is not None:
                require(metadata['facts']['runtime']['build_arn']==build_arn,'runtime_build_join')
            inventory=metadata['modules']
            require(len(inventory)==37 and [m['module'] for m in inventory]==MODULES,'inventory')
            total=sum(m['bytes'] for m in inventory)
            require(total==metadata['raw_source_bytes'] and total<=MAX['source_bytes'] and 5*total+16*MAX['zip_bytes']+72*1024**2<=MAX['logical_bytes'],'admission')
            require(len(canonical(metadata['facts'].get('models',{})))<=16384,'model_limit')
            for info,item in zip(infos,inventory):
                require(set(item)=={'module','archive','path','bytes','sha256'} and item['archive']==info.filename and type(item['bytes']) is int and item['bytes']==info.file_size,'inventory')
                require(type(item['path']) is str and item['path'].startswith('/') and item['path'].endswith('.py'),'inventory')
                require(re.fullmatch('[0-9a-f]{64}',item['sha256']) is not None,'inventory')
                h=hashlib.sha256(); count=0
                with archive.open(info) as source:
                    while True:
                        chunk=source.read(65536)
                        if not chunk: break
                        count+=len(chunk); require(count<=item['bytes'],'source_limit'); h.update(chunk)
                require(count==item['bytes'] and h.hexdigest()==item['sha256'],'source_hash')
            # Account for every local-header byte, compressed member and EOCD.
            cursor=0
            for info in infos:
                require(info.header_offset==cursor,'archive_shape')
                header=struct.unpack_from('<4s5H3I2H',archive_bytes,cursor)
                sig,version,flags,method,mtime,mdate,crc,csize,usize,nlen,xlen=header
                require(sig==b'PK\x03\x04' and flags==info.flag_bits==0 and method==info.compress_type and crc==info.CRC and csize==info.compress_size and usize==info.file_size and xlen==0,'archive_shape')
                require(archive_bytes[cursor+30:cursor+30+nlen]==info.filename.encode('ascii'),'archive_shape')
                cursor+=30+nlen+csize
            require(cursor==archive.start_dir,'archive_shape')
            require(archive_bytes[-22:-18]==b'PK\x05\x06' and archive_bytes[-2:]==b'\0\0','archive_shape')
            eocd=struct.unpack_from('<4s4H2IH',archive_bytes,len(archive_bytes)-22)
            require(eocd[1:5]==(0,0,38,38) and eocd[6]==cursor and eocd[5]+cursor==len(archive_bytes)-22,'archive_shape')
            return inventory,metadata['facts'].get('gaps',[])
    except (zipfile.BadZipFile,KeyError,TypeError,OverflowError,struct.error,UnicodeError):
        raise ValueError('archive_shape') from None


def decode_frames(events, nonce):
    frames=[]
    for event in events:
        require(type(event) is dict and type(event.get('message')) is str and type(event.get('timestamp')) is int and type(event.get('ingestionTime')) is int,'log_event')
        message=event['message']
        require(len(message.encode('utf-8'))<65536,'log_event_limit')
        if 'SDKI1 ' not in message: continue
        require(message.startswith('SDKI1 ') and len(message)>8,'frame_shape')
        kind=message[6]; require(message[7]==' ' and kind in 'HDT','frame_shape')
        data=json_object(message[8:])
        require(type(data) is dict and data.get('nonce')==nonce,'frame_nonce')
        frames.append((kind,data))
    require(2<=len(frames)<=26 and frames[0][0]=='H' and frames[-1][0]=='T','frame_inventory')
    header=frames[0][1]; trailer=frames[-1][1]
    require(type(header.get('schema')) is int and header['schema']==1,'frame_schema')
    if header.get('status')=='negative':
        require(len(frames)==2 and header==trailer and header.get('frame_count')==0 and header.get('archive_bytes')==0,'negative_shape')
        require(set(header)=={'schema','nonce','status','reason','module_count','frame_count','archive_bytes'} and header.get('reason') in REASONS,'negative_shape')
        raise ValueError('worker_negative:'+header['reason'])
    require(header.get('status')=='complete-selected-sources','frame_status')
    keys={'schema','nonce','archive_bytes','archive_sha256','frame_count','module_count','metadata_sha256'}
    require(set(trailer)==keys and set(header)==keys|{'status'} and trailer=={k:header[k] for k in keys},'frame_binding')
    require(type(header['archive_bytes']) is int and 0<header['archive_bytes']<=MAX['zip_bytes'] and type(header['module_count']) is int and header['module_count']==37,'frame_limit')
    count=header['frame_count']
    require(type(count) is int and 1<=count<=24 and len(frames)==count+2,'frame_count')
    require(all(re.fullmatch('[0-9a-f]{64}',header[k]) for k in ('archive_sha256','metadata_sha256')),'frame_hash')
    out=io.BytesIO(); h=hashlib.sha256()
    for seq,(kind,data) in enumerate(frames[1:-1]):
        require(kind=='D' and set(data)=={'nonce','seq','data'} and type(data['seq']) is int and data['seq']==seq and type(data['data']) is str and len(data['data'])<=60000,'frame_order')
        try: chunk=base64.b64decode(data['data'],validate=True)
        except (ValueError,binascii.Error): raise ValueError('frame_base64') from None
        encoded=data['data']; alphabet='ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
        require(len(encoded)==4*((len(chunk)+2)//3),'frame_base64')
        require(not encoded.endswith('==') or alphabet.index(encoded[-3])&15==0,'frame_base64')
        require(not (encoded.endswith('=') and not encoded.endswith('==')) or alphabet.index(encoded[-2])&3==0,'frame_base64')
        require(0<len(chunk)<=45000 and (seq==count-1 or len(chunk)==45000),'frame_size')
        require(out.tell()+len(chunk)<=header['archive_bytes'],'frame_limit')
        out.write(chunk); h.update(chunk)
    require(out.tell()==header['archive_bytes'] and h.hexdigest()==header['archive_sha256'],'archive_hash')
    return out.getvalue(),header


def traversal(read,expected):
    require(type(read) is dict and read.get('after_terminal') is True,'terminal_order')
    pages=read['pages']; require(type(pages) is list and 1<=len(pages)<=6,'page_limit')
    require(set(read)=={'after_terminal','pages'},'capture_schema')
    original_bytes=0
    events=[]; token=None; eof=False
    for index,page in enumerate(pages):
        require(not eof and set(page)=={'request','response_original'},'page_shape')
        req=page['request']; raw=page['response_original']
        require(type(raw) is str,'page_shape')
        original_bytes+=len(raw.encode('utf-8'))+len(canonical(req))+64
        require(original_bytes<=int(1.6*1024**2),'log_original_limit')
        response=json_object(raw)
        required={'logGroupName':expected['group'],'logStreamName':expected['stream'],'startFromHead':True,'limit':64}
        if token is not None: required['nextToken']=token
        require(req==required,'page_request')
        batch=response['events']; nxt=response['nextForwardToken']
        require(type(batch) is list and len(batch)<=64 and type(nxt) is str and 0<len(nxt)<=4096,'page_shape')
        require(not any(k in response for k in ('nextToken','nextPageToken')),'page_shape')
        events.extend(batch); require(len(events)<=256,'event_limit')
        eof=token is not None and nxt==token
        if eof: require(index==len(pages)-1 and not batch,'eof_shape')
        token=nxt
    require(eof,'missing_eof')
    return events


def verify_capture(provider_originals,expected):
    """Input is retained full parsed provider responses, not projected summaries.

    Caller supplies complete independent JSON originals per the README. Their
    provenance is provider-capture class, not authenticated HTTP-wire evidence.
    """
    try:
        require(set(expected)=={'nonce','build_id','build_arn','group','stream','stream_arn','terminal'},'expected_schema')
        require(re.fullmatch('[0-9a-z]{32}',expected['nonce']) is not None and expected['terminal'] in ('SUCCEEDED','FAILED','FAULT','STOPPED','TIMED_OUT'),'expected_schema')
        require(set(provider_originals)=={'capture_class','build_original','describes','reads'},'capture_schema')
        require(provider_originals['capture_class']=='complete-semantic-response-json','capture_class')
        require(type(provider_originals['build_original']) is str and len(provider_originals['build_original'].encode('utf-8'))<=int(0.3*1024**2),'control_original_limit')
        full_build=json_object(provider_originals['build_original'])
        require(len(full_build['builds'])==1 and not full_build.get('buildsNotFound',[]),'build_identity')
        build=full_build['builds'][0]
        require(build['id']==expected['build_id'] and build['arn']==expected['build_arn'] and build['buildStatus']==expected['terminal'],'build_identity')
        require(build['logs']['groupName']==expected['group'] and build['logs']['streamName']==expected['stream'],'build_stream_join')
        match=re.fullmatch(r'arn:aws:codebuild:([a-z0-9-]+):([0-9]{12}):build/(.+)',expected['build_arn'])
        require(match is not None and match[3]==expected['build_id'],'build_identity')
        require(expected['stream_arn']=='arn:aws:logs:'+match[1]+':'+match[2]+':log-group:'+expected['group']+':log-stream:'+expected['stream'],'stream_identity')
        describes=provider_originals['describes']; reads=provider_originals['reads']
        require(len(describes)==2 and len(reads)==2,'capture_count')
        observed=[]
        for raw in describes:
            require(type(raw) is str and len(raw.encode('utf-8'))<=65536,'control_original_limit')
            desc=json_object(raw)
            require('nextToken' not in desc and len(desc['logStreams'])==1,'stream_inventory')
            stream=desc['logStreams'][0]
            require(stream['logStreamName']==expected['stream'] and stream['arn']==expected['stream_arn'],'stream_identity')
            require(type(stream['lastEventTimestamp']) is int and type(stream['lastIngestionTime']) is int,'stream_observation')
            observed.append((stream['lastEventTimestamp'],stream['lastIngestionTime']))
        require(observed[0]==observed[1],'unstable_stream')
        first_events=traversal(reads[0],expected)
        second_events=traversal(reads[1],expected)
        require(first_events==second_events,'changing_logs')
        for event in first_events:
            require(event['timestamp']<=observed[0][0] and event['ingestionTime']<=observed[0][1],'stream_observation')
        archive,header=decode_frames(first_events,expected['nonce'])
        other,second_header=decode_frames(second_events,expected['nonce'])
        require(archive==other and header==second_header,'changing_archive')
        del other
        inventory,gaps=validate_archive(archive,header['metadata_sha256'],expected['build_arn'])
        return {'status':'complete-selected-sources','archive_bytes':archive,'inventory':inventory,'gaps':gaps+['provider-capture originals; no HTTP-wire authentication or finality beyond terminal/two EOF/stable stream observations','diagnostic possession grants no SDK support or transport/native approval']}
    except (KeyError,TypeError,IndexError):
        raise ValueError('capture_schema') from None
