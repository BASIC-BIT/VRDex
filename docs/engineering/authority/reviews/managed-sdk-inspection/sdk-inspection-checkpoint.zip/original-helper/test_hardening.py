"""Generated adversarial cases added during self-review, before their fixes."""
import copy
import io
import json
from pathlib import Path
import stat
import tempfile
import unittest
import zipfile
from unittest.mock import patch
from test_inspection import module, Runtime, NAMES
import test_inspection

class HardeningTests(unittest.TestCase):
    def test_guard_blocks_socket_construction(self):
        import socket
        with module('inspect_sdk').network_guard():
            self.assertRaisesRegex(ValueError,'network_forbidden',socket.socket)
    def test_sibling_source_symlink_parent(self):
        with tempfile.TemporaryDirectory() as t:
            root=Path(t); runtime=Runtime(root/'trusted')
            alias=root/'alias'; alias.symlink_to(runtime.root,target_is_directory=True)
            runtime.paths[NAMES[0]]=str(alias/(NAMES[0].replace('.','/')+'.py'))
            self.assertRaisesRegex(ValueError,'source_path',module('inspect_sdk').collect,runtime,{})
    def test_source_change_during_read(self):
        with tempfile.TemporaryDirectory() as t:
            runtime=Runtime(Path(t)); api=module('inspect_sdk'); original=api.os.read; changed=False
            def read(fd,n):
                nonlocal changed
                result=original(fd,n)
                if not changed:
                    changed=True; Path(runtime.paths[NAMES[0]]).write_text('mutated during read')
                return result
            with patch.object(api.os,'read',read):
                self.assertRaisesRegex(ValueError,'source_changed',api.collect,runtime,{})
    def test_simple_caps_nested_total_before_allocation(self):
        api=module('inspect_sdk')
        self.assertRaisesRegex(ValueError,'runtime_shape',api.simple, ['x'*4096]*256)
    def test_negative_frame_is_bounded_known_reason(self):
        api=module('verify')
        header={'schema':1,'nonce':'n'*32,'status':'negative','reason':'SECRET','module_count':0,'frame_count':0,'archive_bytes':0}
        events=[{'timestamp':1,'ingestionTime':1,'message':'SDKI1 '+kind+' '+json.dumps(header)} for kind in ('H','T')]
        try: api.decode_frames(events,'n'*32)
        except ValueError as exc: self.assertNotIn('SECRET',str(exc))
        else: self.fail('negative accepted')
    def test_exact_original_raw_bytes_cap(self):
        case=test_inspection.ProtocolTests(); case.setUp()
        try:
            facts,expected,_=case.capture()
            facts['reads'][0]['raw_pages']=[' '*(1700000)]
            self.assertRaises(ValueError,module('verify').verify_capture,facts,expected)
        finally: case.doCleanups()
    def test_frame_schema_bool_not_int(self):
        api=module('inspect_sdk')
        metadata={}; archive=b'x'; lines=api.frame_output(metadata,archive,'n'*32)
        events=[]
        for line in lines:
            kind=line[6]; obj=json.loads(line[8:])
            if kind in ('H','T'): obj['schema']=True
            events.append({'timestamp':1,'ingestionTime':1,'message':'SDKI1 '+kind+' '+json.dumps(obj)})
        self.assertRaises(ValueError,module('verify').decode_frames,events,'n'*32)
    def test_append_zip_local_member_rejected(self):
        # A valid canonical archive whose ZIP local region is adulterated must fail.
        with tempfile.TemporaryDirectory() as t:
            api=module('inspect_sdk'); metadata,archive=api.collect(Runtime(Path(t)),{})
            idx=archive.find(b'PK\x01\x02')
            bad=archive[:idx]+b'UNREFERENCED'+archive[idx:]
            self.assertRaises(ValueError,module('verify').validate_archive,bad,api.digest(api.canonical(metadata)))

if __name__=='__main__': unittest.main()

class ModelReadBudgetTests(unittest.TestCase):
    def test_plain_json_actual_read_is_charged_and_bounded(self):
        api=module('inspect_sdk')
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'generated.json'; path.write_bytes(b'{}')
            with api.model_read_guard(64) as counters:
                with open(path,'rb') as f: self.assertEqual(f.read(),b'{}')
            self.assertEqual(counters['weighted_bytes'],6)
            path.write_bytes(b'x'*100)
            with api.model_read_guard(64):
                with open(path,'rb') as f: self.assertRaisesRegex(ValueError,'model_io_limit',f.read)
    def test_gzip_expansion_is_bounded(self):
        import gzip
        api=module('inspect_sdk')
        with tempfile.TemporaryDirectory() as t:
            path=Path(t)/'generated.json.gz'; path.write_bytes(gzip.compress(b'x'*10000))
            with api.model_read_guard(512):
                self.assertRaisesRegex(ValueError,'model_io_limit',lambda:gzip.open(path,'rb').read())
