# generated source only
VALUE = 'json.encoder'
