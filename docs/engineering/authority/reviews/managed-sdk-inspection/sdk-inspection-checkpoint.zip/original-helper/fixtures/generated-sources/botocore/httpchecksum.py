# generated source only
VALUE = 'botocore.httpchecksum'
