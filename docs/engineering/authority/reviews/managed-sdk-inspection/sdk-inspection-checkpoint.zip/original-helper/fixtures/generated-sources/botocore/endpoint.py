# generated source only
VALUE = 'botocore.endpoint'
