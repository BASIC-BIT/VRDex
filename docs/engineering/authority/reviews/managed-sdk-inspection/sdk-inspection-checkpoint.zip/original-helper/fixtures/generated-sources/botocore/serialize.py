# generated source only
VALUE = 'botocore.serialize'
