# generated source only
VALUE = 'botocore.hooks'
