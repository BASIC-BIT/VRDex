# generated source only
VALUE = 'botocore.model'
