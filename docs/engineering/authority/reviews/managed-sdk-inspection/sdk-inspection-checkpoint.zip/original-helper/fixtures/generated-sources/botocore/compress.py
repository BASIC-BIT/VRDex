# generated source only
VALUE = 'botocore.compress'
