# generated source only
VALUE = 'botocore.signers'
