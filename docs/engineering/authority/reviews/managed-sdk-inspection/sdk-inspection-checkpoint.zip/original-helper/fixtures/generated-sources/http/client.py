# generated source only
VALUE = 'http.client'
