# generated source only
VALUE = 'urllib3.util.ssl_'
