# generated source only
VALUE = 'boto3.session'
