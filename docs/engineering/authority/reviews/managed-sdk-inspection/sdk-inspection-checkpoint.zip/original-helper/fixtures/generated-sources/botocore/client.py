# generated source only
VALUE = 'botocore.client'
