# generated source only
VALUE = 'base64'
