# generated source only
VALUE = 'urllib3.connectionpool'
