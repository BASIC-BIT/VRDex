# generated source only
VALUE = 'urllib3.response'
