# generated source only
VALUE = 'botocore.httpsession'
