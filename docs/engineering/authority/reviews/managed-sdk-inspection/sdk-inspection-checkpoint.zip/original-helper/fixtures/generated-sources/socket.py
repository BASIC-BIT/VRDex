# generated source only
VALUE = 'socket'
