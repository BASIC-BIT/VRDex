# generated source only
VALUE = 'botocore.utils'
