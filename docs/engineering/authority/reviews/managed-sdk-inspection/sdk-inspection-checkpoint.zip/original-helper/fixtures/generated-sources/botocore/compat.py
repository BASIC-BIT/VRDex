# generated source only
VALUE = 'botocore.compat'
