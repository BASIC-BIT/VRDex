# generated source only
VALUE = 'urllib3._request_methods'
