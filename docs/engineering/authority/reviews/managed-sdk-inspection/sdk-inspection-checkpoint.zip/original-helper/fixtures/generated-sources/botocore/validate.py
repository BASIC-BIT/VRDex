# generated source only
VALUE = 'botocore.validate'
