# generated source only
VALUE = 'botocore.args'
