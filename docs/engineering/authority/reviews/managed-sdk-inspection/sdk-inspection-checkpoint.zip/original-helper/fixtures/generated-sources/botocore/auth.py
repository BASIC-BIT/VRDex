# generated source only
VALUE = 'botocore.auth'
