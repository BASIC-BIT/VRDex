# generated source only
VALUE = 'botocore.response'
