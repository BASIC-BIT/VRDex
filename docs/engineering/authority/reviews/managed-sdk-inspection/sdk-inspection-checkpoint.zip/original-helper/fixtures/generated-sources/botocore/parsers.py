# generated source only
VALUE = 'botocore.parsers'
