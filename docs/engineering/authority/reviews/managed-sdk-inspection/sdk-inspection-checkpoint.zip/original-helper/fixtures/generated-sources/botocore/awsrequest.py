# generated source only
VALUE = 'botocore.awsrequest'
