# generated source only
VALUE = 'botocore.handlers'
