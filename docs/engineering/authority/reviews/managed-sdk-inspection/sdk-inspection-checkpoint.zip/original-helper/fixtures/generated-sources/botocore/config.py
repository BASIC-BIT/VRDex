# generated source only
VALUE = 'botocore.config'
