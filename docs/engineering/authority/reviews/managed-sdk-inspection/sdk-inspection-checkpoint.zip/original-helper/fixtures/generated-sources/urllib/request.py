# generated source only
VALUE = 'urllib.request'
