# generated source only
VALUE = 'botocore.session'
