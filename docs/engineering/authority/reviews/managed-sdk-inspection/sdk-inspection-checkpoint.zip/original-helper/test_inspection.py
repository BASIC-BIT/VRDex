import base64
import copy
import hashlib
import importlib
import io
import json
from pathlib import Path
import tempfile
import unittest
import zipfile

ROOT = Path(__file__).parent
NAMES = '''boto3.session botocore.session botocore.client botocore.config botocore.args botocore.model botocore.hooks botocore.handlers botocore.utils botocore.endpoint botocore.signers botocore.auth botocore.awsrequest botocore.serialize botocore.validate botocore.httpchecksum botocore.compress botocore.httpsession botocore.response botocore.parsers botocore.compat urllib3._request_methods urllib3.connection urllib3.connectionpool urllib3.poolmanager urllib3.response urllib3.util.request urllib3.util.retry urllib3.util.timeout urllib3.util.ssl_ urllib3.util.url urllib.request http.client json.encoder base64 ssl socket'''.split()

def module(name):
    if not (ROOT / (name + '.py')).is_file():
        raise AssertionError('Missing implementation: ' + name)
    return importlib.import_module(name)

class Runtime:
    def __init__(self, root):
        self.root = root
        self.paths = {}
        self.reads = 0
        for name in NAMES:
            path = root / (name.replace('.', '/') + '.py')
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text('# generated source only\nVALUE = ' + repr(name) + '\n')
            self.paths[name] = str(path)
    def sources(self):
        return self.paths, [{'path': str(self.root), 'kind': 'generated-test'}]
    def facts(self):
        return {'trust': 'generated-test-only', 'gaps': ['native closure unproved'], 'models': {}, 'events': {}, 'runtime': {'build_arn':'arn:aws:codebuild:us-east-1:123456789012:build/p:id','image':'generated-test-only'}}
    def before_open(self, name):
        pass

class CollectorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.runtime = Runtime(Path(self.tmp.name))
    def collect(self, **limits):
        return module('inspect_sdk').collect(self.runtime, limits)
    def test_exact_complete_inventory_and_determinism(self):
        m, z = self.collect()
        m2, z2 = self.collect()
        self.assertEqual(NAMES, module('inspect_sdk').MODULES)
        self.assertEqual(z, z2)
        self.assertEqual(len(m['modules']), 37)
        with zipfile.ZipFile(io.BytesIO(z)) as a:
            self.assertEqual(len(a.infolist()), 38)
            for name, path in self.runtime.paths.items():
                self.assertEqual(a.read('sources/' + name.replace('.', '/') + '.py'), Path(path).read_bytes())
    def test_missing_source(self):
        del self.runtime.paths[NAMES[0]]
        self.assertRaisesRegex(ValueError, 'inventory', self.collect)
    def test_symlink_source(self):
        p = Path(self.runtime.paths[NAMES[0]])
        p.unlink(); p.symlink_to(self.runtime.paths[NAMES[1]])
        self.assertRaisesRegex(ValueError, 'source_path', self.collect)
    def test_source_less(self):
        self.runtime.paths[NAMES[0]] = str(self.runtime.root / 'missing.pyc')
        self.assertRaisesRegex(ValueError, 'source_path', self.collect)
    def test_untrusted_origin(self):
        self.runtime.sources = lambda: (self.runtime.paths, [{'path':'/not-trusted', 'kind':'generated-test'}])
        self.assertRaisesRegex(ValueError, 'source_origin', self.collect)
    def test_changed_before_open(self):
        self.runtime.before_open = lambda name: Path(self.runtime.paths[name]).write_text('changed')
        self.assertRaisesRegex(ValueError, 'source_changed', self.collect)
    def test_admission_before_body_reads(self):
        Path(self.runtime.paths[NAMES[0]]).write_bytes(b'x' * 2600000)
        self.runtime.before_open = lambda name: self.fail('source read before admission')
        self.assertRaisesRegex(ValueError, 'admission', self.collect, logical_bytes=88*1024**2)
    def test_archive_and_metadata_caps(self):
        self.assertRaisesRegex(ValueError, 'archive_limit', self.collect, zip_bytes=10)
        self.assertRaisesRegex(ValueError, 'metadata_limit', self.collect, metadata_bytes=10)
    def test_source_and_fact_caps(self):
        self.assertRaisesRegex(ValueError, 'source_limit', self.collect, source_bytes=10)
        self.runtime.facts = lambda: {'models': {'large': 'x'*16385}, 'events': {}}
        self.assertRaisesRegex(ValueError, 'model_limit', self.collect)
    def test_socket_rejection_before_dispatch(self):
        api = module('inspect_sdk')
        import socket
        original = socket.socket.connect
        with api.network_guard():
            self.assertRaisesRegex(ValueError, 'network_forbidden', socket.socket.connect, None, ('127.0.0.1', 9))
            self.assertRaisesRegex(ValueError, 'network_forbidden', socket.getaddrinfo, 'example.invalid', 443)
        self.assertIs(socket.socket.connect, original)
    def test_unknown_event_registry_is_negative(self):
        self.assertRaisesRegex(ValueError, 'event_registry', module('inspect_sdk').event_facts, object(), 's3', ['PutObject'])
    def test_alias_wildcard_callback_order(self):
        api = module('inspect_sdk')
        def first(): self.fail('handler executed')
        def last(): self.fail('handler executed')
        from collections import namedtuple
        NodeList = namedtuple('NodeList', 'first middle last')
        leaf = lambda vals, children=None: {'chunk':None, 'values':NodeList([], vals, []), 'children':children or {}}
        class Trie:
            _root = leaf([], {'before-call':leaf([], {'s3':leaf([], {'*':leaf([first]), 'PutObject':leaf([last])})})})
            def prefix_search(self, event): return [last, first] if event == 'before-call.s3.PutObject' else []
        class Emitter: _handlers = Trie()
        class Alias:
            _emitter = Emitter()
            _event_aliases = {'old-s3':'s3'}
            def _alias_event_name(self, name): return name.replace('old-s3','s3')
        facts = api.event_facts(Alias(), 'old-s3', ['PutObject'])
        observed = next(x for x in facts['matches'] if x['event']=='before-call.old-s3.PutObject')
        self.assertEqual([last.__qualname__, first.__qualname__], [x['qualname'] for x in observed['callbacks']])
        self.assertEqual(len(facts['registrations']), 2)
    def test_callback_cap(self):
        api = module('inspect_sdk')
        self.assertRaisesRegex(ValueError, 'event_registry', api.event_facts, object(), 's3', ['PutObject'])

class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(); self.addCleanup(self.tmp.cleanup)
    def capture(self):
        api = module('inspect_sdk')
        metadata, archive = api.collect(Runtime(Path(self.tmp.name)), {})
        lines = api.frame_output(metadata, archive, 'n'*32)
        expected = {'nonce':'n'*32, 'build_id':'p:id', 'build_arn':'arn:aws:codebuild:us-east-1:123456789012:build/p:id', 'group':'g', 'stream':'prefix/id', 'stream_arn':'arn:aws:logs:us-east-1:123456789012:log-group:g:log-stream:prefix/id', 'terminal':'SUCCEEDED'}
        desc = {'logStreams':[{'logStreamName':expected['stream'], 'arn':expected['stream_arn'], 'lastEventTimestamp':20, 'lastIngestionTime':30}]}
        pages = [{'request':{'logGroupName':'g','logStreamName':'prefix/id','startFromHead':True,'limit':64},'response':{'events':[{'timestamp':20,'ingestionTime':30,'message':s} for s in lines], 'nextForwardToken':'end'}}, {'request':{'logGroupName':'g','logStreamName':'prefix/id','startFromHead':True,'limit':64,'nextToken':'end'},'response':{'events':[],'nextForwardToken':'end'}}]
        for page in pages: page['response_original']=json.dumps(page.pop('response'))
        build={'id':expected['build_id'],'arn':expected['build_arn'],'buildStatus':'SUCCEEDED','logs':{'groupName':'g','streamName':'prefix/id'}}
        facts = {'capture_class':'complete-semantic-response-json','build_original':json.dumps({'builds':[build],'buildsNotFound':[]}),'describes':[json.dumps(desc),json.dumps(desc)],'reads':[{'after_terminal':True,'pages':pages},{'after_terminal':True,'pages':copy.deepcopy(pages)}]}
        return facts, expected, archive
    def test_two_complete_traversals(self):
        facts, expected, archive = self.capture()
        result = module('verify').verify_capture(facts, expected)
        self.assertEqual(result['status'], 'complete-selected-sources')
        self.assertEqual(result['archive_bytes'], archive)
        self.assertEqual(len(result['inventory']), 37)
    def reject(self, change):
        facts, expected, archive = self.capture()
        facts['build']=json.loads(facts['build_original'])['builds'][0]
        facts['describes']=[json.loads(x) for x in facts['describes']]
        for read in facts['reads']:
            for page in read['pages']: page['response']=json.loads(page.pop('response_original'))
        change(facts, expected)
        facts['build_original']=json.dumps({'builds':[facts.pop('build')],'buildsNotFound':[]})
        facts['describes']=[json.dumps(x) for x in facts['describes']]
        for read in facts['reads']:
            for page in read['pages']: page['response_original']=json.dumps(page.pop('response'))
        self.assertRaises(ValueError, module('verify').verify_capture, facts, expected)
    def test_missing_frame(self): self.reject(lambda f,e: f['reads'][0]['pages'][0]['response']['events'].pop(1))
    def test_duplicate_frame(self): self.reject(lambda f,e: f['reads'][0]['pages'][0]['response']['events'].insert(1, f['reads'][0]['pages'][0]['response']['events'][1]))
    def test_foreign_nonce(self): self.reject(lambda f,e: e.update(nonce='z'*32))
    def test_altered_frame(self): self.reject(lambda f,e: f['reads'][0]['pages'][0]['response']['events'][1].update(message='SDKI1 D '+json.dumps({'nonce':'n'*32,'seq':0,'data':'YWJj'})))
    def test_reordered_frames(self): self.reject(lambda f,e: f['reads'][0]['pages'][0]['response']['events'].reverse())
    def test_missing_eof(self): self.reject(lambda f,e: f['reads'][0]['pages'].pop())
    def test_changing_logs(self): self.reject(lambda f,e: f['reads'][1]['pages'][0]['response']['events'].append({'timestamp':21,'ingestionTime':31,'message':'late'}))
    def test_identity_join(self): self.reject(lambda f,e: f['build']['logs'].update(streamName='foreign'))
    def test_second_stream(self): self.reject(lambda f,e: f['describes'][0]['logStreams'].append(copy.deepcopy(f['describes'][0]['logStreams'][0])))
    def test_before_terminal(self): self.reject(lambda f,e: f['reads'][0].update(after_terminal=False))
    def test_unstable_stream(self): self.reject(lambda f,e: f['describes'][1]['logStreams'][0].update(lastIngestionTime=31))
    def test_archive_traversal(self):
        api = module('verify')
        out = io.BytesIO()
        with zipfile.ZipFile(out,'w') as z: z.writestr('../evil.py',b'x')
        self.assertRaises(ValueError, api.validate_archive, out.getvalue(), '0'*64)
    def test_frame_ceiling(self):
        api = module('inspect_sdk')
        self.assertRaises(ValueError, api.frame_output, {}, b'x'*1048577, 'n'*32)

class PacketTests(unittest.TestCase):
    def test_deterministic_frozen_source_and_no_image_inputs(self):
        api = module('packet')
        owned = json.loads((ROOT/'fixtures/owned.json').read_text())
        source = (ROOT/'inspect_sdk.py').read_bytes()
        a = api.prepare_packet(owned, source); b = api.prepare_packet(owned, source)
        self.assertEqual(a,b)
        p = a['project']
        self.assertEqual(p['source']['type'],'NO_SOURCE')
        self.assertEqual(p['source']['buildspec'],a['buildspec'])
        self.assertLessEqual(len(a['buildspec'].encode()),65536)
        self.assertEqual(p['environment']['computeType'],'BUILD_GENERAL1_SMALL')
        self.assertEqual(a['start'],{'projectName':owned['project']})
        self.assertNotIn('secondarySources',p)
        self.assertLessEqual(a['refs']['planned_polls'],12)
        self.assertGreaterEqual(a['refs']['closure_reserve_bytes'],65536)
    def test_owner_schema(self):
        self.assertRaises(ValueError, module('packet').prepare_packet, {}, b'x')

if __name__ == '__main__': unittest.main()
