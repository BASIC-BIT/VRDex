# Managed SDK inspection task1 implementation report

2026-10-27. Implementation is frozen for independent SPEC/QUALITY review. The covering generated-only suite passes 43 tests. No provider call, actual SDK import/source acquisition, network attempt, image/corpus read, Git edit or commit occurred. No actual managed-runtime compatibility, source possession, resource closure or SDK support is claimed.

## Deliverables

Private root `/workspace/scratch/managed-sdk-inspection/` contains `inspect_sdk.py`, `packet.py`, `verify.py`, three `test_*.py` files, `README.md`, finite `freeze.py`, generated source/model/provider examples, exact generated packet/buildspec, complete test logs, content hash inventory and a full new-file diff. Only this explicitly requested SDD report is outside that private root.

- Collector resolves exactly 37 selected module files before source-body reads, admits sizes, uses no-follow directory and final-file descriptors, checks regular/non-symlink/trusted origin/stable identity, hashes and archives complete sources. No partial success archive is published.
- Managed adapter has actual bounded model/config/method/auth/event paths rather than a fake supported profile. Generated tests exercise these paths through generated modules only. Unknown internals/caps become fixed negative reasons. Registry aliases and wildcard matches use observed local prefix_search ordering with registration-multiset checks; no handler executes.
- Worker entrypoint sets hard/soft 256 MiB address space, 16 MiB file limit, no core dumps and the absolute deadline before SDK import. It rejects socket construction/connect/DNS/send, SDK send, subprocess/fork and thread creation. Separate sessions receive fixed dummy credentials. There is no service operation, serializer payload trial, credential chain, signer implementation, upload or secondary output channel.
- Packet deterministically fixes standard7.0/Python3.12 SMALL, nonprivileged NO_SOURCE/NO_ARTIFACTS/NO_CACHE, pinned inline source, CloudWatch-only logs, one-day group retention requests, exact role trust/log-only policy, one StartBuild request and Root gates. It dispatches nothing.
- Verifier retains complete serialized semantic provider responses, requires two independent complete traversals with stable-token EOF, terminal/identity joins and one stable owned stream, compares exact event sets and both whole ZIP reconstructions, validates canonical names/types/counts/ZIP layout and each full source size/hash, and returns one archive. It rejects malformed/foreign/duplicate/reordered/altered frames, incomplete EOF and changing observations. It makes no HTTP-wire or absolute finality claim.

The exact schemas and concrete generated examples are frozen in `README.md`, `fixtures/owned.json`, `fixtures/packet.json`, `fixtures/capture.json` and `fixtures/expected.json`. Provider strings are complete returned SDK/tool semantic mappings serialized as JSON, not original wire JSON. Real Root capture must retain all returned fields and explicit date/time serialization conventions. `after_terminal` is Root's chronological receipt assertion, not independent clock authentication.

## Actual tests

Command:

```sh
PYTHONDONTWRITEBYTECODE=1 python -m unittest discover -s /workspace/scratch/managed-sdk-inspection -p 'test_*.py' -v
```

Initial actual RED was exit 1, 29 failures for missing implementation, retained in `red.log`/`red.exit`. It was run before implementation. Later self-review RED runs are also retained. `red-hardening.log` includes three genuine failures and one sandbox socket error; imported TestCase duplication made that intermediate run report 51 tests and was removed. `red-model-budget.log` records two missing-guard AttributeErrors. These are actual outputs, not manufactured earlier failures. Some later review tests passed when first added; no prior RED is claimed for them.

Intermediate implementation attempts are preserved in `green-attempt-1` through `green-attempt-6` logs/exits. Attempt1 exposed forbidden socket creation in this sandbox and the initial packet exceeding control capacity. Attempt4 exposed growth exceeding the then-current control estimate. These led to a test that directly calls the blocked dispatch entry and a ten-poll packet. Other intermediate green runs remain honest observations at those revisions.

Final `green.log`/`green.exit`: exit 0, 43 tests, 0 failures/errors, `Ran 43 tests in 0.087s`, `OK`. Coverage includes complete/deterministic inventory, missing/source-less/symlinked/untrusted/changed/oversize source, before-read admission, archive/metadata/model/event limits, alias/wildcard order without handler execution, network/socket rejection, unknown event/model shapes, generated managed-adapter configuration/models/auth, raw-response limits, ZIP traversal/unreferenced data, frame alteration/order/count/nonce, two-read EOF/identity/stream joins, and changing delivery.

`offline-freeze-check.log` independently records exact launcher shell-argument parsing, compressed collector byte round-trip without executing the launcher, and generated two-original/one-archive re-verification. Generated archive size is 9,491 bytes and inventory count is 37. These are generated sources, not possessed SDK originals.

## Exact packet/control freeze

Example account/nonce/deadline remain generated placeholders. Actual Root instantiation changes bytes/hashes and must re-freeze them before mutation.

| Item | Frozen example |
| --- | ---: |
| Collector bytes | 25,583 |
| Inline buildspec UTF-8 bytes | 11,535 |
| Complete buildspec JSON string bytes including escapes | 11,579 |
| Complete canonical CreateProject request bytes | 12,251 |
| Returned buildspec copies reserved | 14 |
| Full-response wrapper envelope per copy | 3,072 bytes |
| Other setup/control envelope | 24,576 bytes |
| Closure reserve | 65,536 bytes |
| Estimated complete control originals | 307,477 bytes |
| Fixed control limit | 314,572 bytes |
| Unallocated headroom | 7,095 bytes |

The exact estimate is `12251 + 14*11579 + 14*3072 + 24576 + 65536 = 307477`. Fourteen source repetitions cover CreateProject response, BatchGetProjects readback, StartBuild response, ten normal build polls and one reconciliation response. No returned original is replaced by request bytes/status summaries. The 3 KiB wrapper envelope is a strict prelaunch/dispatch gate, not measured real provider output. Root must prove actual remaining capacity and retain complete originals. Any unknown/oversized envelope is negative; no borrowing from log traversals/closure.

Ten poll offsets are 15,30,60,90,120,150,180,225,270,300 seconds after StartBuild. These are at least 15 seconds apart with waits <=45 seconds. Unused slots cannot become writes. CarrierStart precedes the first owned mutation including logging; all setup consumes the same 600 seconds. Start/worker/closure remain 120/300/180 seconds, with no retry/replacement and one StopBuild maximum.

Collector SHA256 `c8c48bca85972b414623cf61a1af7ec09f83996b43ac42e8b15e33784c5f1691`.

Buildspec SHA256 `81206e9b4145e0842d7c904f2dd76d4af6cc99f3fcd5142d743bee291e05177e`.

## Narrow resource amendment and actual read categories

Root explicitly amended only this diagnostic's new logical allocation from 32 MiB to 128 MiB during implementation, now recorded in Root rulings. Source 8 MiB, ZIP 1 MiB, metadata 64 KiB, selected model metadata 16 KiB/128 shapes, worker stdout 1.5 MiB, each traversal 1.6 MiB, owned disk 16 MiB and hard/soft address space 256 MiB stay unchanged. Packet refs and README carry the amendment.

Admission is `5U + 16*Zmax + 64 MiB bounded model reserve + 8 MiB margin <=128 MiB`. With maximum U=8 MiB and Zmax=1 MiB, 40+16+64+8=128 MiB. There is no new qualification/transport allocation.

The 5U terms are worker full read/hash/compression input and one Root expanded extraction/hash. Sixteen Zmax covers worker whole-ZIP hash and encoding consumers, both independently retained original-log parses, both frame parses/base64 decodes/whole-ZIP hashes and exact comparison, plus ZIP compressed-input validation/container slack. Both original traversals and both reconstructions are charged. Direct data-frame formatting and pad-bit checks avoid repeated generic data-frame serialization/base64 re-encoding. Up to 5 MiB of bounded slicing/ASCII formatting/output/response-size copies use the 8 MiB margin; the remaining 3 MiB covers bounded model/event selection/identity/package traversal and metadata/control/negative copies. This is conservative logical consumer accounting, not a claim to observe each native/runtime microinstruction.

Managed JSON model construction is explicitly declared activity. During fact construction, bounded local JSON/gzip readers charge compressed bytes once plus plain/decompressed bytes three times for read/output, decoding and parsing, with a hard 64 MiB weighted cap before unbounded reads/expansion. Published `model_io` counters report actual observed weighted work for that runtime. They are zero only in the generated no-model-file fixtures. Unsupported text-mode/direct read variants are negative. Full selected model bodies are not dumped; selected trait graph output remains capped. SDK import machinery is declared managed-runtime infrastructure; no installed bodies were inspected locally to invent a zero cost.

Worker source/ZIP processing is memory-only, with no expanded source staging. Disk 16 MiB covers one ZIP, two original traversal sets, possible <=8 MiB expanded originals and bounded control transients. Diagnostic C evidence remains <=4.5 MiB inside existing C8 MiB: 3.2 MiB two traversals +1 MiB one ZIP +0.3 MiB complete control including closure. No real capacity hold has been invoked by implementer.

## Frozen diff and custody

`inventory.json` contains hashes/lengths of 76 new private content files, totaling 254,352 bytes, including source/tests/README/fixtures/generated packet and all logs. `full-new-files.diff` contains every such new-file body plus inventory; no patch excerpts were substituted. Closing inventory/diff/summary receipts exclude themselves as documented to avoid circular hashes.

- Inventory SHA256 `a35a610d23023d24572706588e69e1ea35055168a9ee639f0d20e7ddafde9831`.
- Full diff bytes 271,759; SHA256 `65d1ce171837dba6bd3f3dc31a48e7e00e3fed2f657691191ab9d6f5c7f1e57f`.
- `freeze-summary.json` binds both and records exact scope. This external report is not part of its own inventory.

## Remaining readiness gaps

Independent SPEC/QUALITY review follows. No managed SDK fit, installed module sizes, actual hook/model shape, upstream authentication, model-read allowance fit or log-delivery closure has yet been observed. Unknown managed-runtime behavior produces a bounded negative, not fake support. Callback owners outside the 37 files remain explicit review gaps.

Root must instantiate actual identities/deadline, freeze real request bytes/hash, establish actual C/control response capacity and chronological receipts, retain fresh pricing/billing evidence and take the prospective $0.10 hold under standing user $20 authority. This includes submit-to-termination billing/rounding/logging and residual uncertainty if stop/termination is ambiguous. Cleanup remains Root-only after durable custody. The packet has no provider driver.

Root additionally identified an ambiguous StartBuild-without-id path: BatchGetBuilds requires a known id. Before paid execution, freeze an explicit bounded ListBuildsForProject reconciliation slot/request for the unique owned project, or leave that negative path blocked. No restart/retry is authorized. This report records the gap; no generic provider orchestration framework was added.
