"""Regenerate this task's generated-only example and immutable review inventory."""
import base64
import difflib
import hashlib
import json
from pathlib import Path
import sys
from inspect_sdk import canonical, collect, frame_output
from packet import prepare_packet
from verify import verify_capture
from test_inspection import Runtime

ROOT=Path(__file__).parent.resolve()
def write_json(path,value): path.write_bytes(canonical(value)+b'\n')
def generate():
    owned=json.loads((ROOT/'fixtures/owned.json').read_text())
    packet=prepare_packet(owned,(ROOT/'inspect_sdk.py').read_bytes())
    write_json(ROOT/'fixtures/packet.json',packet)
    (ROOT/'fixtures/buildspec.yml').write_text(packet['buildspec'])
    metadata,archive=collect(Runtime(ROOT/'fixtures/generated-sources'),{})
    lines=frame_output(metadata,archive,'n'*32)
    expected={'nonce':'n'*32,'build_id':'p:id','build_arn':'arn:aws:codebuild:us-east-1:123456789012:build/p:id','group':'g','stream':'prefix/id','stream_arn':'arn:aws:logs:us-east-1:123456789012:log-group:g:log-stream:prefix/id','terminal':'SUCCEEDED'}
    desc={'logStreams':[{'logStreamName':'prefix/id','arn':expected['stream_arn'],'lastEventTimestamp':20,'lastIngestionTime':30}]}
    build={'id':expected['build_id'],'arn':expected['build_arn'],'buildStatus':'SUCCEEDED','logs':{'groupName':'g','streamName':'prefix/id'}}
    pages=[{'request':{'logGroupName':'g','logStreamName':'prefix/id','startFromHead':True,'limit':64},'response_original':canonical({'events':[{'timestamp':20,'ingestionTime':30,'message':s} for s in lines],'nextForwardToken':'end'}).decode()},{'request':{'logGroupName':'g','logStreamName':'prefix/id','startFromHead':True,'limit':64,'nextToken':'end'},'response_original':canonical({'events':[],'nextForwardToken':'end'}).decode()}]
    original={'capture_class':'complete-semantic-response-json','build_original':canonical({'builds':[build],'buildsNotFound':[]}).decode(),'describes':[canonical(desc).decode(),canonical(desc).decode()],'reads':[{'after_terminal':True,'pages':pages},{'after_terminal':True,'pages':pages}]}
    result=verify_capture(original,expected)
    assert result['archive_bytes']==archive
    write_json(ROOT/'fixtures/capture.json',original)
    write_json(ROOT/'fixtures/expected.json',expected)
    write_json(ROOT/'fixtures/metadata.json',metadata)
    (ROOT/'fixtures/archive.base64').write_text(base64.b64encode(archive).decode()+'\n')
    write_json(ROOT/'fixtures/example-result.json',{'status':result['status'],'inventory_count':len(result['inventory']),'archive_bytes':len(archive),'archive_sha256':hashlib.sha256(archive).hexdigest(),'gaps':result['gaps'],'label':'generated-only; not an observed SDK/provider result'})
    return packet['refs']
def freeze():
    excluded={'inventory.json','full-new-files.diff','freeze-summary.json'}
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and p.name not in excluded and '__pycache__' not in p.parts)
    inventory=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
    write_json(ROOT/'inventory.json',{'schema':1,'scope':'all new private content files except inventory/diff/summary closing receipts','files':inventory})
    diff=[]
    for p in files+[ROOT/'inventory.json']:
        data=p.read_text()
        diff.extend(difflib.unified_diff([],data.splitlines(keepends=True),fromfile='/dev/null',tofile=str(p.relative_to(ROOT)),n=3))
    (ROOT/'full-new-files.diff').write_text(''.join(diff))
    summary={'schema':1,'content_file_count':len(files),'content_bytes':sum(i['bytes'] for i in inventory),'inventory_sha256':hashlib.sha256((ROOT/'inventory.json').read_bytes()).hexdigest(),'diff_sha256':hashlib.sha256((ROOT/'full-new-files.diff').read_bytes()).hexdigest(),'diff_bytes':(ROOT/'full-new-files.diff').stat().st_size,'closing_receipts':'inventory excludes itself/diff/summary; diff includes inventory and excludes diff/summary; this summary binds both'}
    write_json(ROOT/'freeze-summary.json',summary)
    return summary
if __name__=='__main__':
    refs=generate()
    print(json.dumps(refs,sort_keys=True,indent=2))
    if '--freeze' in sys.argv: print(json.dumps(freeze(),sort_keys=True,indent=2))
