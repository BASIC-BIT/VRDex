"""Exercise real adapter code with generated modules and local models only."""
import collections
import types
import unittest
from unittest.mock import patch
from test_inspection import module

NodeList=collections.namedtuple('NodeList','first middle last')
def empty_node(): return {'chunk':None,'values':None,'children':{}}
class Trie:
    _root=empty_node()
    def prefix_search(self,event): return []
class Emitter: _handlers=Trie()
class Events:
    _emitter=Emitter(); _event_aliases={}
    def _alias_event_name(self,event): return event
class Shape:
    def __init__(self,name,kind,traits=None,members=None):
        self.name=name; self.type_name=kind; self._shape_model=traits or {}; self.metadata=self._shape_model
        self.serialization={}; self.members=members or {}; self.required_members=[]
class Service:
    metadata={'protocol':'json'}
    service_id=types.SimpleNamespace(hyphenize=lambda:'s3')
    def operation_model(self,name):
        blob=Shape('Blob','blob',{'streaming':True})
        inp=Shape('Input','structure',{'payload':'layerPartBlob'},{'layerPartBlob':blob})
        return types.SimpleNamespace(input_shape=inp,output_shape=blob,_operation_model={'httpChecksum':{'requestAlgorithmMember':'ChecksumAlgorithm'},'requestCompression':{'encodings':['gzip']}},auth_type=None,http_checksum={'requestChecksumRequired':True},has_streaming_input=True,has_streaming_output=True)
class HTTP:
    def send(self,*args,**kwargs): raise AssertionError('SDK HTTP executed')
class Serializer:
    def serialize_to_request(self,*args): raise AssertionError('serializer executed')
class Endpoint:
    def __init__(self): self.http_session=HTTP()
    def make_request(self,*args): raise AssertionError('endpoint executed')
    def create_request(self,*args): raise AssertionError('request executed')
class Signer:
    _signing_name='s3'; _region_name='us-east-1'; _signature_version='v4'
    def get_auth_instance(self,*args): return types.SimpleNamespace()
class Client:
    def __init__(self,cfg):
        self.meta=types.SimpleNamespace(config=cfg,events=Events(),service_model=Service())
        self._endpoint=Endpoint(); self._serializer=Serializer(); self._request_signer=Signer()
    def _make_api_call(self,*args): raise AssertionError('operation executed')
    def _convert_to_request_dict(self,*args): raise AssertionError('conversion executed')
    upload_layer_part=get_object=put_object=_make_api_call

class RuntimeAdapterTests(unittest.TestCase):
    def test_real_fact_adapter_on_generated_runtime(self):
        api=module('inspect_sdk'); recorded=[]
        class Config:
            def __init__(self,**kwargs): self.__dict__.update(kwargs)
        class Session:
            def __init__(self,**kwargs):
                recorded.append(kwargs)
                if kwargs.get('aws_access_key_id')!='INSPECTIONDUMMY': raise AssertionError('credentials')
            def client(self,service,endpoint_url,config):
                recorded.append((service,endpoint_url)); return Client(config)
        boto3=types.ModuleType('boto3'); boto3.session=types.SimpleNamespace(Session=Session)
        config=types.ModuleType('botocore.config'); config.Config=Config
        https=types.ModuleType('botocore.httpsession'); https.URLLib3Session=HTTP
        generated={'boto3':boto3,'botocore.config':config,'botocore.httpsession':https}
        origins={name:'/generated/'+name+'.py' for name in api.MODULES}
        imported={name:types.SimpleNamespace(__spec__=types.SimpleNamespace(origin=path)) for name,path in origins.items()}
        dist=types.SimpleNamespace(version='0.generated',requires=['dependency>=0'],locate_file=lambda x:'/generated')
        runtime=api.ManagedRuntime(); runtime.paths=origins
        original=HTTP.send
        try:
            with patch.dict('sys.modules',generated),patch.object(api.importlib,'import_module',lambda n: imported[n]),patch.object(api.importlib.metadata,'distribution',lambda n:dist):
                facts=runtime.facts()
            self.assertEqual(len([x for x in recorded if isinstance(x,dict)]),2)
            self.assertEqual(facts['clients']['s3']['configuration']['retries']['value'],{'total_max_attempts':1,'mode':'standard'})
            self.assertFalse(facts['clients']['s3']['configuration']['request_checksum_calculation']['present'])
            self.assertTrue(facts['models']['ecr']['shapes']['Blob']['traits']['streaming'])
            self.assertEqual(facts['models']['ecr']['shapes']['Input']['members']['layerPartBlob'],'Blob')
            self.assertEqual(len(facts['events']['s3']['matches']),20)
            self.assertRaisesRegex(ValueError,'network_forbidden',HTTP().send)
        finally: HTTP.send=original
    def test_unknown_model_type_is_negative(self):
        client=Client(types.SimpleNamespace())
        model=client.meta.service_model
        original=model.operation_model
        def bad(name):
            op=original(name); op.output_shape.type_name='unrecognized'; return op
        model.operation_model=bad
        self.assertRaisesRegex(ValueError,'model_shape',module('inspect_sdk').model_facts,client,['PutObject'])
    def test_callback_count_is_enforced_without_execution(self):
        api=module('inspect_sdk'); root=empty_node()
        def callback(): raise AssertionError('handler executed')
        root['children']={'before-call':{'chunk':'before-call','children':{},'values':NodeList([], [callback]*513, [])}}
        trie=types.SimpleNamespace(_root=root,prefix_search=lambda event:[])
        events=types.SimpleNamespace(_emitter=types.SimpleNamespace(_handlers=trie),_event_aliases={},_alias_event_name=lambda e:e)
        self.assertRaisesRegex(ValueError,'event_registry|event_limit',api.event_facts,events,'s3',['PutObject'])
    def test_missing_managed_source_resolution_is_negative_without_import(self):
        api=module('inspect_sdk')
        with patch.object(api.sysconfig,'get_path',lambda k:'/usr/generated'),patch.object(api.importlib.machinery.PathFinder,'find_spec',lambda *a:None):
            self.assertRaisesRegex(ValueError,'source_path',api.ManagedRuntime().sources)

if __name__=='__main__': unittest.main()
