# CloudWatch stream observation assessment

2026-10-27. Independent read-only assessment of diagnostic namespace `402208ae9464427cae31a61ff81b07c5`. Scope: the verifier's stream-observation guard, retained small Describe/GetLogEvents/negative receipts, and two public AWS API documentation pages. No implementation changes, SDK/archive/native/corpus reads, provider calls, new diagnostic or pipeline review.

## Finding

The `stream_observation` rejection is a verifier assumption failure: DescribeLogStreams summary timestamps are treated as upper bounds on events already returned by GetLogEvents. The retained pages directly contradict that assumption, and AWS documents eventual consistency for `lastEventTimestamp`. Stable descriptive metadata is not a freshness or finality certificate.

This finding does **not** turn the actual attempt positive. Both retained traversals contain matching worker-negative header/trailer frames with reason `model_shape`, `module_count=0`, `frame_count=0`, and `archive_bytes=0`. There is no captured source archive or approved SDK support. The appropriate present disposition is a closed diagnostic with a complete observed framed worker negative, plus a separately recorded verifier metadata-assumption defect.

## Confirmed observations

I independently parsed the six retained small page files without invoking the verifier or decoding/extracting an archive:

| Fact | Observation |
| --- | --- |
| Traversals | Two, with identical complete event arrays |
| Pages per traversal | Three: 50 events, zero events, zero events |
| Second page | Empty, but returned forward token differs from supplied token; not EOF |
| Third page | Empty, returned forward token equals supplied token; EOF observation |
| Before/after Describe lastEventTimestamp | Both `1793068669412` |
| Maximum actual event timestamp | `1793068683004` |
| Before/after Describe lastIngestionTime | Both `1793068669435` |
| Maximum actual event ingestionTime | `1793068683027` |
| Summary lag for both fields | `13,592` milliseconds |
| Framed payload | Matching negative header/trailer; `model_shape`; zero archive bytes |

Both Describe responses name the same exact stream/ARN, with no pagination token. Their uploadSequenceToken values differ even though the two timestamp pairs match; I infer no finality or request-count conclusion from those opaque tokens. The retained `negative-verification.json` records the full verifier failure as `stream_observation`, independent frame rejection as `worker_negative:model_shape`, two closure censuses and confirmed closure. Closure and the $0.005 compute estimate are retained Root-reported facts, not independently re-probed here; the receipt labels the amount an estimate, so this assessment does not call it an invoice.

## Official semantics and limits of inference

AWS explicitly says `lastEventTimestamp` updates on an eventual-consistency basis, usually in less than an hour but occasionally longer. That is incompatible with treating a fresh Describe response as an exact upper bound on event timestamps returned by another API. [AWS DescribeLogStreams](https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_DescribeLogStreams.html).

AWS says empty GetLogEvents pages need not mean pagination has finished. A returned forward token equal to the supplied token identifies the current end reached by that traversal; this supports retaining the third call in each actual read. The API also documents that forward pagination can continue while new events arrive. [AWS GetLogEvents](https://docs.aws.amazon.com/AmazonCloudWatchLogs/latest/APIReference/API_GetLogEvents.html).

The two pages consulted do not establish a synchronous upper-bound guarantee for `lastIngestionTime`. I do not extrapolate the explicit lastEventTimestamp wording into a separate documented SLA for ingestion metadata. Here the actual retained API responses themselves establish that the descriptive ingestion value was behind events already returned. The inference is summary lag, not missing archive bytes. Neither identical traversals, unchanged summary timestamps nor a matching-token EOF proves that CloudWatch can never deliver another event later.

## Minimal bounded disposition to review

1. Preserve exact terminal build/group/stream/ARN joins, single-stream/nonpaginated Describe inventory, full original response retention, both independent from-head traversals, every page/byte/event cap, and matching-token EOF for each. Keep the requirement that the two full event arrays agree. An empty page alone must remain insufficient.
2. Remove the two event-timestamp inequalities against Describe summary timestamps as acceptance gates. Retain and type-check the actual descriptive observations and actual observed maxima, and report lag explicitly. This is the smallest correction needed for this attempt's false rejection; it requires no additional provider request, timeout extension or retry.
3. For an acceptance criterion specifically about **possession of the complete selected framed archive**, treat equality of the before/after descriptive timestamp pairs as advisory too. A summary catching up between observations does not negate byte-identical, independently retrieved, fully validated archive frames. Keeping that equality as a temporary conservative policy is possible, but must not be described as an AWS completeness guarantee and can still produce another false negative. Changing event arrays, missing/second streams, conflicting or duplicate frames, invalid identities or a missing EOF remain failures.
4. Require exactly the allowed frame sequence and nonce, matching header/trailer, strict frame counts/order/base64, whole-archive size/hash, exact 37-source-plus-metadata inventory, metadata/build binding, source sizes/hashes, archive safety checks and all existing read/disk/evidence limits. Decode and compare both observations as already designed. Only a complete positive archive satisfying those checks can yield `complete-selected-sources`.
5. Distinguish the bounded observation outcome from the worker outcome. Valid matching negative frames should retain `worker_negative:model_shape` without claiming a source archive. Malformed/incomplete frames remain capture failures. Any future positive should state: complete selected archive bytes possessed from two matching bounded EOF observations of the identified terminal build; AWS-managed provider-capture provenance; no authenticated upstream source, HTTP-wire proof, absolute CloudWatch finality, SDK support or transport/native approval.

This recommendation changes verification semantics only. It grants no new diagnostic attempt and does not repair the independent `model_shape` worker failure. Preserve the original failed-verifier receipt and explain any later revised disposition instead of rewriting the historical outcome as if the old guard passed. No waiting for potentially hour-scale summary convergence or new polling loop is justified within the existing finite carrier.

## Evidence pins

- `/workspace/scratch/managed-sdk-inspection/verify.py`: SHA256 `e5025cdf3e9c9388a1fc9bc8cca5fd878e89aa87b3a7d6b8ec258e4112ddc854`.
- Actual `negative-verification.json`: SHA256 `0f05c79289ca90949761d302b4d78b7f4a1b101aef2a3fbbbe73b5f72a764807`.
- Actual `describe-before.json`: SHA256 `aea27fcc421bb09911a8c5bc845181f6af5413cae01344e9ff12c6977e0fa4fe`.
- Actual `describe-after.json`: SHA256 `2fce517ba754bea5597799b68e18c7daef8baa62a1a691df5eb3ae67ad75f454`.

Actual filenames above are under `/workspace/scratch/sdk-inspection-live-402208ae9464427cae31a61ff81b07c5/`. Public documentation acquisition was limited to the two linked official pages, with the combined returned text bounded below 32 KiB. This assessment is the only file written.
