# SDK inspection provisioning follow-up review

2026-10-27. **SPEC: PASS. QUALITY: PASS**, scoped to the proposed additional preparation carrier and its resource/lifecycle disposition. No blocking issue was found in this proposal. This is a peer review under the existing owned-test authorization, not a new user-permission requirement or a claim that the next trial has run.

Reviewed subject: `/workspace/scratch/managed-sdk-inspection-provisioning-followup.md`, SHA256 `ef3f9d17ec730fdc6c4d2be351add49b29c841c600ff376f7fd0781574232b51`.

The review used retained metadata only. No implementation edits, provider/network calls, corpus or SDK-body reads, subagents, or tests occurred. The previously reviewed 53-test helper revision was not reopened for a broader audit.

## Verified negative closure

The retained provisioning response shows exact role trust and logs-only policy readback, followed by a definite CreateProject `InvalidInputException` concerning `sts:AssumeRole`. Its eight reported API invocations contain no StartBuild. Corrected preflight reports five calls; cleanup reports nine, totaling 22. The original preflight was rejected at code validation. The proposed recovery records `accepted:false`, an empty error at the attempted local step and no provider invocation record; the ledger identifies the latest-start guard as the reason no recovery API call occurred. Thus the guard attribution relies on the controller/ledger receipt rather than an AWS error message.

Cleanup records successful deletion of the owned inline policy, role and log group. Two separately executed census sets each report the exact project in `projectsNotFound`, role `NoSuchEntity`, and an empty nonpaginated log-group result. This supports `CLOSED_NEGATIVE_NO_PROJECT_OR_BUILD`; it does not convert preparation into a successful SDK observation.

All nine byte counts and hashes in `closure-refs.json` matched the retained files. They total 51,488 bytes; including the 1,490-byte closure manifest, the directory's ten retained JSON files total **52,978 bytes**. Charge that complete amount, plus later receipts, when applying the proposal's existing history/readiness margin.

Pinned evidence:

- `closure-refs.json`: `a2cf124ef961767b05470785f5ecc4ba0365decf1f5cebcb33cf6a86458954e7`.
- `actual-negative-cleanup.json`: `1c8ca95455cabf5511392204a22e12c421b2faff8a97dabc3fcbf952ece0a646`.
- `actual-provisioning.json`: `ede7a9c72749fdc0ac164501b4b221d03e0f270ceaf343c2ed17efd741dfe752`.
- `actual-project-recovery.json`: `f8258bdb6b5c1009b2d664a62eb3e328b3a78836ca72ffbd6af878a3408aa9bd`.
- `ledger.json`: `fb69ea18543e43529fa61f6da1931216eef1f592fc3f1fde7857165458f6adbb`.

These files are under `/workspace/scratch/sdk-inspection-live-7c9c3e3d216f43a0aed0e1cb39ca8544/`.

## SPEC disposition

The new trial is an explicit, separately accounted Root amendment. It uses a fresh namespace and preserves the first carrier's negative result, originals, 22 observed calls/27 conservative dispatch holds, $0.10 hold and 128 MiB reservation. It does not disguise an earlier attempt as unused capacity. Adding at most 74 new calls gives the stated 96 observed-invocation upper and 101 conservative dispatch-held upper. The additional $0.10 produces the stated $3.66346 total hold and $16.33654 unreserved authority. The logical-work reservation becomes 256 MiB across both carriers; the per-process 256 MiB address-space bound is a separate unchanged constraint.

The proposal retains the aggregate 16 MiB disk bound, C8 MiB, a new diagnostic reservation of 4.5 MiB within C, complete response allowances and all qualification limits. Actual aggregate headroom remains a required pre-mutation check; the historical files are charged to the existing margin rather than silently discarded.

One uninterrupted timer/freeze/first-dispatch operation with a ten-second stale-timer rejection addresses the previous preparation delay. The fixed 15-second quiet period consumes the same 600-second clock. Exact setup/readback, one CreateProject, exact project readback and at most one StartBuild remain subordinate to the +120 start cutoff and 300/180 work/closure reservation. The worker's independent start guard, ambiguity reconciliation, at-most-one stop and exact cleanup censuses remain required. Another failure ends this trial without further recovery authority.

## QUALITY disposition and execution conditions

Retained `role-trust-docs-2.json` (SHA256 `5959579c0fec20ecb9df2dea4d2a19d2a165758050a4dbb5e69d9e7adc3ec24b`) includes the AWS CodeBuild confused-deputy documentation example with an exact project SourceArn condition. It supports retaining the project-specific trust scope; it does not prove that IAM propagation caused the observed failure or that 15 seconds will suffice. The proposal accurately preserves that uncertainty and does not broaden trust.

Before mutation, Root still must freeze the fresh actual packet and enforce the proposal's identity, collision, response-capacity, aggregate evidence/work/disk and prospective cost gates. Preserve the first hold; do not treat the absence of a build as invoice-level proof of zero fees. If preparation, timing, ownership, response custody or cleanup becomes uncertain, retain the negative and residuals rather than retrying or claiming closure.

The scoped proposal is ready for Root execution subject to those existing gates. It grants no SDK support, image transfer, production change, native/semantic qualification or capacity admission.
