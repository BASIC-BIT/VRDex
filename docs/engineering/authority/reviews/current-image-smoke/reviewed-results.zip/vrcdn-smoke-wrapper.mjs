import {createProcessOwner} from './scripts/event-proof-processes.mjs';
const owner=createProcessOwner();
const receipt={kind:'owned-vrcdn-credential-smoke',passed:false,progress:false,rejected:false,timedOut:false,cleanup:false};
let child,timer,tail='';
try {
 child=owner.start(process.execPath,['workers/restream/vrcdn-poc.mjs'],{stdio:['ignore','pipe','pipe']});
 let scanned=0;
 child.stderr.on('data',b=>{if(scanned>=131072)return; const s=tail+b.subarray(0,Math.min(b.length,131072-scanned)).toString(); scanned+=b.length; if(/netstream\.publish\.(?:badname|denied)|authentication failed|server error:/i.test(s))receipt.rejected=true; tail=s.slice(-128);});
 let line='';child.stdout.on('data',b=>{line=(line+b.toString()).slice(-8192);let p;while((p=line.indexOf('\n'))>=0){const v=line.slice(0,p);line=line.slice(p+1);try{const x=JSON.parse(v);if(x.event==='vrcdn_poc_output_restream_started')receipt.progress=true;if(x.event==='vrcdn_poc_output_restream_completed'){receipt.finalOutputProgressMs=x.finalOutputProgressMs;receipt.commandCount=x.commandCount;}}catch{}}});
 timer=setTimeout(()=>{receipt.timedOut=true;void owner.close().catch(()=>{});},120000);
 receipt.exitCode=await child.closed;
 receipt.passed=receipt.exitCode===0&&receipt.progress&&!receipt.rejected&&Number.isFinite(receipt.finalOutputProgressMs)&&receipt.finalOutputProgressMs>=58000&&Number.isInteger(receipt.commandCount)&&receipt.commandCount>=2&&!receipt.timedOut;
} catch {receipt.passed=false;}
finally {clearTimeout(timer);try{receipt.cleanup=(await owner.close()).closed;}catch{receipt.cleanup=false;}receipt.passed&&=receipt.cleanup;console.log(JSON.stringify(receipt));process.exitCode=receipt.passed?0:1;}
