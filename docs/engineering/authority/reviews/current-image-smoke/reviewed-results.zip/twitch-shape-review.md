# Twitch shape probe review

Reviewed `twitch-shape-probe.py` against the colocated production `twitch_input.py` and `twitch_transport.py`. Static review only: no probe, tests, cloud actions, or production edits performed.

**Verdict:** Approved for the bounded resolver/selector diagnostic with the root's independent 150-second container bound. Production transport policy and the metadata-only output design are preserved. Scoped rereview confirms all three findings below are addressed in the frozen source, SHA-256 `e874e2426138d03726ed787a801a0e26dba2c6c118f747bba41502a548cc88b4`. The 18-second channel timer covers resolution/selection; cleanup uses the remaining 120-second overall budget.

- The six channel names are fixed. The probe constructs the same `Streamlink`, installs the actual fetch boundary, invokes `AnonymousTwitch(...).streams()` with H.264 options, and calls the real `select_rendition(..., "1080p60")`. No stream is opened, `HLSReader` or decoder launched, or segment persisted. Normal upstream playlist preflights remain permitted.
- The `session.http.send` observer delegates the original arguments and result unchanged, rethrows the original exception, and does not alter adapters, TLS, proxy refusal, redirects, DNS policy, body limits, headers, or HTTP deadlines. It retains only numeric statuses and fixed `safe_reason` values. Requests, URLs, headers, bodies, cookies, codecs, provider error messages, and exception representations are not serialized.
- Shape rows retain numeric dimensions/rate and booleans for manifest presence, URI matching, and codec families. Six channels and at most 24 rows each keep expected output well below 64 KiB. Logging is disabled before production imports, and caught failures never print exception text.

**Findings addressed in scoped rereview**

1. **Deadline coverage gap: addressed.** The remaining overall alarm is now rearmed before `session.http.close()`, including after a channel alarm has fired. Cleanup is therefore covered by the overall budget, with the external container timeout retained as the independent bound.
2. **Evidence precision: addressed.** `resolverReturned` starts false and becomes true immediately after `streams()` returns. This distinguishes a returned empty resolver result from setup/resolution failure. Populated rows plus selector rejection identify a shape mismatch. HTTP status and boundary-reason counters help expose failures swallowed by upstream; successful HTTP alone cannot distinguish offline channels from provider-level rejection in a successful response.
3. **Literal stdout cap: addressed.** The size check now includes the newline added by `print`, so the emitted JSON line is limited to 65,536 bytes. The fixed current schema remains comfortably smaller.

Retain actual task exit status, full image digest, complete CloudWatch logs, and cleanup evidence in the root handoff. This diagnostic establishes resolver and selector observations only; it does not establish media acceptance, playback, or live readiness. Resource size, deployed image identity, and outer task timeout require verification by the root run.
