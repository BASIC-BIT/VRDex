"""Private one-shot resolver-shape diagnostic for the unchanged worker image.

Run from /app with the packaged workers importable. No arguments, credentials,
fallback HTTP, media segments, or provider text are accepted or emitted.
Streamlink's production streams() performs its normal media-playlist preflights.
This proves resolver/selector shape only, never media acceptance or live readiness.
"""

import json
import logging
import math
import signal
import time


CHANNELS = ("shroud", "eslcs", "forsen", "sodapoppin", "loltyler1", "piratesoftware")
ROW_LIMIT = 24
BYTE_LIMIT = 65536


class ProbeDeadline(BaseException):
    # Upstream _check_streams catches Exception; a process deadline must escape it.
    pass


def deadline(*_):
    raise ProbeDeadline()


def numeric(value):
    if isinstance(value, (int, float)) and not isinstance(value, bool):
        if math.isfinite(value) and 0 <= value <= 10000000:
            return value
    return 0


def shape(stream):
    manifest = getattr(stream, "multivariant", None)
    playlists = getattr(manifest, "playlists", [])
    url = getattr(stream, "url", None)
    matches = [p for p in playlists if getattr(p, "uri", None) == url]
    info = getattr(matches[0], "stream_info", None) if matches else None
    resolution = getattr(info, "resolution", None)
    codecs = getattr(info, "codecs", [])
    return {
        "manifestPresent": manifest is not None,
        "playlistCount": len(playlists),
        "uriMatches": len(matches),
        "width": numeric(getattr(resolution, "width", None)),
        "height": numeric(getattr(resolution, "height", None)),
        "fpsNumeric": numeric(getattr(info, "framerate", None)),
        "h264": any(isinstance(c, str) and c.startswith(("avc1", "avc3")) for c in codecs),
        "aac": any(isinstance(c, str) and c.startswith("mp4a.40.") for c in codecs),
    }


def main():
    logging.disable(logging.CRITICAL)
    signal.signal(signal.SIGALRM, deadline)
    lifetime_end = time.monotonic() + 120
    signal.setitimer(signal.ITIMER_REAL, 120)
    report = {"runId": "cv20261028shape2", "channels": []}
    try:
        # This package activates /opt/twitch exactly as production does.
        from workers.restream.twitch_input import AnonymousTwitch, Streamlink, select_rendition
        from workers.restream.twitch_transport import install_fetch_boundary, safe_reason

        for channel in CHANNELS:
            remaining = lifetime_end - time.monotonic()
            if remaining <= 0:
                break
            signal.setitimer(signal.ITIMER_REAL, min(18, remaining))
            result = {
                "channel": channel,
                "resolverReturned": False,
                "streamCount": 0,
                "rows": [],
                "selectorPass": False,
                "safe_reason": "provider_unavailable",
                "httpStatuses": {},
                "httpSafeReasons": {},
            }
            report["channels"].append(result)
            session = None
            try:
                session = Streamlink({"http-timeout": 5, "webbrowser": False, "no-plugin-cache": True})
                install_fetch_boundary(session)
                # Observe the guarded production request only. Never inspect or
                # retain URLs, headers, bodies, cookies, or provider error text.
                original_send = session.http.send

                def observed_send(*args, **kwargs):
                    try:
                        response = original_send(*args, **kwargs)
                    except BaseException as exc:
                        reason = "preparation_timeout" if isinstance(exc, ProbeDeadline) else safe_reason(exc)
                        counts = result["httpSafeReasons"]
                        counts[reason] = counts.get(reason, 0) + 1
                        raise
                    status = response.status_code
                    if isinstance(status, int) and 100 <= status <= 599:
                        counts = result["httpStatuses"]
                        counts[status] = counts.get(status, 0) + 1
                    return response

                session.http.send = observed_send
                streams = AnonymousTwitch(
                    session,
                    "https://www.twitch.tv/" + channel,
                    options={"supported-codecs": ["h264"]},
                ).streams()
                result["resolverReturned"] = True
                result["streamCount"] = len(streams)
                result["rows"] = [shape(s) for s in list(streams.values())[:ROW_LIMIT]]
                select_rendition(streams, "1080p60")
                result["selectorPass"] = True
                result["safe_reason"] = None
            except ProbeDeadline:
                result["safe_reason"] = "preparation_timeout"
            except BaseException as exc:
                result["safe_reason"] = safe_reason(exc)
            finally:
                signal.setitimer(signal.ITIMER_REAL, max(0.001, lifetime_end - time.monotonic()))
                if session is not None:
                    session.http.close()
    except ProbeDeadline:
        pass
    except BaseException:
        report["safe_reason"] = "provider_unavailable"
    finally:
        signal.setitimer(signal.ITIMER_REAL, 0)
    encoded = json.dumps(report, separators=(",", ":"), allow_nan=False)
    if len(encoded.encode("utf-8")) + 1 > BYTE_LIMIT:
        encoded = '{"runId":"cv20261028shape2","safe_reason":"response_limit"}'
    print(encoded, flush=True)


if __name__ == "__main__":
    main()
