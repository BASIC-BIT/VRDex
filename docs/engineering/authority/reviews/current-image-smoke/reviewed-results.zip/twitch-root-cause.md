# Current-image Twitch failure investigation

Read-only investigation on 2026-10-28. Production code and transport policy were not changed. No provider/network or cloud API calls were made by this investigation. Existing image inspection ran with Docker `--network none --read-only --cap-drop ALL --security-opt no-new-privileges`.

## What the actual receipt establishes

`twitch-poll-1.json` records the current image `sha256:e74e3c2d3859d09df95c5e2de82f515a8f055aa36290996ade6ef5a1206fd508`, revision `69e5622a92a1dff05be66abdcf7674a71c482ad1`, private run `cv20261028twitch`.

- Source 0 repeatedly reports `unsupported_media`: first at 694 ms, then 2,905, 6,118, 11,329, 16,692, 18,918, 22,132 and 27,351 ms in retained events. Python acquisition announcements precede these by about 377–387 ms. No warming, transport readiness, dimensions, or decoder children were observed.
- Source 1 has no acquisition events and no decoder children. It was not exercised; this run cannot establish whether it resolves successfully.
- The run ends at the 40-second dual startup limit with `dual_startup_timeout`. The encoded 720p30 recording is the hold program and does not establish Twitch media acceptance. Cleanup reports no live owned descendants.
- The later `provider_unavailable` events are emitted by the Node child-exit/retry path (`twitch-input.mjs`), so they are not independent evidence that the upstream provider emitted that reason.

## Boundary identified, cause still unproven

`run_attempt` installs the production fetch boundary, resolves `AnonymousTwitch(..., options={"supported-codecs": ["h264"]}).streams()`, and immediately calls `select_rendition`. The HLS reader and FFmpeg remux start afterward. With no warmup or decoder, the strongest current candidate is the resolver-to-selector boundary, before segment acquisition and decode. A media-playlist reader rejection before its first segment remains possible from the receipt alone; `unsupported_media` is also used there. The receipt does not identify the exact Python raise site.

`select_rendition` maps both an empty mapping and a nonempty mapping with no acceptable matching playlist to `unsupported_media`. Its criteria require a matching `playlist.uri == stream.url`, populated resolution, width <=1920, height <=1080, positive frame rate <=60.01, AVC codec (`avc1`/`avc3`) and AAC codec (`mp4a.40.*`). It selects the nearest available height under the requested height or the lowest available above it; requesting 1080p60 does not itself require an exact 1080p60 source.

## Pinned dependency findings

The existing local `vrdex-restream-worker:ci` image contains Streamlink **8.6.2** under `/opt/twitch`; `workers.restream.__init__` activates those private wheels. Inspection of these actual classes found no generic metadata-field mismatch:

- `TwitchHLSStream` subclasses `HLSStream` and uses `TwitchM3U8Parser`.
- `HLSStream.parse_variant_playlist` passes the parsed `multivariant` and exact `playlist.uri` into each stream constructor. `HLSStream.__init__` retains the manifest when `is_master` is true.
- Actual `StreamInfo` has `resolution`, `framerate` and `codecs`, matching the adapter's attribute names.
- Existing selector unit fixtures use `SimpleNamespace` stream objects, so their passing status does not prove that current provider manifests carry acceptable values.

An **empty** `.streams()` result cannot safely be labeled offline:

1. `_access_token` raises `NoStreamsError` for a null token, documented upstream as offline/nonexistent. `Plugin.streams` converts it to `{}`.
2. `Twitch._get_hls_streams` converts master-playlist HTTP 4xx/5xx failures to `None`, then `Plugin.streams` returns `{}`.
3. Twitch enables `check_streams=True`. `HLSStream._check_streams` catches **all `Exception`** when fetching/parsing each media playlist and returns false. This includes production `BoundaryError` failures, HTTP failures, invalid/empty media playlists, and parse failures. If every rendition is rejected, `.streams()` returns `{}` and the selector reports `unsupported_media`.
4. Variant parsing also skips iframe variants and variants with no usable name.

The current receipt cannot distinguish these branches from unsupported/missing rendition metadata. Do not change codecs, frame-rate fallbacks, network policy, dependency pins, or channel policy on this evidence.

## Startup timing

Actual `handoff-policy.mjs` exports `PREPARE_MS = 120_000`. The inline diagnostic's second slot starts 60 seconds after the first; it is already within the preparation window, so there is no 45-second preparation threshold or simple 40-vs-60-second deadline mismatch. However `operator-control.mjs` begins with no selected current slot: until source 0 becomes decoded-ready and is selected, its initial automatic candidate remains slot A. Therefore source 1's absence is consistent with source 0 never becoming ready. Dual startup failure is expected for this observed first-source failure and does not diagnose the second source.

## Next minimal probe (prepared, not run here)

`twitch-shape-probe.py` is a private, fixed-input diagnostic for the unchanged image. It serially resolves the six canonical candidates `monstercat`, `insomniac`, `chillhopmusic`, `shroud`, `xqc`, `summit1g` using the actual `Streamlink`, production `install_fetch_boundary`, and `AnonymousTwitch` h264 options. It then calls the actual selector for 1080p60 and exits before constructing `HLSReader`, fetching segments, or spawning FFmpeg. Streamlink's inherent production media-playlist preflights still occur.

Output is one JSON object <=64 KiB including its terminating newline, with fixed run ID `cv20261028shape`. Each channel includes `resolverReturned` (false until `.streams()` returns), stream count, at most 24 stream rows, manifest presence, playlist count, matching-URI count, numeric dimensions/frame rate, AVC/AAC booleans, selector result and fixed `safe_reason`. Aliases can repeat rows; stream count includes aliases. Missing/invalid numeric fields are represented as zero. No stream names or provider text are retained.

A transparent observer around the guarded session's original `http.send` records only HTTP status-code counts and fixed `safe_reason` exception counts before Streamlink can swallow them. It does not inspect response bodies, URLs, headers, cookies, or tokens, and does not alter transport policy. Body-read errors occurring after `send` returns may still evade these exception counts; all-200 empty results do not prove offline.

The script disables logging, bounds each channel at 18 seconds and its own overall lifetime at 120 seconds using a `BaseException` deadline that escapes upstream broad `Exception` handlers. It rearms the remaining overall lifetime alarm before closing each session. Root should use a separate 150-second outer task/process deadline. The probe has no upload or cloud calls; Root can capture the single bounded stdout JSON through the existing private task log. If separately adding S3 persistence, use only the approved fixed private run prefix, AES256, a 15-second CLI timeout and discarded raw stderr.

Interpretation:

- `resolverReturned == false`: resolution did not complete; the default zero count is not evidence of an empty resolver result.
- `resolverReturned == true`, `streamCount == 0`: confirms empty resolver output rather than selector metadata rejection; inspect status/guard reason counts. It still does not by itself distinguish null-token offline, variant filtering, empty preflights, and parse rejection.
- `streamCount > 0`, `selectorPass == false`: the bounded rows isolate missing manifest/matching URI, dimensions, frame rate, or codecs. Preserve facts; do not infer media codecs from source labels.
- `selectorPass == true`: this resolver/selector boundary works for that channel at probe time. A follow-up single-source production acquisition is needed to test segment reading, remux and decode.

Local verification performed: Python AST parse and compile passed. The prepared probe has not been executed against Twitch and makes no claim about current channel availability or media acceptance.
