import { createWriteStream } from 'node:fs';
import { mkdir, stat, writeFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { setTimeout as sleep } from 'node:timers/promises';
import { createProofWorker } from '/app/scripts/event-proof-fixtures.mjs';
import { createProcessOwner, processTable } from '/app/scripts/event-proof-processes.mjs';
import { readCgroupCounters } from '/app/scripts/event-capacity-resources.mjs';
import { createProgramRenderer } from '/app/workers/restream/program-renderer.mjs';
import { createInputSupervisor } from '/app/workers/restream/input-supervisor.mjs';
import { createInputManager } from '/app/workers/restream/input-manager.mjs';
import { createTwitchInput } from '/app/workers/restream/twitch-input.mjs';
import { readTaskMetadata } from '/app/workers/restream/task-metadata.mjs';

// Private diagnostic authority and local recording. No sender or backend writes.
const S3_ROOT = 's3://vrdex-restream-worker-079358094174-artifacts/synthetic-benchmarks';
const begun = performance.now(), wallBegun = Date.now();
const runId = process.env.VRDEX_PROOF_RUN_ID;
const safeRunId = typeof runId === 'string' && /^[A-Za-z0-9_-]{1,96}$/.test(runId);
const directory = `/tmp/event-capacity-${safeRunId ? runId : randomUUID()}`;
const owner = createProcessOwner();
const sourceIds = ['source-0', 'source-1'];
const sources = sourceIds.map(id => ({
  id, acquired: 0, ready: false, everReady: false, readyTransitions: 0,
  losses: 0, dimensions: [], events: [], droppedEvents: 0, decoderChildren: 0,
}));
const kinds = new Set(['acquiring', 'warming', 'transport_ready', 'ad_wait', 'unavailable', 'cancelled', 'buffer']);
const reasons = new Set(['destination_denied', 'dns_denied', 'dns_timeout', 'proxy_denied', 'credentials_denied', 'tls_denied', 'http_timeout', 'response_limit', 'dependency_mismatch', 'unsupported_media', 'provider_unavailable', 'media_timeout', 'preparation_timeout', 'cancelled', 'process_failed']);
const failures = new Set(['invalid_run_id', 'invalid_artifact_root', 'two_public_channels_required', 'metadata_unavailable', 'metadata_invalid', 'work_deadline', 'interrupted', 'dual_startup_timeout', 'worker_stopped', 'renderer_failed', 'output_backpressure', 'recording_limit', 'recording_io_failed', 'command_timeout', 'command_failed', 'rendered_source_mismatch', 'encoded_progress_timeout', 'missing_1080_input', 'program_format_failed', 'cleanup_failed', 'recording_failed', 'receipt_limit', 'upload_failed', 'diagnostic_failed']);
const receipt = {
  schemaVersion: 1, kind: 'private-short-live-diagnostic', qualification: false,
  sourceRevision: '69e5622a92a1dff05be66abdcf7674a71c482ad1',
  runId: safeRunId ? runId : null, publication: false, sourceCount: 2,
  requestedAcquisition: { videoPreset: '1080p60', audioBitrateKbps: 320 },
  programSettings: { videoPreset: '720p30', audioBitrateKbps: 320 },
  limits: { workMs: 180000, captureMs: 150000, cleanupMs: 30000, dualStartupMs: 40000, inputPreparationMs: 15000, recordingBytes: 67108864, receiptBytes: 65536 },
  startedAt: new Date(wallBegun).toISOString(), sources, acknowledgements: [],
  checkpoints: [], samples: [], cgroupIntervals: [],
  resourceScope: 'mounted_cgroup_counters_scope_unverified', cpuUtilizationClaim: false,
  remoteSilenceExercised: false, remoteDeathExercised: false,
  localForcedFailureExercised: false, physicalPlaybackObserved: false,
  passed: false, terminal: false,
};
let phase = 'configuration', fault, interrupted = false, worker, renderer, inputs;
let stream, streamClosed, stoppedOutput = false, bytes = 0, lastOutputAt = -Infinity;
let watchdog, previousCounters, nextSampleAt = 0, lastStateSampleAt = 0;
let commands = [], sequence = 0, metadata, initialPids = new Set(), ownedPids = new Set();
const atMs = () => Math.round(performance.now() - begun);
function fail(code) { const e = new Error(); e.diagnosticCode = code; throw e; }
function recordFailure(code, where = phase) {
  fault ??= { phase: where, reason: failures.has(code) ? code : 'diagnostic_failed' };
}
function signalStop() { interrupted = true; receipt.interrupted = true; receipt.passed = false; recordFailure('interrupted'); void worker?.stop().catch(() => {}); }
process.on('SIGTERM', signalStop);
process.on('SIGINT', signalStop);
// Capture reserves 30s of the 180s work allowance for verification/finalization.
const workTimer = setTimeout(() => { recordFailure('work_deadline'); void worker?.stop().catch(() => {}); }, 150000);
async function bounded(operation, ms, code) {
  let timer;
  try { return await Promise.race([Promise.resolve().then(operation), new Promise((_, reject) => {
    timer = setTimeout(() => { const e = new Error(); e.diagnosticCode = code; reject(e); }, Math.max(1, ms));
  })]); } finally { clearTimeout(timer); }
}
function health() {
  if (fault) fail(fault.reason);
  if (performance.now() - begun >= 150000) fail('work_deadline');
  if (worker?.getState().stopped) fail('worker_stopped');
  if (renderer?.getState().error) fail('renderer_failed');
}
async function census() {
  const rows = await processTable(), descendants = new Set([process.pid]);
  for (let i = 0; i < rows.length; i++) {
    let changed = false;
    for (const row of rows) if (descendants.has(row.parent) && !descendants.has(row.pid)) {
      descendants.add(row.pid); changed = true;
    }
    if (!changed) break;
  }
  const live = rows.filter(row => row.live && row.pid !== process.pid && descendants.has(row.pid) && !initialPids.has(row.pid));
  for (const row of live) ownedPids.add(row.pid);
  return { rows, live };
}
function inputState(id, event) {
  const row = sources.find(source => source.id === id);
  if (!row || !kinds.has(event?.kind)) return;
  if (event.kind === 'buffer') {
    const size = event.compressedBufferUpperBoundBytes;
    if (Number.isSafeInteger(size) && size >= 0) row.maxCompressedBufferBytes = Math.max(row.maxCompressedBufferBytes ?? 0, size);
    return;
  }
  const entry = { atMs: atMs(), kind: event.kind };
  if (event.kind === 'unavailable') entry.reason = reasons.has(event.reason) ? event.reason : 'provider_unavailable';
  if (row.events.length < 32) row.events.push(entry); else row.droppedEvents++;
}
function decoderObservation(event) {
  const row = sources.find(source => source.id === event?.sourceId);
  if (!row || typeof event.ready !== 'boolean') return;
  if (!row.ready && event.ready) row.readyTransitions++;
  if (row.ready && !event.ready) row.losses++;
  row.ready = event.ready; row.everReady ||= event.ready;
}
function observeDimensions(child, id) {
  const row = sources.find(source => source.id === id);
  if (!row || !child.stderr) return;
  row.decoderChildren++;
  let carry = '', scanned = 0, dropping = false;
  const consume = chunk => {
    const count = Math.min(chunk.length, 1048576 - scanned);
    scanned += count;
    for (let index = 0; index < count; index++) {
      const byte = chunk[index];
      if (byte === 10 || byte === 13) {
        if (!dropping && carry.startsWith('[Parsed_showinfo_')) {
          const match = carry.match(/\bs:(\d{1,5})x(\d{1,5})(?:\s|$)/);
          if (match) {
            const width = Number(match[1]), height = Number(match[2]);
            if (width > 0 && height > 0 && !row.dimensions.some(value => value.width === width && value.height === height) && row.dimensions.length < 8)
              row.dimensions.push({ width, height, atMs: atMs() });
          }
        }
        carry = ''; dropping = false;
      } else if (!dropping) {
        if (carry.length === 4096) { carry = ''; dropping = true; }
        else carry += String.fromCharCode(byte);
      }
    }
    if (scanned >= 1048576) { carry = ''; child.stderr.removeListener('data', consume); }
  };
  // Additional listener only. Production timing parsing keeps every stderr byte.
  child.stderr.on('data', consume);
  child.once('close', () => { carry = ''; child.stderr.removeListener('data', consume); });
}
async function sample() {
  const now = performance.now();
  if (now >= nextSampleAt) {
    nextSampleAt = now + 1000;
    try {
      const next = await readCgroupCounters();
      if (previousCounters && receipt.cgroupIntervals.length < 180) {
        const elapsedMs = next.at - previousCounters.at, cpuDeltaNs = next.cpuNs - previousCounters.cpuNs;
        if (elapsedMs > 0 && cpuDeltaNs >= 0 && Number.isFinite(cpuDeltaNs) && Number.isFinite(next.memoryBytes))
          receipt.cgroupIntervals.push({ atMs: atMs(), elapsedMs: Math.round(elapsedMs), cpuDeltaNs, memoryBytes: next.memoryBytes });
      }
      previousCounters = next;
    } catch { receipt.cgroupCountersUnavailable = true; }
    await census();
  }
  if (now >= lastStateSampleAt + 1000 && receipt.samples.length < 180) {
    lastStateSampleAt = now;
    const state = renderer.getState();
    const workerState = worker.getState();
    receipt.samples.push({ atMs: atMs(), readyCount: renderer.getInputs().filter(input => input.getObservation().ready).length,
      renderedSourceId: sourceIds.includes(state.renderedSourceId) ? state.renderedSourceId : null,
      mode: ['automatic', 'manual', 'hold', 'slate'].includes(workerState.mode) ? workerState.mode : 'unknown',
      outputMs: state.outputMs, outputBytes: bytes, stopped: workerState.stopped });
  }
}
async function step() { health(); await worker.tick(); health(); await sample(); await sleep(100); health(); }
async function until(predicate, ms, code) {
  const deadline = Math.min(performance.now() + ms, begun + 150000);
  while (!predicate()) { if (performance.now() >= deadline) fail(code); await step(); }
  health();
}
async function checkpoint(label, expectedSourceId, baselineMs) {
  await until(() => renderer.getState().renderedSourceId === (expectedSourceId ?? undefined) && renderer.getState().outputMs >= baselineMs + 1000, 12000, 'encoded_progress_timeout');
  const state = renderer.getState();
  receipt.checkpoints.push({ label, atMs: atMs(), renderedSourceId: state.renderedSourceId ?? null,
    outputMs: state.outputMs, baselineMs, outputBytes: bytes, progressingAfterAcknowledgement: state.outputMs >= baselineMs + 1000 });
}
async function command(commandType, targetSourceId, expectedSourceId) {
  const issuedAt = atMs(), thisSequence = ++sequence;
  commands = [{ _id: `command-${thisSequence}`, sequence: thisSequence, commandType, ...(targetSourceId ? { targetSourceId } : {}) }];
  await until(() => receipt.acknowledgements.some(ack => ack.sequence === thisSequence), 22000, 'command_timeout');
  const ack = receipt.acknowledgements.find(value => value.sequence === thisSequence);
  ack.issuedAtMs = issuedAt;
  if (ack.outcome !== 'succeeded') fail('command_failed');
  if (ack.observedSourceId !== expectedSourceId || renderer.getState().renderedSourceId !== (expectedSourceId ?? undefined)) fail('rendered_source_mismatch');
  await checkpoint(commandType === 'cut_to_slate' ? 'cut-slate' : `take-${targetSourceId}`, expectedSourceId, Math.max(ack.outputMs ?? 0, renderer.getState().outputMs));
}
async function cleanup() {
  phase = 'cleanup';
  const cleanupBegan = performance.now();
  clearInterval(watchdog);
  stoppedOutput = true;
  const deadline = performance.now() + 30000;
  let stopped = true, ownerResult;
  try { await bounded(() => Promise.all([worker?.stop(), renderer?.stop(), inputs?.stop()]), 12000, 'cleanup_failed'); }
  catch { stopped = false; }
  try { ownerResult = await bounded(() => owner.close(), Math.min(7500, deadline - performance.now()), 'cleanup_failed'); }
  catch { ownerResult = { closed: false }; stopped = false; }
  if (stream) {
    stream.end();
    try { await bounded(() => streamClosed, Math.min(2000, deadline - performance.now()), 'recording_failed'); }
    catch { stream.destroy(); stopped = false; }
  }
  let censusResult;
  try {
    censusResult = await census();
    const leaked = censusResult.rows.filter(row => row.live && ownedPids.has(row.pid));
    if (leaked.length || censusResult.live.length) {
      stopped = false;
      // Renderer owns its non-detached encoder; only known descendant PIDs are eligible for emergency cleanup.
      for (const row of [...leaked, ...censusResult.live]) { try { process.kill(row.pid, 'SIGKILL'); } catch {} }
      await sleep(100);
      censusResult = await census();
    }
  } catch { stopped = false; }
  const liveOwned = censusResult?.rows.filter(row => row.live && ownedPids.has(row.pid)).length;
  receipt.cleanup = { ...ownerResult, rendererAndInputsStopped: stopped,
    liveOwnedDescendants: liveOwned ?? null, observedDescendantCount: ownedPids.size,
    closed: stopped && ownerResult?.closed === true && ownerResult?.liveGroups === 0 && liveOwned === 0 && censusResult?.live.length === 0 };
  if (!receipt.cleanup.closed) recordFailure('cleanup_failed', 'cleanup');
  receipt.cleanupElapsedMs = Math.round(performance.now() - cleanupBegan);
}

try {
  await mkdir(directory, { mode: 0o700, recursive: false });
  if (!safeRunId) fail('invalid_run_id');
  if (process.env.VRDEX_RESTREAM_ARTIFACT_S3_URI !== S3_ROOT) fail('invalid_artifact_root');
  let channels;
  try { channels = JSON.parse(process.env.VRDEX_PROOF_PUBLIC_CHANNELS_JSON ?? 'null'); } catch { fail('two_public_channels_required'); }
  if (!Array.isArray(channels) || channels.length !== 2 || new Set(channels).size !== 2 || channels.some(value => typeof value !== 'string' || !/^[a-z0-9_]{3,25}$/.test(value))) fail('two_public_channels_required');
  phase = 'metadata';
  try { metadata = await readTaskMetadata(); } catch { fail('metadata_unavailable'); }
  const cpuUnits = metadata.task.Limits?.CPU * 1024, memoryMiB = metadata.task.Limits?.Memory;
  if (!Number.isFinite(cpuUnits) || cpuUnits <= 0 || !Number.isFinite(memoryMiB) || memoryMiB <= 0 ||
    !/^arn:aws:ecs:[a-z0-9-]+:\d{12}:task\/[A-Za-z0-9_/-]+$/.test(metadata.task.TaskARN ?? '') ||
    !/^sha256:[a-f0-9]{64}$/.test(metadata.container.ImageID ?? '')) fail('metadata_invalid');
  receipt.metadata = { taskArn: metadata.task.TaskARN, imageId: metadata.container.ImageID, cpuUnits, memoryMiB };
  initialPids = new Set((await processTable()).map(row => row.pid));
  phase = 'startup';
  stream = createWriteStream(`${directory}/program.ts`, { flags: 'wx', mode: 0o600, highWaterMark: 1048576 });
  streamClosed = new Promise(resolve => stream.once('close', resolve));
  stream.on('error', () => { recordFailure('recording_io_failed'); void worker?.stop().catch(() => {}); });
  renderer = createProgramRenderer({ quality: '720p30', audioBitrateKbps: 320,
    onError: () => { recordFailure('renderer_failed'); void worker?.stop().catch(() => {}); },
    onObservation: decoderObservation,
    createInput: args => createInputSupervisor({ ...args, spawnProcess: (commandName, argsList, options) => {
      const child = owner.start(commandName, argsList, options); observeDimensions(child, args.source.sourceId); return child;
    } }),
  });
  inputs = createInputManager({
    createVrcdnInput: () => fail('diagnostic_failed'),
    createTwitchInput: args => {
      sources.find(value => value.id === args.source.id).acquired++;
      return createTwitchInput({ ...args, source: args.source.input,
        settings: { ...args.settings, videoPreset: '1080p60' }, spawnProcess: owner.start,
        onState: event => { inputState(args.source.id, event); args.onState(event); } });
    },
  });
  const configuration = {
    mediaSettings: receipt.programSettings, outputId: 'private-recording', outputs: [{ id: 'private-recording' }],
    sessionDeadline: wallBegun + 150000, mode: 'automatic', policy: {},
    sources: channels.map((channel, index) => ({ id: sourceIds[index], type: 'twitch_watch',
      input: { kind: 'twitch', channel }, publicUrl: `https://www.twitch.tv/${channel}` })),
    slots: [{ slotKey: 'a', sourceId: 'source-0', startAt: wallBegun - 1000, endAt: wallBegun + 60000, available: true },
      { slotKey: 'b', sourceId: 'source-1', startAt: wallBegun + 60000, endAt: wallBegun + 180000, available: true }],
  };
  const outputs = { start: async () => {}, stopNow: () => { stoppedOutput = true; }, stop: async () => {},
    enqueue(chunk) {
      if (stoppedOutput) return;
      if (bytes + chunk.length > 67108864) { recordFailure('recording_limit'); stoppedOutput = true; void worker.stop().catch(() => {}); return; }
      bytes += chunk.length; lastOutputAt = performance.now();
      if (!stream.write(chunk)) { recordFailure('output_backpressure'); stoppedOutput = true; void worker.stop().catch(() => {}); }
    }, getState: () => ({ publishing: !stoppedOutput && bytes > 0 && performance.now() - lastOutputAt < 2000 }) };
  worker = createProofWorker({ identity: { eventId: 'private-short-live', sessionId: runId, workerId: runId, epoch: 0 },
    renderer, inputs, outputs, checkEnabled: async () => true,
    control: async (name, args) => {
      if (name === 'acquireSession' || name === 'renewSession') return { granted: true, epoch: 1, serverNow: Date.now(), expiresAt: Math.min(Date.now() + 30000, configuration.sessionDeadline), renewAfterMs: 10000, configuration };
      if (name === 'refreshConfiguration') return { granted: true, serverNow: Date.now(), configuration };
      if (name === 'claimCommands') return { granted: true, commands };
      if (name === 'acknowledgeCommand') {
        if (receipt.acknowledgements.length < 8) receipt.acknowledgements.push({ atMs: atMs(), sequence: args.sequence,
          outcome: ['succeeded', 'failed', 'superseded'].includes(args.outcome) ? args.outcome : 'unknown',
          observedSourceId: sourceIds.includes(args.observedSourceId) ? args.observedSourceId : null,
          outputMs: Number.isFinite(args.outputMs) ? args.outputMs : null,
          failureReason: reasons.has(args.failureReason) ? args.failureReason : (args.failureReason ? 'command_failed' : null) });
        commands = commands.filter(commandRow => commandRow._id !== args.commandId);
      }
      return { accepted: true };
    },
  });
  const startupAt = performance.now();
  await worker.start();
  watchdog = setInterval(() => worker.watchdog(), 50);
  await until(() => renderer.getInputs().length === 2 && renderer.getInputs().every(input => input.getObservation().ready) && renderer.getState().renderedSourceId === 'source-0', Math.max(1, 40000 - (performance.now() - startupAt)), 'dual_startup_timeout');
  receipt.dualReadyAtMs = atMs();
  await checkpoint('initial-source-0', 'source-0', renderer.getState().outputMs);
  phase = 'take_source_1'; await command('switch_source', 'source-1', 'source-1');
  phase = 'immediate_cut'; await command('cut_to_slate', undefined, null);
  phase = 'take_source_0'; await command('switch_source', 'source-0', 'source-0');
  receipt.downscaleObserved = sources.every(row => row.dimensions.some(value => value.width === 1920 && value.height === 1080));
  if (!receipt.downscaleObserved) recordFailure('missing_1080_input', 'dimensions');
  receipt.commandSequenceComplete = receipt.acknowledgements.length === 3 && receipt.checkpoints.length === 4;
} catch (error) { recordFailure(error?.diagnosticCode ?? 'diagnostic_failed'); }
finally {
  clearTimeout(workTimer);
  receipt.captureElapsedMs = atMs();
  await cleanup();
}

// Probe the closed private recording. Raw ffprobe stderr is drained and discarded.
phase = 'verify';
const verifier = createProcessOwner();
try {
  if (bytes > 0) {
    const raw = await verifier.run('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_type,codec_name,width,height,r_frame_rate,sample_rate,channels:format=duration', '-of', 'json', `${directory}/program.ts`], { timeoutMs: 8000, maxBytes: 32768 });
    const facts = JSON.parse(raw.toString()), video = facts.streams.find(row => row.codec_type === 'video'), audio = facts.streams.find(row => row.codec_type === 'audio');
    receipt.format = { videoCodecH264: video?.codec_name === 'h264', width: video?.width ?? null, height: video?.height ?? null,
      fps: video?.r_frame_rate === '30/1' ? 30 : null, audioCodecAAC: audio?.codec_name === 'aac', sampleRate: Number(audio?.sample_rate) || null,
      channels: audio?.channels ?? null, durationSeconds: Number(facts.format?.duration) || null };
    if (!receipt.format.videoCodecH264 || receipt.format.width !== 1280 || receipt.format.height !== 720 || receipt.format.fps !== 30 || !receipt.format.audioCodecAAC || receipt.format.sampleRate !== 48000 || receipt.format.channels !== 2) recordFailure('program_format_failed');
    const recordingStat = await stat(`${directory}/program.ts`);
    receipt.recording = { name: 'program.ts', bytes: recordingStat.size, complete: recordingStat.size === bytes && !['recording_limit', 'output_backpressure', 'recording_io_failed', 'recording_failed'].includes(fault?.reason) };
    if (recordingStat.size !== bytes || recordingStat.size > 67108864) recordFailure('recording_failed');
  } else if (!fault) recordFailure('recording_failed');
} catch { recordFailure('program_format_failed'); }
finally {
  try { receipt.verificationCleanup = await verifier.close(); }
  catch { receipt.verificationCleanup = { closed: false }; recordFailure('cleanup_failed', 'verify'); }
}
receipt.interrupted = interrupted;
receipt.passed = !fault && receipt.downscaleObserved === true && receipt.commandSequenceComplete === true && receipt.cleanup.closed === true && receipt.verificationCleanup.closed === true;
receipt.terminal = true;
receipt.failure = fault ?? null;
receipt.elapsedMs = atMs();
receipt.finishedAt = new Date().toISOString();
receipt.workElapsedMs = receipt.captureElapsedMs + Math.max(0, receipt.elapsedMs - receipt.captureElapsedMs - (receipt.cleanupElapsedMs ?? 0));
const receiptPath = `${directory}/receipt.json`;
async function serializeReceipt() {
  const json = JSON.stringify(receipt) + '\n';
  if (Buffer.byteLength(json) > 65536) fail('receipt_limit');
  await writeFile(receiptPath, json, { mode: 0o600 });
  return json;
}
let json;
try {
  json = await serializeReceipt();
  if (safeRunId && process.env.VRDEX_RESTREAM_ARTIFACT_S3_URI === S3_ROOT) {
    const uploader = createProcessOwner();
    try {
      // Upload only to the fixed private root, never to a caller-controlled URL.
      if (receipt.recording?.bytes > 0 && receipt.recording.bytes <= 67108864) {
        try { await uploader.run('aws', ['s3', 'cp', `${directory}/program.ts`, `${S3_ROOT}/${runId}/program.ts`, '--sse', 'AES256', '--only-show-errors', '--cli-connect-timeout', '3', '--cli-read-timeout', '6'], { timeoutMs: 10000, maxBytes: 4096, env: { ...process.env, AWS_MAX_ATTEMPTS: '1', AWS_EC2_METADATA_DISABLED: 'true' } }); }
        catch { receipt.passed = false; receipt.failure ??= { phase: 'upload_recording', reason: 'upload_failed' }; json = await serializeReceipt(); }
      }
      await uploader.run('aws', ['s3', 'cp', receiptPath, `${S3_ROOT}/${runId}/receipt.json`, '--sse', 'AES256', '--only-show-errors', '--cli-connect-timeout', '3', '--cli-read-timeout', '6'], { timeoutMs: 10000, maxBytes: 4096, env: { ...process.env, AWS_MAX_ATTEMPTS: '1', AWS_EC2_METADATA_DISABLED: 'true' } });
    } finally { const closed = await uploader.close(); if (!closed.closed || closed.liveGroups !== 0) fail('cleanup_failed'); }
  }
} catch (error) {
  receipt.passed = false;
  receipt.failure ??= { phase: 'upload', reason: failures.has(error?.diagnosticCode) ? error.diagnosticCode : 'upload_failed' };
  try { json = await serializeReceipt(); } catch { json = JSON.stringify({ kind: receipt.kind, runId: receipt.runId, passed: false, terminal: true, failure: { phase: 'receipt', reason: 'receipt_limit' }, cleanup: receipt.cleanup }) + '\n'; }
}
if (interrupted) {
  receipt.passed = false; receipt.failure ??= { phase: 'finalize', reason: 'interrupted' };
  try { json = await serializeReceipt(); } catch {}
}
process.stdout.write(json);
process.exitCode = receipt.passed ? 0 : 1;
process.removeListener('SIGTERM', signalStop);
process.removeListener('SIGINT', signalStop);
