# Short live controller handoff

Status: implemented and ready for independent review. Source is frozen for Root's review at `/workspace/scratch/current-image-validation/short-live.mjs`. This agent made no provider calls, branch edits, or subagent calls. The VRDex checkout remained clean. Root owns the actual-image launch and live result.

The standalone ESM file imports the current actual `/app` proof worker, production renderer, input supervisor, Twitch input, input manager, existing process owner, cgroup reader, and ECS metadata reader. These module paths are present in the current packaging manifest. It does not copy historical image code or modify production behavior. The source revision is the Root-supplied `69e5622a92a1dff05be66abdcf7674a71c482ad1`; Root must bind the launch to its actual immutable current image.

## Launch contract

Run the exact file contents as inline ESM in the current image, with workdir `/app`. Root can use a task-definition command equivalent to `timeout --signal=TERM --kill-after=10s 240s node --input-type=module -e <literal file contents>`. A task-definition command can carry the source; an ECS command override has the smaller override-size limit. The controller imports absolute `/app` paths, so it does not depend on an uploaded script path.

Required environment:

```text
VRDEX_PROOF_RUN_ID=<new unique ASCII alphanumeric, underscore, or hyphen ID, 1..96 characters>
VRDEX_RESTREAM_ARTIFACT_S3_URI=s3://vrdex-restream-worker-079358094174-artifacts/synthetic-benchmarks
VRDEX_PROOF_PUBLIC_CHANNELS_JSON=["monstercat","insomniac"]
AWS_REGION=us-east-1
```

The two channel names above are Root-selected public candidates. This agent did not check whether either is live, has a 1080 rendition, or belongs to the user. The controller has no channel default and rejects missing, malformed, duplicate, or noncanonical names. No output sender, output credential, backend token, or publication attestation is needed. Keep ECS `secrets` empty for this diagnostic. The existing task role supplies private evidence-upload access.

The run creates one unique private directory `/tmp/event-capacity-<run-id>` with `program.ts` and `receipt.json`. Existing directories cause failure rather than overwrite. Upload destinations are fixed beneath the approved S3 root at `<run-id>/receipt.json` and optional `<run-id>/program.ts`. Uploads request AES256 and use bounded CLI connection/read/process times with retries disabled. Raw provider stderr is drained and never written to a file, receipt, or stdout.

## What the controller checks

Both actual Twitch acquisitions request `1080p60`, independently of production `720p30` rendering and AAC320 output. An additional observer reads each production decoder's existing pre-scale `showinfo` stderr, retaining only numeric dimensions. It has a 4096-character carry and 1MiB scan ceiling per decoder child. Production timing listeners still receive the original bytes. Both sources must actually report 1920x1080. Requested or selected rendition names never count as observed dimensions. Actual input frame rate is not asserted.

The actual proof control sequence is initial source 0, `switch_source` to source 1, `cut_to_slate`, then `switch_source` to source 0. Each command must acknowledge success with the expected encoded source identity, and a checkpoint requires the actual renderer identity plus at least 1000ms of further encoded output advancement after acknowledgement. The cut uses the production immediate-slate command. Its issue and acknowledgement times are retained; this diagnostic does not set a new production latency policy.

The receipt retains bounded allowlisted acquisition states/reasons, source readiness transitions, dimensions, acknowledgements, actual rendered identities, worker mode, output milliseconds/bytes, ECS task ARN, image ID, CPU/memory allocation, and numeric cgroup counter intervals where readable. Cgroup scope is explicitly unverified and no CPU utilization or capacity claim is made.

The private recording is capped at 64MiB before writes. Any recording backpressure fails the run. Final ffprobe checks H264 1280x720 at 30fps and AAC 48000Hz stereo. AAC320 is the requested production encoder setting, not a newly measured bitrate assertion. The program records the real renderer output, with no synthetic fallback in the launchable file.

Capture is capped at 150 seconds, reserving time inside the 180-second work ceiling for verification. Dual decoded startup is capped at 40 seconds. The underlying production 15-second input preparation deadline is unchanged. Cleanup has a separate 30-second bound. The 240-second outer command gives delivery and termination room. Root still needs its independent external ECS deadline.

Cleanup awaits worker, renderer, and input-manager stops, closes the existing process owner, and checks zero live owner process groups. The renderer's encoder is not injectable through the current API, so the controller follows Root's explicit instruction to use renderer-owned stop plus an independent `/proc` descendant census. It checks known owned PIDs and current descendants for leaks. Only known descendant PIDs are eligible for emergency SIGKILL. Cleanup failure always yields `passed:false`, including when emergency cleanup later removes a leak. A separate owned ffprobe process is closed before receipt delivery.

The receipt is plain JSON capped at 64KiB, written privately and emitted once to stdout. Root should require both task exit 0 and `passed:true`, plus the receipt's cleanup facts. No `uploadComplete` field is invented. Delivery failure makes stdout/local evidence negative and the task exits 1. If final CLI-owner cleanup fails after a successful S3 receipt upload, task/stdout evidence takes precedence over the earlier S3 object.

## Local verification completed

- `node --check /workspace/scratch/current-image-validation/short-live.mjs` passed. The final syntax check covers the frozen source.
- A local full lifecycle integration used `node --input-type=module` with the controller loaded in memory. For that test only, `/app` import prefixes resolved to current checkout module files, Twitch acquisition returned a generated local 45-second 1920x1080 60fps H264/AAC fixture, ECS metadata returned explicitly fake local values, and uploads were disabled. The real current proof worker, input manager, supervisor, renderer, encoder, recording, command acknowledgements, ffprobe, and process cleanup ran. It exited 0 with both numeric 1920x1080 observations, all three successful acknowledgements, all four progressing encoded checkpoints, correct 720p30/AAC48k stereo output, a 1,428,236-byte recording, and zero live descendants/process groups. Capture took 5651ms and elapsed time before delivery was 9716ms.
- The same local lifecycle with a 1280x720 30fps fixture exited 1 with `passed:false` and fixed reason `missing_1080_input`, despite all commands and format checks completing. It recorded both actual 1280x720 observations and zero live descendants/process groups. Capture took 5658ms and elapsed time before delivery was 9732ms.
- A local negative configuration execution with no artifact root exited 1 with `passed:false`, fixed reason `invalid_artifact_root`, zero acquisitions, and clean cleanup. It made no metadata, media, CLI-upload, or provider calls.
- `git -C /workspace/VRDex status --short` returned no changes.

The final two small edits add allowlisted worker mode to samples and make recording completeness independent of a missing-1080 diagnostic failure. They passed syntax validation. The prior lifecycle runs validate the same media/control logic, and were not repeated for those receipt-only edits.

Local generated fixtures and receipts stay under `/tmp/short-live-local-*` and `/tmp/event-capacity-short-local-*`. They are explicitly synthetic local test evidence. They are not live Twitch, actual-image, Fargate allocation, or upload evidence.

## Remaining limits

No actual-image execution, Twitch availability/1080 success, AWS CLI upload, S3 readback, hosted admission, production capacity qualification, sustained soak, destination playback, or physical VRChat acceptance was established here. Missing/offline public channels produce a bounded negative; they never trigger a replacement source. Manual take/cut operations establish no broadcaster-silence or death behavior. Those fields remain false, as does local forced failure coverage. Root must retain the actual ECS launch, exact image digest, task exit, stdout receipt, and private S3 readback for the real run.
