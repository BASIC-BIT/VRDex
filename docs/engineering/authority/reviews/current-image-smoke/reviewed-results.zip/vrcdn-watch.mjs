import {createProcessOwner} from './scripts/event-proof-processes.mjs';
import {setTimeout as sleep} from 'node:timers/promises';
const owner=createProcessOwner(),began=Date.now();
const receipt={kind:'owned-vrcdn-playback-smoke',passed:false,publicationSource:'unverified',sourceIdentityVerified:false,accounts:{},cleanup:false};
try{
 await sleep(12000);
 const account=process.env.VRDEX_DIAGNOSTIC_ACCOUNT;if(!['basicbit1','basicbit'].includes(account))throw Error('Invalid diagnostic account');
 for(const account of [process.env.VRDEX_DIAGNOSTIC_ACCOUNT]){
  const row={passed:false,attempts:[]};receipt.accounts[account]=row;
  for(let i=0;i<2;i++){
   try{
    const data=await owner.run('ffprobe',['-v','error','-rw_timeout','5000000','-analyzeduration','3000000','-probesize','2000000','-show_entries','stream=codec_name,width,height,r_frame_rate,sample_rate,channels','-of','json','https://stream.vrcdn.live/live/'+account+'.live.ts'],{timeoutMs:12000,maxBytes:16384});
    const streams=JSON.parse(data.toString()).streams;const v=streams.find(x=>x.codec_name==='h264'),a=streams.find(x=>x.codec_name==='aac');
    const facts={received:true,width:v?.width,height:v?.height,rate:v?.r_frame_rate,audioRate:Number(a?.sample_rate),channels:a?.channels};facts.passed=facts.width===1280&&facts.height===720&&facts.rate==='30/1'&&facts.audioRate===48000&&facts.channels===2;row.attempts.push(facts);row.passed||=facts.passed;
   }catch{row.attempts.push({received:false,passed:false});}
   if(row.passed)break;await sleep(2000);
  }
 }
 receipt.passed=Object.values(receipt.accounts).every(x=>x.passed);
}finally{await sleep(Math.max(0,130000-(Date.now()-began)));try{receipt.cleanup=(await owner.close()).closed;}catch{receipt.cleanup=false;}receipt.passed&&=receipt.cleanup;console.log(JSON.stringify(receipt));process.exitCode=receipt.passed?0:1;}
