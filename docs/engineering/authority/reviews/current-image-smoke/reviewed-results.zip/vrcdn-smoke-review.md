# VRCDN smoke review

SPEC: PASS for the revised credential and public playback codec smoke, subject to the stated task configuration and root acceptance checks below.

QUALITY: PASS WITH LIMITATION. No blocking correctness, process cleanup, or secret logging issue remains in the reviewed scripts for that narrow scope. The playback retry window can produce a false negative when ingest becomes ready late.

This was a static review only. No tests, publication, cloud calls, or source edits were performed. This report is the only file written by the reviewer. The actual runtime image and final ECS task definition were not inspected.

## Reviewed scope

- `vrcdn-smoke-wrapper.mjs`, final lines 1-14.
- `vrcdn-watch.mjs`, final lines 1-20.
- `/workspace/VRDex/workers/restream/vrcdn-poc.mjs` and `/workspace/VRDex/scripts/event-proof-processes.mjs`. Their scratch checkout copies have matching SHA-256 hashes.
- `workers/restream/live-control.mjs` was read to trace the POC's ZeroMQ endpoint and child processes.

The root's concrete operating constraints are part of this verdict. Each owned account runs in a separate Fargate task and therefore a separate awsvpc network namespace. Each task contains one nonessential publisher and one essential watcher for only that account. The existing image and POC are reused with synthetic `single-output-smoke`, 60 seconds, 720p30, and ECS secret injection. The publisher wrapper has a 120 second bound, the watcher remains alive for at least 130 seconds, and the outer container bound is 240 seconds. The task allocation is 4 vCPU and 8 GiB. The root has an eight minute deadline and requires both container exit results and both passing cleanup receipts, followed by ECS STOPPED, ENI absence, and task definition deregistration.

These task properties were supplied by the root, rather than independently observed in ECS. In particular, the final task definition must establish the image identity, mode, duration, quality profile, account-to-secret mapping, container roles, and timeout commands. The wrapper does not enforce those environment values itself.

## Resolved blockers

1. Both POCs use the FFmpeg default ZeroMQ bind on port 5555 and controllers connect to localhost port 5555. Two publishers in the same awsvpc task would collide. The revised separate-task layout removes that collision without changing the POC. Evidence: `vrcdn-poc.mjs:16`, `:294`, `:793`; `live-control.mjs:38`.
2. The original essential watcher exited around 80 seconds, ahead of the publisher's 120 second bound. The final watcher waits until 130 seconds before cleanup, leaving the publisher time to emit its receipt. Evidence: `vrcdn-watch.mjs:20`.
3. The final wrapper requires `!rejected`, finite output progress of at least 58 seconds, an integer command count of at least two, a clean child exit, no timeout, and process group cleanup. The original predicate omitted the rejection and numeric checks. Evidence: `vrcdn-smoke-wrapper.mjs:12-14`.
4. The final watcher explicitly reports `publicationSource: 'unverified'` and `sourceIdentityVerified: false`. It allowlists the selected account and probes only that account's public TS URL. Evidence: `vrcdn-watch.mjs:4`, `:7-14`.

## Remaining limitation

The watcher starts after 12 seconds and makes only two attempts, each bounded at 12 seconds, with two second waits. It stops probing by roughly 40 seconds even though it stays alive until 130 seconds. A valid publication that becomes ready after that probe window can fail the playback smoke while the publisher later completes successfully. The POC itself permits a startup window of up to 60 seconds by default. Treat this result as a bounded early observation, and report a missed playback observation as a smoke failure or inconclusive outcome. A passing playback receipt remains useful within the declared narrow scope. Evidence: `vrcdn-watch.mjs:6`, `:10-17`; `vrcdn-poc.mjs:14`, `:779-789`.

## Cleanup and receipt assessment

`createProcessOwner` starts the POC in a detached process group. FFmpeg and the Python ZeroMQ sender inherit that group. Cleanup sends TERM and then KILL to the group, checks `/proc` for live group members, and requires child close receipts. Probe subprocess output and runtime have explicit bounds. The wrapper's timeout also invokes this cleanup. Evidence: `event-proof-processes.mjs:25-60`, `:70-104`; `vrcdn-smoke-wrapper.mjs:10-14`.

External SIGTERM or a hard outer timeout can bypass JavaScript `finally` and omit a receipt. The root's requirement to reject missing receipts and independently verify terminal ECS cleanup covers that failure path. An essential watcher exit code alone is insufficient because the publisher is nonessential. The revised requirement to check both containers and both receipts is necessary.

## Secret logging assessment

The publisher child stdout and stderr are piped into the wrapper rather than inherited by the container log stream. The wrapper emits a small receipt and never forwards raw child text or caught exceptions. Its stdout buffer and rejection scan are bounded. The final watcher receives a hardcoded public URL assembled from an allowlisted account, discards probe stderr, and emits selected stream facts. No direct path from an injected ingest secret to these scripts' container stdout or stderr was found.

The POC's own redaction is not a general secret sanitizer, so the wrapper must remain the actual publisher entrypoint and raw child output must stay captured. The reviewed logging conclusion does not cover shell tracing, an alternate entrypoint, dumping environment variables, or external task configuration.

## Interpretation of results

A passing publisher receipt supports successful bounded execution of the configured POC. A passing watcher receipt supports receipt of H.264 stream headers reporting 1280x720 at 30/1 and AAC at 48 kHz stereo from the selected public URL. It does not prove decoded frame cadence, this run's content identity or freshness, the hold/source visual sequence, long duration stability, or overall live qualification. The final explicit unverified source fields correctly preserve that limit.
