"""Offline packet renderer and externally trusted NO_SOURCE bootstrap authority."""
import argparse, base64, binascii, hashlib, inspect, io, json, os, pathlib, re, selectors, stat, subprocess, sys, time, urllib.parse, urllib.request, zipfile
FILES=('diagnostic.py','probe.py','support/encode.py','support/preflight.py','pins.json','manifest.json')
class Failure(ValueError):pass

def need(ok,why):
    if not ok:raise Failure(why)
def sha(b):return hashlib.sha256(b).hexdigest()
def wire(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
def unique(pairs):
    out={}
    for k,v in pairs:
        need(k not in out,'duplicate_json_key');out[k]=v
    return out

def canonical_base64(s,cap,on_decoded=None):
    need(isinstance(s,str) and s.isascii() and len(s)<=4*((cap+2)//3),'carrier_bound')
    try:b=base64.b64decode(s,validate=True)
    except (ValueError,binascii.Error):raise Failure('base64_invalid') from None
    if on_decoded:on_decoded(len(b))
    need(len(b)<=cap and base64.b64encode(b).decode('ascii')==s,'base64_noncanonical');return b

def envelope(z):
    need(len(z)<=2097152,'source_zip_cap')
    return wire({'schema':'codec-diagnostic-code-envelope-v1','zipBytes':len(z),'zipSHA256':sha(z),'zipBase64':base64.b64encode(z).decode('ascii')})
def identities(e,z,m):return {n:{'bytes':len(b),'sha256':sha(b)} for n,b in [('envelope',e),('zip',z),('manifest',m)]}
def identity(b,pin):need(len(b)==pin['bytes'] and sha(b)==pin['sha256'],'external_identity')

def verify(e,pins):
    need(isinstance(e,bytes) and len(e)<=3145728,'envelope_bound');identity(e,pins['envelope'])
    try:o=json.loads(e.decode('ascii'),object_pairs_hook=unique)
    except (UnicodeError,json.JSONDecodeError):raise Failure('envelope_json') from None
    need(set(o)=={'schema','zipBytes','zipSHA256','zipBase64'} and wire(o)==e,'envelope_canonical')
    need(o['schema']=='codec-diagnostic-code-envelope-v1' and type(o['zipBytes']) is int and o['zipBytes']==pins['zip']['bytes'] and o['zipSHA256']==pins['zip']['sha256'],'envelope_claims')
    need(len(o['zipBase64'])==4*((o['zipBytes']+2)//3),'base64_length')
    z=canonical_base64(o['zipBase64'],2097152);identity(z,pins['zip'])
    result={}
    try:
        with zipfile.ZipFile(io.BytesIO(z)) as archive:
            infos=archive.infolist();need(len(infos)==6 and {i.filename for i in infos}==set(FILES),'source_tree')
            need(sum(i.file_size for i in infos)<=2097152,'source_expansion')
            for i in infos:
                need(not i.is_dir() and not i.flag_bits&1 and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) and i.compress_type in (0,8),'source_member_type')
                with archive.open(i) as inp:b=inp.read(i.file_size+1);need(len(b)==i.file_size and inp.read(1)==b'','source_eof')
                result[i.filename]=b
    except (zipfile.BadZipFile,EOFError,RuntimeError):raise Failure('source_zip_invalid') from None
    identity(result['manifest.json'],pins['manifest'])
    try:manifest=json.loads(result['manifest.json'].decode('ascii'),object_pairs_hook=unique)
    except (UnicodeError,json.JSONDecodeError):raise Failure('manifest_json') from None
    need(set(manifest)==set(FILES)-{'manifest.json'} and wire(manifest)==result['manifest.json'],'manifest_tree')
    for name,pin in manifest.items():
        need(set(pin)=={'bytes','sha256'} and type(pin['bytes']) is int and re.fullmatch('[0-9a-f]{64}',pin['sha256']),'manifest_pin');identity(result[name],pin)
    return result

def decode_response(response,binary_cap,ledger,*,response_bytes=None):
    """Explicit binary-output GetObject contract: canonical base64 Body."""
    need(isinstance(response,dict) and type(response.get('ContentLength')) is int,'response_schema')
    body=response.get('Body');need(isinstance(body,str) and body.isascii(),'response_body')
    carrier=len(body);carrier_cap=4*((binary_cap+2)//3)
    need(carrier<=carrier_cap,'response_carrier_cap')
    # Count an actual serialized response if caller retained it; else count this exact representation.
    encoded=wire(response);actual=len(encoded) if response_bytes is None else response_bytes
    need(type(actual) is int and actual>=carrier and actual<=carrier_cap+65536,'response_bound')
    declared=response['ContentLength'];need(0<=declared<=binary_cap,'response_content_length')
    ledger.charge('getobject-carrier-metadata',actual)
    b=canonical_base64(body,binary_cap,lambda n:ledger.charge('getobject-decoded-binary',n));need(len(b)==declared,'response_length')
    need(not response.get('ContentRange'),'response_not_complete');return b

def verify_source_response(response,pins,ledger,*,response_bytes=None):
    # Actual textual GetObject contract is literal ASCII; never sniff or fall back.
    cap=3145728
    need(isinstance(response,dict) and type(response.get('ContentLength')) is int,'source_response_schema')
    body=response.get('Body');need(isinstance(body,str) and body.isascii(),'source_response_body')
    need(len(body)<=cap and 0<=response['ContentLength']<=cap,'source_response_body_cap')
    need('ContentRange' not in response,'source_response_not_complete')
    actual=len(wire(response)) if response_bytes is None else response_bytes
    need(type(actual) is int and len(body)<=actual<=len(body)+65536 and actual<=cap+65536,'source_response_bound')
    ledger.charge('source-getobject-carrier-metadata',actual)
    ledger.charge('source-getobject-ascii-copy',len(body))
    data=body.encode('ascii');need(len(data)==response['ContentLength'],'source_response_length')
    return verify(data,pins)

def output_response(response,ledger,*,response_bytes=None):
    data=decode_response(response,10485760,ledger,response_bytes=response_bytes)
    need(data.startswith(b'PK\x03\x04'),'output_zip_signature')
    return data,{'bytes':len(data),'sha256':sha(data)}

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*args,**kw):raise Failure('redirect_rejected')

def signing_deadline(setup_deadline):return min(setup_deadline,time.monotonic()+30)

def cli(argv,deadline):
    start=time.monotonic();work_end=deadline-.5;proc=None;sel=selectors.DefaultSelector();out=bytearray();reason=None;text=None
    safe={'operation':'source_presign','pid':None,'pgid':None,'bytes':{'stdout':0,'stderr':0},'eof':{'stdout':False,'stderr':False},'exit':{'state':'missing','reason':'not_started'},'groupClosed':True,'reason':None}
    env=dict(os.environ);env.update(AWS_MAX_ATTEMPTS='1',AWS_RETRY_MODE='standard',AWS_EC2_METADATA_DISABLED='true',AWS_S3_US_EAST_1_REGIONAL_ENDPOINT='regional',AWS_DEFAULT_REGION='us-east-1',AWS_REGION='us-east-1')
    try:
        need(time.monotonic()<work_end,'signing_deadline')
        proc=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True);safe['pid']=proc.pid;safe['pgid']=proc.pid
        for name in ('stdout','stderr'):sel.register(getattr(proc,name),selectors.EVENT_READ,name)
        while sel.get_map():
            need(time.monotonic()<work_end,'signing_deadline')
            for key,_ in sel.select(min(.05,max(.001,work_end-time.monotonic()))):
                data=os.read(key.fileobj.fileno(),8192);name=key.data
                if not data:sel.unregister(key.fileobj);safe['eof'][name]=True;continue
                safe['bytes'][name]+=len(data);need(sum(safe['bytes'].values())<=65536,'signing_output_cap')
                if name=='stdout':out.extend(data)
        code=proc.wait(timeout=max(.001,work_end-time.monotonic()));need(code==0,'signing_failed');text=out.decode('ascii').strip()
    except Failure as error:reason=error.args[0] if error.args and error.args[0] in ('signing_deadline','signing_output_cap','signing_failed') else 'signing_io_failed'
    except subprocess.TimeoutExpired:reason='signing_deadline'
    except UnicodeError:reason='signing_output_encoding'
    except BaseException:reason='signing_io_failed'
    finally:
        safe['elapsedSeconds']=time.monotonic()-start
        if proc:
            code=proc.poll();safe['exit']={'state':'available','code':code} if code is not None else {'state':'missing','reason':'not_exited'}
            try:os.killpg(proc.pid,9)
            except ProcessLookupError:pass
            except OSError:pass
            try:proc.wait(timeout=max(.001,min(.2,deadline-time.monotonic())))
            except (subprocess.TimeoutExpired,OSError):pass
            safe['groupClosed']=False
            while True:
                try:os.killpg(proc.pid,0)
                except ProcessLookupError:safe['groupClosed']=True;break
                except OSError:break
                if time.monotonic()>=deadline:break
                time.sleep(min(.01,max(0,deadline-time.monotonic())))
            for stream in (proc.stdout,proc.stderr):stream.close()
            if not safe['groupClosed']:reason='signing_group_unclosed'
        sel.close();safe['reason']=reason;safe['totalSeconds']=time.monotonic()-start
    if reason:
        error=Failure(reason);error.safeCLIOutcome=safe;raise error from None
    return text,safe

def fetch_source(url,size,digest,host,path,deadline):
    u=urllib.parse.urlsplit(url);need(u.scheme=='https' and u.hostname==host and u.path==path and not u.username and not u.password and u.port in (None,443),'source_origin')
    op=urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect());chunks=[];n=0;h=hashlib.sha256()
    try:
        with op.open(urllib.request.Request(url),timeout=min(5,max(.01,deadline-time.monotonic()))) as r:
            need(r.status==200 and r.geturl()==url,'source_response')
            while True:
                need(time.monotonic()<deadline,'source_deadline');b=r.read(min(65536,size-n+1))
                if not b:break
                n+=len(b);need(n<=size,'source_size');chunks.append(b);h.update(b)
        need(n==size and h.hexdigest()==digest,'source_identity');return b''.join(chunks)
    except Failure:raise
    except BaseException as e:raise Failure('source_'+type(e).__name__) from None

def bootstrap(pins,bucket,key,region,nonce,destination):
    # Trusted inline authority owns only this fresh root before any source operation.
    root=pathlib.Path(destination);owned=False;stage='root';safe_cli=None
    try:
        root.mkdir(mode=0o700,parents=False,exist_ok=False);owned=True;stage='ownership'
        with (root/'.owner').open('xb') as marker:marker.write((nonce+'\n').encode('ascii'))
        stage='timebase'
        raw=os.environ.get('CODEBUILD_START_TIME','');need(re.fullmatch(r'\d{13}',raw),'provider_timebase_missing')
        elapsed=time.time()-int(raw)/1000;need(0<=elapsed<240,'provider_setup_expired');deadline=time.monotonic()+240-elapsed
        stage='source_sign';url,safe_cli=cli(['aws','s3','presign','s3://'+bucket+'/'+key,'--region',region,'--expires-in','300'],signing_deadline(deadline))
        line=wire({'schema':'codec-bootstrap-cli-outcome-v1','nonce':nonce,'stage':stage,'outcome':safe_cli});need(len(line)<=4096,'bootstrap_record_cap');print(line.decode('ascii'),end='',flush=True)
        stage='source_download';data=fetch_source(url,pins['envelope']['bytes'],pins['envelope']['sha256'],bucket+'.s3.'+region+'.amazonaws.com','/'+key,deadline);url=None
        stage='source_verify';files=verify(data,pins)
        stage='source_install';code=root/'code';code.mkdir(mode=0o755)
        for name,data in files.items():
            dest=code/name;dest.parent.mkdir(mode=0o755,exist_ok=True)
            with dest.open('xb') as out:out.write(data)
            os.chmod(dest,0o644)
        # Evidence remains absent for diagnostic.run(exist_ok=False); no delivered import precedes verification.
        stage='source_exec';os.execv(sys.executable,[sys.executable,'-I','-B',str(code/'diagnostic.py'),'--nonce',nonce,'--output',str(root/'evidence'),'--provider-start-ms',raw])
    except BaseException as error:
        if not owned:raise Failure('bootstrap_root_not_owned') from None
        safe_cli=getattr(error,'safeCLIOutcome',safe_cli)
        allowed={'signing_deadline','signing_output_cap','signing_failed','signing_io_failed','signing_output_encoding','signing_group_unclosed'}
        reason=safe_cli['reason'] if safe_cli and safe_cli.get('reason') in allowed else stage+'_failed'
        record={'schema':'codec-bootstrap-negative-v1','state':'failed_pre_harness','nonce':nonce,'externalPins':pins,'stage':stage,'reason':reason,'safeCLIOutcome':safe_cli}
        data=wire(record);need(len(data)<=4096,'bootstrap_record_cap');evidence=root/'evidence';evidence.mkdir(mode=0o700,exist_ok=False)
        with (evidence/'bootstrap-negative.json').open('xb') as out:out.write(data)
        raise Failure(reason) from None

def freeze(root,destination):
    root=pathlib.Path(root);destination=pathlib.Path(destination);destination.mkdir(exist_ok=True)
    files={name:(root/name).read_bytes() for name in FILES if name!='manifest.json'}
    manifest=wire({name:{'bytes':len(b),'sha256':sha(b)} for name,b in files.items()});files['manifest.json']=manifest
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for name in FILES:
            zi=zipfile.ZipInfo(name,date_time=(2026,1,1,0,0,0));zi.compress_type=zipfile.ZIP_DEFLATED;zi.external_attr=(stat.S_IFREG|0o644)<<16;z.writestr(zi,files[name])
    data=out.getvalue();env=envelope(data);pins=identities(env,data,manifest);verify(env,pins)
    (root/'manifest.json').write_bytes(manifest)
    for n,b in [('code.zip',data),('code-envelope.json',env),('packet-pins.json',wire(pins))]:(destination/n).write_bytes(b)
    return pins

def render(pins,*,nonce,bucket,source_key,evidence_prefix,role_arn,managed_image='aws/codebuild/standard:8.0-26.10.15'):
    need(re.fullmatch(r'[a-z0-9-]{6,40}',nonce),'nonce');need(source_key!=evidence_prefix and not source_key.startswith(evidence_prefix.rstrip('/')+'/'),'source_evidence_separation')
    destination='/tmp/cd'
    names=['Failure','need','sha','wire','unique','canonical_base64','identity','verify','NoRedirect','signing_deadline','cli','fetch_source','bootstrap']
    script='import base64,binascii,hashlib,io,json,os,pathlib,re,selectors,stat,subprocess,sys,time,urllib.parse,urllib.request,zipfile\nFILES='+repr(FILES)+'\n'
    for name in names:script+=inspect.getsource(globals()[name])+'\n'
    script+='bootstrap('+repr(pins)+','+repr(bucket)+','+repr(source_key)+',"us-east-1",'+repr(nonce)+','+repr(destination)+')\n'
    buildspec={'version':0.2,'phases':{'build':{'commands':["python3 -I -B - <<'CODEC_TRUSTED_BOOTSTRAP'\n"+script+'CODEC_TRUSTED_BOOTSTRAP']}},'artifacts':{'base-directory':destination+'/evidence','files':['**/*'],'discard-paths':'no'}}
    inline=json.dumps(buildspec,sort_keys=True,separators=(',',':'));need(len(inline.encode())<=262144,'inline_cap')
    request={'name':'codec-diagnostic-'+nonce,'source':{'type':'NO_SOURCE','buildspec':inline},'artifacts':{'type':'S3','location':bucket,'path':evidence_prefix,'name':'evidence.zip','namespaceType':'NONE','packaging':'ZIP','overrideArtifactName':False,'encryptionDisabled':True},'environment':{'type':'LINUX_CONTAINER','computeType':'BUILD_GENERAL1_MEDIUM','image':managed_image,'privilegedMode':True,'environmentVariables':[],'imagePullCredentialsType':'CODEBUILD'},'serviceRole':role_arn,'timeoutInMinutes':15,'queuedTimeoutInMinutes':5,'autoRetryLimit':0,'cache':{'type':'NO_CACHE'},'badgeEnabled':False,'logsConfig':{'cloudWatchLogs':{'status':'ENABLED','groupName':'/aws/codebuild/codec-diagnostic-'+nonce},'s3Logs':{'status':'DISABLED'}},'tags':[{'key':'allocation','value':'codec-diagnostic-'+nonce}]}
    return request,{'nonce':nonce,'externalPins':pins,'inline':{'bytes':len(inline.encode()),'sha256':sha(inline.encode())},'request':{'bytes':len(wire(request)),'sha256':sha(wire(request))},'sourceKey':source_key,'artifactKey':evidence_prefix+'/evidence.zip','evidenceBaseDirectory':destination+'/evidence','readinessRequired':['fresh bucket-default/private AES256','actual output HeadObject AES256','Root hold/allocation/capability/provider readback','one idempotent StartBuild with no buildspec override']}

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=pathlib.Path,default=pathlib.Path(__file__).resolve().parent);ap.add_argument('--destination',type=pathlib.Path,required=True);ap.add_argument('--nonce',required=True);ap.add_argument('--source-key',required=True);ap.add_argument('--evidence-prefix',required=True);ap.add_argument('--role-arn',required=True);a=ap.parse_args()
    pins=freeze(a.root,a.destination);req,record=render(pins,nonce=a.nonce,bucket='vrdex-restream-worker-079358094174-artifacts',source_key=a.source_key,evidence_prefix=a.evidence_prefix,role_arn=a.role_arn)
    (a.destination/'create-project.json').write_bytes(wire(req));(a.destination/'readiness.json').write_bytes(wire(record));print(wire(record).decode(),end='')
