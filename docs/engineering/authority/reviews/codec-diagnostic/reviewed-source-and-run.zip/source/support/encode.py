"""Private offline Docker-save body encoder; image acceptance belongs to scanner.

encode(source, scanner_facts, fresh_output, *, limits=Limits(), check=lambda: None)
returns a success inventory, or raises EncodeError after writing a negative inventory.
replay(output, *, descriptor=None, limits=Limits(), check=lambda: None) yields <=64KiB.
Exhaust replay before treating its hash/size validation as complete. No rootfs extraction.
"""
from dataclasses import dataclass
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import zlib

CHUNK = 65536
RESERVE = 1048576
INVENTORY_ALLOWANCE = 1048576


class EncodeError(ValueError):
    pass


@dataclass(frozen=True)
class Limits:
    save_bytes: int = 2147483648
    encoded_bytes: int = 536870912
    metadata_bytes: int = 16777216
    reserve_bytes: int = RESERVE

    def validate(self):
        for value, ceiling in ((self.save_bytes, 2147483648),
                               (self.encoded_bytes, 536870912),
                               (self.metadata_bytes, 16777216)):
            need(type(value) is int and 0 < value <= ceiling, 'invalid limits')
        need(type(self.reserve_bytes) is int and RESERVE <= self.reserve_bytes < self.metadata_bytes,
             'outer inventory/terminal reserve must be at least 1MiB')
        need(self.metadata_bytes >= self.reserve_bytes + INVENTORY_ALLOWANCE,
             'metadata limit cannot hold reserved inventory space')


def need(condition, reason):
    if not condition:
        raise EncodeError(reason)


def wire(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True) + '\n').encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def count(value):
    return type(value) is int and value >= 0


def valid_hash(value):
    return isinstance(value, str) and re.fullmatch('[0-9a-f]{64}', value) is not None


def safe_member(name):
    return (isinstance(name, str) and re.fullmatch(r'[a-zA-Z0-9_./-]+', name) is not None
            and not name.startswith('/') and not any(p in ('.', '..') for p in name.split('/')))


def regular(path):
    """Reject symlinks, including a replacement between lstat and open."""
    before = os.lstat(path)
    need(stat.S_ISREG(before.st_mode), 'source/artifact is not a regular file')
    fd = os.open(path, os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
    stream = os.fdopen(fd, 'rb')
    after = os.fstat(stream.fileno())
    if not stat.S_ISREG(after.st_mode) or (before.st_dev, before.st_ino) != (after.st_dev, after.st_ino):
        stream.close()
        raise EncodeError('source/artifact changed during open')
    return stream


def identity(s):
    return s.st_dev, s.st_ino, s.st_size, s.st_mtime_ns, s.st_ctime_ns


def file_record(path, check=lambda: None):
    h, size = hashlib.sha256(), 0
    with regular(path) as f:
        while True:
            check()
            data = f.read(CHUNK)
            if not data:
                break
            h.update(data)
            size += len(data)
    return {'name': path.name, 'bytes': size, 'sha256': h.hexdigest()}


class Reader:
    def __init__(self, stream, limit, check):
        self.stream, self.limit, self.check = stream, limit, check
        self.offset, self.hash = 0, hashlib.sha256()

    def read(self, size):
        need(0 <= size <= CHUNK, 'read chunk bound')
        self.check()
        data = self.stream.read(size)
        self.offset += len(data)
        need(self.offset <= self.limit, 'save cap exceeded')
        self.hash.update(data)
        need(len(data) == size, 'missing source bytes')
        return data


def _header(raw):
    """Only delineate classic framing. This does not accept an image."""
    try:
        name = raw[:100].split(b'\0', 1)[0].decode('ascii')
        size_text = raw[124:136].split(b'\0', 1)[0].strip()
        need(re.fullmatch(b'[0-7]+', size_text) is not None, 'bad member size')
        size = int(size_text, 8)
    except (ValueError, UnicodeError) as exc:
        raise EncodeError('bad classic header') from exc
    need(safe_member(name), 'unsafe member path')
    need(not raw[345:500].split(b'\0', 1)[0], 'unsupported classic prefix')
    kind = raw[156]
    need(kind in (0, 48, 53), 'unsupported classic member type')
    need(kind != 53 or size == 0 and name.endswith('/'), 'bad directory')
    return name, size, kind


def encode(source, scanner_facts, output, *, limits=Limits(), check=lambda: None):
    """Create output exclusively. Failures preserve bounded partials and source.

    Scanner facts use the unchanged scanDockerSave result. An optional ``offset``
    on a layer fact means the absolute raw body offset and is checked if supplied.
    Output must have a trusted parent; no cleanup or deletion is performed here.
    """
    output, source = Path(output), Path(source)
    output.mkdir(mode=0o700, exist_ok=False)
    owned = []
    complete_files = set()
    pieces, members = [], []
    encoded_total, literal_total = 0, 0
    layer_files = {}
    inventory = {'schema': 'lossless-save-inventory-v1', 'complete': False,
                 'reason': 'not completed', 'source': str(source), 'sourceRetained': True,
                 'artifacts': []}
    try:
        limits.validate()
        archive = scanner_facts['archive']
        need(archive.get('complete') is True and count(archive['bytes']) and
             archive['bytes'] <= limits.save_bytes and valid_hash(archive['sha256']), 'bad scanner archive facts')
        layer_list = scanner_facts['originals']['layers']
        need(isinstance(layer_list, list) and len(layer_list) <= 1024, 'bad scanner layer facts')
        layers = {}
        inventory['expectedArchive'] = dict(archive)
        inventory['expectedLayers'] = []
        inventory['layerNamesByFile'] = layer_files
        for fact in layer_list:
            name = fact['name']
            need(safe_member(name) and len(name) <= 100 and name not in layers and count(fact['bytes']) and
                 fact['bytes'] <= archive['bytes'] and valid_hash(fact['sha256']), 'bad scanner layer facts')
            if 'offset' in fact:
                need(count(fact['offset']), 'bad supplied offset')
            layers[name] = fact
            inventory['expectedLayers'].append({k: fact[k] for k in ('name', 'bytes', 'sha256')})
        literal_path = output / 'literal.bin'
        literal_path.touch(mode=0o600, exist_ok=False)
        owned.append(literal_path)
        literal_piece = None
        literal_hash = None

        def finish_literal():
            nonlocal literal_piece
            if literal_piece is not None:
                literal_piece['sha256'] = literal_hash.hexdigest()
                pieces.append(literal_piece)
                literal_piece = None

        with regular(source) as src, literal_path.open('ab') as literals:
            initial = identity(os.fstat(src.fileno()))
            inventory['sourceObserved'] = {'bytes': initial[2], 'device': initial[0], 'inode': initial[1]}
            need(initial[2] == archive['bytes'], 'source size differs from scanner')
            reader = Reader(src, limits.save_bytes, check)

            def literal(data, offset):
                nonlocal literal_piece, literal_hash, literal_total
                need(literal_total + len(data) + INVENTORY_ALLOWANCE <= limits.metadata_bytes - limits.reserve_bytes,
                     'metadata cap exceeded')
                if literal_piece is None:
                    literal_piece = {'kind': 'literal', 'offset': offset, 'bytes': 0,
                                     'file': 'literal.bin', 'file_offset': literal_total}
                    literal_hash = hashlib.sha256()
                check()
                literals.write(data)
                literal_hash.update(data)
                literal_piece['bytes'] += len(data)
                literal_total += len(data)

            zeros, seen = 0, set()
            while reader.offset < archive['bytes']:
                offset = reader.offset
                raw = reader.read(512)
                literal(raw, offset)
                if raw == bytes(512):
                    zeros += 1
                    continue
                need(zeros == 0, 'member after EOF framing')
                name, size, kind = _header(raw)
                need(name not in seen and len(seen) < 1024, 'duplicate member or member count cap')
                seen.add(name)
                body_offset = reader.offset
                need(body_offset + size + (-size % 512) <= archive['bytes'], 'bad body offsets/missing bytes')
                fact = layers.get(name)
                if fact is not None:
                    need(kind != 53 and size == fact['bytes'] and
                         fact.get('offset', body_offset) == body_offset, 'layer bytes/offset mismatch')
                h = hashlib.sha256()
                remaining = size
                if fact is not None:
                    finish_literal()
                    artifact = 'layer-%04d.gz' % len([p for p in pieces if p['kind'] == 'gzip'])
                    path = output / artifact
                    layer_files[artifact] = name
                    owned.append(path)
                    compressor = zlib.compressobj(level=9, wbits=31)
                    compressed_hash, compressed_size = hashlib.sha256(), 0
                    with path.open('xb') as target:
                        def compressed(data):
                            nonlocal encoded_total, compressed_size
                            for pos in range(0, len(data), CHUNK):
                                part = data[pos:pos + CHUNK]
                                need(encoded_total + len(part) <= limits.encoded_bytes, 'encoded layer cap exceeded')
                                check()
                                target.write(part)
                                compressed_hash.update(part)
                                compressed_size += len(part)
                                encoded_total += len(part)
                        while remaining:
                            data = reader.read(min(CHUNK, remaining))
                            h.update(data)
                            compressed(compressor.compress(data))
                            remaining -= len(data)
                        compressed(compressor.flush())
                    need(h.hexdigest() == fact['sha256'], 'layer hash differs from scanner')
                    complete_files.add(artifact)
                    pieces.append({'kind': 'gzip', 'name': name, 'offset': body_offset, 'bytes': size,
                                   'sha256': h.hexdigest(), 'file': artifact, 'encoded_bytes': compressed_size,
                                   'encoded_sha256': compressed_hash.hexdigest()})
                else:
                    while remaining:
                        at = reader.offset
                        data = reader.read(min(CHUNK, remaining))
                        h.update(data)
                        literal(data, at)
                        remaining -= len(data)
                members.append({'name': name, 'offset': body_offset, 'bytes': size, 'sha256': h.hexdigest()})
                if size % 512:
                    at = reader.offset
                    pad = reader.read(-size % 512)
                    need(not any(pad), 'nonzero padding')
                    literal(pad, at)
            finish_literal()
            need(zeros >= 2, 'missing complete EOF framing')
            need(set(layers) <= seen, 'scanner layer missing from source')
            need(reader.hash.hexdigest() == archive['sha256'], 'source hash differs from scanner')
            need(identity(os.fstat(src.fileno())) == initial and identity(os.lstat(source)) == initial,
                 'source changed during encoding')
        complete_files.add('literal.bin')
        # Bind retained known nonlayer originals to supplied scanner facts too.
        by_name = {m['name']: m for m in members}
        for name, field in (('manifest.json', 'manifestUTF8'),
                            (scanner_facts.get('configSHA', '') + '.json', 'configUTF8')):
            if field in scanner_facts['originals']:
                expected = scanner_facts['originals'][field].encode('utf8')
                need(name in by_name and by_name[name]['bytes'] == len(expected) and
                     by_name[name]['sha256'] == sha(expected), 'nonlayer original differs from scanner')
        descriptor = {'schema': 'lossless-save-v1', 'archive': archive, 'pieces': pieces, 'members': members,
                      'literal_bytes': literal_total, 'encoded_bytes': encoded_total}
        body = wire(descriptor)
        need(literal_total + len(body) + INVENTORY_ALLOWANCE <= limits.metadata_bytes - limits.reserve_bytes,
             'descriptor metadata cap exceeded')
        descriptor_path = output / 'descriptor.json'
        with descriptor_path.open('xb') as f:
            owned.append(descriptor_path)
            f.write(body)
        complete_files.add('descriptor.json')
        # Full retained replay is mandatory, independently of the source read hash.
        replay_hash, replay_size = hashlib.sha256(), 0
        for data in replay(output, limits=limits, check=check):
            replay_hash.update(data)
            replay_size += len(data)
        need(identity(os.lstat(source)) == initial, 'source changed before replay completion')
        inventory.update(complete=True, reason=None,
                         replay={'bytes': replay_size, 'sha256': replay_hash.hexdigest()},
                         metadataReserveBytes=limits.reserve_bytes)
    except Exception as exc:
        inventory['reason'] = (type(exc).__name__ + ': ' + str(exc))[:2048]
        failure = exc
    else:
        failure = None
    # Finalization deliberately ignores cancellation so the negative can be retained.
    for path in owned:
        if path.exists():
            record = file_record(path)
            record['complete'] = path.name in complete_files
            inventory['artifacts'].append(record)
    if 'expectedLayers' in inventory:
        complete_names = {name for file, name in layer_files.items() if file in complete_files}
        inventory['incompleteLayers'] = [f['name'] for f in inventory['expectedLayers'] if f['name'] not in complete_names]
    inv_bytes = wire(inventory)
    need(len(inv_bytes) <= INVENTORY_ALLOWANCE, 'inventory reserve exceeded')
    with (output / 'inventory.json').open('xb') as f:
        f.write(inv_bytes)
    if failure is not None:
        raise EncodeError(inventory['reason']) from failure
    return inventory


def replay(output, *, descriptor=None, limits=Limits(), check=lambda: None):
    """Yield bounded retained raw-save chunks; integrity commits only at exhaustion.

    Descriptor may be supplied as a decoded dict for independent transport adapters.
    Every artifact is read as a regular no-follow file. Concatenated gzip is rejected.
    """
    try:
        yield from _replay(Path(output), descriptor, limits, check)
    except EncodeError:
        raise
    except Exception as exc:
        raise EncodeError(type(exc).__name__ + ': ' + str(exc)) from exc


def _replay(output, descriptor, limits, check):
    limits.validate()
    need(not output.is_symlink() and output.is_dir(), 'unsafe output directory')
    if descriptor is None:
        with regular(output / 'descriptor.json') as f:
            need(os.fstat(f.fileno()).st_size <= limits.metadata_bytes - limits.reserve_bytes, 'descriptor cap')
            parts = []
            while True:
                check()
                data = f.read(CHUNK)
                if not data:
                    break
                parts.append(data)
        descriptor = json.loads(b''.join(parts))
    d = descriptor
    need(d['schema'] == 'lossless-save-v1', 'descriptor schema')
    archive = d['archive']
    need(archive.get('complete') is True and count(archive['bytes']) and
         archive['bytes'] <= limits.save_bytes and valid_hash(archive['sha256']), 'archive replay cap/facts')
    need(count(d['literal_bytes']) and count(d['encoded_bytes']), 'bad artifact totals')
    need(d['literal_bytes'] + len(wire(d)) + INVENTORY_ALLOWANCE <= limits.metadata_bytes - limits.reserve_bytes,
         'replay metadata cap')
    need(d['encoded_bytes'] <= limits.encoded_bytes, 'replay encoded cap')
    need(isinstance(d['pieces'], list) and len(d['pieces']) <= 2049, 'descriptor piece cap')
    offset, literal_offset, encoded_total = 0, 0, 0
    files, names = set(), set()
    for piece in d['pieces']:
        need(count(piece['bytes']) and count(piece['offset']) and piece['offset'] == offset and
             valid_hash(piece['sha256']), 'overlapping/incomplete descriptor')
        offset += piece['bytes']
        need(offset <= archive['bytes'], 'piece raw cap')
        if piece['kind'] == 'literal':
            need(piece['file'] == 'literal.bin' and piece['file_offset'] == literal_offset and
                 count(piece['file_offset']), 'literal descriptor offset/path')
            literal_offset += piece['bytes']
        else:
            need(piece['kind'] == 'gzip' and re.fullmatch(r'layer-[0-9]{4}\.gz', piece['file']) is not None
                 and piece['file'] not in files and safe_member(piece['name']) and piece['name'] not in names,
                 'unsafe/duplicate compressed descriptor')
            need(count(piece['encoded_bytes']) and valid_hash(piece['encoded_sha256']), 'bad encoded facts')
            files.add(piece['file'])
            names.add(piece['name'])
            encoded_total += piece['encoded_bytes']
    need(offset == archive['bytes'] and literal_offset == d['literal_bytes'] and
         encoded_total == d['encoded_bytes'], 'incomplete descriptor/totals')
    whole, emitted = hashlib.sha256(), 0
    with regular(output / 'literal.bin') as literals:
        need(os.fstat(literals.fileno()).st_size == literal_offset, 'literal file size mismatch')
        for piece in d['pieces']:
            check()
            h, size = hashlib.sha256(), 0
            if piece['kind'] == 'literal':
                remaining = piece['bytes']
                while remaining:
                    check()
                    data = literals.read(min(CHUNK, remaining))
                    need(data, 'truncated literal')
                    remaining -= len(data)
                    h.update(data)
                    whole.update(data)
                    emitted += len(data)
                    size += len(data)
                    yield data
            else:
                compressed_h = hashlib.sha256()
                inflater = zlib.decompressobj(31)
                with regular(output / piece['file']) as f:
                    need(os.fstat(f.fileno()).st_size == piece['encoded_bytes'], 'encoded file size mismatch')
                    remaining = piece['encoded_bytes']
                    while remaining:
                        check()
                        packed = f.read(min(CHUNK, remaining))
                        need(packed, 'truncated encoded file')
                        remaining -= len(packed)
                        compressed_h.update(packed)
                        while packed:
                            check()
                            # At most one excess byte detects inflation beyond declared body.
                            data = inflater.decompress(packed, min(CHUNK, piece['bytes'] - size + 1))
                            packed = inflater.unconsumed_tail
                            need(not inflater.unused_data, 'trailing/concatenated gzip')
                            size += len(data)
                            emitted += len(data)
                            need(size <= piece['bytes'] and emitted <= limits.save_bytes, 'gzip inflation cap')
                            h.update(data)
                            whole.update(data)
                            if data:
                                yield data
                    need(inflater.eof and not inflater.unused_data and not inflater.unconsumed_tail, 'truncated/trailing gzip')
                    need(compressed_h.hexdigest() == piece['encoded_sha256'], 'encoded original hash mismatch')
            need(size == piece['bytes'] and h.hexdigest() == piece['sha256'], 'raw piece size/hash mismatch')
    need(emitted == archive['bytes'] and whole.hexdigest() == archive['sha256'], 'whole replay size/hash mismatch')
