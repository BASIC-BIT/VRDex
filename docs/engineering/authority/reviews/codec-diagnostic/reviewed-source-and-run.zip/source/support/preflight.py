"""Tiny Docker24 compatibility probe. Only explicit CLI invocation performs operations."""
import base64, threading
import argparse, hashlib, json, os, pathlib, selectors, shutil, signal, subprocess, tarfile, time, urllib.request, uuid
URL='https://download.docker.com/linux/static/stable/x86_64/docker-24.0.9.tgz'
SIZE=70199284
SHA='692ecfc28333485d184f628b74c25b2894cee9495a51a5418ba60ef95bf733ca'
LOG_CAP=131072
META_CAP=16777216
SAVE_CAP=2147483648
MEMBERS={'containerd','containerd-shim-runc-v2','ctr','docker','docker-init','docker-proxy','dockerd','runc'}
class Failure(Exception):pass

def remaining(deadline):
    value=deadline-time.monotonic()
    if value<=0:raise Failure('deadline')
    return value

def digest(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(65536),b''):h.update(b)
    return h.hexdigest()

def payload():return bytes(i%251 for i in range(65537))

def download(path,size,sha,deadline):
    count=0;h=hashlib.sha256()
    # Reject redirects away from the pinned HTTPS origin.
    with urllib.request.urlopen(URL,timeout=min(15,remaining(deadline))) as response,open(path,'wb') as out:
        if hasattr(response,'geturl') and response.geturl()!=URL:raise Failure('download_redirect')
        while True:
            remaining(deadline);b=response.read(65536)
            if not b:break
            count+=len(b)
            if count>size:raise Failure('download_size')
            h.update(b);out.write(b)
    if count!=size or h.hexdigest()!=sha:raise Failure('download_identity')

def extract(archive,target,deadline=None):
    # Never use extractall: exact flat regular executables only.
    target.mkdir(mode=0o700,exist_ok=True);seen=set();total=0
    with tarfile.open(archive,'r:gz') as tf:
        for member in tf:
            if deadline is not None:remaining(deadline)
            if member.name.rstrip('/')=='docker' and member.isdir():continue
            name=member.name.removeprefix('docker/')
            if member.name!='docker/'+name or name not in MEMBERS or name in seen or not member.isfile():raise Failure('tar_member')
            if member.size<=0 or member.size>200000000:raise Failure('tar_size')
            total+=member.size
            if total>300000000:raise Failure('tar_total')
            seen.add(name)
            with tf.extractfile(member) as source,open(target/name,'xb') as out:shutil.copyfileobj(source,out,65536)
            os.chmod(target/name,0o700)
    if seen!=MEMBERS:raise Failure('tar_missing')

def environment(root):
    env={k:v for k,v in os.environ.items() if k in {'HOME','LANG','LC_ALL','SSL_CERT_FILE','SSL_CERT_DIR','HTTPS_PROXY','HTTP_PROXY','NO_PROXY','https_proxy','http_proxy','no_proxy'}}
    env.update(PATH=str(root/'bin')+':/usr/bin:/bin',DOCKER_HOST='unix://'+str(root/'daemon.sock'),DOCKER_CONFIG=str(root/'config'),BUILDX_CONFIG=str(root/'config'/'buildx'),XDG_RUNTIME_DIR=str(root/'runtime'))
    return env

def daemon_args(root):
    return [str(root/'bin'/'dockerd'),'--host=unix://'+str(root/'daemon.sock'),'--data-root='+str(root/'data'),'--exec-root='+str(root/'exec'),'--pidfile='+str(root/'daemon.pid'),'--config-file='+str(root/'daemon.json'),'--iptables=false','--bridge=none','--ip-forward=false','--ip-masq=false']

class Cancellation:
    active=None
    def __init__(self):self.cancelled=False;self.reason=None;self.shielded=False;self.previous={}
    def handle(self,signum,frame):
        if self.cancelled:return
        self.cancelled=True;self.reason='signal_'+str(signum)
        if self.shielded:return
        raise Failure('cancelled_signal_'+str(signum))
    def shield(self):self.shielded=True
    def __enter__(self):
        Cancellation.active=self
        for value in (signal.SIGTERM,signal.SIGINT):
            self.previous[value]=signal.signal(value,self.handle)
        return self
    def __exit__(self,*args):
        Cancellation.active=None
        for value,handler in self.previous.items():signal.signal(value,handler)

def group_exists(pid):
    try:os.killpg(pid,0);return True
    except ProcessLookupError:return False

def kill_owned(proc):
    if proc is None:return True
    try:
        try:os.killpg(proc.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        term_end=time.monotonic()+1
        try:proc.wait(timeout=1)
        except subprocess.TimeoutExpired:pass
        # Leader status never substitutes for group absence.
        while group_exists(proc.pid) and time.monotonic()<term_end:time.sleep(.02)
        if group_exists(proc.pid):
            try:os.killpg(proc.pid,signal.SIGKILL)
            except ProcessLookupError:pass
        try:proc.wait(timeout=1)
        except subprocess.TimeoutExpired:return False
        end=time.monotonic()+1
        while group_exists(proc.pid) and time.monotonic()<end:time.sleep(.02)
        return not group_exists(proc.pid)
    except (OSError,PermissionError):return False

def capture_record(stdout,stderr,oe,ee):
    def item(data,complete):return {'base64':base64.b64encode(data).decode('ascii'),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'complete':complete,'missingData':not complete}
    return {'stdout':item(stdout,oe),'stderr':item(stderr,ee)}
def raw(record,stream):return base64.b64decode(record[stream]['base64'],validate=True)
def text_stdout(record):return raw(record,'stdout').decode('utf8',errors='strict')

class DaemonLog:
    # Own only this pipe. No file-size resource limit reaches daemon state writes.
    def __init__(self,pipe,cap=LOG_CAP):
        self.pipe=pipe;self.cap=cap;self.data=bytearray();self.error=None;self.complete=False;self.stop=threading.Event()
        self.thread=threading.Thread(target=self.collect,daemon=True)
    def start(self):self.thread.start()
    def collect(self):
        select=selectors.DefaultSelector();select.register(self.pipe,selectors.EVENT_READ)
        try:
            while not self.stop.is_set():
                for key,_ in select.select(.05):
                    data=os.read(key.fileobj.fileno(),65536)
                    if not data:self.complete=self.error is None;return
                    space=self.cap-len(self.data);self.data.extend(data[:space])
                    if len(data)>space:self.error='daemon_output_cap'
                    # Continue draining while owner notices error and stops daemon.
        except BaseException as e:self.error='daemon_log_'+type(e).__name__
        finally:select.close()
    def check(self):
        if self.error:raise Failure(self.error)
    def finish(self):
        self.thread.join(timeout=1)
        if self.thread.is_alive():self.stop.set();self.thread.join(timeout=.2);self.error=self.error or 'daemon_log_missing_eof'
        self.pipe.close()

def validate_capture(stdout,stderr,out_eof,err_eof,code):
    if len(stdout)+len(stderr)>LOG_CAP:raise Failure('command_output_cap')
    if not out_eof or not err_eof:raise Failure('command_missing_eof')
    if code!=0:raise Failure('command_exit')

def capture_pipes(proc,deadline,sink=None,monitor=None):
    selector=selectors.DefaultSelector();buf={'stdout':bytearray(),'stderr':bytearray()};eof={'stdout':False,'stderr':False};count=0;written=0
    for name in buf:selector.register(getattr(proc,name),selectors.EVENT_READ,name)
    try:
        while selector.get_map():
            remaining(deadline)
            if monitor:monitor.check()
            for key,_ in selector.select(min(.1,remaining(deadline))):
                b=os.read(key.fileobj.fileno(),65536);name=key.data
                if not b:selector.unregister(key.fileobj);eof[name]=True;continue
                if sink and name=='stdout':
                    written+=len(b)
                    # Tiny originals share the stricter 16MiB ceiling.
                    if written>min(SAVE_CAP,META_CAP):raise Failure('tiny_save_retention_cap')
                    sink.write(b)
                else:
                    space=LOG_CAP-count;buf[name].extend(b[:space]);count+=len(b)
                    if count>LOG_CAP:raise Failure('command_output_cap')
        return bytes(buf['stdout']),bytes(buf['stderr']),eof['stdout'],eof['stderr']
    except BaseException as error:
        error.partialCapture=(bytes(buf['stdout']),bytes(buf['stderr']),eof['stdout'],eof['stderr'])
        raise
    finally:selector.close()

def command(args,env,deadline,sink=None,monitor=None):
    proc=subprocess.Popen(args,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    result=None;primary=None
    try:
        out,err,oe,ee=capture_pipes(proc,deadline,sink,monitor);code=proc.wait(timeout=remaining(deadline))
        result={'args':args,'exitCode':code,'signal':None if code>=0 else -code,'stdoutEOF':oe,'stderrEOF':ee,'error':None,**capture_record(out,err,oe,ee)}
        validate_capture(out,err,oe,ee,code)
        if monitor:monitor.check()
    except BaseException as error:
        primary=error
        if result is None:
            out,err,oe,ee=getattr(error,'partialCapture',(b'',b'',False,False))
            result={'args':args,'exitCode':proc.poll(),'stdoutEOF':oe,'stderrEOF':ee,'error':type(error).__name__,**capture_record(out,err,oe,ee)}
    finally:
        # Cancellation handler raises at most once. Later signals cannot interrupt closure.
        guard=Cancellation.active;old_shield=guard.shielded if guard else False
        if guard:guard.shield()
        try:clean=kill_owned(proc)
        except BaseException:
            clean=False
        finally:
            proc.stdout.close();proc.stderr.close()
            if guard:guard.shielded=old_shield
        if guard and guard.cancelled and primary is None:primary=Failure('cancelled_signal')
        if not clean:
            if primary is None:primary=Failure('command_cleanup_uncertain')
            primary.cleanupError='command_cleanup_uncertain'
            result['cleanupError']='command_cleanup_uncertain'
    if primary is not None:
        primary.commandResult=result
        raise primary
    return result

def closed_cleanup(value):return all(value.get(k) is True for k in ['builderRemoved','daemonReaped','socketAbsent'])

def run(root,source_root,buildx,buildx_version):
    with Cancellation() as cancellation:return run_owned(root,source_root,buildx,buildx_version,cancellation)

def run_owned(root,source_root,buildx,buildx_version,cancellation):
    root=root.resolve();source_root=source_root.resolve();root.mkdir(mode=0o700,parents=False,exist_ok=False)
    deadline=time.monotonic()+300;work_deadline=deadline-15;records=[];daemon=None;daemon_log=None;name='tiny-'+uuid.uuid4().hex;env=environment(root)
    result={'schema':'docker24-tiny-preflight-v1','nonce':name,'passed':False,'actualImageVerified':False,'capacityAccepted':False,'operationalConditions':'OPEN','cleanup':{},'trustPremises':{'managedBuildxExpectedVersion':buildx_version}}
    def save(name,data):
        raw=data if isinstance(data,bytes) else (json.dumps(data,sort_keys=True,indent=2)+'\n').encode()
        if len(raw)>META_CAP:raise Failure('metadata_cap')
        (root/name).write_bytes(raw)
    def invoke(args,sink=None,limit=None):
        try:value=command(args,env,min(work_deadline,time.monotonic()+limit) if limit else work_deadline,sink,daemon_log)
        except BaseException as error:
            if hasattr(error,'commandResult'):records.append(error.commandResult);save('commands.json',records)
            raise
        records.append(value);save('commands.json',records);return value
    try:
        if not (source_root/'scripts/event-marker-native-controller.mjs').is_file():raise Failure('source_root')
        if shutil.disk_usage(root).free<536870912:raise Failure('disk_headroom')
        result['sourceIdentities']={str(f):digest(f) for f in [pathlib.Path(__file__),pathlib.Path(__file__).with_name('scan.mjs'),source_root/'scripts/event-marker-native-controller.mjs']}
        save('scanner-source.mjs',(source_root/'scripts/event-marker-native-controller.mjs').read_bytes())
        download(root/'docker.tgz',SIZE,SHA,work_deadline);extract(root/'docker.tgz',root/'bin',work_deadline)
        result['download']={'bytes':(root/'docker.tgz').stat().st_size,'sha256':digest(root/'docker.tgz')}
        (root/'docker.tgz').unlink() # Tool installation bytes are not claimed as tiny evidence originals.
        for directory in ['config','config/cli-plugins','runtime','context']:(root/directory).mkdir(mode=0o700)
        if not buildx.is_file() or not os.access(buildx,os.X_OK):raise Failure('buildx_path')
        shutil.copyfile(buildx,root/'config'/'cli-plugins'/'docker-buildx');os.chmod(root/'config'/'cli-plugins'/'docker-buildx',0o700)
        result['trustPremises']['managedBuildxSHA256']=digest(buildx)
        observed=text_stdout(invoke(['docker','buildx','version'])).strip()
        if observed!=buildx_version:raise Failure('buildx_version')
        save('daemon.json',{})
        daemon=subprocess.Popen(daemon_args(root),env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        daemon_log=DaemonLog(daemon.stdout);daemon_log.start()
        ready_until=min(work_deadline,time.monotonic()+25)
        while not (root/'daemon.sock').exists():
            if daemon.poll() is not None:raise Failure('daemon_early_exit')
            if time.monotonic()>=ready_until:raise Failure('daemon_not_ready')
            time.sleep(.05)
        invoke(['docker','version']);info=invoke(['docker','info','--format','{{json .}}']);save('daemon-info.json',json.loads(text_stdout(info)))
        # A nonce-owned context auto-selects its Docker driver builder; avoid unsupported
        # manual creation of a second Docker-driver builder or external BuildKit pulls.
        invoke(['docker','context','create',name,'--docker','host='+env['DOCKER_HOST']])
        builder=invoke(['docker','--context',name,'buildx','inspect',name,'--bootstrap'])
        if 'Driver:        docker' not in text_stdout(builder) and not any(line.split()==['Driver:','docker'] for line in text_stdout(builder).splitlines()):raise Failure('builder_driver')
        if name not in text_stdout(builder):raise Failure('builder_identity')
        data=payload();save('context/payload.bin',data);save('context/Dockerfile',b'FROM scratch\nCOPY payload.bin /payload.bin\n')
        result['fixture']={'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        tag=name+':tiny'
        invoke(['docker','--context',name,'buildx','build','--network=none','--load','--tag',tag,str(root/'context')])
        inspected=invoke(['docker','image','inspect',tag]);parsed=json.loads(text_stdout(inspected))
        if len(parsed)!=1:raise Failure('image_count')
        image_id=parsed[0]['Id']
        import re
        if not re.fullmatch(r'sha256:[0-9a-f]{64}',image_id):raise Failure('image_id')
        exact=invoke(['docker','image','inspect',image_id]);save('inspect.json',raw(exact,'stdout'))
        if json.loads(text_stdout(exact))[0]['Id']!=image_id:raise Failure('image_binding')
        with open(root/'save.tar','xb') as out:terminal=invoke(['docker','image','save',image_id],out)
        save('save-terminal.json',terminal)
        scan=invoke(['node',str(pathlib.Path(__file__).with_name('scan.mjs')),str(source_root),str(root/'save.tar'),str(root/'inspect.json'),str(root/'save-terminal.json'),image_id])
        facts=json.loads(text_stdout(scan));save('scan.json',facts)
        if not facts['originals']['layers'] or not any(x['bytes']>65536 for x in facts['originals']['layers']):raise Failure('fixture_layer_boundary')
        result['imageId']=image_id;result['actualImageVerified']=True
    except BaseException as e:
        result['failure']=str(e)[:2048] or type(e).__name__
    finally:
        cancellation.shield()
        cleanup={'builderRemoved':False,'daemonReaped':False,'socketAbsent':False}
        if daemon is not None:
            try:
                # Private context removal retires the automatically selected Docker builder.
                r=command(['docker','context','rm','--force',name],env,min(deadline,time.monotonic()+3));records.append(r)
                check=command(['docker','context','ls','--format','{{.Name}}'],env,min(deadline,time.monotonic()+3));records.append(check)
                cleanup['builderRemoved']=name not in text_stdout(check).splitlines()
            except BaseException as e:
                cleanup['contextError']=str(e)[:1024]
                if hasattr(e,'commandResult'):records.append(e.commandResult)
            cleanup['daemonReaped']=kill_owned(daemon)
            cleanup['socketAbsent']=not (root/'daemon.sock').exists()
        else:cleanup.update(builderRemoved=True,daemonReaped=True,socketAbsent=not (root/'daemon.sock').exists())
        if daemon_log:
            daemon_log.finish();save('daemon.log',bytes(daemon_log.data))
            result['daemonCapture']={**capture_record(bytes(daemon_log.data),b'',daemon_log.complete,True)['stdout'],'error':daemon_log.error}
            if daemon_log.error:result.setdefault('failure',daemon_log.error)
        result['cleanup']=cleanup
        if not closed_cleanup(cleanup):result.setdefault('failure','cleanup_uncertain');result['cleanupFailure']='cleanup_uncertain'
        # Binaries/state are temporary tools, never included in evidence inventory.
        for directory in ['bin','data','exec','config','runtime']:
            if cleanup['daemonReaped']:shutil.rmtree(root/directory,ignore_errors=True)
        save('commands.json',records)
        evidence=[f for f in root.rglob('*') if f.is_file() and not any(part in {'bin','data','exec','config','runtime'} for part in f.relative_to(root).parts)]
        total=sum(f.stat().st_size for f in evidence)
        if total>META_CAP-1048576:result['passed']=False;result['failure']='tiny_originals_cap'
        result['retainedBytesBeforeResult']=total
        result['originals']=[{'path':str(f.relative_to(root)),'bytes':f.stat().st_size,'sha256':digest(f)} for f in evidence]
        result['cancellation']={'observed':cancellation.cancelled,'reason':cancellation.reason}
        if cancellation.cancelled:result.setdefault('failure','cancelled_'+str(cancellation.reason))
        result['passed']=result['actualImageVerified'] and closed_cleanup(cleanup) and 'failure' not in result and not cancellation.cancelled and time.monotonic()<deadline
        encoded_result=(json.dumps(result,sort_keys=True,indent=2)+'\n').encode()
        if len(encoded_result)>1048576:raise Failure('result_inventory_cap')
        save('result.json',encoded_result)
    return result

if __name__=='__main__':
    a=argparse.ArgumentParser(description=__doc__);a.add_argument('--output',type=pathlib.Path,required=True);a.add_argument('--source-root',type=pathlib.Path,required=True);a.add_argument('--buildx',type=pathlib.Path,required=True);a.add_argument('--buildx-version',required=True);x=a.parse_args()
    print(json.dumps(run(x.output,x.source_root,x.buildx,x.buildx_version)))
