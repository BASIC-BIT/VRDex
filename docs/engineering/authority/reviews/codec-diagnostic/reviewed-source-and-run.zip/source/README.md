# Private finite codec diagnostic

This source-only harness describes twelve sequential synthetic generation, encoding and MPEG-TS cells in one retained image. It produces `unqualified-codec-diagnostic-v1`; it cannot qualify a worker or populate a capacity table.

The delivered code ZIP has exactly six files: `diagnostic.py`, `probe.py`, `support/encode.py`, `support/preflight.py`, `pins.json`, `manifest.json`. The helpers are unchanged. Only replay and non-download Docker helper primitives are used. `check_result.py`, tests and `packet_renderer.py` stay outside that ZIP.

Offline verification:

```sh
python -m unittest discover -s tests -v
python -m py_compile diagnostic.py probe.py packet_renderer.py check_result.py tests/*.py
```

These tests use small generated archives and bounded Python process/cgroup simulations. They do not fetch, import or execute retained layers, Docker, FFmpeg, native code or an SDK.

Freeze and render a review request (does not make a provider call):

```sh
python -B packet_renderer.py --destination packet --nonce review000 \
  --source-key synthetic-benchmarks/codec-diagnostic-review000/source-envelope.json \
  --evidence-prefix synthetic-benchmarks/codec-diagnostic-review000/output \
  --role-arn arn:aws:iam::079358094174:role/codec-diagnostic-review000
```

Root must choose a fresh nonce and exact owned role/source/evidence names at admission, rerender, and review/pin the exact request. The renderer freezes the ZIP and canonical ASCII envelope before embedding their external identities in the NO_SOURCE inline bootstrap. Source objects cannot replace this initial verifier. Root uploads `code-envelope.json` as the literal ASCII PutObject Body string. The buildspec's absolute evidence-only base directory is `/tmp/cd/evidence`; the exact native destination is recorded in `readiness.json`. `encryptionDisabled:true` requires fresh private bucket-default AES256 and actual output HeadObject AES256 checks; it is not encryption proof.

Actual textual source GetObject responses have literal ASCII Body strings. `packet_renderer.verify_source_response(response, external_pins, ledger)` explicitly requires bounded literal ASCII, exact ContentLength and no ContentRange, then verifies the external envelope hash before parsing JSON. It never attempts base64 or falls back to another decoder. Binary output ZIP responses use the separately observed canonical-base64 contract: `packet_renderer.output_response(response, ledger)` bounds/canonically decodes each full evidence read and returns its binary identity. Pass the retained actual response byte count via `response_bytes` when different from the function's canonical JSON representation. Source calls charge actual carrier/metadata plus the actual ASCII byte copy; binary output calls charge actual carrier/metadata plus decoded binary, including repeated reads. Use a distinct 80 MiB Root transport/decode allocation and a separate 80 MiB local high-water accounting record; preserve transient copies and checker/hash reads in the fixed controller small-work reservation. Root must fetch output twice independently, retain matching binary pins and run:

```sh
python -B check_result.py evidence.zip --nonce <actual-nonce>
```

The checker loads this frozen directory's `pins.json` and `manifest.json` as external authority. Do not run an unreviewed checker from a downloaded output. A checker failure cannot be repaired with evidence from another attempt.

The live wrapper only starts through its explicit CLI after bootstrap verification. `CODEBUILD_START_TIME` is retained and used in milliseconds, consuming provisioning/source delays. Acquisition/load ends at provider second 240, cells by second 720, each cell encodes no later than its second 32 and closes by second 40, leaving 180 seconds for process closure/evidence/upload. No retry or fallback is allowed. Source/retained signing explicitly requests the regional us-east-1 S3 endpoint; bearer URLs remain memory-only. Parent cgroup v1 hierarchy, ancestor controls and actual keeper/FFmpeg process joins must be observed. Absent `controlVisibilityPolicy` retains strict full-root behavior. This private packet pins `allow-incomplete-delegated-v1`, permitting only the verified aligned v1 delegated view described below. Moved/unsupported controls produce finite negative records. The keeper waits for RELEASE after wait4/final counters. The child is UID/GID 65534, capability-free, network-none, read-only and receives no host environment.

Controller work reserves 11,055,652,581 of 12,884,901,888 bytes. Docker/native/kernel/interpreter/signing internals and synthetic media buffers are outside that ledger; their disk, memory and time bounds are separate. Disk monitoring covers source, evidence and owned Docker state using allocated blocks and free space. It is an operational sampled ceiling, not a filesystem quota. Cells include keeper overhead and shared-parent contention. Media-time warmup uses actual sampled coverage; absent metrics remain typed missing.

No actual image/provider execution has been performed by implementation. Root still owns fresh resource/budget admission, provider readback, one idempotent start, actual cgroup capability, two independent output reads, native encryption evidence, provider cleanup and two empty resource censuses.

Round 1 review fixes retain raw parent, keeper and reached FFmpeg membership, mountinfo, affinity, namespaces and every control-file path/text through the root ancestor. The checker reconstructs that hierarchy and joins it to raw counters and the exact case's FFmpeg argv. Incomplete pre-FFmpeg records validate their available stages. Docker attach group closure is an independent cleanup obligation; failure stops cell admission and retains the exact group for bounded final termination and absence observation, including when its argv lacks the owned root.

The observed managed signing operation took 12.4875 seconds. Source and retained-input signing now use at most 30 seconds, clamped to provider-start plus 240 seconds, with no retry or alternate credentials. The trusted source CLI owner reserves 0.5 seconds within that allowance for bounded group cleanup, records only elapsed time, exit/missing state, stream byte counts/EOF, PID/PGID and observed group absence, and fails when closure is unproved. A bounded `codec-bootstrap-cli-outcome-v1` success line can appear in CloudWatch; it contains no URL, raw streams or environment values.

The trusted bootstrap creates its fresh owned root before signing. Before the harness starts, a failure creates at most one 4 KiB `evidence/bootstrap-negative.json` with schema `codec-bootstrap-negative-v1`, state `failed_pre_harness`, nonce, external pins, stage, static reason and safe CLI outcome. Root validates this separately as zero measured cells; it cannot pass the normal twelve-cell checker. A successful bootstrap leaves `evidence/` creation to `diagnostic.run`. Existing roots are never taken over. These changes require a newly pinned source ZIP and external inline authority before another run.


The private delegated policy preserves hidden higher ancestors as unknown. Canonical controller membership is mapped relative to each visible mount root, using the collector's proven mount view. Aligned v1 roots, process/cgroup namespace and stable PID joins, all visible ancestor limits, exact two-CPU/4 GiB child controls and the existing image/isolation checks remain required. V2, hybrid, escaped, ambiguous, narrower or unjoined views block execution. Raw membership, mountinfo, independent namespace/affinity/process reads and control text persist before admission, including partial reads and a named failed subcheck. Parent facts are saved before topology selection and CLI signing.

A completed delegated cell is `incomplete` with `hidden_higher_ancestors`, `measurementStatus: partial`, `executionComplete: true`, `controlVisibility: delegated_subtree` and `fullHostVisible: false`. FPS, speed, CPU core-equivalents, memory peaks and throttle deltas retain verified values after all sample/process/argv/finite-output/EOF/final-counter/exit/no-OOM/cleanup joins succeed. CPU percent is missing with `effective_cpu_entitlement_unknown`; the requested leaf quota never supplies a denominator. Failed delegated cells keep their negative reason, raw facts and missing metrics, and stop later admission. Every cell remains unqualified.

CSV appends `measurementStatus,executionComplete,controlVisibility,fullHostVisible` on every metric row. The independent checker reconstructs mappings and proofs, recomputes rates and counters, joins kernel argv/namespace PID and raw stdout events, checks image/isolation and closure, and verifies CSV against JSON. Its `completedButIncomplete` count is separate from observed/censored/incomplete/not-run counts. Historical strict fixtures and old eight-column CSV remain supported; delegated cells require the extended CSV and the externally pinned policy. New capture/control fields consume the existing evidence and small-work reservations; overflow remains an honest negative and never expands those limits.

Runtime paths use the exclusively created private `/tmp/cd` bootstrap root, `/tmp/cd/code`, `/tmp/cd/evidence`, and runtime child `/tmp/cd/d`. Both roots carry exclusive `.owner` markers with the full attempt nonce. Existing roots and foreign markers are rejected. Before acquisition, every known Docker/containerd socket path, including the 64-hex shim suffix, must fit 103 ASCII bytes. Helper bytes remain pinned and unchanged.

Cleanup records whether the fresh private data root admitted no container creates, reconciled tracked creates, or has unproved container absence. A daemon that never became ready can close only with the first proof and proved owned process/group absence. Socket unlink requires those proofs, a matching owned Unix socket, a refused local connection, and an unchanged inode. Live sockets, foreign ownership, unclosed groups and uncertain tracked-container absence retain incomplete cleanup and state. The earlier failed run and its incomplete cleanup remain historical evidence.

Task 6 keeps the short control paths and exclusively creates `/codebuild/output/codec-<nonce>/data` for Docker state. Bounded live mountinfo must map the path to the existing read-write XFS mount, with matching device identities and no symlink or intervening mount. The private adapter verifies the pinned helper's one data-root argument, rewrites it, and appends explicit overlay2. Empty daemon config avoids duplicate settings. Actual Docker 24.0.9 client/server, overlay2, canonical owned data root, XFS and d_type support must verify before the single replay/load. Unsupported hosts stop without fallback.

The monitor starts only after both owned roots are fixed. Every scan shares 100000 entries, 0.8 seconds, 256 charged bytes per successful stat, 512 MiB small-work allowance and a 6 GiB aggregate allocated-block ceiling. Both backing filesystems retain the existing 8 GiB initial and 2 GiB during free-space thresholds. Per-root entries/blocks and incomplete scan context remain visible. After container/process/daemon closure, cleanup retains bounded mount absence, marker/source/path/inode checks and owned-directory absence. Any residual mount or ownership mismatch leaves an explicit obligation. The checker joins these additive facts without changing delegated measurement or qualification rules.
