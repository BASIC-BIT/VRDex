"""Independent generated adversarial fixtures and bounded process/cgroup simulations."""
import base64, gzip, hashlib, importlib.util, io, json, os, pathlib, shutil, stat, subprocess, sys, tarfile, tempfile, time, unittest, zipfile
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, packet_renderer as p, check_result as c, probe
from test_boundaries import wire,sha,zip_bytes

class Failures(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)
    def source(self):
        files={n:b'x' for n in p.FILES if n!='manifest.json'};files['manifest.json']=wire({n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()});return files
    def verify_files(self,files,manifest_override=None):
        z=zip_bytes(files);e=p.envelope(z);pins=p.identities(e,z,manifest_override or files['manifest.json']);return p.verify(e,pins)
    def test_manifest_and_zip_mutations_rejected(self):
        files=self.source();files['probe.py']=b'replacement'
        with self.assertRaises(p.Failure):self.verify_files(files)
        files=self.source();files['evil.py']=b'exec'
        with self.assertRaises(p.Failure):self.verify_files(files)
        files=self.source();files['manifest.json']=wire({'diagnostic.py':{'bytes':1,'sha256':sha(b'x')}})
        with self.assertRaises(p.Failure):self.verify_files(files)
        files=self.source();z=zip_bytes(files)[:-8];e=p.envelope(z)
        with self.assertRaises(p.Failure):p.verify(e,p.identities(e,z,files['manifest.json']))
    def test_bad_nested_base64_not_parsed_as_zip(self):
        files=self.source();z=zip_bytes(files);e=p.envelope(z);o=json.loads(e);o['zipBase64']=o['zipBase64'][:-1]+'!';bad=wire(o);pins=p.identities(bad,z,files['manifest.json'])
        with patch.object(p.zipfile,'ZipFile',side_effect=AssertionError('unverified ZIP parsed')):
            with self.assertRaises(p.Failure):p.verify(bad,pins)
    def test_malicious_source_cannot_replace_inline_initial_verifier(self):
        files=self.source();z=zip_bytes(files);e=p.envelope(z);pins=p.identities(e,z,files['manifest.json'])
        request,record=p.render(pins,nonce='test123',bucket='bucket',source_key='source',evidence_prefix='evidence/test123',role_arn='arn:aws:iam::079358094174:role/test')
        inline=request['source']['buildspec'];self.assertIn(pins['envelope']['sha256'],inline);self.assertNotIn('buildspec.yml',p.FILES)
        self.assertEqual(request['source']['type'],'NO_SOURCE');self.assertIs(request['artifacts']['encryptionDisabled'],True)
        self.assertEqual(record['artifactKey'],'evidence/test123/evidence.zip')
        hostile=b'print("execute replacement verifier")'
        with patch.object(p.json,'loads',side_effect=AssertionError('hostile parsed')):
            with self.assertRaises(p.Failure):p.verify(hostile,pins)
    def test_zip_duplicate_symlink_encryption_expansion_and_crc(self):
        cases=[]
        for kind in ('duplicate','symlink','encrypted','oversized','crc'):
            b=io.BytesIO()
            with zipfile.ZipFile(b,'w') as z:
                info=zipfile.ZipInfo('encoded/literal.bin');info.external_attr=((stat.S_IFLNK|0o777) if kind=='symlink' else (stat.S_IFREG|0o600))<<16
                z.writestr(info,b'abc')
                if kind=='duplicate':
                    import warnings
                    with warnings.catch_warnings():warnings.simplefilter('ignore');z.writestr(info,b'abc')
            raw=bytearray(b.getvalue())
            if kind=='encrypted':
                central=raw.index(b'PK\x01\x02');raw[central+8]|=1;raw[6]|=1
            if kind=='oversized':
                central=raw.index(b'PK\x01\x02');raw[central+24:central+28]=(400000000).to_bytes(4,'little')
            if kind=='crc':raw[raw.index(b'abc')]=ord('z')
            path=self.root/(kind+'.zip');path.write_bytes(raw)
            with self.assertRaises((d.Failure,zipfile.BadZipFile,RuntimeError)):
                d.extract_selected(path,self.root/kind,{'encoded/literal.bin':{'bytes':3,'sha256':sha(b'abc')}},10000,time.monotonic()+1)
    def test_unchanged_replay_fixture_and_late_corruption(self):
        pins=json.loads((pathlib.Path(d.__file__).parent/'pins.json').read_bytes())
        module=d.verified_module(pathlib.Path(d.__file__).parent/'support/encode.py','fixture_replay',pins['helpers']['support/encode.py'])
        body=b'generated body'*100;packed=gzip.compress(body,mtime=0);literal=b'header';whole=literal+body
        (self.root/'literal.bin').write_bytes(literal);(self.root/'layer-0000.gz').write_bytes(packed)
        descriptor={'schema':'lossless-save-v1','archive':{'complete':True,'bytes':len(whole),'sha256':sha(whole)},'literal_bytes':len(literal),'encoded_bytes':len(packed),'pieces':[{'kind':'literal','offset':0,'bytes':len(literal),'sha256':sha(literal),'file':'literal.bin','file_offset':0},{'kind':'gzip','offset':len(literal),'bytes':len(body),'sha256':sha(body),'encoded_bytes':len(packed),'encoded_sha256':sha(packed),'file':'layer-0000.gz','name':'abc/layer.tar'}]}
        (self.root/'descriptor.json').write_bytes(wire(descriptor));self.assertEqual(b''.join(module.replay(self.root)),whole)
        descriptor['archive']['sha256']='0'*64;(self.root/'descriptor.json').write_bytes(wire(descriptor))
        gen=module.replay(self.root);self.assertEqual(next(gen),literal)
        with self.assertRaises(module.EncodeError):list(gen)
    def test_helper_tar_facade_closes_owns_reads_without_global_patch(self):
        path=self.root/'t.tgz'
        with tarfile.open(path,'w:gz') as tf:
            data=b'x'*50;i=tarfile.TarInfo('docker/docker');i.size=len(data);tf.addfile(i,io.BytesIO(data))
        original=tarfile.open;facade=d.TarFacade(path.stat().st_size*2,time.monotonic()+1)
        with facade.open(path,'r:gz') as tf:self.assertEqual(tf.extractfile(tf.next()).read(),b'x'*50)
        self.assertIs(tarfile.open,original);self.assertGreater(facade.total,0)
        facade=d.TarFacade(1,time.monotonic()+1)
        with self.assertRaises(d.Failure):
            with facade.open(path,'r:gz') as tf:tf.next()
    def test_load_broken_pipe_timeout_and_missing_eof_are_finite(self):
        commands=[['import sys;sys.stdin.close();sys.exit(0)',iter([b'x'*65536]*4),262144],['import time;time.sleep(3)',iter([b'x']),1],['import os,time;pid=os.fork();time.sleep(3) if pid==0 else None',iter([b'x']),1]]
        for i,(code,gen,size) in enumerate(commands):
            start=time.monotonic()
            with self.assertRaises(d.Failure):d.stream_load(gen,[sys.executable,'-c',code],dict(os.environ),size,'0'*64,start+.2)
            self.assertLess(time.monotonic()-start,2)
    def test_progress_sample_reset_nan_and_unit_guards(self):
        for a,b in [({'t':1,'frame':2,'mediaUs':5000000,'cpuNs':5},{'t':1,'frame':4,'mediaUs':6000000,'cpuNs':6}),({'t':1,'frame':2,'mediaUs':5000000,'cpuNs':5},{'t':2,'frame':1,'mediaUs':6000000,'cpuNs':6})]:
            with self.assertRaises(d.Failure):d.derive([a,b],2)
        with self.assertRaises(d.Failure):d.derive([],4)
    def test_image_control_join_rejects_flags_lies(self):
        h={'NetworkMode':'none','ReadonlyRootfs':True,'Privileged':False,'Memory':4294967296,'MemorySwap':4294967296,'CpuPeriod':100000,'CpuQuota':200000,'CpusetCpus':'0,1','PidsLimit':128,'CapDrop':['ALL'],'SecurityOpt':['no-new-privileges']}
        value={'Image':'image','HostConfig':h,'Config':{'User':'65534:65534','Entrypoint':['python3']},'Mounts':[{'Source':'/probe','Destination':'/codec-probe.py','RW':False}]}
        d.inspect_child(value,{'imageId':'image'},[0,1],pathlib.Path('/probe'))
        value['Image']='wrong'
        with self.assertRaises(d.Failure):d.inspect_child(value,{'imageId':'image'},[0,1],pathlib.Path('/probe'))
        value['Image']='image';h['Memory']=0
        with self.assertRaises(d.Failure):d.inspect_child(value,{'imageId':'image'},[0,1],pathlib.Path('/probe'))
    def test_cgroup_fixture_missing_counters_and_moved_pid(self):
        proc=self.root/'proc';pid=proc/'42';pid.mkdir(parents=True);cg=self.root/'cgroup';cg.mkdir()
        for ctl in ('cpu','cpuacct','memory','cpuset'):(cg/ctl/'x').mkdir(parents=True)
        membership='\n'.join(f'{i}:{ctl}:/x' for i,ctl in enumerate(('cpu','cpuacct','memory','cpuset'),1))+'\n'
        (pid/'cgroup').write_text(membership);(pid/'mountinfo').write_text('\n'.join(f'1 0 0:1 / {cg/ctl} rw - cgroup cgroup rw,{ctl}' for ctl in ('cpu','cpuacct','memory','cpuset')))
        (pid/'stat').write_text('42 (keeper) '+' '.join(['0']*30));(pid/'ns').mkdir()
        for n in ('cgroup','mnt','pid','net','user'):(pid/'ns'/n).symlink_to('ns:'+n)
        with patch.object(d.os,'sched_getaffinity',return_value={0,1}):
            obs=d.Cgroups(42,proc)
            with self.assertRaises(FileNotFoundError):obs.snapshot()
            (pid/'cgroup').write_text(membership.replace('/x','/moved'))
            with self.assertRaises(d.Failure):obs.stable()
    def test_cgroup_hidden_mount_root_rejected(self):
        proc=self.root/'proc';pid=proc/'42';pid.mkdir(parents=True)
        (pid/'cgroup').write_text('1:cpu,cpuacct,memory,cpuset:/x\n');(pid/'mountinfo').write_text('1 0 0:1 /hidden /sys/fs/cgroup rw - cgroup cgroup rw,cpu,cpuacct,memory,cpuset')
        with self.assertRaises(d.Failure):d.Cgroups(42,proc)
    def test_checker_output_zip_inventory_and_stale_nonce(self):
        r=d.empty_result('expected',{'imageId':'image'},'setup_failed');r['cleanup']={'state':'closed'};r['inventory']={'raw':{'bytes':1,'sha256':sha(b'x')}}
        path=self.root/'out.zip';path.write_bytes(zip_bytes({'result.json':wire(r),'raw':b'x'}));self.assertEqual(c.read_zip(path,'expected',expected_pins={'imageId':'image'})['counts']['not_run'],12)
        with self.assertRaises(c.Invalid):c.read_zip(path,'stale',expected_pins={'imageId':'image'})
        path.write_bytes(zip_bytes({'result.json':wire(r),'raw':b'y'}))
        with self.assertRaises(c.Invalid):c.read_zip(path,'expected',expected_pins={'imageId':'image'})
    def test_no_source_import_side_effects(self):
        self.assertFalse(any(n in sys.modules for n in ('boto3','docker')))
        # Top-level imports never open a socket, start a process, or read layer bodies.
        source=pathlib.Path(d.__file__).read_text();self.assertNotIn('preflight.download(',source);self.assertNotIn('encode.encode(',source)
    def test_source_and_output_carrier_limits_before_decode(self):
        class Ledger:
            def charge(self,*args):pass
        for cap,carrier in [(3145728,4194304),(10485760,13981016)]:
            with self.assertRaises(p.Failure):p.decode_response({'Body':'A'*(carrier+4),'ContentLength':cap},cap,Ledger())
        with self.assertRaises(p.Failure):p.decode_response({'Body':'YWJj','ContentLength':3,'ContentRange':'bytes 0-2/4'},10,Ledger())

if __name__=='__main__':unittest.main()

class SetupBoundaries(unittest.TestCase):
    def test_monitor_finish_before_start_preserves_negative(self):
        with tempfile.TemporaryDirectory() as td:
            monitor=d.Monitor(pathlib.Path(td))
            facts=monitor.finish()
            self.assertEqual(facts['scans'],0)
    def test_synthetic_nan_and_initial_negative_counter_rejected(self):
        for sample in [{'t':float('nan'),'frame':1,'mediaUs':5000000,'cpuNs':1},{'t':1,'frame':-1,'mediaUs':5000000,'cpuNs':1}]:
            with self.assertRaises(d.Failure):d.derive([sample],2)
    def test_transport_wrong_length_still_charges_decoded_bytes(self):
        class Ledger:
            used=0
            def charge(self,name,n):self.used+=n
        led=Ledger()
        with self.assertRaises(p.Failure):p.decode_response({'Body':'YWJj','ContentLength':0},10,led)
        self.assertGreaterEqual(led.used,len(p.wire({'Body':'YWJj','ContentLength':0}))+3)
    def test_wrong_external_image_and_save_pin_rejected(self):
        r=d.empty_result('n',{'imageId':'wrong'},'setup_failed');r['cleanup']={'state':'closed'}
        with self.assertRaises(c.Invalid):c.check(r,{},'n',expected_pins={'imageId':'required'})
    def test_setup_control_failure_writes_all_cells_and_closes(self):
        import types
        with tempfile.TemporaryDirectory() as td:
            root=pathlib.Path(td);source=root/'source';source.mkdir();actual=pathlib.Path(d.__file__).parent
            for name in p.FILES:
                if name=='manifest.json':continue
                dest=source/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes((actual/name).read_bytes())
            p.freeze(source,root/'packet');runtime=pathlib.Path('/tmp')/root.name[-6:];runtime.mkdir();self.addCleanup(shutil.rmtree,runtime);(runtime/'.owner').write_text('test123\n')
            fake=types.SimpleNamespace(start=lambda:None,finish=lambda:{'fixture':True},check=lambda:None)
            with patch.object(d,'__file__',str(source/'diagnostic.py')),patch.object(d,'Monitor',return_value=fake),patch.object(d,'Cgroups',side_effect=d.Failure('resource_control_unproven')):
                result=d.run('test123',runtime/'evidence',time.time())
            self.assertEqual(result['cleanup']['state'],'closed');self.assertEqual(len(result['cells']),12)
            self.assertTrue(all(x['state']=='not_run' and x['reason']=='resource_control_unproven' for x in result['cells']))
            self.assertTrue((runtime/'evidence/result.json').exists());self.assertEqual(result['failedStage'],'parent_controls')
    def test_regional_signing_contract_is_explicit(self):
        self.assertEqual(d.signing_environment({})['AWS_S3_US_EAST_1_REGIONAL_ENDPOINT'],'regional')
        source=p.render(p.identities(b'e',b'z',b'm'),nonce='test123',bucket='b',source_key='s',evidence_prefix='e',role_arn='r')[0]['source']['buildspec']
        self.assertIn('AWS_S3_US_EAST_1_REGIONAL_ENDPOINT',source)
    def test_successful_command_with_unclosed_group_is_negative(self):
        with patch.object(d,'kill_group',return_value=False):
            with self.assertRaises(d.Failure):d.command([sys.executable,'-c','pass'],dict(os.environ),time.monotonic()+1)
