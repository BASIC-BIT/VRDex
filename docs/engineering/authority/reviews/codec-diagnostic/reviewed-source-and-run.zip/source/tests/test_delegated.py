"""Generated aligned-v1 fixtures; no host, codec, provider or image execution."""
import copy,json,os,pathlib,sys,tempfile,unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, check_result as checker, probe
import test_runtime
POLICY='allow-incomplete-delegated-v1'
ROOT='/ecs/task-fixture/container-fixture'
CTLS=('cpu','cpuacct','memory','cpuset')
def hierarchy(path=ROOT,root=ROOT):
    membership='1:cpu,cpuacct:/PATH\n2:memory:/PATH\n3:cpuset:/PATH\n'.replace('/PATH',path)
    mounts='\n'.join(f'{i} 0 0:{i} {root} /sys/fs/cgroup/{c} rw - cgroup cgroup rw,{c}' for i,c in [(1,'cpu,cpuacct'),(2,'memory'),(3,'cpuset')])
    return {'membership':membership,'mountinfo':mounts}
def seal_capture(raw):
    raw.update(complete=True,readErrors={},capturedAt=1,fields={})
    values={'membership':raw['membership'],'mountinfo':raw['mountinfo'],'affinity':raw['affinity'],**{'namespaces.'+n:v for n,v in raw['namespaces'].items()},**{'identity.'+n:raw['identity'][n] for n in ('stat','cmdline','status')}}
    for name,value in values.items():
        suffix={'membership':'cgroup','mountinfo':'mountinfo','affinity':'status:sched_getaffinity'}.get(name,name.split('.',1)[-1] if name.startswith('identity.') else 'ns/'+name.split('.',1)[-1])
        raw['fields'][name]={'path':f"/proc/{raw['pid']}/{suffix}",'t':1,'complete':True,'value':copy.deepcopy(value)}
    if 'controlFiles' in raw:raw['controlReads']={name:{'path':name,'t':1,'complete':True,'value':value} for name,value in raw['controlFiles'].items()}
    if 'collector' in raw:seal_capture(raw['collector'])
    return raw
def fixture_namespaces(child=False):
    return {n:f'{n}:[{200+i if child and n in ("mnt","pid","net") else 100+i}]' for i,n in enumerate(('cgroup','mnt','pid','net','user'),1)}
def fixture(path=ROOT,pid=41,child=False):
    raw=hierarchy(path);raw.update(pid=pid,namespaces=fixture_namespaces(child),affinity=[0,1] if child else [0,1,2,3],controlFiles={})
    raw['identity']={'startTime':'100','stat':str(pid)+' (fixture) '+' '.join(['0']*19+['100']+['0']*10),'cmdline':'python3\u0000','status':f'NSpid:\t{pid}\t7\n'}
    for p in [path]+([] if path==ROOT else [ROOT]):
        vals={'cpu.cfs_quota_us':'200000' if p!=ROOT else '-1','cpu.cfs_period_us':'100000','memory.limit_in_bytes':'4294967296' if p!=ROOT else '7247757312','memory.memsw.limit_in_bytes':'4294967296' if p!=ROOT else '14495514624','cpuset.cpus':'0,1' if p!=ROOT else '0-3'}
        for c,n in d.CONTROL_FILES:
            m='cpu,cpuacct' if c=='cpu' else c
            raw['controlFiles'][str(pathlib.PurePosixPath('/sys/fs/cgroup')/m/pathlib.PurePosixPath(p).relative_to(ROOT)/n)]=vals[n]
    raw['collector']=copy.deepcopy({k:v for k,v in fixture_base().items()})
    return seal_capture(raw)
def fixture_base():
    x=hierarchy();x.update(pid=41,namespaces=fixture_namespaces(),affinity=[0,1,2,3],identity={'startTime':'100','stat':'41 (fixture) '+' '.join(['0']*19+['100']+['0']*10),'cmdline':'python3\u0000','status':'NSpid:\t41\t41\n'})
    return x
class Delegated(unittest.TestCase):
    def test_aligned_visible_root_maps_without_fabricating_host_root(self):
        raw=fixture();h=d.resolve_visible_v1(raw,POLICY)
        self.assertEqual(h['visibility'],'delegated_subtree');self.assertFalse(h['fullHostVisible']);self.assertEqual(h['roots'],dict.fromkeys(CTLS,ROOT))
        leaf,anc,_,mounts=d.reconstruct_controls(raw,POLICY)
        self.assertEqual(leaf['path'],ROOT);self.assertEqual(anc,[]);self.assertEqual(str(mounts['cpu']),'/sys/fs/cgroup/cpu,cpuacct')
        with self.assertRaises(d.Failure):d.resolve_visible_v1(raw,None)
    def test_bad_roots_escape_duplicates_v2_and_hybrid_rejected(self):
        base=fixture()
        for membership,mountinfo in [(base['membership'].replace(ROOT,ROOT+'/../escape'),base['mountinfo']), (base['membership'],base['mountinfo'].replace(ROOT,ROOT+'x',1)),(base['membership'],base['mountinfo']+'\n'+base['mountinfo'].splitlines()[0]),(base['membership']+'0::/\n',base['mountinfo']), (base['membership'],base['mountinfo']+'\n8 0 0:8 / /sys/fs/cgroup/unified rw - cgroup2 cgroup rw')]:
            raw=copy.deepcopy(base);raw.update(membership=membership,mountinfo=mountinfo)
            with self.subTest(membership=membership,mountinfo=mountinfo),self.assertRaises(d.Failure):d.resolve_visible_v1(raw,POLICY)
    def test_proof_preserves_unknown_and_rejects_visible_conflicts_or_unproven_view(self):
        parent=fixture();keeper=fixture(ROOT+'/docker/leaf',42,True);ff=fixture(ROOT+'/docker/leaf',43,True)
        # Include the intermediate visible ancestor, as the real hierarchy walk requires.
        for raw in (keeper,ff):
            for k,v in list(parent['controlFiles'].items()):raw['controlFiles'][k.replace('/'+k.rsplit('/',1)[-1],'/docker/'+k.rsplit('/',1)[-1])]=v
        seal_capture(keeper);seal_capture(ff)
        proof=d.prove_visible_controls(parent,keeper,ff,POLICY)
        self.assertIsNone(proof['effectiveCpus']);self.assertFalse(proof['fullHostVisible']);self.assertEqual(proof['leafQuotaCores'],2);self.assertEqual(len(proof['unknownHigherAncestors']),4)
        for mutate in [lambda p,k,f:p['controlFiles'].__setitem__('/sys/fs/cgroup/cpu,cpuacct/cpu.cfs_quota_us','100000'),lambda p,k,f:k['collector']['namespaces'].__setitem__('cgroup','unrelated'),lambda p,k,f:k['collector'].__setitem__('mountinfo',k['collector']['mountinfo'].replace('0:1','0:9')),lambda p,k,f:f['namespaces'].__setitem__('mnt','unrelated'),lambda p,k,f:k['controlFiles'].pop(next(iter(k['controlFiles'])))]:
            p,k,f=copy.deepcopy((parent,keeper,ff));mutate(p,k,f);seal_capture(p);seal_capture(k);seal_capture(f)
            with self.assertRaises(d.Failure):d.prove_visible_controls(p,k,f,POLICY)
    def test_partial_capture_survives_parse_and_read_failures(self):
        with tempfile.TemporaryDirectory() as td:
            r=pathlib.Path(td);p=r/'42';p.mkdir();(p/'cgroup').write_text('0::/bad\n');(p/'mountinfo').write_text('malformed')
            saved=[]
            with patch.object(d.os,'sched_getaffinity',return_value={0,1}):
                with self.assertRaises(d.Failure):d.Cgroups(42,r,policy=POLICY,sink=lambda x:saved.append(copy.deepcopy(x)))
            self.assertTrue(saved);last=saved[-1];self.assertEqual(last['membership'],'0::/bad\n');self.assertEqual(last['mountinfo'],'malformed');self.assertIn('namespaces.cgroup',last['readErrors']);self.assertEqual(last['failedSubcheck'],'resource_control_unproven')
    def test_null_denominator_needs_proof_and_preserves_absolute_values(self):
        samples=[{'t':1,'frame':180,'mediaUs':6000000,'cpuNs':1000000000},{'t':11,'frame':750,'mediaUs':25000000,'cpuNs':16000000000}]
        with self.assertRaises(d.Failure):d.derive(samples,None)
        proof={'visibility':'delegated_subtree','fullHostVisible':False,'effectiveCpus':None}
        values=d.derive(samples,None,['raw'],proof=proof)
        self.assertEqual(values['fps']['value'],57);self.assertEqual(values['speed']['value'],1.9);self.assertEqual(values['cpuCores']['value'],1.5);self.assertEqual(values['cpuPercent'],d.missing('effective_cpu_entitlement_unknown'))

class DelegatedExecution(unittest.TestCase):
    setUp=test_runtime.Runtime.setUp
    fake_cell=test_runtime.Runtime.fake_cell
    def artifact(self,behavior='success'):
        cell,ev=self.fake_cell(behavior,delegated=True)
        pins={'imageId':'image','controlVisibilityPolicy':POLICY}
        result=d.empty_result('test123',pins,'fixture_unrun');result['cells'][0]=cell;result['cleanup']={'state':'closed'}
        files={name:(ev.root/name).read_bytes() for name in ev.inventory};files['metrics.csv']=d.metrics_csv(result['cells'])
        result['inventory']={n:{'bytes':len(b),'sha256':d.sha(b)} for n,b in files.items()}
        return cell,result,files,pins
    def rehash(self,result,files):result['inventory']={n:{'bytes':len(b),'sha256':d.sha(b)} for n,b in files.items()}
    def test_completed_delegated_stays_incomplete_with_available_metrics(self):
        cell,result,files,pins=self.artifact()
        self.assertEqual(cell['state'],'incomplete',cell);self.assertEqual(cell['reason'],'hidden_higher_ancestors');self.assertEqual(cell['measurementStatus'],'partial');self.assertTrue(cell['executionComplete']);self.assertFalse(cell['fullHostVisible']);self.assertIsNone(d.cell_blocker(cell))
        self.assertEqual(cell['metrics']['fps']['state'],'available');self.assertEqual(cell['metrics']['cpuPercent'],d.missing('effective_cpu_entitlement_unknown'))
        outcome=checker.check(result,files,'test123',expected_pins=pins);self.assertEqual(outcome['completedButIncomplete'],1)
    def test_delegated_observed_cpu_percent_metric_and_csv_forgery_rejected(self):
        for mutation in ('observed','percent','rate','csv','ancestry','entitlement','policy'):
            with self.subTest(mutation=mutation):
                cell,result,files,pins=self.artifact()
                if mutation=='observed':cell['state']='observed';cell['reason']=None
                elif mutation=='percent':cell['metrics']['cpuPercent']=copy.deepcopy(cell['metrics']['cpuCores'])
                elif mutation=='rate':cell['metrics']['fps']['value']+=1
                elif mutation=='csv':files['metrics.csv']=files['metrics.csv'].replace(b',partial,',b',complete,')
                elif mutation=='policy':pins={'imageId':'image'};result['identities']=pins
                else:
                    name=cell['sourceRefs'][0];raw=json.loads(files[name])
                    if mutation=='ancestry':raw['controls']['unknownHigherAncestors']=[]
                    else:raw['controls']['effectiveCpus']=2
                    files[name]=d.wire(raw)
                self.rehash(result,files)
                with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
                self.doCleanups();self.setUp()
    def test_completion_joins_required_even_when_result_incomplete(self):
        for mutation in ('argv','stdoutEOF','stderrEOF','progressEnd','final','cleanup','counter','identity'):
            with self.subTest(mutation=mutation):
                cell,result,files,pins=self.artifact();name=cell['sourceRefs'][0];raw=json.loads(files[name])
                if mutation=='argv':raw['ffmpeg']['argv']=['wrong']
                elif mutation=='final':raw['final']=None
                elif mutation=='cleanup':raw['cleanup']['attachGroupClosed']=False;cell['cleanup']=raw['cleanup']
                elif mutation=='counter':raw['snapshots'][0]['values']['cpuacct.usage']+=1
                elif mutation=='identity':raw['ffmpeg']['identity']['startTime']='999'
                else:raw[mutation]=False
                files[name]=d.wire(raw);self.rehash(result,files)
                with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
                self.doCleanups();self.setUp()
    def test_failed_delegated_retains_reason_and_missing_values(self):
        cell,_,_,_=self.artifact('oom')
        self.assertEqual(cell['state'],'censored');self.assertEqual(cell['reason'],'oom');self.assertFalse(cell['executionComplete']);self.assertTrue(all(x['state']=='missing' for x in cell['metrics'].values()))

class DelegatedAdversarial(unittest.TestCase):
    setUp=DelegatedExecution.setUp
    fake_cell=DelegatedExecution.fake_cell
    artifact=DelegatedExecution.artifact
    rehash=DelegatedExecution.rehash
    def test_independent_checker_rejects_raw_proof_and_join_forgery(self):
        mutations={
            'ready_image':lambda r:r['readyInspect'].__setitem__('Image','wrong'),
            'container_id':lambda r:r['terminalInspect'].__setitem__('Id','b'*64),
            'terminal_network':lambda r:r['terminalInspect']['HostConfig'].__setitem__('NetworkMode','host'),
            'create_argv':lambda r:r['createArgv'].__setitem__(3,'wrong-name'),
            'raw_capture_field':lambda r:r['ffmpeg']['fields']['membership'].__setitem__('value','1:cpu:/elsewhere'),
            'collector_root':lambda r:r['keeper']['collector'].__setitem__('membership',r['keeper']['collector']['membership'].replace(ROOT,ROOT+'x')),
            'collector_mountpoint':lambda r:r['keeper']['collector'].__setitem__('mountinfo',r['keeper']['collector']['mountinfo'].replace('/sys/fs/cgroup/','/unrelated/')),
            'namespace':lambda r:r['ffmpeg']['namespaces'].__setitem__('mnt','other'),
            'nspid':lambda r:r['ffmpeg']['identity'].__setitem__('status','NSpid:\t43\t999\n'),
            'exit_event':lambda r:r['events'][-1]['message'].__setitem__('exitCode',9),
            'progress_event_end':lambda r:r['events'][-2]['message']['raw'].__setitem__('progress','continue'),
            'counter_reset':lambda r:(r['final']['values'].__setitem__('cpuacct.usage',0),r['final']['raw'].__setitem__('/sys/fs/cgroup/cpu,cpuacct/leaf/cpuacct.usage','0')),
        }
        for label,mutate in mutations.items():
            with self.subTest(label=label):
                cell,result,files,pins=self.artifact();name=cell['sourceRefs'][0];raw=json.loads(files[name]);mutate(raw);files[name]=d.wire(raw);self.rehash(result,files)
                with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
                self.doCleanups();self.setUp()
    def test_checker_does_not_reuse_runtime_mapping_or_rate_proof(self):
        _,result,files,pins=self.artifact()
        with patch.object(d,'resolve_visible_v1',side_effect=AssertionError('runtime mapping reused')),patch.object(d,'prove_visible_controls',side_effect=AssertionError('runtime proof reused')),patch.object(d,'derive',side_effect=AssertionError('runtime derivation reused')):
            self.assertEqual(checker.check(result,files,'test123',expected_pins=pins)['completedButIncomplete'],1)
    def test_source_proof_rejects_unjoined_collector_and_partial_capture(self):
        parent=fixture();keeper=fixture(ROOT+'/leaf',42,True);ff=fixture(ROOT+'/leaf',43,True)
        for change in [lambda k:k['collector'].__setitem__('membership',k['collector']['membership'].replace(ROOT,ROOT+'x')),lambda k:k.__setitem__('complete',False),lambda k:k['fields']['membership'].__setitem__('value','wrong')]:
            k=copy.deepcopy(keeper);change(k)
            with self.assertRaises(d.Failure):d.prove_visible_controls(parent,k,ff,POLICY)

class CaptureIntegration(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)
    def proc(self,pid,path,child=False,mountinfo=None):
        raw=fixture(path,pid,child);p=self.root/'proc'/str(pid);p.mkdir(parents=True)
        for n,value in [('cgroup',raw['membership']),('mountinfo',mountinfo or raw['mountinfo']),*[(n,raw['identity'][n]) for n in ('stat','cmdline','status')]]:(p/n).write_text(value)
        (p/'ns').mkdir()
        for n,value in raw['namespaces'].items():(p/'ns'/n).symlink_to(value)
        return p
    def actual_files(self):
        mount=self.root/'controls';mount.mkdir()
        for member in (ROOT,ROOT+'/leaf'):
            raw=fixture(member,42,member!=ROOT)
            for name,value in raw['controlFiles'].items():
                p=mount/pathlib.PurePosixPath(name).relative_to('/sys/fs/cgroup');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value)
        return mount
    def test_target_paths_are_read_through_proven_collector_view(self):
        mount=self.actual_files();parent_mounts=hierarchy()['mountinfo'].replace('/sys/fs/cgroup',str(mount));target_mounts=hierarchy(ROOT+'/leaf')['mountinfo'].replace('/sys/fs/cgroup','/target-only/cgroup')
        self.proc(os.getpid(),ROOT,mountinfo=parent_mounts);self.proc(42,ROOT+'/leaf',True,target_mounts);saved=[]
        with patch.object(d.os,'sched_getaffinity',side_effect=lambda pid:{0,1} if pid==42 else {0,1,2,3}):
            cg=d.Cgroups(42,self.root/'proc',policy=POLICY,sink=lambda r:saved.append(copy.deepcopy(r)));raw=cg.evidence()
            self.assertTrue(all(name.startswith(str(mount)) for name in raw['controlFiles']));leaf,anc,_,_=d.reconstruct_controls(raw,POLICY);self.assertEqual(leaf['quota'],200000);self.assertEqual(len(anc),1)
            self.assertEqual(str(cg.path('cpu')),str(mount/'cpu,cpuacct'/'leaf'))
            (self.root/'proc'/'42'/'ns'/'mnt').unlink();(self.root/'proc'/'42'/'ns'/'mnt').symlink_to('changed')
            with self.assertRaises(d.Failure):cg.stable()
    def test_malformed_control_retains_raw_text_and_specific_subcheck(self):
        mount=self.actual_files();mi=hierarchy()['mountinfo'].replace('/sys/fs/cgroup',str(mount));self.proc(os.getpid(),ROOT,mountinfo=mi);self.proc(42,ROOT+'/leaf',True,mi)
        bad=mount/'cpu,cpuacct'/'leaf'/'cpu.cfs_quota_us';bad.write_text('malformed');saved=[]
        with patch.object(d.os,'sched_getaffinity',side_effect=lambda pid:{0,1} if pid==42 else {0,1,2,3}):
            cg=d.Cgroups(42,self.root/'proc',policy=POLICY,sink=lambda r:saved.append(copy.deepcopy(r)))
            with self.assertRaises(d.Failure):cg.evidence()
        self.assertEqual(saved[-1]['controlFiles'][str(bad)],'malformed');self.assertEqual(saved[-1]['failedSubcheck'],'control_source_invalid')
    def test_constructor_failure_keeps_host_evidence_without_cli(self):
        from types import SimpleNamespace
        sink_data={'pid':os.getpid(),'membership':'0::/unsupported\n','mountinfo':'retained raw','readErrors':{},'failedSubcheck':'resource_control_unproven'}
        def failing_capture(pid,**kw):kw['sink'](sink_data);raise d.Failure('resource_control_unproven')
        monitor=SimpleNamespace(start=lambda:None,finish=lambda:{})
        runtime=pathlib.Path('/tmp')/self.root.name[-6:];runtime.mkdir();(runtime/'.owner').write_text('capture-test\n')
        self.addCleanup(__import__('shutil').rmtree,runtime)
        with patch.object(d,'Cgroups',side_effect=failing_capture),patch.object(d,'Monitor',return_value=monitor),patch.object(d,'verified_module',return_value=None),patch.object(d,'command',side_effect=AssertionError('CLI called before host admission')),patch.object(d,'owned_processes',return_value=[]):
            result=d.run('capture-test',runtime/'evidence',__import__('time').time())
        self.assertEqual(result['failure'],'resource_control_unproven');self.assertEqual(result['host']['failedSubcheck'],'resource_control_unproven');self.assertEqual(json.loads((runtime/'evidence'/'parent-capture.json').read_bytes()),sink_data)

class CompletionGuard(unittest.TestCase):
    setUp=test_runtime.Runtime.setUp
    fake_cell=test_runtime.Runtime.fake_cell
    def test_final_counter_reset_cannot_create_available_partial_rates(self):
        cell,ev=self.fake_cell('success',delegated=True);raw=json.loads((ev.root/cell['sourceRefs'][0]).read_bytes());self.assertTrue(d.execution_complete(raw))
        raw['final']['values']['cpuacct.usage']=0
        self.assertFalse(d.execution_complete(raw))

class NegativeControls(unittest.TestCase):
    setUp=DelegatedExecution.setUp
    fake_cell=DelegatedExecution.fake_cell
    artifact=DelegatedExecution.artifact
    rehash=DelegatedExecution.rehash
    def test_negative_visible_control_failure_is_checkable_with_raw_facts(self):
        cell,result,files,pins=self.artifact();name=cell['sourceRefs'][0];raw=json.loads(files[name])
        raw['controls']=None;raw.pop('ffmpeg');raw['events']=raw['events'][:1];raw['samples']=[];raw['snapshots']=[];raw['exit']=None;raw['final']=None;raw['reason']='resource_control_unproven'
        raw['keeper']['controlFiles']['/sys/fs/cgroup/cpu,cpuacct/leaf/cpu.cfs_quota_us']='100000';raw['keeper']['controlReads']['/sys/fs/cgroup/cpu,cpuacct/leaf/cpu.cfs_quota_us']['value']='100000'
        cell.update(reason='resource_control_unproven',executionComplete=False);cell['metrics']={k:d.missing('resource_control_unproven') for k in d.METRICS};files[name]=d.wire(raw);files['metrics.csv']=d.metrics_csv(result['cells']);self.rehash(result,files)
        self.assertEqual(checker.check(result,files,'test123',expected_pins=pins)['counts']['incomplete'],1)
    def test_failed_execution_is_checkable_without_available_values(self):
        _,result,files,pins=self.artifact('oom');self.assertEqual(checker.check(result,files,'test123',expected_pins=pins)['counts']['censored'],1)

class ControlSyntax(unittest.TestCase):
    def test_empty_or_malformed_cpuset_cannot_become_a_visible_constraint(self):
        for text in ('0,,1','0-1-2','-1','0-'):
            raw=fixture(ROOT+'/leaf',42,True);raw['controlFiles']['/sys/fs/cgroup/cpuset/leaf/cpuset.cpus']=text
            with self.subTest(text=text),self.assertRaises(d.Failure):d.reconstruct_controls(raw,POLICY)

class CollectorMappingScope(unittest.TestCase):
    def test_unrelated_new_mount_does_not_change_proven_controller_view(self):
        parent=fixture();keeper=fixture(ROOT+'/leaf',42,True);ff=fixture(ROOT+'/leaf',43,True)
        for raw in (keeper,ff):raw['collector']['mountinfo']+='\n9 0 0:9 / /unrelated rw - tmpfs tmpfs rw';seal_capture(raw)
        self.assertIsNone(d.prove_visible_controls(parent,keeper,ff,POLICY)['effectiveCpus'])

class CaptureReferences(unittest.TestCase):
    setUp=DelegatedExecution.setUp
    fake_cell=DelegatedExecution.fake_cell
    artifact=DelegatedExecution.artifact
    rehash=DelegatedExecution.rehash
    def test_mismatched_or_missing_independent_capture_reference_is_rejected(self):
        for label in ('missing','changed','unreferenced'):
            with self.subTest(label=label):
                cell,result,files,pins=self.artifact();name=cell['sourceRefs'][0];raw=json.loads(files[name]);capture=raw['processCaptures'][0]
                if label=='missing':files.pop(capture)
                elif label=='changed':fact=json.loads(files[capture]);fact['identity']['startTime']='wrong';files[capture]=d.wire(fact)
                else:raw['processCaptures']=[];files[name]=d.wire(raw)
                self.rehash(result,files)
                with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
                self.doCleanups();self.setUp()

    def test_runtime_container_identity_mismatch_blocks_metrics(self):
        cell,_=self.fake_cell('container_mismatch',delegated=True)
        self.assertEqual(cell['state'],'incomplete');self.assertEqual(cell['reason'],'container_identity');self.assertTrue(all(m['state']=='missing' for m in cell['metrics'].values()))

    def test_wrong_exit_process_or_missing_wait4_peak_erases_partial_metrics(self):
        for behavior in ('wrong_exit_pid','missing_peak'):
            with self.subTest(behavior=behavior):
                cell,_=self.fake_cell(behavior,delegated=True)
                self.assertEqual(cell['state'],'incomplete');self.assertFalse(cell['executionComplete']);self.assertTrue(all(m['state']=='missing' for m in cell['metrics'].values()))
                self.doCleanups();self.setUp()

class ControlReadFacts(unittest.TestCase):
    def test_missing_or_unjoined_control_read_facts_block_proof(self):
        for missing in (True,False):
            parent=fixture();keeper=fixture(ROOT+'/leaf',42,True);ff=fixture(ROOT+'/leaf',43,True)
            if missing:keeper.pop('controlReads')
            else:keeper['controlReads'][next(iter(keeper['controlReads']))]['value']='wrong'
            with self.assertRaises(d.Failure):d.prove_visible_controls(parent,keeper,ff,POLICY)

class AttachExitEvidence(unittest.TestCase):
    setUp=DelegatedExecution.setUp
    fake_cell=DelegatedExecution.fake_cell
    artifact=DelegatedExecution.artifact
    rehash=DelegatedExecution.rehash
    def test_completed_partial_retains_actual_attach_exit(self):
        cell,result,files,pins=self.artifact();name=cell['sourceRefs'][0];raw=json.loads(files[name]);self.assertEqual(raw.get('attachExitCode'),0)
        raw['attachExitCode']=1;files[name]=d.wire(raw);self.rehash(result,files)
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)


class ReviewRoundOne(unittest.TestCase):
    setUp=DelegatedExecution.setUp
    fake_cell=DelegatedExecution.fake_cell
    artifact=DelegatedExecution.artifact
    rehash=DelegatedExecution.rehash
    def retain_changed_artifact(self,cell,result,files,raw):
        for key,name in zip(('keeper','ffmpeg'),raw['processCaptures']):
            files[name]=d.wire({k:v for k,v in raw[key].items() if k not in ('hostPid','namespacePid','argv')})
        stdout='cell-00-stdout.log';files[stdout]=b''.join(d.wire(event['message']) for event in raw['events']);raw['stdoutBytes']=len(files[stdout])
        files[cell['sourceRefs'][0]]=d.wire(raw);files['metrics.csv']=d.metrics_csv(result['cells']);self.rehash(result,files)
    def test_r1_runtime_rejects_unknown_or_malformed_sealed_namespace_ids(self):
        for key,value in [('cgroup',''),('mnt',None),('pid','pid:[0]'),('net','net:unknown'),('user','pid:[100]')]:
            with self.subTest(key=key,value=value):
                processes=[fixture(),fixture(ROOT+'/leaf',42,True),fixture(ROOT+'/leaf',43,True)]
                for process in processes if key=='cgroup' else processes[1:]:
                    process['namespaces'][key]=value
                    if key=='cgroup':process['collector']['namespaces'][key]=value
                    seal_capture(process)
                with self.assertRaises(d.Failure):d.prove_visible_controls(*processes,POLICY)
    def test_r1_checker_rejects_unknown_namespace_with_consistent_capture_and_ready(self):
        cell,result,files,pins=self.artifact();raw=json.loads(files[cell['sourceRefs'][0]])
        for key in ('parent','keeper','ffmpeg'):
            raw[key]['namespaces']['cgroup']='';raw[key]['collector']['namespaces']['cgroup']='';seal_capture(raw[key])
        raw['events'][0]['message']['facts']['namespaces']['cgroup']=''
        self.retain_changed_artifact(cell,result,files,raw)
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
    def test_r1_checker_requires_known_matching_ready_namespace_facts(self):
        for mutation in ('missing','contradictory','malformed'):
            with self.subTest(mutation=mutation):
                cell,result,files,pins=self.artifact();raw=json.loads(files[cell['sourceRefs'][0]]);facts=raw['events'][0]['message']['facts']
                if mutation=='missing':facts.pop('namespaces')
                elif mutation=='contradictory':facts['namespaces']={n:f'{n}:[999999]' for n in fixture_namespaces()}
                else:facts['namespaces']['cgroup']=''
                self.retain_changed_artifact(cell,result,files,raw)
                with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
                self.doCleanups();self.setUp()
    def test_r1_runtime_ready_namespace_mismatch_or_absence_blocks_metrics(self):
        for behavior in ('ready_namespace_missing','ready_namespace_mismatch'):
            with self.subTest(behavior=behavior):
                cell,_=self.fake_cell(behavior,delegated=True)
                self.assertFalse(cell['executionComplete']);self.assertTrue(all(m['state']=='missing' for m in cell['metrics'].values()))
                self.doCleanups();self.setUp()
    def test_r2_no_raw_completed_claim_rejected_even_with_matching_csv(self):
        for metadata in ({}, {'measurementStatus':'complete'}, {'controlVisibility':'full_root'}, {'fullHostVisible':True}):
            with self.subTest(metadata=metadata):
                pins={'imageId':'image','controlVisibilityPolicy':POLICY};result=d.empty_result('review',pins,'not_started');cell=result['cells'][0]
                cell.update(state='incomplete',reason='hidden_higher_ancestors',executionComplete=True,controlVisibility='delegated_subtree',measurementStatus='partial',fullHostVisible=False,ancestryLimitation='hidden_higher_ancestors');cell.update(metadata)
                files={'metrics.csv':d.metrics_csv(result['cells'])};self.rehash(result,files)
                with self.assertRaises(checker.Invalid):checker.check(result,files,'review',expected_pins=pins)
    def test_r2_removed_raw_refs_cannot_preserve_completion_count(self):
        cell,result,files,pins=self.artifact();cell.pop('sourceRefs');cell['metrics']={k:d.missing('missing_evidence') for k in d.METRICS};files['metrics.csv']=d.metrics_csv(result['cells']);self.rehash(result,files)
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins=pins)
    def test_r2_historical_missing_raw_negative_remains_valid(self):
        pins={'imageId':'image'};result=d.empty_result('review',pins,'not_started');result['cells'][0].update(state='incomplete',reason='missing_evidence');files={'metrics.csv':d.metrics_csv(result['cells'])};self.rehash(result,files)
        self.assertEqual(checker.check(result,files,'review',expected_pins=pins)['completedButIncomplete'],0)
