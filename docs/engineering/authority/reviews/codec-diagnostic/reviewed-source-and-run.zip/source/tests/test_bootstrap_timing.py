"""Bounded Python-only signing supervision and pre-source negative-artifact tests."""
import contextlib, io, json, os, pathlib, subprocess, sys, tempfile, time, unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, packet_renderer as p

class BootstrapTiming(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)/'owned';self.pins={k:{'bytes':1,'sha256':'a'*64} for k in ('envelope','zip','manifest')}
    def safe(self,reason=None,closed=True):return {'operation':'source_presign','reason':reason,'pid':123,'pgid':123,'bytes':{'stdout':10,'stderr':0},'eof':{'stdout':True,'stderr':True},'exit':{'state':'available','code':0},'groupClosed':closed,'elapsedSeconds':1.0,'totalSeconds':1.0}
    def test_both_signing_paths_use_30_seconds_clamped_to_setup(self):
        for module in (p,d):
            self.assertTrue(callable(getattr(module,'signing_deadline',None)),'missing signing clamp')
            with patch.object(module.time,'monotonic',return_value=100):
                self.assertEqual(module.signing_deadline(500),130);self.assertEqual(module.signing_deadline(110),110)
    def test_cli_success_returns_safe_facts_without_recording_stream_contents(self):
        secret='https://bearer.invalid/?token=private'
        value,safe=p.cli([sys.executable,'-c',f'import sys;print({secret!r});print("raw-secret-stderr",file=sys.stderr)'],time.monotonic()+2)
        self.assertEqual(value,secret);encoded=json.dumps(safe)
        self.assertNotIn(secret,encoded);self.assertNotIn('raw-secret',encoded);self.assertTrue(safe['groupClosed']);self.assertTrue(all(safe['eof'].values()));self.assertEqual(safe['exit'],{'state':'available','code':0});self.assertGreater(safe['bytes']['stderr'],0)
    def test_cli_nonzero_and_deadline_expose_only_safe_outcome(self):
        for code,seconds in [('import sys;print("sensitive",file=sys.stderr);sys.exit(3)',2),('import time;time.sleep(3)',.65)]:
            with self.assertRaises(p.Failure) as caught:p.cli([sys.executable,'-c',code],time.monotonic()+seconds)
            safe=getattr(caught.exception,'safeCLIOutcome',None);self.assertIsInstance(safe,dict);self.assertNotIn('sensitive',json.dumps(safe));self.assertTrue(safe['groupClosed']);self.assertIn(safe['reason'],('signing_failed','signing_deadline'))
    def test_false_group_absence_fails_successful_cli(self):
        real=os.killpg
        def killpg(pid,sig):
            if sig==0:raise PermissionError('private diagnostic must not leak')
            return real(pid,sig)
        with patch.object(p.os,'killpg',side_effect=killpg):
            with self.assertRaises(p.Failure) as caught:p.cli([sys.executable,'-c','pass'],time.monotonic()+2)
        safe=getattr(caught.exception,'safeCLIOutcome',{});self.assertIs(safe.get('groupClosed'),False);self.assertEqual(safe.get('reason'),'signing_group_unclosed');self.assertNotIn('private diagnostic',str(caught.exception))
    def test_presign_failure_writes_owned_bounded_pre_harness_artifact(self):
        failure=p.Failure('unsafe exception text https://bearer.invalid');failure.safeCLIOutcome=self.safe('signing_deadline')
        def sign(*args):
            self.assertTrue(self.root.is_dir(),'root must precede CLI');self.assertFalse((self.root/'evidence').exists());raise failure
        with patch.dict(os.environ,{'CODEBUILD_START_TIME':str(int(time.time()*1000))}),patch.object(p,'cli',side_effect=sign):
            with self.assertRaises(p.Failure):p.bootstrap(self.pins,'bucket','key','us-east-1','test123',str(self.root))
        path=self.root/'evidence/bootstrap-negative.json';self.assertTrue(path.exists());self.assertLessEqual(path.stat().st_size,4096);record=json.loads(path.read_bytes());self.assertEqual(record['schema'],'codec-bootstrap-negative-v1');self.assertEqual(record['nonce'],'test123');self.assertEqual(record['stage'],'source_sign');self.assertEqual(record['reason'],'signing_deadline');self.assertNotIn('unsafe exception',path.read_text());self.assertNotIn('bearer.invalid',path.read_text());self.assertNotIn('cells',record)
    def test_success_prints_safe_outcome_but_leaves_evidence_for_run(self):
        files={'diagnostic.py':b'x'};stream=io.StringIO()
        def sign(*args):self.assertTrue(self.root.exists());return 'https://bearer.invalid',self.safe()
        with patch.dict(os.environ,{'CODEBUILD_START_TIME':str(int(time.time()*1000))}),patch.object(p,'cli',side_effect=sign),patch.object(p,'fetch_source',return_value=b'code'),patch.object(p,'verify',return_value=files),patch.object(p.os,'execv') as execute,contextlib.redirect_stdout(stream):
            p.bootstrap(self.pins,'bucket','key','us-east-1','test123',str(self.root))
        self.assertFalse((self.root/'evidence').exists());execute.assert_called_once();line=stream.getvalue();self.assertLessEqual(len(line),4096);self.assertNotIn('bearer.invalid',line);self.assertEqual(json.loads(line)['schema'],'codec-bootstrap-cli-outcome-v1')
    def test_group_failure_artifact_retains_unclosed_obligation(self):
        failure=p.Failure('signing_group_unclosed');failure.safeCLIOutcome=self.safe('signing_group_unclosed',False)
        with patch.dict(os.environ,{'CODEBUILD_START_TIME':str(int(time.time()*1000))}),patch.object(p,'cli',side_effect=failure):
            with self.assertRaises(p.Failure):p.bootstrap(self.pins,'b','k','us-east-1','test123',str(self.root))
        record=json.loads((self.root/'evidence/bootstrap-negative.json').read_bytes());self.assertEqual(record['reason'],'signing_group_unclosed');self.assertIs(record['safeCLIOutcome']['groupClosed'],False)
    def test_unowned_root_is_never_modified(self):
        self.root.mkdir();(self.root/'keep').write_text('original')
        with patch.object(p,'cli') as sign:
            with self.assertRaises(p.Failure):p.bootstrap(self.pins,'b','k','us-east-1','test123',str(self.root))
        sign.assert_not_called();self.assertEqual((self.root/'keep').read_text(),'original');self.assertFalse((self.root/'evidence').exists())
    def test_verify_failure_writes_static_reason_without_delivered_execution(self):
        with patch.dict(os.environ,{'CODEBUILD_START_TIME':str(int(time.time()*1000))}),patch.object(p,'cli',return_value=('url',self.safe())),patch.object(p,'fetch_source',return_value=b'bad'),patch.object(p,'verify',side_effect=ValueError('sensitive source')),patch.object(p.os,'execv') as execute,contextlib.redirect_stdout(io.StringIO()):
            with self.assertRaises(p.Failure):p.bootstrap(self.pins,'b','k','us-east-1','test123',str(self.root))
        record=json.loads((self.root/'evidence/bootstrap-negative.json').read_bytes());self.assertEqual(record['stage'],'source_verify');self.assertEqual(record['reason'],'source_verify_failed');self.assertNotIn('sensitive',json.dumps(record));execute.assert_not_called()

if __name__=='__main__':unittest.main()
