"""Bounded operational scans: accounting, failure context and cleanup propagation."""
import contextlib
import itertools
import pathlib
import sys
import tempfile
import types
import unittest
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d


class MonitorTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.ledger = types.SimpleNamespace(observed={})
        self.ledger.observe = lambda name, n: self.ledger.observed.__setitem__(name, self.ledger.observed.get(name, 0) + n)
        self.meter = patch.object(d, '_METER', self.ledger)
        self.meter.start()
        self.addCleanup(self.meter.stop)

    def test_complete_scan_counts_allocated_blocks_without_following_symlinks(self):
        (self.root / 'dir').mkdir()
        (self.root / 'dir' / 'body').write_bytes(b'x' * 8192)
        (self.root / 'link').symlink_to('dir', target_is_directory=True)
        expected = sum(p.lstat().st_blocks * 512 for p in (self.root / 'dir', self.root / 'dir' / 'body', self.root / 'link'))
        monitor = d.Monitor(self.root)
        with patch.object(d.shutil, 'disk_usage', return_value=types.SimpleNamespace(free=8589934592)):
            monitor.scan()
        facts = monitor.finish()
        self.assertEqual(facts['allocatedBlockPeak'], expected)
        self.assertEqual(facts['scans'], 1)
        self.assertEqual(facts.get('lastScan', {}).get('entries'), 3)
        self.assertTrue(facts.get('lastScan', {}).get('complete'))
        self.assertEqual(self.ledger.observed.get('filesystemObservationBytes', 0), 768)

    def test_deadline_failure_retains_partial_accounting_and_elapsed_context(self):
        (self.root / 'body').write_bytes(b'x')
        monitor = d.Monitor(self.root)
        # Start, before-entry, after-traversal: the final operation crossed the deadline.
        with patch.object(d.time, 'monotonic', side_effect=[10, 10.1, 10.9, 10.9]):
            monitor.loop()
        facts = monitor.finish()
        self.assertEqual(facts['monitorError'], 'disk_scan_deadline')
        self.assertEqual(facts.get('lastScan', {}).get('entries'), 1)
        self.assertAlmostEqual(facts.get('lastScan', {}).get('elapsedSeconds'), .9)
        self.assertFalse(facts.get('lastScan', {}).get('complete'))
        self.assertEqual(facts['scans'], 0)
        self.assertEqual(self.ledger.observed.get('filesystemObservationBytes', 0), 256)
        with self.assertRaisesRegex(d.Failure, '^disk_scan_deadline$'):
            monitor.check()

    def test_entry_cap_is_distinct_and_stops_before_extra_stat(self):
        class Entry:
            path = 'unused'
            name = 'body'
            def is_dir(self): return False
            def is_symlink(self): return False
            def stat(self, *, follow_symlinks):
                if not follow_symlinks:
                    return types.SimpleNamespace(st_blocks=1, st_mode=0o100600)
                raise AssertionError('followed symlink')
        @contextlib.contextmanager
        def entries(_root):
            yield itertools.repeat(Entry(), 100002)
        monitor = d.Monitor(self.root)
        with patch.object(d.os, 'walk', return_value=[(str(self.root), [], ['body'] * 100002)]), patch.object(d.os, 'scandir', entries), patch.object(d.os, 'lstat', return_value=types.SimpleNamespace(st_blocks=1)), patch.object(d.time, 'monotonic', return_value=10):
            monitor.loop()
        facts = monitor.finish()
        self.assertEqual(facts['monitorError'], 'disk_scan_entry_cap')
        self.assertEqual(facts.get('lastScan', {}).get('entries'), 100001)
        self.assertEqual(facts.get('lastScan', {}).get('elapsedSeconds'), 0)
        self.assertFalse(facts.get('lastScan', {}).get('complete'))
        self.assertEqual(self.ledger.observed.get('filesystemObservationBytes', 0), 25600000)
        self.assertEqual(facts['scans'], 0)

    def test_empty_scan_still_enforces_elapsed_work_bound(self):
        monitor = d.Monitor(self.root)
        with patch.object(d.time, 'monotonic', side_effect=[10, 10.9, 10.9]):
            monitor.loop()
        self.assertEqual(monitor.finish()['monitorError'], 'disk_scan_deadline')

    def test_small_work_cap_keeps_admitted_observations_and_stops_scan(self):
        scan_root = self.root / 'scan'
        scan_root.mkdir()
        for name in ('first', 'second', 'third'):
            (scan_root / name).write_bytes(b'x')
        ledger = d.Ledger(self.root / 'ledger', 'codec-diagnostic-meter')
        ledger.observed['smallObservableBytes'] = 536870656  # Exactly one observation remains.
        monitor = d.Monitor(scan_root)
        with patch.object(d, '_METER', ledger):
            monitor.loop()
        facts = monitor.finish()
        self.assertEqual(facts['monitorError'], 'small_work_cap')
        self.assertEqual(ledger.observed.get('filesystemObservationBytes', 0), 256)
        self.assertEqual(ledger.observed['smallObservableBytes'], 536870912)
        self.assertEqual(facts['lastScan']['entries'], 2)
        self.assertFalse(facts['lastScan']['complete'])
        self.assertEqual(facts['scans'], 0)
        with self.assertRaisesRegex(d.Failure, '^small_work_cap$'):
            monitor.check()

    def test_scan_io_failure_is_closed_and_keeps_partial_accounting(self):
        class Entry:
            path = 'unused'
            name = 'body'
            def is_dir(self): return False
            def is_symlink(self): return False
            def stat(self, *, follow_symlinks):
                return types.SimpleNamespace(st_blocks=1, st_mode=0o100600)
        @contextlib.contextmanager
        def entries(_root):
            def stream():
                yield Entry()
                raise PermissionError('fixture unreadable directory')
            yield stream()
        monitor = d.Monitor(self.root)
        with patch.object(d.os, 'scandir', entries):
            monitor.loop()
        facts = monitor.finish()
        self.assertEqual(facts['monitorError'], 'monitor_observation_failed')
        self.assertFalse(facts.get('lastScan', {}).get('complete'))
        self.assertEqual(self.ledger.observed.get('filesystemObservationBytes', 0), 256)
        with self.assertRaises(d.Failure):
            monitor.check()


if __name__ == '__main__':
    unittest.main()
