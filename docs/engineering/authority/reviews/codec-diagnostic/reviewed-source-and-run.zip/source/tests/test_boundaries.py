"""Offline boundary tests. Fixtures are generated; no retained layer is opened."""
import base64, gzip, hashlib, importlib, io, json, os, pathlib, subprocess, sys, tempfile, time, unittest, zipfile
from unittest.mock import patch
ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    import diagnostic as d
    import packet_renderer as p
    import check_result as c
    import probe
except ImportError:
    d = p = c = probe = None

def sha(b): return hashlib.sha256(b).hexdigest()
def wire(o): return (json.dumps(o, sort_keys=True, separators=(',', ':'))+'\n').encode('ascii')
def zip_bytes(files):
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items(): z.writestr(n,b)
    return out.getvalue()

class Boundaries(unittest.TestCase):
    def setUp(self):
        self.assertIsNotNone(d, 'finite diagnostic implementation is absent')
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup)
        self.root=pathlib.Path(self.tmp.name)
    def test_arithmetic_and_repeated_read_charges(self):
        self.assertEqual(sum(d.WORK.values()),11055652581)
        self.assertEqual(d.WORK_CAP-sum(d.WORK.values()),1829249307)
        self.assertEqual(sum(d.CUSTODY),75606704)
        led=d.Ledger(self.root/'ledger','codec-diagnostic-test',10)
        led.charge('a',10)
        with self.assertRaises(d.Failure): led.charge('a',1)
        with self.assertRaises(d.Failure): d.Ledger(self.root/'ledger','codec-diagnostic-test',10)
        f=d.Counted(io.BytesIO(b'abcd'),8)
        self.assertEqual(f.read(4),b'abcd');f.seek(0);self.assertEqual(f.read(4),b'abcd')
        f.seek(0)
        with self.assertRaises(d.Failure): f.read(1)
    def test_unknown_interrupt_charges_reservation(self):
        led=d.Ledger(self.root/'ledger','codec-diagnostic-test',10);led.charge('x',1);led.uncertain()
        self.assertEqual(led.used,10);self.assertTrue(json.loads((self.root/'ledger').read_text())['uncertain'])
    def test_phase_deadlines_do_not_reset_at_host_start(self):
        cl=d.Clocks(1000,now_wall=1200,now_mono=50)
        self.assertEqual(cl.setup,90);self.assertEqual(cl.cells,570);self.assertEqual(cl.end,750)
        self.assertFalse(cl.admit(531));self.assertTrue(cl.admit(530))
        self.assertEqual(cl.cell(100), (132,140))
    def test_redirect_never_dispatches_destination(self):
        requests=[]
        class Transport:
            def __call__(self,req):
                requests.append(req.full_url)
                return io.BytesIO(b'')
        handler=d.NoRedirect()
        with self.assertRaises(d.Failure): handler.redirect_request(None,None,302,'m',{},'https://other.invalid/secret')
        self.assertEqual(requests,[])
        # Exercise urllib's real redirect dispatch stack without a socket.
        import urllib.request, urllib.response
        class FakeHTTP(urllib.request.HTTPHandler):
            def http_open(self,req):
                requests.append(req.full_url)
                import email.message
                headers=email.message.Message();headers['Location']='http://other.invalid/x'
                r=urllib.response.addinfourl(io.BytesIO(b''), headers, req.full_url,302);r.msg='Found';return r
        opener=urllib.request.build_opener(FakeHTTP(),d.NoRedirect())
        with self.assertRaises(d.Failure):opener.open('http://first.invalid/x')
        self.assertEqual(requests,['http://first.invalid/x'])
    def test_downloader_length_hash_eof_and_no_retry(self):
        class Response(io.BytesIO):
            status=200
            def geturl(self):return 'https://download.docker.com/x'
        calls=[]
        class Opener:
            def open(self,*a,**kw):calls.append(1);return Response(b'abc')
        d.download('https://download.docker.com/x',self.root/'a',3,sha(b'abc'),time.monotonic()+1,opener=Opener())
        self.assertEqual((self.root/'a').read_bytes(),b'abc');self.assertEqual(len(calls),1)
        for size,h in [(2,sha(b'ab')),(4,sha(b'abcd')),(3,'0'*64)]:
            with self.assertRaises(d.Failure):d.download('https://download.docker.com/x',self.root/(str(size)+'x'),size,h,time.monotonic()+1,opener=Opener())
    def test_source_outer_hash_precedes_json_and_nested_parse(self):
        files={n:b'x' for n in p.FILES if n!='manifest.json'}
        files['manifest.json']=wire({n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()})
        z=zip_bytes(files);e=p.envelope(z);pins=p.identities(e,z,files['manifest.json'])
        self.assertEqual(p.verify(e,pins),files)
        with patch.object(p.json,'loads',side_effect=AssertionError('parsed hostile source')):
            with self.assertRaises(p.Failure):p.verify(b'{malicious',pins)
        replacement=bytearray(e);replacement[-2]^=1
        with self.assertRaises(p.Failure):p.verify(bytes(replacement),pins)
        for bad in [e+b' ',e.replace(b'"zipBytes":',b'"zipBytes":0,"zipBytes":')]:
            badpins={**pins,'envelope':{'bytes':len(bad),'sha256':sha(bad)}}
            with self.assertRaises(p.Failure):p.verify(bad,badpins)
    def test_transport_strict_canonical_and_actual_charges(self):
        ledger=d.Ledger(self.root/'l','codec-diagnostic-x',100000)
        b=b'abc';resp={'Body':base64.b64encode(b).decode(),'ContentLength':3}
        self.assertEqual(p.decode_response(resp,3,ledger),b)
        once=ledger.used;p.decode_response(resp,3,ledger);self.assertEqual(ledger.used,2*once)
        for body in ['YWJj\n','YWJj====','YWJj☃']:
            with self.assertRaises(p.Failure):p.decode_response({'Body':body,'ContentLength':3},3,ledger)
        with self.assertRaises(p.Failure):p.decode_response({'Body':'YWJj','ContentLength':2},3,ledger)
    def test_selected_extraction_safety_and_repeated_compressed_reads(self):
        files={'encoded/descriptor.json':b'{}','encoded/literal.bin':b'abc'}
        pins={n:{'bytes':len(b),'sha256':sha(b)} for n,b in files.items()}
        path=self.root/'a.zip';path.write_bytes(zip_bytes({**files,'unselected':b'z'}))
        facts=d.extract_selected(path,self.root/'out',pins,100000,time.monotonic()+1)
        self.assertGreater(facts['compressedReadBytes'],0);self.assertEqual((self.root/'out/literal.bin').read_bytes(),b'abc')
        for extra in ['../x','/x','encoded/../x']:
            path.write_bytes(zip_bytes({**files,extra:b'z'}))
            with self.assertRaises(d.Failure):d.extract_selected(path,self.root/sha(extra.encode()),pins,100000,time.monotonic()+1)
    def test_load_requires_exhaustion_pipe_exit_and_full_hash(self):
        command=[sys.executable,'-c','import sys;sys.stdin.buffer.read()']
        fact=d.stream_load(iter([b'ab',b'c']),command,dict(os.environ),3,sha(b'abc'),time.monotonic()+2)
        self.assertTrue(fact['exhausted']);self.assertTrue(fact['stdoutEOF'])
        def late():
            yield b'abc'
            raise ValueError('late corruption')
        for gen,cmd in [(late(),command),(iter([b'abc']),[sys.executable,'-c','import sys;sys.exit(2)']),(iter([b'abc']),command)]:
            with self.assertRaises(d.Failure):d.stream_load(gen,cmd,dict(os.environ),3,'0'*64,time.monotonic()+2)
    def test_matrix_and_child_argv(self):
        self.assertEqual(len(d.MATRIX),12)
        self.assertEqual([x['audioKbps'] for x in d.MATRIX],[160,320]*6)
        for cell in d.MATRIX:
            argv=probe.ffmpeg_argv(cell)
            self.assertEqual(argv[-3:],['mpegts','/dev/null'][-3:] if False else ['-f','mpegts','/dev/null'])
            self.assertNotIn('-re',argv);self.assertIn('25',argv);self.assertIn('2',argv)
        argv=d.child_args('n','sha256:'+'a'*64,'0,1',self.root/'probe.py',d.MATRIX[0])
        self.assertIn('--read-only',argv);self.assertIn('--network=none',argv);self.assertIn('--memory-swap=4294967296',argv)
        self.assertNotIn('--privileged',argv)
    def test_progress_sparse_warmup_units_and_counter_reset(self):
        raw=[{'t':1,'frame':100,'mediaUs':4000000,'cpuNs':1000000000},{'t':2,'frame':180,'mediaUs':6000000,'cpuNs':2000000000},{'t':4,'frame':300,'mediaUs':10000000,'cpuNs':5000000000}]
        facts=d.derive(raw,2)
        self.assertEqual(facts['fps']['value'],60);self.assertEqual(facts['speed']['value'],2)
        self.assertEqual(facts['cpuCores']['value'],1.5);self.assertEqual(facts['cpuPercent']['value'],75)
        self.assertEqual(facts['speed']['interval']['mediaSeconds'],[6,10])
        self.assertEqual(d.derive(raw[:2],2)['fps']['state'],'missing')
        raw[-1]['cpuNs']=0
        with self.assertRaises(d.Failure):d.derive(raw,2)
    def test_cgroup_rejects_hidden_v2_and_narrow_ancestors(self):
        with self.assertRaises(d.Failure):d.parse_cgroups('0::/x\n')
        leaf={'quota':200000,'period':100000,'memory':4294967296,'cpus':[0,1],'path':'/x','memsw':4294967296}
        parent={**leaf,'quota':100000}
        with self.assertRaises(d.Failure):d.prove_controls(leaf,[parent],[0,1],True)
        with self.assertRaises(d.Failure):d.prove_controls(leaf,[],[0],True)
        with self.assertRaises(d.Failure):d.prove_controls(leaf,[],[0,1],False)
        self.assertEqual(d.prove_controls(leaf,[{**leaf,'path':'/'}],[0,1],True)['effectiveCpus'],2)
    def test_typed_terminal_states_and_missing_is_not_zero(self):
        self.assertEqual(d.disposition(exit_code=0,complete=True,controls=True,metrics=True),'observed')
        self.assertEqual(d.disposition(exit_code=0,complete=True,controls=True,metrics=False),'incomplete')
        for why in ['timeout','oom','exit_failure']:
            self.assertEqual(d.disposition(reason=why),'censored')
        result=d.empty_result('n',{'imageId':'i'},'setup_failed')
        self.assertEqual(len(result['cells']),12);self.assertTrue(all(x['state']=='not_run' for x in result['cells']))
        self.assertEqual(result['cells'][0]['metrics']['fps']['state'],'missing')
    def test_evidence_overflow_reserves_terminal_space(self):
        ev=d.Evidence(self.root,cap=100,reserve=20)
        ev.save('raw',b'x'*80)
        with self.assertRaises(d.Failure):ev.save('overflow',b'x')
        ev.save('terminal',b'y'*20,terminal=True)
        self.assertEqual(sum(x['bytes'] for x in ev.inventory.values()),100)
    def test_checker_rejects_fabricated_zero_and_duplicate_cells(self):
        result=d.empty_result('n',{'imageId':'i'},'setup_failed')
        result['inventory']={};result['cleanup']={'state':'closed'}
        c.check(result,{},expected_nonce='n',expected_pins={'imageId':'i'})
        result['cells'][0]['metrics']['fps']={'state':'available','value':0,'unit':'fps','interval':{},'sourceRefs':[]}
        with self.assertRaises(c.Invalid):c.check(result,{},expected_nonce='n',expected_pins={'imageId':'i'})
        result=d.empty_result('n',{'imageId':'i'},'setup_failed');result['inventory']={};result['cells'][1]=result['cells'][0]
        with self.assertRaises(c.Invalid):c.check(result,{},expected_nonce='n',expected_pins={'imageId':'i'})

if __name__=='__main__':unittest.main()
