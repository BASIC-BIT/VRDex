"""Bounded Python-only process and cgroup supervision simulations."""
import copy, io, json, os, pathlib, select, subprocess, sys, tempfile, time, types, unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, probe, check_result as checker

class Runtime(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.root=pathlib.Path(self.tmp.name)
    def readline(self,proc,timeout=2):
        self.assertTrue(select.select([proc.stdout],[],[],timeout)[0],'bounded handshake absent')
        return json.loads(proc.stdout.readline())
    def test_keeper_wait4_stop_and_release_are_live_protocol(self):
        # Replace only the FFmpeg launch with a tiny Python emitter; actual keeper code runs.
        code='''import os,sys,time\nprint('frame=180\\nout_time_us=6000000\\nprogress=continue',flush=True)\ntime.sleep(5)'''
        harness="import sys;sys.path.insert(0,"+repr(str(pathlib.Path(d.__file__).parent))+");import probe;orig=probe.subprocess.Popen;probe.facts=lambda:{'fixture':True};probe.subprocess.Popen=lambda *a,**kw:orig([sys.executable,'-c',"+repr(code)+"],**kw);probe.main("+repr(d.MATRIX[0])+")"
        proc=subprocess.Popen([sys.executable,'-c',harness],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        self.addCleanup(lambda:proc.kill() if proc.poll() is None else None)
        self.assertEqual(self.readline(proc)['event'],'READY');proc.stdin.write(b'GO\n');proc.stdin.flush()
        started=self.readline(proc);self.assertEqual(started['event'],'STARTED');proc.stdin.write(b'RUN\n');proc.stdin.flush()
        self.assertEqual(self.readline(proc)['event'],'PROGRESS');proc.stdin.write(b'STOP\n');proc.stdin.flush()
        terminal=self.readline(proc);self.assertEqual(terminal['event'],'EXIT');self.assertEqual(terminal['exitCode'],-15);self.assertGreater(terminal['ffmpegPeakKiB'],0)
        self.assertIsNone(proc.poll(),'keeper must live until final host snapshot')
        proc.stdin.write(b'RELEASE\n');proc.stdin.flush();self.assertEqual(proc.wait(timeout=2),0)
        for f in (proc.stdin,proc.stdout,proc.stderr):f.close()
    def fake_cell(self,behavior,delegated=False):
        cpus=sorted(os.sched_getaffinity(0))[:2]
        if len(cpus)!=2:self.skipTest('needs two available logical CPUs for simulation')
        raw_control={'quota':200000,'period':100000,'memory':4294967296,'memsw':4294967296,'cpus':cpus,'path':'/x'}
        membership='1:cpu,cpuacct,memory,cpuset:/x\n'
        source=pathlib.Path(d.__file__).resolve().with_name('probe.py')
        info={'Id':'a'*64,'Image':'image','Config':{'User':'65534:65534','Entrypoint':['python3']},'HostConfig':{'NetworkMode':'none','ReadonlyRootfs':True,'Privileged':False,'Memory':4294967296,'MemorySwap':4294967296,'CpuPeriod':100000,'CpuQuota':200000,'CpusetCpus':','.join(map(str,cpus)),'PidsLimit':128,'CapDrop':['ALL'],'SecurityOpt':['no-new-privileges']},'Mounts':[{'Source':str(source),'Destination':'/codec-probe.py','RW':False}],'State':{'Pid':42,'Running':True,'OOMKilled':False}}
        facts={'uid':65534,'credentialEnvironment':False,'interfaces':['lo'],'routes':'header\n','affinity':cpus}
        if delegated:
            from test_delegated import fixture_namespaces
            facts['namespaces']=fixture_namespaces(True)
            if behavior=='ready_namespace_missing':facts.pop('namespaces')
            elif behavior=='ready_namespace_mismatch':facts['namespaces']['cgroup']='cgroup:[999999]'
        script=self.root/'attach.py'
        script.write_text('''import sys,json,time\ndef emit(x):print(json.dumps(x),flush=True)\nemit({'event':'READY','facts':FACTS})\nif sys.stdin.readline()!='GO\\n':sys.exit(3)\nif BEHAVIOR=='keeper_dead':sys.exit(0)\nemit({'event':'STARTED','pid':7,'affinity':CPUS,'argv':ARGV})\nif sys.stdin.readline()!='RUN\\n':sys.exit(4)\nfor frame,us in [(180,6000000),(750,25000000)]:\n time.sleep(.01);emit({'event':'PROGRESS','raw':{'frame':str(frame),'out_time_us':str(us),'progress':'continue' if frame==180 else 'end'}})\nemit({'event':'EXIT','pid':99 if BEHAVIOR=='wrong_exit_pid' else 7,'exitCode':0,'progressEOF':True,**({} if BEHAVIOR=='missing_peak' else {'ffmpegPeakKiB':100})})\nif sys.stdin.readline()!='RELEASE\\n':sys.exit(5)\n'''.replace('FACTS',repr(facts)).replace('BEHAVIOR',repr(behavior)).replace('CPUS',repr(cpus)).replace('ARGV',repr(probe.ffmpeg_argv(d.MATRIX[0]))))
        real_popen=subprocess.Popen;driver={'process':None};counter={'n':0}
        def spawn(*args,**kw):driver['process']=real_popen([sys.executable,str(script)],**kw);return driver['process']
        def command(args,*unused,**kw):
            if args[1]=='inspect':
                value=copy.deepcopy(info)
                if behavior=='container_mismatch':value['Id']='b'*64
                if driver['process'] and driver['process'].poll() is not None:value['State'].update(Pid=0,Running=False,OOMKilled=behavior=='oom')
                return {'stdout':json.dumps([value]).encode()}
            return {'stdout':('a'*64+'\n').encode() if args[1]=='create' else b''}
        class CG:
            def __init__(self,pid,**kw):
                self.pid=pid;self.groups={x:'/x' for x in ('cpu','cpuacct','memory','cpuset')};self.ns={'net':'child','pid':'child'};self.affinity=cpus;self.membership=membership;self.mountinfo='\n'.join(f'1 0 0:1 / /sys/fs/cgroup/{c} rw - cgroup cgroup rw,{c}' for c in ('cpu','cpuacct','memory','cpuset'))
                self.sink=kw.get('sink',lambda raw:None);self.sink(self.evidence())
            def controls(self):return raw_control
            def ancestors(self):return [{**raw_control,'path':'/'}]
            def evidence(self):
                if delegated:
                    from test_delegated import fixture,ROOT,seal_capture
                    raw=fixture(ROOT+'/leaf',self.pid,True);raw['affinity']=cpus
                    raw['identity']['cmdline']='\x00'.join(probe.ffmpeg_argv(d.MATRIX[0]))+'\x00' if self.pid==43 else 'python3\x00'
                    for path in raw['controlFiles']:
                        if path.endswith('cpuset.cpus'):raw['controlFiles'][path]=','.join(map(str,cpus))
                    raw['collector']['affinity']=cpus
                    return seal_capture(raw)
                files={}
                for relative in ['/x','/']:
                    for controller,name in d.CONTROL_FILES:
                        values={'cpu.cfs_quota_us':'200000','cpu.cfs_period_us':'100000','memory.limit_in_bytes':'4294967296','memory.memsw.limit_in_bytes':'4294967296','cpuset.cpus':','.join(map(str,cpus))}
                        files[str(pathlib.Path('/sys/fs/cgroup')/controller/relative.lstrip('/')/name)]=values[name]
                return {'pid':self.pid,'membership':self.membership,'mountinfo':self.mountinfo,'namespaces':self.ns,'affinity':self.affinity,'controlFiles':files}
            def snapshot(self):
                counter['n']+=1;n=counter['n']
                if behavior=='missing_counter':raise d.Failure('missing_counters')
                values={'cpuacct.usage':n*1000000,'cpuacct.stat:user':n,'cpuacct.stat:system':n,'cpu.stat:nr_periods':n,'cpu.stat:nr_throttled':0,'cpu.stat:throttled_time':0,'memory.usage_in_bytes':1000,'memory.max_usage_in_bytes':2000,'memory.failcnt':0,'memory.oom_control:under_oom':0,'memory.oom_control:oom_kill_disable':0}
                raw={}
                for k,v in values.items():
                    if ':' not in k:controller='cpuacct' if k.startswith('cpuacct') else 'memory';raw['/sys/fs/cgroup/'+controller+'/x/'+k]=str(v)
                for base in ('cpuacct.stat','cpu.stat','memory.oom_control'):raw['/sys/fs/cgroup/'+('cpuacct' if base=='cpuacct.stat' else 'cpu' if base=='cpu.stat' else 'memory')+'/x/'+base]='\n'.join(k.split(':')[1]+' '+str(v) for k,v in values.items() if k.startswith(base+':'))
                if delegated:
                    from test_delegated import ROOT
                    raw={k.replace('/cpuacct/','/cpu,cpuacct/').replace('/cpu/','/cpu,cpuacct/').replace('/x/','/leaf/'):v for k,v in raw.items()}
                    m=self.evidence()['membership']
                else:m=membership
                return {'t':time.monotonic(),'values':values,'raw':raw,'pid':self.pid,'membership':m}
        real_bounded=d.bounded
        def bounded(path,*a):
            if str(path).endswith('/children'):return b'43'
            if str(path).endswith('/43/status'):return b'NSpid:\t43\t7\n'
            return real_bounded(path,*a)
        parent=CG(41);parent.ns={'net':'parent','pid':'parent'};parent.groups={x:'/' for x in ('cpu','cpuacct','memory','cpuset')}
        pe=parent.evidence();pe['membership']=membership.replace('/x','/');pe['controlFiles']={k:v for k,v in pe['controlFiles'].items() if '/x/' not in k};parent.evidence=lambda:pe
        if delegated:
            from test_delegated import fixture,ROOT,seal_capture
            pe=fixture();pe['affinity']=cpus
            for path in pe['controlFiles']:
                if path.endswith('cpuset.cpus'):pe['controlFiles'][path]=','.join(map(str,cpus))
            pe['collector']['affinity']=cpus;seal_capture(pe)
            parent.evidence=lambda:pe;parent.ns=pe['namespaces'];parent.groups=dict.fromkeys(('cpu','cpuacct','memory','cpuset'),ROOT)
        ev=d.Evidence(self.root/'evidence');clocks=d.Clocks(time.time());monitor=types.SimpleNamespace(check=lambda:None)
        with patch.object(d,'command',side_effect=command),patch.object(d.subprocess,'Popen',side_effect=spawn),patch.object(d,'Cgroups',CG),patch.object(d,'bounded',side_effect=bounded):
            result=d.run_cell(d.MATRIX[0],0,'test123',{'imageId':'image',**({'controlVisibilityPolicy':'allow-incomplete-delegated-v1'} if delegated else {})},self.root,dict(os.environ),clocks,monitor,ev,cpus,parent)
        return result,ev
    def test_cell_protocol_observed_and_checker_recomputes(self):
        cell,ev=self.fake_cell('success');self.assertEqual(cell['state'],'observed',cell)
        result=d.empty_result('test123',{'imageId':'image'},'fixture_unrun');result['cells'][0]=cell;result['cleanup']={'state':'closed'};result['inventory']=ev.inventory
        files={name:(ev.root/name).read_bytes() for name in ev.inventory}
        checked=checker.check(result,files,'test123',expected_pins={'imageId':'image'});self.assertEqual(checked['counts']['observed'],1)
        cell['metrics']['cpuPercent']['value']+=1
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins={'imageId':'image'})
    def test_keeper_death_is_incomplete_not_observed(self):
        cell,ev=self.fake_cell('keeper_dead');self.assertEqual(cell['state'],'incomplete');self.assertTrue(all(m['state']=='missing' for m in cell['metrics'].values()))
    def test_missing_counter_is_incomplete(self):
        cell,ev=self.fake_cell('missing_counter');self.assertEqual(cell['state'],'incomplete');self.assertEqual(cell['reason'],'missing_counters')
    def test_oom_preserves_censored_disposition(self):
        cell,ev=self.fake_cell('oom');self.assertEqual(cell['state'],'censored');self.assertEqual(cell['reason'],'oom')

if __name__=='__main__':unittest.main()

class ReviewRegressions(unittest.TestCase):
    setUp=Runtime.setUp
    fake_cell=Runtime.fake_cell
    def artifact(self,behavior='success'):
        cell,ev=self.fake_cell(behavior)
        result=d.empty_result('test123',{'imageId':'image'},'fixture_unrun');result['cells'][0]=cell;result['cleanup']={'state':'closed'};result['inventory']=copy.deepcopy(ev.inventory)
        files={name:(ev.root/name).read_bytes() for name in ev.inventory}
        return cell,result,files
    def mutate(self,result,files,change):
        name=result['cells'][0]['sourceRefs'][0];raw=json.loads(files[name]);change(raw);files[name]=d.wire(raw);result['inventory'][name]={'bytes':len(files[name]),'sha256':d.sha(files[name])}
    def test_rejects_removed_ancestor_after_rehash(self):
        _,result,files=self.artifact();self.mutate(result,files,lambda raw:raw['controls'].__setitem__('ancestors',[]))
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins={'imageId':'image'})
    def test_rejects_unrelated_leaf_path_after_rehash(self):
        _,result,files=self.artifact();self.mutate(result,files,lambda raw:raw['controls']['leaf'].__setitem__('path','/unrelated'))
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins={'imageId':'image'})
    def test_rejects_wrong_workload_after_rehash(self):
        _,result,files=self.artifact();self.mutate(result,files,lambda raw:raw['ffmpeg'].__setitem__('argv',['unrelated-workload']))
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins={'imageId':'image'})
    def test_rejects_changed_keeper_membership_after_rehash(self):
        _,result,files=self.artifact();self.mutate(result,files,lambda raw:raw['keeper'].__setitem__('membership',raw['keeper']['membership'].replace('/x','/elsewhere')))
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins={'imageId':'image'})
    def test_rejects_hidden_mount_after_rehash(self):
        _,result,files=self.artifact();self.mutate(result,files,lambda raw:raw['keeper'].__setitem__('mountinfo','1 0 0:1 /hidden /sys/fs/cgroup rw - cgroup cgroup rw,cpu,cpuacct,memory,cpuset'))
        with self.assertRaises(checker.Invalid):checker.check(result,files,'test123',expected_pins={'imageId':'image'})
    def test_false_attach_closure_blocks_following_cells(self):
        with patch.object(d,'kill_group',return_value=False):cell,ev=self.fake_cell('success')
        self.assertEqual(cell['state'],'incomplete');self.assertEqual(cell['cleanup']['state'],'incomplete');self.assertFalse(cell['cleanup']['attachGroupClosed']);self.assertIsNotNone(d.cell_blocker(cell))
    def test_pre_ffmpeg_negative_artifacts_are_checkable(self):
        for behavior in ('missing_counter','keeper_dead'):
            with self.subTest(behavior=behavior):
                _,result,files=self.artifact(behavior)
                outcome=checker.check(result,files,'test123',expected_pins={'imageId':'image'});self.assertEqual(outcome['counts']['incomplete'],1)
                # Each fixture needs a separate evidence tree.
                self.doCleanups();self.setUp()
    def test_attach_group_fallback_does_not_depend_on_root_in_argv(self):
        with patch.object(d.os,'killpg',return_value=None):
            self.assertIn(777,d.owned_processes(self.root,time.monotonic()+1,proc=self.root,attach_groups=[777]))
