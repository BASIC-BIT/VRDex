"""Task 2 transport correction: textual source is literal ASCII, binary output base64."""
import base64, io, json, pathlib, sys, unittest, zipfile
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import packet_renderer as p

class Ledger:
    def __init__(self):self.used=0;self.items=[]
    def charge(self,name,n):self.used+=n;self.items.append((name,n))

class SourceTransport(unittest.TestCase):
    def setUp(self):
        self.files={n:b'x' for n in p.FILES if n!='manifest.json'}
        self.files['manifest.json']=p.wire({n:{'bytes':len(b),'sha256':p.sha(b)} for n,b in self.files.items()})
        out=io.BytesIO()
        with zipfile.ZipFile(out,'w') as z:
            for n,b in self.files.items():z.writestr(n,b)
        self.z=out.getvalue();self.e=p.envelope(self.z);self.pins=p.identities(self.e,self.z,self.files['manifest.json'])
        self.response={'Body':self.e.decode('ascii'),'ContentLength':len(self.e)}
    def test_literal_source_accepts_and_charges_actual_carrier_and_ascii_copy(self):
        led=Ledger();actual=len(p.wire(self.response))+10
        self.assertEqual(p.verify_source_response(self.response,self.pins,led,response_bytes=actual),self.files)
        self.assertEqual(led.used,actual+len(self.e))
        p.verify_source_response(self.response,self.pins,led,response_bytes=actual)
        self.assertEqual(led.used,2*(actual+len(self.e)))
    def test_base64_as_source_rejected_without_fallback(self):
        body=base64.b64encode(self.e).decode('ascii');response={'Body':body,'ContentLength':len(body)}
        with patch.object(p.json,'loads',side_effect=AssertionError('unverified source parsed')):
            with self.assertRaises(p.Failure):p.verify_source_response(response,self.pins,Ledger())
    def test_external_hash_precedes_json_for_literal_source(self):
        body='x'+self.response['Body'][1:];response={**self.response,'Body':body}
        with patch.object(p.json,'loads',side_effect=AssertionError('unverified source parsed')):
            with self.assertRaises(p.Failure):p.verify_source_response(response,self.pins,Ledger())
    def test_wrong_length_rejected_but_actual_ascii_copy_charged(self):
        response={**self.response,'ContentLength':0};led=Ledger()
        with self.assertRaises(p.Failure):p.verify_source_response(response,self.pins,led)
        self.assertEqual(led.used,len(p.wire(response))+len(self.e))
    def test_non_ascii_and_range_rejected(self):
        for response in [{**self.response,'Body':'☃'},{**self.response,'ContentRange':'bytes 0-1/2'},{**self.response,'ContentRange':None}]:
            with self.subTest(responseKeys=list(response)):
                with self.assertRaises(p.Failure):p.verify_source_response(response,self.pins,Ledger())
    def test_source_body_and_metadata_response_caps(self):
        cap=3145728
        for response,actual in [({'Body':'x'*(cap+1),'ContentLength':cap+1},None),(self.response,cap+65536+1),({**self.response,'Metadata':'x'*65537},None),(self.response,len(self.e)-1)]:
            with self.assertRaises(p.Failure):p.verify_source_response(response,self.pins,Ledger(),response_bytes=actual)
    def test_source_schema_rejects_non_integer_lengths_and_non_string_body(self):
        for response in [[],{}, {'Body':b'abc','ContentLength':3},{**self.response,'ContentLength':True},{**self.response,'ContentLength':'3'}]:
            with self.assertRaises(p.Failure):p.verify_source_response(response,self.pins,Ledger())
    def test_binary_output_still_requires_canonical_base64(self):
        data=b'PK\x03\x04tiny';response={'Body':base64.b64encode(data).decode('ascii'),'ContentLength':len(data)}
        self.assertEqual(p.output_response(response,Ledger())[0],data)
        with self.assertRaises(p.Failure):p.output_response({'Body':data.decode('ascii'),'ContentLength':len(data)},Ledger())
        with self.assertRaises(p.Failure):p.output_response({**response,'Body':response['Body']+'\n'},Ledger())

if __name__=='__main__':unittest.main()
