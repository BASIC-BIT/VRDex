"""Short private runtime and cleanup regressions. Only Python and local AF_UNIX."""
import json, os, pathlib, socket, shutil, subprocess, sys, tempfile, time, types, unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, packet_renderer as p, check_result as c

NONCE='4cb652e1b594462398f9ed9b6e0fdf12'

class RuntimePaths(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(prefix='',dir='/tmp');self.addCleanup(self.tmp.cleanup);self.base=pathlib.Path('/tmp')/pathlib.Path(self.tmp.name).name[:6];self.base.mkdir();self.addCleanup(shutil.rmtree,self.base)
        (self.base/'.owner').write_text(NONCE+'\n')
    def runtime(self):return d.create_runtime(self.base,NONCE)
    def close(self,root,state=None,daemon=None,env=None):
        return d.close_runtime(root,NONCE,daemon,env,time.monotonic()+2,{},state or {'freshDataRoot':True,'createAdmissions':0,'tracked':{}})
    def test_process_discovery_rejects_foreign_prefix_and_embedded_text(self):
        proc=self.base/'proc';proc.mkdir();root=pathlib.Path('/tmp/cd/d')
        foreign=[b'python3\0/tmp/cd/d-foreign/worker.py\0',b'python3\0message=/tmp/cd/d/worker.py\0',b'python3\0prefix/tmp/cd/d/worker.py\0',b'python3\0/tmp/cd/d/../foreign/worker.py\0',b'python3\0--message=/tmp/cd/d/worker.py\0',b'python3\0/tmp/cd/d//worker.py\0',b'python3\0/tmp/cd/d/worker.py']
        for index,argv in enumerate(foreign):
            entry=proc/str(2147483600+index);entry.mkdir();(entry/'cmdline').write_bytes(argv)
        self.assertEqual(d.owned_processes(root,time.monotonic()+1,proc=proc),[])
    def test_process_discovery_accepts_actual_daemon_containerd_and_socket_arguments(self):
        proc=self.base/'proc';proc.mkdir();root=pathlib.Path('/tmp/cd/d')
        owned=[b'/tmp/cd/d/bin/dockerd\0--host=unix:///tmp/cd/d/daemon.sock\0',b'containerd\0--config\0/tmp/cd/d/exec/containerd/containerd.toml\0',b'containerd-shim-runc-v2\0-address\0/tmp/cd/d/exec/containerd/containerd.sock\0',b'dockerd\0--data-root=/tmp/cd/d/data\0',b'dockerd\0--exec-root=/tmp/cd/d/exec\0',b'dockerd\0--pidfile=/tmp/cd/d/daemon.pid\0',b'dockerd\0--config-file=/tmp/cd/d/daemon.json\0',b'containerd\0--address=unix:///tmp/cd/d/exec/containerd/containerd.sock\0',b'containerd\0unix:/tmp/cd/d/exec/containerd/containerd.sock\0']
        expected=[]
        for index,argv in enumerate(owned):
            pid=2147483600+index;expected.append(pid);entry=proc/str(pid);entry.mkdir();(entry/'cmdline').write_bytes(argv)
        self.assertEqual(sorted(d.owned_processes(root,time.monotonic()+1,proc=proc)),expected)
    def test_foreign_group_leader_never_receives_a_signal(self):
        root=self.runtime();foreign=b'python3\0'+os.fsencode(str(root)+'-foreign/worker.py')+b'\0'
        # Simulate a discovered owned child whose group leader proves foreign.
        with patch.object(d,'owned_processes',return_value=[2147483646]),patch.object(d.os,'getpgid',return_value=2147483646),patch.object(d,'bounded',side_effect=lambda path,cap=65536:foreign if str(path).startswith('/proc/') else pathlib.Path(path).read_bytes()),patch.object(d.os,'killpg') as signal:
            facts=self.close(root)
        signal.assert_not_called();self.assertEqual(facts['state'],'incomplete');self.assertIn('owned_process_absence_unproven',facts['obligations'])
    def test_actual_shape_and_104_byte_paths_reject_before_creation(self):
        old=pathlib.Path('/tmp/codec-diagnostic-'+NONCE)/('owned-'+NONCE)
        for root in (old,pathlib.Path('/'+'x'*13)):
            with self.assertRaisesRegex(d.Failure,'runtime_socket_path'):d.runtime_sockets(root)
        self.assertGreater(len(str(old/'exec/containerd/containerd-debug.sock').encode('ascii')),104)
        self.assertEqual(len(str(pathlib.Path('/'+'x'*13)/'exec/containerd/daemon/s'/('a'*64)).encode('ascii')),104)
    def test_short_root_known_paths_bind_real_unix_sockets(self):
        paths=d.runtime_sockets(pathlib.Path('/tmp/cd/d'))
        self.assertIn(pathlib.Path('/tmp/cd/d/exec/containerd/containerd-debug.sock'),paths)
        self.assertIn(pathlib.Path('/tmp/cd/d/exec/containerd/daemon/s')/('a'*64),paths)
        self.assertTrue(all(len(str(x).encode('ascii'))<=103 for x in paths))
        root=self.runtime()
        for path in d.runtime_sockets(root):
            path.parent.mkdir(parents=True,exist_ok=True)
            with socket.socket(socket.AF_UNIX) as sock:sock.bind(str(path))
            path.unlink()
    def test_runtime_is_exclusive_and_bound_to_full_nonce(self):
        root=self.runtime();self.assertEqual(root,self.base/'d');self.assertEqual((root/'.owner').read_text(),NONCE+'\n');self.assertEqual(list((root/'data').iterdir()),[])
        with self.assertRaises(FileExistsError):self.runtime()
        (self.base/'.owner').write_text('foreign\n')
        with self.assertRaisesRegex(d.Failure,'runtime_ownership'):d.create_runtime(self.base,NONCE)
    def test_renderer_and_bootstrap_keep_nonce_in_exclusive_marker(self):
        pins=p.identities(b'e',b'z',b'm');request,ready=p.render(pins,nonce=NONCE,bucket='b',source_key='s',evidence_prefix='e',role_arn='r')
        self.assertEqual(ready['evidenceBaseDirectory'],'/tmp/cd/evidence');self.assertEqual(json.loads(request['source']['buildspec'])['artifacts']['base-directory'],'/tmp/cd/evidence');self.assertIn(NONCE,request['name'])
        target=self.base/'boot'
        with patch.dict(os.environ,{'CODEBUILD_START_TIME':str(int(time.time()*1000))}),patch.object(p,'cli',side_effect=p.Failure('signing_failed')):
            with self.assertRaises(p.Failure):p.bootstrap(pins,'b','k','us-east-1',NONCE,str(target))
        self.assertEqual((target/'.owner').read_text(),NONCE+'\n')
        with patch.object(p,'cli') as sign:
            with self.assertRaises(p.Failure):p.bootstrap(pins,'b','k','us-east-1',NONCE,str(target))
        sign.assert_not_called()
    def test_never_ready_zero_create_closes_without_docker_query(self):
        root=self.runtime()
        with patch.object(d,'command',side_effect=AssertionError('daemon was never ready')):
            facts=self.close(root,env={'DOCKER_HOST':'unused'})
        self.assertEqual(facts['state'],'closed');self.assertEqual(facts['containerAbsence'],'no_create_admitted');self.assertTrue(facts['freshDataRoot']);self.assertEqual(facts['createAdmissions'],0)
    def test_stale_socket_removed_only_after_process_absence(self):
        root=self.runtime();path=root/'daemon.sock'
        with socket.socket(socket.AF_UNIX) as sock:sock.bind(str(path))
        seen=[]
        def census(*args,**kw):seen.append(path.exists());return []
        with patch.object(d,'owned_processes',side_effect=census):facts=self.close(root)
        self.assertTrue(seen and all(seen));self.assertEqual(facts['state'],'closed');self.assertFalse(path.exists())
    def test_owned_python_daemon_group_is_reaped_before_stale_unlink(self):
        root=self.runtime();path=root/'daemon.sock'
        with socket.socket(socket.AF_UNIX) as sock:sock.bind(str(path))
        proc=subprocess.Popen([sys.executable,'-c','import time;time.sleep(20)',str(root)],start_new_session=True)
        self.addCleanup(lambda:d.kill_group(proc,time.monotonic()+1))
        facts=self.close(root,daemon=proc)
        self.assertEqual(facts['state'],'closed',facts);self.assertIsNotNone(proc.poll());self.assertTrue(facts['ownedProcessesAbsent']);self.assertFalse(path.exists())
    def test_live_nested_socket_keeps_runtime_incomplete(self):
        root=self.runtime();path=root/'exec/containerd/containerd-debug.sock';path.parent.mkdir(parents=True)
        with socket.socket(socket.AF_UNIX) as sock:
            sock.bind(str(path));sock.listen(1);facts=self.close(root)
            self.assertEqual(facts['state'],'incomplete');self.assertTrue(path.exists())
    def test_unknown_create_admission_stays_tracked_after_create_error(self):
        from test_delegated import fixture
        parent=types.SimpleNamespace(evidence=fixture)
        state={'freshDataRoot':True,'createAdmissions':0,'tracked':{}}
        root=self.runtime();ev=d.Evidence(self.base/'evidence');monitor=types.SimpleNamespace(check=lambda:None)
        with patch.object(d,'command',side_effect=d.Failure('create_transport_failed')):
            cell=d.run_cell(d.MATRIX[0],0,NONCE,{'imageId':'image','controlVisibilityPolicy':'allow-incomplete-delegated-v1'},root,{},d.Clocks(time.time()),monitor,ev,[0,1],parent,{},state)
        self.assertEqual(state['createAdmissions'],1);self.assertEqual(state['tracked'],{'codec-'+NONCE+'-00':None});self.assertEqual(cell['cleanup']['state'],'incomplete');self.assertEqual(cell['reason'],'create_transport_failed')
    def test_live_foreign_socket_and_marker_are_never_removed(self):
        for foreign in (False,True):
            with self.subTest(foreign=foreign):
                root=self.base/'d'
                if not root.exists():root=self.runtime()
                path=root/'daemon.sock'
                if foreign:(root/'.owner').write_text('foreign\n')
                with socket.socket(socket.AF_UNIX) as sock:
                    sock.bind(str(path));sock.listen(1);facts=self.close(root);self.assertEqual(facts['state'],'incomplete');self.assertTrue(path.exists())
                path.unlink()
    def test_unclosed_group_and_tracked_container_keep_stale_socket(self):
        root=self.runtime();path=root/'daemon.sock'
        with socket.socket(socket.AF_UNIX) as sock:sock.bind(str(path))
        with patch.object(d,'kill_group',return_value=False):
            facts=self.close(root,daemon=types.SimpleNamespace(pid=999999))
        self.assertEqual(facts['state'],'incomplete');self.assertTrue(path.exists());self.assertIn('daemon_process_group_unclosed',facts['obligations'])
        state={'freshDataRoot':True,'createAdmissions':1,'tracked':{'codec-'+NONCE+'-00':None}}
        with patch.object(d,'command',side_effect=d.Failure('daemon_unavailable')):facts=self.close(root,state=state,env={'x':'y'})
        self.assertEqual(facts['containerAbsence'],'unproven');self.assertEqual(facts['state'],'incomplete');self.assertTrue(path.exists())
    def test_final_container_reconciliation_queries_only_tracked_names(self):
        root=self.runtime();name='codec-'+NONCE+'-00';cid='b'*64;state={'freshDataRoot':True,'createAdmissions':1,'tracked':{name:cid}};calls=[]
        def command(args,*a,**kw):
            calls.append(args)
            return {'stdout':(cid+'\n').encode() if len(calls)==1 else b''}
        with patch.object(d,'command',side_effect=command):facts=self.close(root,state=state,env={'DOCKER_HOST':'private'})
        self.assertEqual(facts['state'],'closed');self.assertEqual(facts['containerAbsence'],'tracked_reconciled');self.assertEqual(facts['trackedContainers'],[])
        self.assertEqual(calls[1],['docker','rm','-f',cid]);self.assertTrue(all('name=^/'+name+'$' in args for args in (calls[0],calls[2])))
    def test_checker_validates_no_create_proof_and_incomplete_union(self):
        facts={'state':'closed','obligations':[],'ownedRoot':'/tmp/cd/d','containerAbsence':'no_create_admitted','freshDataRoot':True,'createAdmissions':0,'trackedContainers':[],'daemonReaped':True,'unclosedAttachGroups':[],'socketAbsent':True,'ownedProcessesAbsent':True}
        result=d.empty_result(NONCE,{'imageId':'image'},'daemon_failed');result['cleanup']=facts
        c.check(result,{},NONCE,expected_pins={'imageId':'image'})
        for key,value in [('freshDataRoot',False),('createAdmissions',1),('trackedContainers',['owned']),('ownedProcessesAbsent',False),('socketAbsent',False)]:
            bad=json.loads(json.dumps(result));bad['cleanup'][key]=value
            with self.assertRaises(c.Invalid):c.check(bad,{},NONCE,expected_pins={'imageId':'image'})
    def test_no_create_proof_allows_a_cell_failure_before_create(self):
        result=d.empty_result(NONCE,{'imageId':'image'},'resource_control_unproven');result['cells'][0]['state']='incomplete'
        result['cleanup']={'state':'closed','obligations':[],'ownedRoot':'/tmp/cd/d','containerAbsence':'no_create_admitted','freshDataRoot':True,'createAdmissions':0,'trackedContainers':[],'daemonReaped':True,'unclosedAttachGroups':[],'socketAbsent':True,'ownedProcessesAbsent':True}
        self.assertEqual(c.check(result,{},NONCE,expected_pins={'imageId':'image'})['counts']['incomplete'],1)
    def test_early_failure_primary_reason_survives_cleanup_failure(self):
        actual=pathlib.Path(d.__file__).parent;source=self.base/'code';source.mkdir()
        for name in p.FILES:
            if name=='manifest.json':continue
            dest=source/name;dest.parent.mkdir(exist_ok=True);dest.write_bytes((actual/name).read_bytes())
        p.freeze(source,self.base/'packet')
        monitor=types.SimpleNamespace(start=lambda:None,finish=lambda:{},check=lambda:None)
        with patch.object(d,'__file__',str(source/'diagnostic.py')),patch.object(d,'Monitor',return_value=monitor),patch.object(d,'Cgroups',side_effect=d.Failure('resource_control_unproven')),patch.object(d,'owned_processes',side_effect=d.Failure('census_failed')):
            result=d.run(NONCE,self.base/'evidence',time.time())
        self.assertEqual(result['failure'],'resource_control_unproven');self.assertEqual(result['cleanup']['state'],'incomplete');self.assertEqual(result['cleanup']['containerAbsence'],'no_create_admitted');self.assertTrue((self.base/'d').exists())

if __name__=='__main__':unittest.main()
