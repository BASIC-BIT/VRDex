"""Offline, bounded diagnostic evidence checker. Never invokes external tools."""
import argparse, csv, hashlib, io, json, math, os, pathlib, re, stat, sys, zipfile
import diagnostic as d
import probe
class Invalid(ValueError):pass
def require(ok,why):
    if not ok:raise Invalid(why)
def unique(pairs):
    result={}
    for k,v in pairs:require(k not in result,'duplicate_json_key');result[k]=v
    return result

def close(a,b):
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):return math.isfinite(a) and math.isfinite(b) and math.isclose(a,b,rel_tol=1e-10,abs_tol=1e-10)
    if isinstance(a,dict) and isinstance(b,dict):return a.keys()==b.keys() and all(close(a[k],b[k]) for k in a)
    if isinstance(a,list) and isinstance(b,list):return len(a)==len(b) and all(close(x,y) for x,y in zip(a,b))
    return type(a) is type(b) and a==b

CONTROLLERS=('cpu','cpuacct','memory','cpuset')
POLICY='allow-incomplete-delegated-v1'
CONTROL_FILES=(('cpu','cpu.cfs_quota_us'),('cpu','cpu.cfs_period_us'),('memory','memory.limit_in_bytes'),('memory','memory.memsw.limit_in_bytes'),('cpuset','cpuset.cpus'))
COUNTER_FILES=(('cpuacct','cpuacct.usage'),('cpuacct','cpuacct.stat'),('cpu','cpu.stat'),('memory','memory.usage_in_bytes'),('memory','memory.max_usage_in_bytes'),('memory','memory.failcnt'),('memory','memory.oom_control'))
def path(text):
    require(isinstance(text,str) and text.startswith('/') and not text.startswith('//') and not any(c in text for c in ('\\','\x00','\n','\r','\t')),'canonical_path')
    p=pathlib.PurePosixPath(text);require(str(p)==text and '..' not in p.parts,'canonical_path');return p

def cpus(text):
    out=set()
    for span in text.strip().split(','):
        require(bool(re.fullmatch(r'[0-9]+(?:-[0-9]+)?',span)),'cpuset_syntax');v=span.split('-');a=int(v[0]);b=int(v[-1]);require(0<=a<=b<65536,'cpuset_range');out.update(range(a,b+1))
    return sorted(out)

def hierarchy(raw,policy):
    groups={};mounts={};roots={};devices={}
    for line in raw['membership'].splitlines():
        pieces=line.split(':',2);require(len(pieces)==3 and pieces[0].isdigit() and int(pieces[0])>0 and pieces[1],'v1_membership')
        canonical=path(pieces[2])
        for c in pieces[1].split(','):require(c and c not in groups,'duplicate_controller');groups[c]=str(canonical)
    require(set(CONTROLLERS)<=set(groups),'required_controllers')
    for line in raw['mountinfo'].splitlines():
        left,sep,right=line.partition(' - ');l=left.split();r=right.split();require(sep and len(l)>=6 and len(r)>=3,'mountinfo')
        require(r[0]!='cgroup2','unsupported_v2')
        if r[0]!='cgroup':continue
        relevant=set(r[2].split(','))&set(CONTROLLERS)
        for c in relevant:
            require(c not in mounts and re.fullmatch(r'[0-9]+:[0-9]+',l[2]),'ambiguous_mount');roots[c]=str(path(l[3]));mounts[c]=str(path(l[4]));devices[c]=l[2]
    require(set(mounts)==set(CONTROLLERS) and len(set(roots.values()))==1 and len({groups[c] for c in CONTROLLERS})==1,'aligned_mounts')
    require(all(path(groups[c]).is_relative_to(path(roots[c])) for c in CONTROLLERS),'mount_root_containment')
    delegated=roots['cpu']!='/'
    require(not delegated or (policy==POLICY and re.fullmatch(r'/ecs/[^/]+/[^/]+',roots['cpu'])),'delegated_policy_or_form')
    return {'groups':groups,'mounts':mounts,'roots':roots,'devices':devices,'delegated':delegated}

def known_namespaces(value):
    names=('cgroup','mnt','pid','net','user')
    require(isinstance(value,dict) and set(value)==set(names),'namespace_ids_missing')
    for name in names:require(isinstance(value[name],str) and re.fullmatch(name+r':\[[1-9][0-9]*\]',value[name]),'namespace_id_format')
    return value

def collector_view(raw,policy):
    target=hierarchy(raw,policy);collector=raw.get('collector')
    if not collector:require(not target['delegated'],'collector_missing');return target
    view=hierarchy(collector,policy)
    if target['delegated'] or view['delegated']:known_namespaces(raw.get('namespaces'));known_namespaces(collector.get('namespaces'))
    require(raw['namespaces']['cgroup']==collector['namespaces']['cgroup'],'collector_cgroup_namespace')
    for c in CONTROLLERS:
        require(target['devices'][c]==view['devices'][c] and path(target['roots'][c]).is_relative_to(path(view['roots'][c])) and path(target['groups'][c]).is_relative_to(path(view['roots'][c])),'collector_mount_mapping')
    return {**view,'groups':target['groups']}

def parents(member,root):
    p=path(member);r=path(root);require(p.is_relative_to(r),'visible_ancestry');out=[]
    while p!=r:p=p.parent;out.append(str(p))
    return out

def control_records(raw,policy):
    h=collector_view(raw,policy);records=[];required=set()
    for relative in [h['groups']['cpu']]+parents(h['groups']['cpu'],h['roots']['cpu']):
        texts={}
        for c,n in CONTROL_FILES:
            p=str(path(h['mounts'][c])/path(relative).relative_to(path(h['roots'][c]))/n);required.add(p);texts[n]=raw['controlFiles'][p]
        record={'path':relative,'quota':int(texts['cpu.cfs_quota_us']),'period':int(texts['cpu.cfs_period_us']),'memory':int(texts['memory.limit_in_bytes']),'memsw':int(texts['memory.memsw.limit_in_bytes']),'cpus':cpus(texts['cpuset.cpus'])}
        require(record['period']>0 and (record['quota']==-1 or record['quota']>0) and record['memory']>0 and record['memsw']>=record['memory'],'control_numeric');records.append(record)
    require(set(raw['controlFiles'])==required,'control_raw_paths')
    if h['delegated']:
        reads=raw.get('controlReads',{});require(set(reads)==required,'control_read_set')
        for name,fact in reads.items():require(fact.get('path')==name and fact.get('complete') is True and fact.get('value')==raw['controlFiles'][name] and 'error' not in fact and type(fact.get('t')) in (int,float) and math.isfinite(fact['t']),'control_read_join')
    return records,h

def identity(raw,require_fields=False):
    ident=raw['identity'];text=ident['stat'];require(int(text.split(' ',1)[0])==raw['pid'],'identity_pid')
    start=text.rsplit(')',1)[1].split()[19];require(start.isdigit() and ident.get('startTime',start)==start,'identity_start')
    if require_fields:
        known_namespaces(raw.get('namespaces'))
        require(raw.get('complete') is True and not raw.get('readErrors') and not raw.get('failedSubcheck'),'capture_incomplete')
        fields=raw['fields'];expected={'membership':raw['membership'],'mountinfo':raw['mountinfo'],'affinity':raw['affinity'],**{'namespaces.'+n:raw['namespaces'][n] for n in ('cgroup','mnt','pid','net','user')},**{'identity.'+n:ident[n] for n in ('stat','cmdline','status')}}
        require(set(fields)==set(expected),'capture_field_set')
        for name,value in expected.items():
            f=fields[name];suffix={'membership':'cgroup','mountinfo':'mountinfo','affinity':'status:sched_getaffinity'}.get(name,name.split('.',1)[-1] if name.startswith('identity.') else 'ns/'+name.split('.',1)[-1])
            require(f.get('complete') is True and 'error' not in f and f.get('value')==value and f.get('path')==f"/proc/{raw['pid']}/{suffix}" and type(f.get('t')) in (int,float) and math.isfinite(f['t']),'capture_field_join')
    return start

def process_controls(raw,cell,state,policy=None):
    """Reconstruct the proof from raw texts without calling collector proof code."""
    controls=raw.get('controls');keeper=raw.get('keeper');parent=raw.get('parent');ffmpeg=raw.get('ffmpeg')
    events=[e['message'] for e in raw['events']];ready=[e for e in events if e['event']=='READY'];started=[e for e in events if e['event']=='STARTED']
    require(len(ready)<=1 and len(started)<=1,'protocol_stage');delegated=False;kv=None
    if parent:
        pr,pv=control_records(parent,policy);delegated=pv['delegated']
        require(all((a['quota']==-1 or a['quota']/a['period']>=2) and a['memory']>=4294967296 for a in pr),'parent_controls')
    if keeper:
        kr,kv=control_records(keeper,policy);kl=kr[0];ka=kr[1:];selected=set(keeper['affinity']);delegated=kv['delegated']
        require(parent and all(kv[k]==pv[k] for k in ('roots','mounts','devices')),'parent_collector_mapping')
        require(all(path(kv['groups'][c]).is_relative_to(path(pv['groups'][c])) and kv['groups'][c]!=pv['groups'][c] for c in CONTROLLERS),'parent_membership_join')
        require(selected<=set(parent['affinity']) and all(selected<=set(a['cpus']) and (a['quota']==-1 or a['quota']/a['period']>=2) and a['memory']>=4294967296 for a in pr+ka),'visible_constraints')
        require(keeper['namespaces']['net']!=parent['namespaces']['net'] and keeper['namespaces']['pid']!=parent['namespaces']['pid'],'process_namespace_join')
    if controls:
        require(keeper and parent and len(ready)==1,'control_stage')
        require(kl['quota']==200000 and kl['period']==100000 and kl['memory']==kl['memsw']==4294967296 and len(selected)==2 and selected==set(kl['cpus']) and ka,'leaf_controls')
        observed={'effectiveCpus':2,'memoryBytes':4294967296,'leaf':kl,'ancestors':ka,'affinity':sorted(selected),'hierarchy':'v1','visible':True}
        if delegated:
            observed.update(effectiveCpus=None,visible=False,visibility='delegated_subtree',fullHostVisible=False,leafQuotaCores=2,unknownHigherAncestors=[{'controller':c,'visibleRoot':kv['roots'][c]} for c in CONTROLLERS],rawRefs=['parent','keeper']+(['ffmpeg'] if ffmpeg else []))
            for process in [parent,keeper]+([ffmpeg] if ffmpeg else []):
                identity(process,True);collector=process['collector'];identity(collector,True)
                require(collector['pid']==parent['pid'] and collector['namespaces']==parent['namespaces'] and collector['membership']==parent['membership'] and identity(collector)==identity(parent),'collector_identity_join')
                cv=hierarchy(collector,policy);require(all(cv[k]==pv[k] for k in ('roots','mounts','devices')),'collector_controller_join')
        require(close(observed,controls),'controls_source_join')
        facts=ready[0]['facts'];require(facts['affinity']==controls['affinity'] and facts['uid']==65534 and not facts['credentialEnvironment'] and facts['interfaces']==['lo'] and len(facts['routes'].splitlines())==1,'ready_control_join')
        if delegated:require(known_namespaces(facts.get('namespaces'))==known_namespaces(keeper.get('namespaces')),'ready_namespace_join')
    else:require(state!='observed','controls_missing')
    if started:require(started[0]['argv']==probe.ffmpeg_argv(cell),'started_workload_join')
    if ffmpeg:
        fr,fv=control_records(ffmpeg,policy)
        require(controls and len(started)==1 and ffmpeg['affinity']==controls['affinity'] and ffmpeg['membership']==keeper['membership'] and ffmpeg['namespaces']==keeper['namespaces'] and fv==kv and fr==kr,'process_control_join')
        require(ffmpeg['hostPid']==ffmpeg['pid'] and ffmpeg['namespacePid']==started[0]['pid'] and ffmpeg['affinity']==started[0]['affinity'] and ffmpeg['argv']==started[0]['argv']==probe.ffmpeg_argv(cell),'ffmpeg_workload_join')
        if delegated:
            require(ffmpeg['identity']['cmdline'].split('\x00')[:-1]==started[0]['argv'],'kernel_argv_join')
            ids=next(line for line in ffmpeg['identity']['status'].splitlines() if line.startswith('NSpid:')).split()[1:]
            require(int(ids[0])==ffmpeg['pid'] and int(ids[-1])==started[0]['pid'],'kernel_namespace_pid_join')
    else:require(state!='observed' and not raw.get('samples') and raw.get('exit') is None,'ffmpeg_stage_missing')
    require(cell.get('cleanup')==raw['cleanup'] and type(raw['cleanup'].get('attachGroupClosed')) is bool,'cleanup_join')
    if raw['cleanup']['state']=='closed':require(raw['cleanup'].get('attachGroupClosed') is True,'attach_group_cleanup')
    else:require(state!='observed','cleanup_incomplete')
    if raw['cleanup'].get('attachGroupClosed') is False:require(state!='observed' and 'attach_group_unclosed' in raw['cleanup'].get('obligations',[]),'attach_group_obligation')
    counter_paths={str(path(kv['mounts'][c])/path(kv['groups'][c]).relative_to(path(kv['roots'][c]))/name) for c,name in COUNTER_FILES} if keeper else set()
    return counter_paths,delegated

def derived_rates(samples,delegated,refs):
    missing=lambda why:{'state':'missing','reason':why}
    values={k:missing('insufficient_post_warmup_samples') for k in ('fps','speed','cpuCores','cpuPercent')}
    if delegated:values['cpuPercent']=missing('effective_cpu_entitlement_unknown')
    for s in samples:
        require(set(s)=={'t','frame','mediaUs','cpuNs'} and all(type(v) in (int,float) and math.isfinite(v) and v>=0 for v in s.values()) and all(type(s[k]) is int for k in ('frame','mediaUs','cpuNs')),'sample_units')
    for a,b in zip(samples,samples[1:]):require(b['t']>a['t'] and all(b[k]>=a[k] for k in ('frame','mediaUs','cpuNs')),'sample_reset')
    selected=[s for s in samples if s['mediaUs']>=5000000]
    if len(selected)<2:return values
    a,b=selected[0],selected[-1];dt=b['t']-a['t'];interval={'wallMono':[a['t'],b['t']],'mediaSeconds':[a['mediaUs']/1e6,b['mediaUs']/1e6],'frames':[a['frame'],b['frame']],'coverage':'actual_sampled_post_warmup'}
    core=(b['cpuNs']-a['cpuNs'])/1e9/dt
    for k,v,unit in [('fps',(b['frame']-a['frame'])/dt,'frames/s'),('speed',(b['mediaUs']-a['mediaUs'])/1e6/dt,'media_s/wall_s'),('cpuCores',core,'core-equivalents')]+([] if delegated else [('cpuPercent',core*50,'percent_of_verified_2_cpus')]):values[k]={'state':'available','value':v,'unit':unit,'interval':interval,'sourceRefs':refs}
    return values

def inspect_isolation(value,image,selected,source):
    require(value['Image']==image,'container_image');h=value['HostConfig'];config=value['Config']
    require(h['NetworkMode']=='none' and h['ReadonlyRootfs'] is True and h['Privileged'] is False and h['Memory']==4294967296 and h['MemorySwap']==4294967296 and h['CpuPeriod']==100000 and h['CpuQuota']==200000 and cpus(h['CpusetCpus'])==selected and h['PidsLimit']==128,'container_controls')
    require(h['CapDrop']==['ALL'] and h['SecurityOpt']==['no-new-privileges'],'container_security')
    require(not any(h.get(k) for k in ('Devices','DeviceRequests','ExtraHosts','Binds','Tmpfs','PidMode')) and h.get('IpcMode')!='host','container_isolation')
    require(config['User']=='65534:65534' and config['Entrypoint']==['python3'],'container_user_entrypoint')
    require(value['Mounts']==[{'Source':source,'Destination':'/codec-probe.py','RW':False}] or (len(value['Mounts'])==1 and value['Mounts'][0]['Source']==source and value['Mounts'][0]['Destination']=='/codec-probe.py' and value['Mounts'][0]['RW'] is False),'container_mount')

def completed_joins(raw,cell,files,index):
    require(raw.get('attachExitCode')==0,'attach_process_exit')
    selected=raw['keeper']['affinity'];create=raw['createArgv'];require(len(create)>18,'create_argv')
    mounts=[v for v in create if v.startswith('--mount=')];require(len(mounts)==1,'create_mount')
    prefix='--mount=type=bind,src=';suffix=',dst=/codec-probe.py,readonly';mount=mounts[0]
    require(mount.startswith(prefix) and mount.endswith(suffix),'create_mount');source=mount[len(prefix):-len(suffix)];require(path(source).name=='probe.py','probe_source_path')
    preset={k:cell[k] for k in d.MATRIX[0]};wire=json.dumps(preset,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)
    expected=['docker','create','--name',f"codec-{raw['nonce']}-{index:02d}",'--pull=never','--network=none','--read-only','--user=65534:65534','--cap-drop=ALL','--security-opt=no-new-privileges','--pids-limit=128','--memory=4294967296','--memory-swap=4294967296','--cpu-period=100000','--cpu-quota=200000','--cpuset-cpus='+','.join(map(str,selected)),mount,'--entrypoint=python3','--interactive',raw['imageId'],'-I','-B','/codec-probe.py','--cell',wire]
    require(create==expected,'create_argv_join')
    require(re.fullmatch(r'[0-9a-f]{64}',raw['createdContainerId']) and raw['readyInspect']['Id']==raw['terminalInspect']['Id']==raw['createdContainerId'],'container_identity_join')
    for value in (raw['readyInspect'],raw['terminalInspect']):inspect_isolation(value,raw['imageId'],selected,source)
    captures=[f'cell-{index:02d}-keeper-capture.json',f'cell-{index:02d}-ffmpeg-capture.json'];require(raw.get('processCaptures')==captures,'process_capture_refs')
    for key,name in zip(('keeper','ffmpeg'),captures):
        require(name in files,'process_capture_missing');capture=json.loads(files[name],object_pairs_hook=unique);expected={k:v for k,v in raw[key].items() if k not in ('hostPid','namespacePid','argv')}
        require(capture==expected,'process_capture_join')
    require(raw['readyInspect']['State']['Pid']==raw['keeper']['pid'] and raw['readyInspect']['State']['Running'] is True and raw['readyInspect']['State']['OOMKilled'] is False,'ready_process_inspect')
    log=f'cell-{index:02d}-stdout.log';err=f'cell-{index:02d}-stderr.log';require(log in files and err in files,'capture_log_refs')
    body=files[log];require(body.endswith(b'\n') and raw['stdoutBytes']==len(body) and raw['stderrBytes']==len(files[err]),'capture_log_lengths')
    messages=[json.loads(line,object_pairs_hook=unique) for line in body.splitlines()]
    require(messages==[e['message'] for e in raw['events']],'event_raw_log_join')
    tags=[e['event'] for e in messages];require(tags[:2]==['READY','STARTED'] and tags[-1]=='EXIT' and all(t=='PROGRESS' for t in tags[2:-1]),'completed_protocol_order')
    require(messages[-1]==raw['exit'] and messages[-2]['raw']['progress']=='end' and all(m['raw']['progress']=='continue' for m in messages[2:-2]),'completed_protocol_join')
    require(raw['exit'].get('pid')==raw['ffmpeg']['namespacePid'],'exit_pid_join')
    require(type(raw['exit']['ffmpegPeakKiB']) in (int,float) and math.isfinite(raw['exit']['ffmpegPeakKiB']) and raw['exit']['ffmpegPeakKiB']>0,'wait4_peak')
    events=raw['events'];require(all(raw['start']<=e['t']<=raw['end'] for e in events) and all(a['t']<=b['t'] for a,b in zip(events,events[1:])) and raw['end']<=raw['deadline'],'completed_event_clock')
    snaps=raw['snapshots']+[raw['final']];require(2<=len(snaps)<=402 and all(raw['start']<=s['t']<=raw['end'] for s in snaps) and all(a['t']<b['t'] for a,b in zip(snaps,snaps[1:])),'counter_clock')
    counters=['cpuacct.usage','cpuacct.stat:user','cpuacct.stat:system','cpu.stat:nr_periods','cpu.stat:nr_throttled','cpu.stat:throttled_time','memory.max_usage_in_bytes','memory.failcnt']
    for a,b in zip(snaps,snaps[1:]):require(all(b['values'][k]>=a['values'][k] for k in counters),'whole_run_counter_reset')

def csv_agreement(cells,body):
    columns=['cell','state','reason','metric','metricState','value','unit','missingReason','measurementStatus','executionComplete','controlVisibility','fullHostVisible']
    reader=csv.DictReader(io.StringIO(body.decode('ascii')));names=reader.fieldnames
    require(names in (columns,columns[:8]),'csv_columns');rows=list(reader);require(len(rows)==12*len(d.METRICS),'csv_row_count');seen=set()
    by_id={c['id']:c for c in cells}
    for row in rows:
        require(set(row)==set(names) and row['cell'] in by_id and row['metric'] in d.METRICS,'csv_cell_metric');key=(row['cell'],row['metric']);require(key not in seen,'csv_duplicate');seen.add(key)
        cell=by_id[row['cell']];fact=cell['metrics'][row['metric']]
        expected={'cell':cell['id'],'state':cell['state'],'reason':cell.get('reason') or '','metric':row['metric'],'metricState':fact['state'],'value':str(fact.get('value','')),'unit':fact.get('unit',''),'missingReason':fact.get('reason','')}
        for name in columns[8:]:expected[name]=str(cell.get(name,'')).lower() if type(cell.get(name)) is bool else cell.get(name,'')
        require(all(row[k]==expected[k] for k in names),'csv_json_divergence')
        if cell.get('controlVisibility')=='delegated_subtree':require(names==columns,'csv_delegated_metadata')

def storage_mount_rows(text):
    require(isinstance(text,str) and len(text.encode())<=262144,'storage_mountinfo_cap');rows=[]
    for line in text.splitlines():
        f=line.split();require(len(f)>=10 and f.count('-')==1,'storage_mountinfo');i=f.index('-');require(i>=6 and len(f)>=i+4,'storage_mountinfo')
        rows.append({'mountpoint':str(path(f[4])),'device':f[2],'filesystem':f[i+1],'readWrite':'rw' in f[5].split(',') and 'rw' in f[i+3].split(','),'mountId':f[0]})
    return rows

def storage_joins(result):
    storage=result.get('storage');loaded='load' in result or any(c['state']!='not_run' for c in result['cells']);daemon=result.get('daemon')
    require(isinstance(storage,dict),'storage_missing')
    admitted=storage.get('owned') is True
    if not admitted:
        require(result.get('failure') and not loaded and 'daemon' not in result and 'actual' not in storage,'storage_incomplete')
        # A never-admitted data child can still have a fully proved parent closure.
        # Closed claims take the same parent/marker/mount/absence joins below.
        if not storage.get('created') or result['cleanup']['state']!='closed':
            if storage.get('created'):require(result['cleanup']['state']=='incomplete','storage_unowned_closure')
            return
    nonce=result['nonce'];root='/codebuild/output/codec-'+nonce;data=root+'/data';control='/tmp/cd/d'
    require(storage.get('root')==root and storage.get('dataRoot')==data and storage.get('nonce')==nonce and storage.get('created') is True,'storage_path_join')
    source=result.get('sourceIdentities',{}).get('diagnostic.py');require(source and storage.get('source')==source,'storage_source_join')
    marker=(json.dumps({'nonce':nonce,'source':source},sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii');mp=storage.get('marker',{})
    require(mp.get('bytes')==len(marker) and mp.get('sha256')==hashlib.sha256(marker).hexdigest(),'storage_marker_join')
    ident=storage.get('identity',{});device=ident.get('device');require(type(device) is int and device>=0,'storage_device')
    identities=[(ident,0o700),(mp.get('identity'),0o600)]
    if admitted:identities.append((storage.get('dataIdentity'),0o700))
    for value,mode in identities:
        require(isinstance(value,dict) and value.get('device')==device and value.get('uid')==ident.get('uid') and type(value.get('uid')) is int and value['uid']>=0 and value.get('mode')==mode and type(value.get('inode')) is int and value['inode']>0,'storage_identity_join')
    backing=storage['backing'];require(backing['mountpoint']=='/codebuild/output' and backing['filesystem']=='xfs' and backing['readWrite'] is True and backing['device']==f'{os.major(device)}:{os.minor(device)}','storage_backing_join')
    for name in ['mountinfo']+(['preloadMountinfo'] if 'actual' in storage else []):
        rows=storage_mount_rows(storage[name]);matches=[r for r in rows if path(data).is_relative_to(path(r['mountpoint']))]
        require(matches and max(matches,key=lambda r:len(r['mountpoint']))==backing and sum(r['mountpoint']=='/codebuild/output' for r in rows)==1 and not any(path(r['mountpoint']).is_relative_to(path(root)) for r in rows),'storage_mount_join')
    if daemon:
        expected=[control+'/bin/dockerd','--host=unix://'+control+'/daemon.sock','--data-root='+data,'--exec-root='+control+'/exec','--pidfile='+control+'/daemon.pid','--config-file='+control+'/daemon.json','--iptables=false','--bridge=none','--ip-forward=false','--ip-masq=false','--storage-driver=overlay2']
        require(daemon.get('args')==expected and daemon.get('socket')==control+'/daemon.sock' and daemon.get('config')=={},'storage_argv_join')
    require(not (loaded or (daemon and not result.get('failure'))) or storage.get('actual',{}).get('verified') is True,'storage_actual_missing')
    if 'actual' in storage:
        require(daemon is not None,'storage_actual_daemon');info=daemon['info'];version=json.loads(daemon['version'],object_pairs_hook=unique)
        require(info.get('Driver')=='overlay2' and info.get('DockerRootDir')==data and info.get('ServerVersion')==version.get('Server',{}).get('Version')==version.get('Client',{}).get('Version')=='24.0.9','storage_info_join')
        status=info.get('DriverStatus',[]);require(isinstance(status,list) and all(isinstance(p,list) and len(p)==2 for p in status) and sum(p[0]=='Backing Filesystem' for p in status)==sum(p[0]=='Supports d_type' for p in status)==1,'storage_status_join');values=dict(status)
        require(values.get('Backing Filesystem')=='xfs' and values.get('Supports d_type')=='true','storage_status_join')
        require(storage['actual']=={'verified':True,'driver':'overlay2','dataRoot':data,'backingFilesystem':'xfs','supportsDType':True,'dockerVersion':'24.0.9'},'storage_actual_join')
    resources=result.get('resources',{});roots=resources.get('roots')
    require(roots==['/tmp/cd',root] or (result.get('failure') and not daemon and not loaded and roots==['/tmp/cd']),'storage_monitor_roots')
    for name,value in [('scanEntryLimit',100000),('scanSecondsLimit',.8),('entryChargeBytes',256),('smallWorkLimit',536870912),('diskCeilingBytes',6442450944)]:require(resources.get(name)==value,'storage_monitor_limits')
    scan=resources.get('lastScan')
    if scan is not None:
        parts=scan['roots'];require([p['root'] for p in parts]==roots and all(type(p['entries']) is int and 0<=p['entries']<=100001 and type(p['allocatedBlocksBytes']) is int and p['allocatedBlocksBytes']>=0 for p in parts),'storage_monitor_parts')
        require(sum(p['entries'] for p in parts)==scan['entries'] and sum(p['allocatedBlocksBytes'] for p in parts)==scan['allocatedBlocksBytes'],'storage_monitor_sum')
        if scan['complete']:require(scan['entries']<=100000 and scan['elapsedSeconds']<.8 and scan['allocatedBlocksBytes']<=6442450944,'storage_monitor_completed_limits')
    if result['cleanup']['state']=='closed':
        closure=storage.get('closure',{});require(closure.get('absent') is True and closure.get('mountsBeneath')==[] and closure.get('identity')==ident and closure.get('markerSHA256')==mp['sha256'] and result['cleanup'].get('runtimeAbsent') is True,'storage_closure_join')
        require(not any(path(r['mountpoint']).is_relative_to(path(root)) for r in storage_mount_rows(closure['mountinfo'])),'storage_closure_mounts')

def check(result,files,expected_nonce,*,expected_pins=None):
    require(result.get('schema')=='unqualified-codec-diagnostic-v1' and result.get('kind')=='UNQUALIFIED_SYNTHETIC_CODEC_DIAGNOSTIC','schema_kind')
    require(not any(k in result for k in ('qualification','capacityAccepted','admission','measuredTable','nativeAccepted')),'qualification_fields')
    require(result.get('nonce')==expected_nonce,'nonce')
    if expected_pins is None:expected_pins=json.loads((pathlib.Path(__file__).parent/'pins.json').read_bytes())
    require(isinstance(result.get('identities'),dict) and all(result['identities'].get(k)==v for k,v in expected_pins.items()),'external_pins')
    require(result['identities'].get('controlVisibilityPolicy')==expected_pins.get('controlVisibilityPolicy') and expected_pins.get('controlVisibilityPolicy') in (None,'full-root-only',POLICY),'external_policy')
    if 'helpers' in expected_pins:
        manifest=json.loads((pathlib.Path(__file__).parent/'manifest.json').read_bytes())
        sources=result.get('sourceIdentities',{})
        require(all(sources.get(k)==v for k,v in manifest.items()),'source_pins')
    inventory=result.get('inventory');require(isinstance(inventory,dict) and set(inventory)==set(files),'inventory_tree')
    for name,pin in inventory.items():require(set(pin)=={'bytes','sha256'} and len(files[name])==pin['bytes'] and hashlib.sha256(files[name]).hexdigest()==pin['sha256'],'inventory_identity')
    cells=result.get('cells');require(isinstance(cells,list) and len(cells)==12,'cell_count')
    require(result.get('cleanup',{}).get('state') in ('closed','incomplete'),'cleanup_union')
    cleanup=result['cleanup']
    if 'containerAbsence' in cleanup or cleanup.get('ownedRoot')=='/tmp/cd/d':
        require(cleanup.get('containerAbsence') in ('no_create_admitted','tracked_reconciled','unproven') and type(cleanup.get('freshDataRoot')) is bool and type(cleanup.get('createAdmissions')) is int and 0<=cleanup['createAdmissions']<=12 and isinstance(cleanup.get('trackedContainers'),list),'runtime_container_proof')
        if cleanup['containerAbsence']=='no_create_admitted':require(cleanup['freshDataRoot'] and cleanup['createAdmissions']==0 and not cleanup['trackedContainers'],'no_create_proof')
        if cleanup['containerAbsence']=='tracked_reconciled':require(cleanup['freshDataRoot'] and cleanup['createAdmissions']>0 and not cleanup['trackedContainers'],'tracked_container_proof')
        if cleanup['state']=='closed':require(cleanup['containerAbsence']!='unproven' and cleanup.get('ownedProcessesAbsent') is True and cleanup.get('daemonReaped') is True and cleanup.get('socketAbsent') is True and cleanup.get('unclosedAttachGroups')==[] and cleanup.get('obligations')==[],'runtime_closure_proof')

    if 'storage' in result or 'daemon' in result or 'load' in result or ('helpers' in expected_pins and any(cell['state']!='not_run' for cell in cells)):storage_joins(result)
    if result.get('storage',{}).get('created'):require('storage.json' in files,'storage_evidence_missing')
    if 'storage.json' in files:require(json.loads(files['storage.json'],object_pairs_hook=unique)==result.get('storage'),'storage_evidence_join')

    if any(cell.get('state')!='not_run' for cell in cells) and 'save' in expected_pins:
        require(result.get('loadedImage',{}).get('Id')==expected_pins['imageId'] and set(result['loadedImage']['RootFS']['Layers'])==set(expected_pins['diffIds']),'loaded_image_join')
        load=result.get('load',{})
        require(load.get('bytes')==expected_pins['save']['bytes'] and load.get('sha256')==expected_pins['save']['sha256'] and load.get('exhausted') is True and load.get('exitCode')==0 and load.get('stdoutEOF') and load.get('stderrEOF') and load.get('stdinClosed'),'load_join')
    for index,(cell,preset) in enumerate(zip(cells,d.MATRIX)):
        require(all(cell.get(k)==v for k,v in preset.items()),'matrix_identity')
        require(cell.get('nonce')==expected_nonce and cell.get('imageId')==result['identities']['imageId'],'cell_join')
        state=cell.get('state');require(state in ('observed','censored','incomplete','not_run'),'state_union')
        if 'executionComplete' in cell:require(type(cell['executionComplete']) is bool,'execution_complete_type')
        if cell.get('executionComplete') is True:
            refs=cell.get('sourceRefs')
            require(state=='incomplete' and cell.get('reason')=='hidden_higher_ancestors' and cell.get('measurementStatus')=='partial' and cell.get('controlVisibility')=='delegated_subtree' and cell.get('fullHostVisible') is False and cell.get('ancestryLimitation')=='hidden_higher_ancestors' and expected_pins.get('controlVisibilityPolicy')==POLICY,'completed_metadata')
            require(isinstance(refs,list) and len(refs)==1 and isinstance(refs[0],str) and refs[0] in files,'completion_raw_required')
        metrics=cell.get('metrics');require(isinstance(metrics,dict) and set(metrics)==set(d.METRICS),'metric_set')
        for key,m in metrics.items():
            if m.get('state')=='missing':require(set(m)=={'state','reason'} and isinstance(m['reason'],str) and bool(m['reason']),'missing_union')
            elif m.get('state')=='available':
                require(set(m)=={'state','value','unit','interval','sourceRefs'} and type(m['value']) in (int,float) and math.isfinite(m['value']) and m['value']>=0 and m['sourceRefs'] and all(ref in files for ref in m['sourceRefs']),'metric_union_refs')
                require(state!='not_run','not_run_available')
            else:raise Invalid('metric_union')
        if state=='not_run':require(bool(cell.get('reason')),'not_run_reason');continue
        if state=='observed':require(all(m['state']=='available' for m in metrics.values()) and cell.get('reason') is None and cell.get('cleanup',{}).get('state')=='closed','observed_completeness')
        if state=='censored':require(cell.get('reason') in ('timeout','oom','exit_failure'),'censored_reason')
        if state=='incomplete':require(bool(cell.get('reason')),'incomplete_reason')
        refs=cell.get('sourceRefs',[])
        if not refs:
            require(state=='incomplete' and all(m['state']=='missing' for m in metrics.values()),'raw_missing');continue
        require(len(refs)==1 and refs[0] in files,'raw_reference')
        raw=json.loads(files[refs[0]],object_pairs_hook=unique)
        require(raw['nonce']==expected_nonce and raw['cellId']==cell['id'] and raw['imageId']==cell['imageId'],'raw_join')
        require(raw['deadline']-raw['start']<=40.000001 and raw['encodeDeadline']-raw['start']<=32.000001,'cell_clocks')
        try:counter_paths,delegated=process_controls(raw,cell,state,expected_pins.get('controlVisibilityPolicy'))
        except (d.Failure,KeyError,TypeError,ValueError) as error:raise Invalid('process_control_evidence:'+str(error)) from None
        samples=raw.get('samples',[]);snapshots=raw.get('snapshots',[])
        indexed={s['t']:s for s in snapshots}
        progress=[e for e in raw.get('events',[]) if e['message']['event']=='PROGRESS']
        require(len(progress)==len(samples),'progress_coverage')
        for sample,event in zip(samples,progress):
            require(sample['t'] in indexed,'sample_counter_reference');snap=indexed[sample['t']]
            require(sample['cpuNs']==snap['values']['cpuacct.usage'] and sample['frame']==int(event['message']['raw']['frame']) and sample['mediaUs']==int(event['message']['raw']['out_time_us']),'sample_source_join')
        for snap in snapshots+([raw['final']] if raw.get('final') else []):
            require(snap['membership']==raw['keeper']['membership'] and snap['pid']==raw['keeper']['pid'],'counter_membership')
            require(set(snap['raw'])==counter_paths and snap['values'],'counter_sources')
            parsed={}
            for path,text in snap['raw'].items():
                base=pathlib.PurePosixPath(path).name
                if base in ('cpuacct.stat','cpu.stat','memory.oom_control'):
                    for line in text.splitlines():k,v=line.split();parsed[base+':'+k]=int(v)
                else:parsed[base]=int(text)
            required={'cpuacct.usage','cpuacct.stat:user','cpuacct.stat:system','cpu.stat:nr_periods','cpu.stat:nr_throttled','cpu.stat:throttled_time','memory.usage_in_bytes','memory.max_usage_in_bytes','memory.failcnt','memory.oom_control:under_oom','memory.oom_control:oom_kill_disable'}
            require(parsed==snap['values'] and required<=set(parsed) and all(type(v) is int and v>=0 for v in parsed.values()),'raw_counters_recompute')
        if delegated:
            require(expected_pins.get('controlVisibilityPolicy')==POLICY and raw.get('controlVisibilityPolicy')==POLICY,'delegated_external_policy')
            require(state!='observed' and cell.get('controlVisibility')=='delegated_subtree' and cell.get('fullHostVisible') is False and cell.get('measurementStatus')=='partial' and cell.get('ancestryLimitation')=='hidden_higher_ancestors','delegated_metadata')
            require(metrics['cpuPercent']['state']=='missing','delegated_cpu_percent')
            completed=cell.get('executionComplete') is True
            if completed:
                require(state=='incomplete' and cell.get('reason')=='hidden_higher_ancestors','delegated_disposition')
                require(raw.get('reason') is None and raw.get('ffmpeg') and raw.get('controls') and raw.get('final') and snapshots and len(samples)>=2,'delegated_complete_stages')
                require(raw['exit']['exitCode']==0 and raw['exit']['progressEOF'] is True and raw['progressEnd'] is True and raw['stdoutEOF'] is True and raw['stderrEOF'] is True and samples[-1]['mediaUs']>=24900000,'delegated_protocol_complete')
                require(raw['cleanup']['state']=='closed' and raw['cleanup'].get('attachGroupClosed') is True and raw['cleanup'].get('removed') is True and raw['terminalInspect']['State']['Pid']==0 and raw['terminalInspect']['State']['Running'] is False and raw['terminalInspect']['State']['OOMKilled'] is False,'delegated_closure')
                require(raw['final']['values']['memory.failcnt']==snapshots[0]['values']['memory.failcnt'] and raw['final']['values']['memory.oom_control:under_oom']==0,'delegated_no_oom')
                require(all(m['state']=='available' for k,m in metrics.items() if k!='cpuPercent'),'delegated_available_metrics')
                try:completed_joins(raw,cell,files,index)
                except (KeyError,ValueError,TypeError,IndexError,StopIteration) as error:raise Invalid('completed_join:'+str(error)) from None
            else:
                require(cell.get('executionComplete') is False and cell.get('reason')==raw.get('reason') and cell.get('reason')!='hidden_higher_ancestors' and all(m['state']=='missing' for m in metrics.values()),'delegated_failed_metrics')
                continue
        else:require(cell.get('controlVisibility') in (None,'full_root') and cell.get('fullHostVisible') in (None,True),'visibility_claim')
        derived=derived_rates(samples,delegated,refs)
        for k,m in derived.items():require(close(metrics[k],m),'derived_metric_'+k)
        if raw.get('final'):
            first=snapshots[0];final=raw['final'];interval={'wallMono':[first['t'],final['t']],'coverage':'whole_run_including_keeper'}
            for key,counter,unit,factor in [('cgroupPeakBytes','memory.max_usage_in_bytes','bytes',1),('throttledSeconds','cpu.stat:throttled_time','seconds',1e-9),('throttledPeriods','cpu.stat:nr_throttled','periods',1)]:
                value=final['values'][counter] if key=='cgroupPeakBytes' else final['values'][counter]-first['values'][counter]
                require(value>=0 and close(metrics[key],d.available(value*factor,unit,interval,refs)),'counter_metric_'+key)
        if raw.get('exit') and 'ffmpegPeakKiB' in raw['exit']:require(close(metrics['ffmpegPeakBytes'],d.available(raw['exit']['ffmpegPeakKiB']*1024,'bytes',{'coverage':'true_ffmpeg_wait4_peak'},refs)),'rss_metric')
        if state=='observed':
            require(raw['exit']['exitCode']==0 and raw['exit']['progressEOF'] and raw['progressEnd'] and raw['stdoutEOF'] and raw['stderrEOF'] and samples[-1]['mediaUs']>=24900000 and raw['cleanup']['state']=='closed' and raw['terminalInspect']['State']['Pid']==0 and not raw['terminalInspect']['State']['OOMKilled'],'observed_raw_completeness')
    if 'metrics.csv' in files:csv_agreement(cells,files['metrics.csv'])
    else:require(not any(c.get('controlVisibility')=='delegated_subtree' for c in cells),'delegated_csv_missing')
    return {'completedButIncomplete':sum(c.get('executionComplete') is True and c['state']=='incomplete' for c in cells),'schema':result['schema'],'nonce':expected_nonce,'counts':{s:sum(c['state']==s for c in cells) for s in ('observed','censored','incomplete','not_run')},'cleanup':result['cleanup']['state'],'inventoryVerified':len(files)}

def read_zip(path,expected_nonce,*,expected_pins=None):
    path=pathlib.Path(path);require(path.stat().st_size<=10485760,'output_zip_cap');files={}
    try:
        with zipfile.ZipFile(path) as z:
            infos=z.infolist();require(len(infos)<=128 and sum(x.file_size for x in infos)<=8388608,'output_expansion_cap')
            seen=set()
            for i in infos:
                n=i.filename;require(n not in seen and '/' not in n and '\\' not in n and n not in ('.','..','') and not i.is_dir() and not i.flag_bits&1 and stat.S_IFMT(i.external_attr>>16) in (0,stat.S_IFREG) and i.compress_type in (0,8),'output_member');seen.add(n)
                with z.open(i) as inp:b=inp.read(i.file_size+1);require(len(b)==i.file_size and inp.read(1)==b'','output_eof')
                files[n]=b
    except (zipfile.BadZipFile,RuntimeError,EOFError):raise Invalid('output_zip_invalid') from None
    require('result.json' in files,'result_missing');result=json.loads(files.pop('result.json'),object_pairs_hook=unique)
    return check(result,files,expected_nonce,expected_pins=expected_pins)

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('zip',type=pathlib.Path);ap.add_argument('--nonce',required=True);a=ap.parse_args()
    try:print(json.dumps(read_zip(a.zip,a.nonce),sort_keys=True))
    except (Invalid,ValueError,KeyError,TypeError) as e:print('INVALID: '+str(e),file=sys.stderr);sys.exit(1)
