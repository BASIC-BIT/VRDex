"""Read-only keeper. Runs only in the pinned diagnostic container."""
import argparse, json, os, pathlib, select, selectors, signal, subprocess, sys, time

def ffmpeg_argv(c):
    rate=str(c['videoKbps'])+'k';fps=str(c['fps'])
    return ['ffmpeg','-hide_banner','-nostdin','-y','-loglevel','warning','-stats_period','0.25','-progress','pipe:1','-f','lavfi','-i',f"testsrc2=size={c['width']}x{c['height']}:rate={c['fps']}",'-f','lavfi','-i','sine=frequency=1000:sample_rate=48000','-t','25','-map','0:v:0','-map','1:a:0','-c:v','libx264','-threads:v','2','-preset',c['x264Preset'],'-tune','zerolatency','-pix_fmt','yuv420p','-g',fps,'-keyint_min',fps,'-sc_threshold','0','-bf','0','-x264-params','nal-hrd=cbr:force-cfr=1','-b:v',rate,'-minrate',rate,'-maxrate',rate,'-bufsize',str(c['videoKbps']*2)+'k','-c:a','aac','-b:a',str(c['audioKbps'])+'k','-ar','48000','-ac','2','-mpegts_flags','+resend_headers','-muxdelay','0','-f','mpegts','/dev/null']

def emit(o):
    b=json.dumps(o,separators=(',',':'),allow_nan=False)
    if len(b)>65536:raise ValueError('message_cap')
    print(b,flush=True)

def receive(expected,timeout):
    if not select.select([sys.stdin],[],[],timeout)[0]:raise ValueError('handshake_timeout')
    line=sys.stdin.buffer.readline(65)
    if line!=expected.encode()+b'\n':raise ValueError('handshake_invalid')

def tool_info(arg):
    env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
    proc=subprocess.Popen(['ffmpeg',arg],env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
    selector=selectors.DefaultSelector();selector.register(proc.stdout,selectors.EVENT_READ);data=bytearray();deadline=time.monotonic()+2
    try:
        while selector.get_map():
            if time.monotonic()>=deadline:raise ValueError('tool_info_deadline')
            for key,_ in selector.select(.05):
                b=os.read(key.fileobj.fileno(),4096)
                if not b:selector.unregister(key.fileobj);continue
                data.extend(b)
                if len(data)>32768:raise ValueError('tool_info_cap')
        if proc.wait(timeout=max(.01,deadline-time.monotonic()))!=0:raise ValueError('tool_info_exit')
        return data.decode('utf8')
    finally:
        selector.close()
        if proc.poll() is None:proc.kill();proc.wait(timeout=1)
        proc.stdout.close()

def facts():
    env=dict(os.environ)
    dangerous=any(any(x in k.upper() for x in ('AWS_','CREDENTIAL','SECRET','TOKEN','PASSWORD','DOCKER_HOST','PROXY')) for k in env)
    return {'ffmpegVersion':tool_info('-version'),'ffmpegBuildConfig':tool_info('-buildconf'),'pid':os.getpid(),'uid':os.getuid(),'gid':os.getgid(),'affinity':sorted(os.sched_getaffinity(0)),'environmentNames':sorted(env),'credentialEnvironment':dangerous,'interfaces':sorted(p.name for p in pathlib.Path('/sys/class/net').iterdir()),'routes':pathlib.Path('/proc/net/route').read_text()[:8192],'mountinfo':pathlib.Path('/proc/self/mountinfo').read_text()[:8192],'cgroup':pathlib.Path('/proc/self/cgroup').read_text()[:8192],'namespaces':{n:os.readlink('/proc/self/ns/'+n) for n in ('pid','mnt','net','user','cgroup')}}

def main(cell):
    emit({'event':'READY','facts':facts()});receive('GO',8)
    env={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C','LC_ALL':'C'}
    argv=ffmpeg_argv(cell)
    # No PIPE stderr accumulation: Docker attach drains this inherited stream.
    proc=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=sys.stderr)
    emit({'event':'STARTED','pid':proc.pid,'affinity':sorted(os.sched_getaffinity(proc.pid)),'argv':argv})
    waited=False
    try:
        # Parent verifies actual FFmpeg host PID/affinity before releasing progress drain.
        receive('RUN',5)
        record={};bytes_read=0;pending=b'';stopped=False
        selector=selectors.DefaultSelector();selector.register(proc.stdout,selectors.EVENT_READ,'progress');selector.register(sys.stdin,selectors.EVENT_READ,'control')
        try:
            done=False
            while not done:
                for key,_ in selector.select(.1):
                    if key.data=='control':
                        control=os.read(sys.stdin.fileno(),65)
                        if control!=b'STOP\n' or stopped:raise ValueError('control_invalid')
                        stopped=True;proc.terminate()
                    else:
                        data=os.read(proc.stdout.fileno(),4096)
                        if not data:done=True;break
                        bytes_read+=len(data);pending+=data
                        if bytes_read>65536 or len(pending)>8192:raise ValueError('progress_cap')
                        while b'\n' in pending:
                            line,pending=pending.split(b'\n',1)
                            key,sep,val=line.decode('ascii',errors='strict').strip().partition('=')
                            if not sep:raise ValueError('progress_syntax')
                            record[key]=val
                            if key=='progress':emit({'event':'PROGRESS','raw':record});record={}
            if pending:raise ValueError('progress_missing_line_eof')
        finally:selector.close()
        pid,status,usage=os.wait4(proc.pid,0);waited=True
        code=os.waitstatus_to_exitcode(status);proc.returncode=code
        emit({'event':'EXIT','pid':pid,'exitCode':code,'progressEOF':True,'ffmpegPeakKiB':usage.ru_maxrss,'userSeconds':usage.ru_utime,'systemSeconds':usage.ru_stime})
        receive('RELEASE',8)
    finally:
        if not waited:
            try:proc.kill()
            except ProcessLookupError:pass
            try:os.wait4(proc.pid,0)
            except ChildProcessError:pass
        proc.stdout.close()

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('--cell',required=True);args=ap.parse_args()
    try:main(json.loads(args.cell))
    except BaseException as e:
        emit({'event':'PROBE_ERROR','reason':type(e).__name__});sys.exit(1)
