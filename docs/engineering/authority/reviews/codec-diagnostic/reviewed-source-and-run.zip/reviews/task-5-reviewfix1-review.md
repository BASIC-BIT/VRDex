# Task 5 review fix round 1: scoped rereview

Finding 1: **ADDRESSED.** SPEC: **PASS.** QUALITY: **PASS.** No new blocking issue found in the correction. This verdict covers Finding 1 and the correction diff only. The original review remains intact; retained-image runtime success is still unproven.

Reviewed `task5-reviewfix1.diff`, the appended Task 5 implementation report, the corrected monitor and the frozen red/green/focused/comparison/custody logs. Independently verified the new freeze's `source-identities.json` SHA256 `b8907af731d8681758002447127097009f76217deccd6b62c2aa7b1f5ec604db` and all 28 listed file identities. Only `diagnostic.py`, `tests/test_monitor.py` and generated `manifest.json` differ among existing source/test files from the original Task 5 freeze.

## SPEC

The correction restores `small('filesystemObservationBytes',256)` immediately after each successful stat at `diagnostic.py:502`. Removing the deferred batch restores the preceding monitor's small-work admission behavior and retains admitted observations when a later charge fails. The `finally` block still records elapsed time, encountered entries and incomplete status on that failure. The exception reaches the existing fail-closed monitor error path; traversal stops before a third entry can consume further work in the reported boundary case.

Scandir and direct non-following stat remain. The distinct entry/deadline reasons, final deadline check, observation-error handling and cleanup integration are unchanged. No bound was increased: 100000 entries, 0.8 seconds, disk ceiling 6442450944, parent RSS ceiling 268435456, 512 MiB small-work classification and 12 GiB runtime ledger remain as reviewed. The monitor retains its operational sampled designation rather than claiming a filesystem quota.

## QUALITY

The new regression uses a real Ledger and real `small()` with only 256 bytes remaining. It checks that the first observation remains recorded, the second charge stops the scan at exactly 536870912 recorded small-work bytes, `lastScan.entries` is 2, the scan stays incomplete and `monitor.check()` propagates `small_work_cap`. This directly covers the reported defect. Existing enumeration-error partial-accounting coverage remains.

Accepted the recorded verification without rerunning tests: the new regression first failed with `0 != 256`; all six monitor tests then passed; the final eight-test monitor and related ledger selection passed. The correction is small enough that this focused evidence, alongside the previously reviewed full-suite evidence, is sufficient for its scope. Frozen custody evidence records refreshed six-member source/envelope/ZIP/manifest joins, ASCII delivery, syntax validation and unchanged helpers, probe, pins, checker and renderer.

The refreshed comparison uses a real Ledger and per-observation charging in both versions. It reports 0.019312445 seconds for the original monitor and 0.006562305 seconds for the corrected monitor over 4100 entries, with identical filesystem and small-work counters. The report explicitly supersedes the original batching and fourfold-speed statements. The approximately 2.94-fold timing difference is one local sample; it does not identify the historical failed predicate or establish retained-vfs success under the unchanged limits.

No tests, provider calls, SDK, native image, Docker or FFmpeg execution, or child agents were run during this rereview. Only this report was written. Root retains ownership of the live rerun and spending.
