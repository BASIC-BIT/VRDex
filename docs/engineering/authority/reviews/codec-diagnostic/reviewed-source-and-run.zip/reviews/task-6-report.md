# Task 6 report: owned XFS data root and explicit overlay2

Implementation is ready for independent review. No live invocation occurred. Root owns review, the actual fresh-nonce packet, provider resources, cost/history reconciliation and the next single encoding attempt.

## Change

The private diagnostic exclusively creates `/codebuild/output/codec-<nonce>/data`, with a 0700 parent, a 0600 finite nonce/source marker, recorded inode/device/UID/mode identities and bounded mountinfo. It requires the effective read-write XFS mount at `/codebuild/output`, matching device identities, and no symlink or intervening mount. Unsupported placement is terminal. The existing short `/tmp/cd` control, socket, exec, configuration and tool paths remain.

`owned_daemon_args(control_root,data_root)` verifies the unchanged pinned helper, requires its one expected data-root argument, rewrites that argument and appends `--storage-driver=overlay2`. Empty daemon.json remains. The exact recorded argv object is passed to Popen. Before constructing the replay generator or loading anything, actual Docker info/version and a fresh mount observation must prove overlay2, the exact canonical owned data root, client/server Docker 24.0.9, XFS and d_type support. There is no driver fallback, second daemon, alternate path or load retry.

The monitor fixes both owned paths before its first scan. This avoids a race where a first one-root scan could otherwise be reported as two-root coverage. It shares the unchanged 100000-entry count, 0.8-second deadline, 256-byte successful-observation charge, 512 MiB small-work total and 6 GiB allocated-block ceiling across both roots. Free-space checks cover each backing filesystem with the unchanged 8 GiB initial and 2 GiB during thresholds. RSS/cadence and conservative traversal remain. Aggregate and per-root entries/blocks, active root and partial-scan context persist. No shared parent is scanned.

After existing container/process/daemon closure, the second root receives a bounded mount census, exact path/inode/UID/mode/marker/source recheck and removal/absence evidence. Residual mounts or ambiguous ownership prevent deletion and leave an explicit obligation. Runtime removal is also rechecked and recorded. The checker independently reconstructs storage mount/argv/info/marker/monitor/closure joins and requires the retained storage record. Existing delegated `incomplete` status, missing CPU percent, metric completeness, custody, budget-history and production-empty-table rules remain.

Existing source/test changes against Task 5 review-fix 1 are limited to diagnostic.py, check_result.py, README.md and generated manifest.json, with new tests/test_storage.py. Helpers, encode/replay implementation, probe.py, pins.json and packet_renderer.py are byte-identical to the base freeze.

## Tests and verification

All tests use generated tiny fixtures, mocked storage/Docker boundaries, Python processes and existing local AF_UNIX fixtures. There were no real mounts, daemon startups, image saves/loads, provider, network, SDK, native-image or large corpus operations. No child agents or commits were created.

Tests were written and observed failing before each connected implementation change. Retained RED logs under `verification-task6/` show:

- `red-storage.log`: 15 expected missing-feature failures.
- `red-integration.log`: two failures proving the old run path lacked explicit overlay2 and reached load under VFS.
- `red-checker.log`: two failures proving missing storage joins and missing-storage load acceptance.
- `red-monitor-order.log`: two failures proving scanning started before storage-root admission and a root could be added after a scan.
- `red-partial-root.log`: one missing active-root field error, followed by its correction.
- `red-retained-storage.log`: one failure proving an omitted retained storage record was accepted.

The initial helper GREEN run exposed fixture setup issues and a canonical-path comparison bug; these were corrected before the successful GREEN runs. Those initial logs remain available rather than being presented as passing.

Final focused command:

```sh
python -B -m unittest discover -s tests -p test_storage.py -v
```

**23 passed in 0.835 seconds**, retained in `green-final-focused.log`. Cases cover supported/overlay/missing/read-only/intervening/symlink mappings, exclusive marker ownership, immutable helper and strict argv rewrite, actual argv execution/recording equality, VFS/fuse/wrong-root/version/backing/d_type rejection, aggregate entry/time/disk/work limits, exact entry/disk boundaries, second-filesystem headroom, partial second-root errors, mount/marker cleanup refusal, owned-only deletion and checker negative mutations.

The earlier sandbox full run had 141 tests and seven AF_UNIX PermissionError errors, with no other failure. The seven affected cases were the two foreign-marker variants, live nested socket, owned Python daemon group, short socket paths, stale socket, and unclosed-group/tracked-container socket fixtures in test_runtime_paths. The authorized normal escalation permitted those local bindings; an intermediate full run passed all 141 tests. Later focused additions and the final checker join justified the final full run:

```sh
python -B -m unittest discover -s tests -v
```

**145 passed in 3.879 seconds**, with no failures or errors, in `full-suite-final-escalated.log`. This includes strict/delegated tests and all Task 5 monitor regressions. Historical accounting remains exact: Task 5 previously ran a full 121-test suite, followed by eight scoped review-fix tests. This task does not recast those scoped tests as a historical full rerun. The current inherited suite has 122 cases, and this task adds 23.

`verification-task6/custody.py` verifies all 28 recorded members of the base immutable freeze, the unchanged five pinned/helper/probe/renderer files, the exact six delivered source members and canonical envelope/ZIP/manifest joins. It also checks inline/request identities and compiles all 15 application/test Python files plus the trusted ASCII inline bootstrap without bytecode. `custody.log` records success. Earlier freezes remain unchanged.

## Immutable handoff and exact identities

Freeze: `/workspace/scratch/codec-task6-source-freeze`. It contains 45 files and 614545 logical bytes, with files 0444 and directories 0555. It contains only current source/tests, the scoped diff, one review packet and verification evidence. Historical freezes/packets are not nested inside it.

`source-identities.json` SHA256 is `d68a8fa9a1a7feb47195529f9af69e454379ef5b9026dbea49ab0f2f064cc576`.

| File | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 83479 | bd549febdb051be41a2ea135bfc1fb67eeb6515a13fe180fabb5fe9140da4a53 |
| check_result.py | 40199 | 276fb10104ce8241b5b4367111a48941e68209b4c31f5f51e37d1432ef58c6dd |
| tests/test_storage.py | 18658 | b037d77e8a2a3aefd6b29e9281416bf83f3bcd642e40fbd36a0feb2063fa01b1 |
| manifest.json | 542 | c2bc459c64421c350c20584e2b3ea63ef21595a7f5f972c2352fe22ded5e869f |
| task6-scoped.diff | 47961 | 2d2e297fc4787263b8f54b77d0738982c0c21c6246a5dba19bf9309e44708481 |
| packet-task6-review/code.zip | 40985 | df191e97a89e75907f71eab12703169750255662a0c4d95e5d3ebfa966e8d46e |
| packet-task6-review/code-envelope.json | 54806 | 94d38ea2a1b2cd991aa390581018f4670cddbf488ec1823016812ca70978bb8e |

The trusted inline fixture is 10860 bytes, SHA256 `babd02daa547886806678c8c2c5f5ba8eb5c75b2ce514417ecc7ac1ed73a7143`. The canonical create-project fixture is 12009 bytes, SHA256 `cce6aab10b5ecf45a2ee12b38f6db344f1506ffc368736c8c6071cb8f8fe4809`.

Root explicitly allowed deterministic offline packet generation before independent review so reviewers can inspect coherent custody joins. The task6review nonce/keys/role are offline fixtures, and `packet-task6-review/UNAPPROVED.txt` marks the packet as review-only. Actual use remains gated on independent review passing and Root's actual request rendering/admission. This is the only ordering amendment to the brief.

No implementation blocker was found. The next host must still prove its own supported XFS placement and actual overlay2 state. Overlay2 does not guarantee that the finite replay/monitor bounds will fit. Preserve any resulting negative. No new hold was created, and no cap or historical cost was changed.

## Review fix round 1: proved closure after partial setup

Verified the P2 finding in task-6-review.md against the actual runtime. The exclusive XFS parent and source-bound marker can exist before its data-child mkdir fails. `close_storage` then independently proves parent ownership, removes it and records absence, while `owned` correctly remains unset because data-root admission never completed. The old checker rejected this safely closed setup negative solely as `storage_unowned_closure`.

The checker now distinguishes completed data-root admission from independently proved parent ownership/closure. A never-admitted partial setup must remain a setup negative, with every cell not_run, no daemon record, no load record and no actual-storage admission. A closed claim then traverses the same root/path/nonce/source/marker identity, XFS mapping, monitor-limits and mount/identity/marker/absence closure joins used for admitted storage. Data-child identity is required only after completed data-root admission. Unproved partial ownership still permits only incomplete cleanup; the fix does not accept a bare closed claim.

The new generated regression forces the data-child mkdir to raise OSError after the parent and complete marker have been written. It executes the real run finalizer and real storage cleanup under generated mount observations, verifies no daemon/replay/load or monitor thread starts, confirms parent/runtime absence and closed cleanup, then checks the result with both storage_joins and the full offline result checker. Temporary fixture paths are rebound to the fixed production paths only for the independent checker. Mutating or removing marker/hash/identity/mode, closure/absence/identity/marker/mount evidence, path/source, or adding any daemon/load record is rejected.

RED command:

```sh
PYTHONPATH=tests python -B -m unittest test_storage.PartialStorageRun -v
```

`verification-task6-reviewfix1/red.log` records one test error in 0.008 seconds at the expected `Invalid: storage_unowned_closure`. After the first correction, `green.log` records one passing test in 0.010 seconds. A further generated empty-daemon-record mutation exposed one acceptance failure in `red-daemon-record.log`, one test in 0.012 seconds. Requiring absence of the daemon key corrected that admission edge case.

Final focused verification:

```sh
python -B -m unittest discover -s tests -p test_storage.py -v
```

`focused.log`: **24 tests passed in 0.806 seconds**, no errors or failures.

Direct checker verification:

```sh
PYTHONPATH=tests python -B -m unittest test_storage.CheckerStorage test_storage.PartialStorageRun -v
```

`direct-joins.log`: **4 tests passed in 0.026 seconds**, no errors or failures. Root explicitly bounded this correction to focused storage/direct-join cases. The previously passing 145-case full suite was not rerun. No escalation was required.

Only check_result.py and tests/test_storage.py changed. Diagnostic source, helpers, probe, pins, renderer, manifest and the entire existing review packet remain byte-identical. The source envelope is unchanged at 54806 bytes, SHA256 `94d38ea2a1b2cd991aa390581018f4670cddbf488ec1823016812ca70978bb8e`; ZIP remains 40985 bytes, SHA256 `df191e97a89e75907f71eab12703169750255662a0c4d95e5d3ebfa966e8d46e`. No new source packet or inline authority was generated. The retained original packet remains review-only pending the passing follow-up review.

New immutable freeze: `/workspace/scratch/codec-task6-reviewfix1-source-freeze`, 32 files and 455400 logical bytes, files 0444/directories 0555. It contains current source/tests, the unchanged original review packet, scoped fix diff and fix-only verification logs. The original Task 6 freeze and all 44 members listed in its source-identities.json were independently rehashed and remain unchanged. Both changed Python files compile.

| Corrected identity | Bytes | SHA256 |
| --- | ---: | --- |
| check_result.py | 40622 | 0bbe77c6bb70706e9c136f2dfb6790eb0f433db7e4ad44e5bba5115198ffe7c4 |
| tests/test_storage.py | 21973 | 32e4e3f6712e9a52deca0901c9a9714bae08ad7cbb1568a13d9e709fb133741c |
| task6-reviewfix1.diff | 10750 | ada1ad91931076755c88971f70cefb353cd4bbda6284ba077f42959d78b261d9 |
| source-identities.json | 3751 | dce9c394316487975f7c202de9a37d60d697a9dbdc18225b395b9278c1b5f1f1 |

The scoped correction diff compares directly against the original Task 6 freeze. No provider/native/Docker/network operations, child agents, holds, cap changes or commits occurred in this fix round.
