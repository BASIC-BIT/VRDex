# Task 5 — disk monitor integration

Status: DONE_WITH_CONCERNS. The narrow monitor change is implemented and locally verified. Root owns the live retained-image rerun; this report does not claim that image now loads within the unchanged scan limits. No provider calls, Docker, FFmpeg, native image execution, SDK runs, child agents or commits occurred.

## Root-cause evidence and limits

The original frozen source combines `count <= 100000` and `monotonic() < started + .8` in one `disk_scan_unbounded` predicate. The original attempt `/workspace/scratch/codec-capacity-live-4bc870565ef64c419c2e657c47db23fe/artifact-read-2.zip` records that error at `single_replay_load`, 20 completed scans, allocated-block peak 4,880,068,608, parent RSS peak 36,413,440 and filesystemObservationBytes 74,802,432. The latter represents 292,197 successful observations across completed and interrupted scans, not one scan's entry count. Cleanup is closed, there were zero container-create admissions, and every cell is not_run. Daemon evidence identifies the vfs driver.

The historical failed predicate cannot be recovered exactly: neither per-scan counts nor elapsed times were retained. Entry-cap failure, deadline failure, or both remain possible. Calling this a disk-capacity failure is unsupported; the last observed allocated-block peak was below 6,442,450,944. It also does not establish a bound on an unobserved later peak.

The source demonstrates avoidable per-entry overhead: os.walk's directory enumeration followed by pathlib construction and lstat, plus a locked ledger update for every successful stat. The optimization's benefit is supported by one small same-host real-filesystem comparison with 100 directories and 4,000 empty files: original 0.018972304 seconds, revised 0.004658558 seconds, identical 1,049,600 filesystemObservationBytes and one complete scan. This approximately fourfold difference supports the overhead hypothesis; it is not evidence of the original failed predicate or of future retained-vfs success. Full results are frozen in `verification/comparison.txt`.

## Implemented scope and bounds

Only `diagnostic.py`, generated `manifest.json`, and new `tests/test_monitor.py` differ from the previous source/test baseline. Generated packet files are in the new `packet-task5-review` directory; historical packets and freezes remain intact.

The monitor streams os.scandir entries, uses entry.stat(follow_symlinks=False) directly, and queues only observed directories. It charges the existing 256-byte filesystem-observation classification once per scan, including interrupted scans, through a finally block. It closes scandir contexts and propagates observation errors fail-closed instead of relying on os.walk's silent directory-error handling.

The existing 100000-entry and 0.8-second bounds remain. Separate `disk_scan_entry_cap` and `disk_scan_deadline` reasons identify the failed condition. `resources.lastScan` records actual entries encountered, elapsedSeconds and whether the scan completed, including failed scans. At an entry overflow, entries is 100001 and the extra entry is rejected before stat. Deadline enforcement also checks the scan tail, including accounting; empty trees cannot bypass the time bound. The scanner remains cooperative around filesystem calls, as before, rather than promising preemption of a blocking kernel operation.

No bound amendment was made or requested. The local comparison supports attempting the small optimization under the original limits. If the live image exceeds either original bound, its new context will support a concrete Root ruling instead of arbitrary widening.

The disk ceiling 6,442,450,944, start free-space threshold 8 GiB, during-run free-space threshold 2 GiB, parent RSS ceiling 268,435,456, monitor interval, finite finish join, and `sampled_operational_not_quota` designation remain. The 12 GiB runtime ledger, 512 MiB small-work classification, 8 MiB evidence cap, provider/job deadlines, delegated missing measurements, cleanup machinery, six-file source contract and independent checker are unchanged. probe.py, pins.json, original helpers, renderer and checker compare byte-for-byte with the prior freeze.

## Test-first and verification evidence

RED command, before implementation:

```sh
python -B -m unittest discover -s tests -p test_monitor.py -v
```

The final red run has five assertion failures and no test errors. It catches missing scan context, the original conflated entry-cap reason, missing final/empty-tree deadline checks, and lost partial observations on an enumeration failure. Earlier test-fixture drafts were corrected before the implementation; the retained red log is the final valid reproduction. The entry-cap test supplies a bounded lazy filesystem double and an old-walk fixture so the original production branch demonstrably returns `disk_scan_unbounded`.

GREEN, same command: five tests pass in 0.350 seconds. After the small cleanup to use one final elapsed-time read, the complete final suite verifies all five cases again.

Full necessary command from `/workspace/scratch/codec-capacity-diagnostic`:

```sh
python -B -m unittest discover -s tests -v
```

Sandbox run: 121 tests, seven AF_UNIX bind PermissionErrors. Affected cases were `test_live_foreign_socket_and_marker_are_never_removed` (foreign=False and foreign=True), `test_live_nested_socket_keeps_runtime_incomplete`, `test_owned_python_daemon_group_is_reaped_before_stale_unlink`, `test_short_root_known_paths_bind_real_unix_sockets`, `test_stale_socket_removed_only_after_process_absence`, and `test_unclosed_group_and_tracked_container_keep_stale_socket`.

The explicitly authorized normal escalation for AF_UNIX fixture binding succeeded: **121 tests passed in 3.087 seconds**, no failures or errors. Both full logs are retained. No unrelated repository suites were rerun.

Syntax validation: all 14 Python files in the final freeze compile without writing bytecode; the generated trusted inline bootstrap compiles and is ASCII. Packet custody validation verifies the exact six delivered members, external envelope/ZIP/manifest identities, current source bytes and unchanged helper/probe/pin/checker/renderer identities. An initial custody-script assertion incorrectly split the JSON-encoded buildspec before decoding it; decoding it first fixed that verification script, with no production change.

## Immutable handoff

New immutable freeze: `/workspace/scratch/codec-task5-source-freeze`. It contains source, tests, one regenerated packet, scoped diff and verification logs, without nested historical freezes: 31 files, 450029 logical bytes, 14 unchanged files linked from the already immutable preceding freeze. Files are 0444 and directories 0555. `source-identities.json` SHA256: `3b4ce62ce31e8b17934d97d81519afc31006da5a82f3115e4608553e7d643b90`.

Scoped diff: `/workspace/scratch/codec-task5-source-freeze/task5-scoped.diff` (10627 bytes), SHA256 `fd4f4bbd8eacf231225a341d12324cd55098be7407aadec0cbeb6ad923f9e6be`.

| Identity | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 75181 | c388aba697d309fc560d6ee490cf69348e2f407ab76693676a575083b1042473 |
| tests/test_monitor.py | 5428 | a56d0ae4fc4d67d739994fed8d6e31213556f02aa2beb0047842c5fc862ec437 |
| manifest.json | 542 | 78a7b5e705921a973eaeab737429fa6e1e95ee43a1dcde483c4c46335d705d3f |
| packet-task5-review/code.zip | 38918 | fe9d6660b95df2c982c035f81b553895012159c60ecfe3538943b4b8f32d6811 |
| packet-task5-review/code-envelope.json | 52050 | d46b852f1c90727744579a5137efb4d97a4ff19bb9a80004373fc8f7008843c1 |

The packet's task5review nonce and keys are offline review fixtures. Root must render the actual fresh-attempt request after review. The old attempt's artifacts and independent checker conclusions have not been reinterpreted or rewritten. Concern remaining: real retained-vfs entry count and elapsed scan time remain unmeasured under the revised monitor until Root's authorized live rerun.

## Review fix round 1 — Finding 1 resolved

This section supersedes the batching and fourfold-performance statements above for the current implementation. The original Task 5 freeze and review remain unchanged for audit.

Verified Finding 1: a final batch larger than the remaining small-work allowance is rejected before any batch observations are recorded, and it lets the whole scan run before rejection. Restored `small('filesystemObservationBytes',256)` immediately after every successful stat, matching the prior admission and partial-accounting behavior. Removed the scan-local observation accumulator and final batch charge. Scandir, direct entry.stat, distinct failure reasons, lastScan context, fail-closed observation errors and all numeric limits remain.

Added `test_small_work_cap_keeps_admitted_observations_and_stops_scan`, using a real Ledger, real small(), three actual tiny files, and initial smallObservableBytes 536870656. The first observation's 256 bytes remain recorded; the second stat triggers small_work_cap at 536870912, no third entry is processed, and lastScan reports entries=2 and complete=false. The enumeration-error partial-accounting test remains and passes.

RED, before the correction:

```sh
python -B -m unittest discover -s tests -p test_monitor.py -v
```

Six tests ran in 0.358 seconds; only the new regression failed, with `0 != 256` for recorded filesystemObservationBytes. GREEN, same command after the correction: all six pass in 0.425 seconds.

Final scoped verification, including the two directly related ledger boundary tests:

```sh
PYTHONPATH=tests python -B -m unittest test_monitor test_boundaries.Boundaries.test_arithmetic_and_repeated_read_charges test_boundaries.Boundaries.test_unknown_interrupt_charges_reservation -v
```

All eight tests passed in 0.397 seconds. Root explicitly bounded this fix's verification to the monitor and affected meter tests, so the unchanged full 121-test suite was not repeated. No escalation was needed. All 14 Python files and the trusted inline bootstrap compile; six-member source custody, canonical envelope/ZIP/manifest/current-source joins, ASCII delivery and unchanged helper/pin/probe/checker/renderer identities verify.

Refreshed local comparison uses the same 4,100-entry real directory fixture and a real Ledger with per-successful-observation small() charging in both versions. Original monitor: 0.019312445 seconds. Corrected scandir monitor: 0.006562305 seconds, approximately 2.94 times lower elapsed time. Both report exactly 1,049,600 filesystemObservationBytes, 1,050,774 smallObservableBytes and one complete scan. This single local sample replaces the prior approximately fourfold result; it does not establish retained-vfs timing or the historical failed predicate.

New immutable freeze: `/workspace/scratch/codec-task5-reviewfix1-source-freeze` (29 files, 402270 logical bytes, 14 unchanged immutable hardlinks; files 0444/directories 0555). Source-identities SHA256: `b8907af731d8681758002447127097009f76217deccd6b62c2aa7b1f5ec604db`. It contains current source/tests, the regenerated `packet-task5-reviewfix1`, and RED/GREEN/focused/comparison/custody logs. No earlier freeze or packet is nested inside it. The first freeze and review remain intact.

Scoped correction diff against the original Task 5 freeze: `/workspace/scratch/codec-task5-reviewfix1-source-freeze/task5-reviewfix1.diff`, 4539 bytes, SHA256 `e40c57b70064ff8953f8b1f49b061b2cf2ff039fb8fbb11bc6660e97c35f9a4f`. Only diagnostic.py, tests/test_monitor.py and generated manifest.json change among existing source/test files.

| Corrected identity | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 75004 | 89df729d5f7e6935b09dab20fe2f26e27c25092c8912ebb18d6a11993254454f |
| tests/test_monitor.py | 6469 | c631d2e01e943440118a4000e1646920a08a1498a7744d4e4529d5e0b8f59775 |
| manifest.json | 542 | 06c805adff3863140a4b22d261d4df009b4fff248f8ce327712615b30678e2f5 |
| packet-task5-reviewfix1/code.zip | 38864 | e71da8f10765a108cf9da62ef86a5a27cafd770d20871290cf7c550eebf9f702 |
| packet-task5-reviewfix1/code-envelope.json | 51978 | 36b7f4b55a8124f92e77ea54440c364450df0630d1141e547b40b3c3ac4d8de7 |

The new packet's task5reviewfix1 nonce/keys are offline fixtures. Root still owns actual attempt rendering, review and live rerun. No provider/native execution, child agents, numeric bound changes or commits occurred in this fix round.
