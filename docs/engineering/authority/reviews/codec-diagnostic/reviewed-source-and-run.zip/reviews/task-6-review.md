# Task 6 independent SPEC+QUALITY review

Verdict: **CHANGES REQUESTED** — one P2 correctness finding in storage failure/closure evidence. Review is bound to `/workspace/scratch/codec-task6-source-freeze/source-identities.json`, SHA256 `d68a8fa9a1a7feb47195529f9af69e454379ef5b9026dbea49ab0f2f064cc576`.

## Actionable finding

**P2 — Accept a proved clean closure after partial storage setup.** `check_result.py:220–223` requires `cleanup.state == 'incomplete'` whenever storage has `created=True` but lacks `owned=True`. The runtime can legitimately produce the opposite: `diagnostic.py:520–524` records the exclusively created parent and complete owner marker before creating its data child. If that child mkdir fails (for example ENOSPC), `owned` is never set. Nevertheless, `close_storage` at lines 544–552 can verify the original parent identity, source-bound marker and absence of mounts, remove that parent, and retain absence evidence. The finalizer at lines 998–1009 then correctly records `cleanup.state='closed'`. The checker rejects this safely closed setup-negative with `storage_unowned_closure`, losing validation of the exact negative the diagnostic must preserve.

Minimal correction: distinguish completed data-root admission from proved parent ownership/closure. Allow the partially initialized, never-started-daemon negative to report closed only after independently joining its recorded root/path/nonce/source/marker identity and closure/mount/absence evidence. Do not simply remove the rejection or permit a bare closed claim; missing/ambiguous ownership must remain incomplete. Keep replay/daemon admission dependent on completed storage setup.

Add one focused generated regression: force the data-child mkdir to fail after the parent and marker exist; confirm no daemon/replay/load starts, owned parent removal is proved, and the resulting setup-negative passes storage checker joins. Mutating/removing its marker or closure evidence must still fail. No provider or real mount is needed.

## Remaining scope and evidence

The remaining scoped change satisfies the reviewed requirements: fresh fixed XFS placement, short control paths, pinned-helper argv adaptation and identical recorded/executed argv, explicit overlay2 plus pre-load Docker24/XFS/d_type gates, a shared two-root scan budget with partial contributions, and mount/marker-protected closure. No additional blocking finding identified.

Verified all 44 listed freeze member lengths/hashes and byte equality of pins.json, probe.py, packet_renderer.py, support/preflight.py and support/encode.py against Task 5 review-fix 1. Inspected the 441-line scoped diff, relevant callers, generated tests and retained verification evidence. Retained logs report 23 focused tests and 145 full-suite tests passing; these were not rerun. No source edits, child agents, live/native/provider/SDK/Docker operations or infrastructure changes were performed.

Root's explicit ruling permits deterministic offline packet generation for custody before review. The review packet remains local and unapproved for actual use. Actual AWS use remains gated on a passing follow-up review of the fix.
