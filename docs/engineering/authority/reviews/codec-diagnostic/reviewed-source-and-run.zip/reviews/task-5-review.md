# Task 5 scoped SPEC + QUALITY review

SPEC: **FAIL.** QUALITY: **CHANGES REQUIRED.** One blocking finding in the new accounting batch must be corrected before the live rerun. This review covers the frozen monitor optimization, its tests and recorded evidence only.

Reviewed the Task 5 brief and report, `task5-scoped.diff`, the affected monitor/ledger integration, and the frozen verification logs. Independently verified `source-identities.json` SHA256 `3b4ce62ce31e8b17934d97d81519afc31006da5a82f3115e4608553e7d643b90` and all 30 listed file identities. Compared existing baseline files with the previous freeze. Only `diagnostic.py` and its generated manifest change among existing source/test files; `tests/test_monitor.py` is new.

## Finding 1: batched accounting loses observations and weakens small-work admission

Blocking, high priority. Frozen `diagnostic.py:493` initializes a scan-local observation count; lines 502 and 513 accumulate successful stats and charge all of them only in `finally`. `small()` at lines 13–19 rejects a batch before updating either `smallObservableBytes` or `filesystemObservationBytes` if the batch exceeds the remaining 512 MiB allowance.

Consequently, a scan can perform up to 100000 successful observations, representing 25,600,000 classified bytes, before finding that its charge is inadmissible. When that happens, none of those observations are recorded. The same loss occurs when an interrupted scan's final batch exceeds the remaining allowance. The run fails closed with `small_work_cap`, but failure alone does not preserve the required finite small-work admission or truthful partial accounting. `lastScan.entries` is useful failure context, but it does not repair the ledger and includes entries rejected before stat.

A tiny mocked comparison against the previous freeze confirmed this without running a suite. Both versions started with `smallObservableBytes = 536870656`, leaving 256 bytes, and received three regular-file entries with a fixed clock, mocked free space and mocked RSS read:

| Frozen version | Successful stats | Recorded filesystemObservationBytes | Final smallObservableBytes | Error |
| --- | ---: | ---: | ---: | --- |
| Previous | 2 | 256 | 536870912 | small_work_cap |
| Task 5 | 3 | 0 | 536870656 | small_work_cap |

Restore the per-successful-observation `small('filesystemObservationBytes', 256)` charge while retaining the `scandir` and `DirEntry.stat` optimization. This is the smallest correction and preserves the previous admission behavior without introducing a reservation mechanism. Add a focused regression with a nearly exhausted real `small()` meter, and verify that successful observations before the rejected observation remain recorded. Also retain the enumeration-error partial-accounting coverage. Reassess the optimization's performance claim after this correction because the existing fourfold comparison includes removal of per-entry ledger locking.

## Other scope checks

The new reasons distinguish the 100000-entry cap from the 0.8-second deadline, and `lastScan` reports encountered entries, elapsed time and completion on success and failure. The entry overflow rejects entry 100001 before stat. The final check also rejects a scan whose tail exceeds the deadline, including an empty scan. Filesystem operations remain cooperative and can block beyond the deadline. Scandir contexts close on exceptions, ordinary observation errors propagate to `monitor_observation_failed`, and cleanup integration remains unchanged.

No hidden numeric bound increase was found. Disk ceiling 6442450944, initial/during-run headroom, parent RSS ceiling 268435456, 12 GiB conservative runtime ledger, 8 MiB evidence cap and deadlines remain unchanged. Finding 1 concerns enforcement and evidence of the unchanged 512 MiB classification. The operational sampled designation remains explicit and does not claim a filesystem quota. The helper, probe, pins, checker and renderer identities are unchanged; the generated packet has the expected revised diagnostic and manifest identities.

Accepted the recorded five-test red/green evidence and final 121-test passing log as evidence, without rerunning them. The five new tests cover normal traversal, distinct entry-cap context, tail/empty-tree deadlines and partial observations on enumeration failure. They replace `small()`'s real cap behavior with an accumulating fake meter, so they do not cover Finding 1.

The report correctly distinguishes historical facts from inference. The original failed predicate remains unknown, and the small local timing comparison does not establish that the retained vfs image now fits either unchanged scan limit. Root alone owns that rerun. No provider, SDK, native image, Docker or FFmpeg execution occurred during this review. Only this review report was written; the new verification was the tiny mocked boundary comparison above and file-identity checks.
