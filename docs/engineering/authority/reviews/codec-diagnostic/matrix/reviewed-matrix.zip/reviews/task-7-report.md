# Task 7 report: observed child cgroup bind view

The local mapping correction is complete and ready for independent review. The immutable candidate is `/workspace/scratch/codec-task7-source-freeze`. Its deterministic packet is explicitly UNAPPROVED and OFFLINE. No live invocation occurred. Root owns review and all provider actions.

## Cause and correction

The retained 45,741-byte actual artifact shows keeper membership and its cgroup bind mount root at `/ecs/<task>/<container>/docker/<64-lowercase-hex-id>`. The collector root/member remains `/ecs/<task>/<container>`. Both processes share the cgroup namespace and controller devices; their mount namespaces differ. The baseline constructor applied strict collector-root admission to the target before collecting the parent view. It therefore failed with `resource_control_unproven`, empty controlFiles and no samples.

`resolve_visible_v1` and the independent checker's `hierarchy` retain strict default collector admission. An explicit target parsing role recognizes only the existing root forms or the exact observed Docker bind root. The nested form requires the existing delegated policy and target membership equal to that root. `visible_view` and `collector_view` then require the strict collector root and membership to equal the nested target's ECS parent, as well as the existing canonical alignment, same-device, cgroup-namespace and descendant joins. Nested collectors, arbitrary descendant roots and foreign parents remain inadmissible. No generalized cgroup model was introduced.

Under the explicit delegated policy, Cgroups now retains both independent process captures before topology admission, including when the target is malformed. All subsequent control and counter reads use the collector's mountpoints and visible ancestry. The new constructor regression uses real tiny files, actual capture/parsing/evidence/snapshot code and nonexistent `/target-only/cgroup` paths. It proves those target paths are never read.

The existing keeper/FFmpeg/parent, READY, argv, process identity, namespace PID, source/image and cleanup joins are unchanged. Controls remain quota 200000/100000, two-CPU affinity, and 4 GiB memory equal to memsw. A completed delegated cell remains INCOMPLETE with hidden higher ancestors and missing CPU percent. No source/image qualification or actual CPU/memory metric is claimed.

Only diagnostic.py, check_result.py, README.md, generated manifest.json and new tests/test_child_cgroup_view.py differ from Task 6 review-fix 1. Probe, helper sources, pins and packet_renderer are byte-identical. Storage, workload, image, limits and provider logic are unchanged.

## RED, GREEN and verification

All work used generated tiny Python fixtures and existing local Python/AF_UNIX tests. There was no provider, SDK, Docker, FFmpeg, native-image, network or retained-large-image execution, no child agents, and no commit.

Tests were written before production changes. Exact retained commands and outcomes:

```sh
PYTHONPATH=tests python -B -m unittest test_child_cgroup_view -v
```

`verification-task7/red.log` ran 10 tests in 0.032 seconds, with three expected `resource_control_unproven` errors and one failure proving the collector capture was absent after rejected target admission. Three already existing imported CaptureIntegration tests were inadvertently discovered in that first run; the test file now imports their containing module and discovers only the seven new cases.

After the runtime correction, the same command produced `red-checker.log`: seven tests in 0.027 seconds with exactly one expected `Invalid: delegated_policy_or_form` error from the independent checker. The runtime parser/proof functions are poisoned in this checker regression, proving that it reconstructs the mapping itself.

An initial checker edit had an extra closing parenthesis. The attempted focused and full runs exposed that syntax error before any successful verification. Their logs remain `initial-green-syntax-error.log` and `initial-full-syntax-error.log`. The latter ran 30 discovered tests with seven import errors. The syntax error was corrected.

The final focused command above passed all seven tests in 0.031 seconds, recorded in `green.log`. Cases cover exact nested target admission, collector-based control and counter paths, independent checker reconstruction, strict collector admission, arbitrary descendants, malformed IDs, target membership below the bind root, foreign parent, collector membership below its root, controller device mismatch, cgroup namespace mismatch, unaligned roots, hybrid membership, missing collector, canonical escapes, absent delegated policy, missing visible ancestor/read facts, and preservation of both captures on failure.

```sh
python -B -m unittest discover -s tests -v
```

The sandbox run executed 153 cases in 4.445 seconds with seven AF_UNIX PermissionError errors, recorded in `full-suite.log`. They were the two foreign-marker variants of `test_live_foreign_socket_and_marker_are_never_removed`, plus `test_live_nested_socket_keeps_runtime_incomplete`, `test_owned_python_daemon_group_is_reaped_before_stale_unlink`, `test_short_root_known_paths_bind_real_unix_sockets`, `test_stale_socket_removed_only_after_process_absence`, and `test_unclosed_group_and_tracked_container_keep_stale_socket`. No other failure occurred.

The authorized normal escalation of the same full command allowed local socket bindings. `full-suite-escalated.log` records **153 passed in 3.927 seconds**, with no errors or failures. Existing strict/delegated, source transport, monitor, storage and closure checks remain green.

```sh
python -B verification-task7/observed_mapping.py
python -B verification-task7/custody.py
```

`observed-mapping.log` replays only the retained small actual parent/keeper raw topology. The immutable baseline rejects the original keeper root as `resource_control_unproven`; the revised runtime and independent checker agree on the collector mapping. The original keeper controlFiles remain empty. The complete original artifact still passes the revised independent checker as zero observed, one incomplete, eleven not_run, completedButIncomplete zero, cleanup closed. No missing observations are synthesized.

`custody.log` verifies all 31 recorded members of the Task 6 review-fix 1 freeze and all 44 recorded members of the original Task 6 freeze, the five unchanged pinned/helper/probe/renderer files, the exact five changed source/test files, all six delivered source members and canonical ZIP/envelope/manifest joins. It independently regenerates the same ZIP, envelope, pins, inline request and readiness bytes. Sixteen application/test Python files and the trusted ASCII inline bootstrap compile without bytecode. Earlier freezes were never edited. The first custody draft assumed all historical freeze manifests used the same layout; that assumption failed on an older metadata-shaped manifest before the check was narrowed to the two relevant Task 6 freezes.

## Actual retained evidence identities

The unchanged original artifact is `/workspace/scratch/codec-capacity-live-1566fc5f1035405c993629fd6fa8537e/artifact-read-1.zip`.

| Evidence | Bytes | SHA256 |
| --- | ---: | --- |
| Original artifact ZIP | 45741 | 6f79ad006abfe5e4f2fa619b1aa7ffd99c52b0419cbc3b5a284603894969b188 |
| parent-capture.json inside original | 46530 | f87422b223a3acd36e94d458cdc8adfa636e85fca97eb3cc57636eb31237bf2c |
| cell-00-keeper-capture.json inside original | 29675 | 6aa76ed9abd5797acbabb93089875092eb4187650438720cb886a8ccc916aae5 |

## Immutable handoff and exact source packet

The non-nested freeze contains 39 files and 561518 logical bytes, with files 0444 and directories 0555. It contains current source/tests, only the Task 7 packet, scoped diff and Task 7 verification evidence. It does not nest historical freezes or prior packets. All 38 members listed by source-identities.json were rehashed after copying and permissions were checked.

`source-identities.json` is 4620 bytes, SHA256 `e8c61cca658644fc2837e6aae2090558953481cf984cc5a71a366ed9657cc6bd`.

| File in freeze | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 83947 | f0066ceadc9f03eeb10ee0856a66299d4470ad5cd3cef93b698fa347ac3fe83e |
| check_result.py | 41024 | 151bd2e854859d743f6038293ba811ab073208c0257c1bacb9db7cea396ad44b |
| tests/test_child_cgroup_view.py | 8115 | 891b83da32098ce691b9201ecf1b4b1b37754430e26b0444efda28b2c1e2adc4 |
| manifest.json | 542 | 489a4ceb960ba5ca66d9df7c3c2e1585d76a24474398c958b03c146936769394 |
| task7-scoped.diff | 20153 | 9ca3d3a17ff2f3bd1ba70b574f6a213557c3b873c9d84fc1030dbbacc5c9cc35 |
| packet-task7-review/code.zip | 41112 | 03e92d351215b6b7ccd0bd4485284c97d5adaa1017d844562e959c23adfe98c9 |
| packet-task7-review/code-envelope.json | 54974 | dd6c621c749b7fa580ca5b17943106985469b6a75fb5a1d67101483085fbfe7e |

The deterministic trusted inline fixture is 10859 bytes, SHA256 `cb4fedbd0a00aecaa4cac43aacf7e8969a12f4396037e27d1dc55bf594489a65`. The canonical create-project fixture is 12011 bytes, SHA256 `183eff8977a3e4e7395cf0006a6206a03cd25f2e9aeb39b2cf4a1ee3d4f2a518`.

The exact offline rendering command was:

```sh
python -B packet_renderer.py --root . --destination packet-task7-review \
  --nonce task7review \
  --source-key synthetic-benchmarks/codec-diagnostic-review/task7/code-envelope.json \
  --evidence-prefix synthetic-benchmarks/codec-diagnostic-review/task7/evidence \
  --role-arn arn:aws:iam::079358094174:role/codec-diagnostic-task7review
```

The nonce, keys and role are review fixtures. `packet-task7-review/UNAPPROVED.txt` explicitly prohibits live use before independent review and Root's actual fresh-nonce request rendering/admission. No hold, resource or billing action occurred. The next actual run must still prove its own collector, ancestor reads, controls and process/sample joins; any resulting negative remains a negative.
