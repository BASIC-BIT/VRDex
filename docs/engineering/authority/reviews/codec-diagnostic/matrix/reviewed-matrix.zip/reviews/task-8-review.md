# Task 8 independent scoped review

SPEC: PASS.

QUALITY: PASS. No actionable findings within the requested Task 8 scope.

Reviewed `task-8-brief.md`, `task-8-report.md`, the frozen `task8-scoped.diff`, the surrounding frozen `run_cell` implementation, the new regression, and retained verification evidence. Baseline is `/workspace/scratch/codec-task7-source-freeze`; candidate is `/workspace/scratch/codec-task8-source-freeze`.

## Specification check

- The sole production edit at `diagnostic.py:656` adds `not released` to periodic keeper sampling. It prevents the next periodic snapshot after RELEASE when the keeper's `/proc` entries may already be gone.
- EXIT handling still requires a keeper and an unreleased state, checks attach-process liveness, records `raw.final` with `keeper.snapshot()`, sends RELEASE, then sets `released=True`. The final snapshot remains before RELEASE and retains its failure behavior.
- The selector loop still drains both attach streams under the existing deadline. Zero attach exit, both EOFs, release, no pending protocol data, final metrics, progress completion, finite output and closed cleanup remain required by the unchanged completion path.
- Active and pre-release snapshots still propagate missing keeper files. No exception handler was added or relaxed. The active-negative regression requires `cell_FileNotFoundError`, incomplete execution, no RELEASE and no final snapshot.
- Independent byte comparison against Task 7 confirms exactly three changed source members: `diagnostic.py`, its generated `manifest.json` identity, and new `tests/test_release_sampling.py`. All other source members are identical. Probe, handshake, control proof, ancestor/namespace checks, EOF proof, helpers, pins, image/workload configuration, storage and limits have no changes.

## Quality and evidence check

The generated regression executes the real `run_cell` and completion/metric code with mocked process, selector and keeper behavior. RELEASE immediately makes snapshots fail; a delayed selector round exceeds the periodic interval before stdout and stderr EOF. Assertions cover no snapshot after release, final snapshot immediately before RELEASE, both EOFs, zero attach exit, closed cleanup, finite output and recognition by the unchanged independent checker. Delegated visibility still yields `hidden_higher_ancestors`, without promoting the result to a fully qualified measurement.

The retained final baseline RED shows the success scenario failing with `cell_FileNotFoundError` while the active-negative test passes. GREEN records both tests passing. The full-suite escalation log records 155 passing tests. These tests were not rerun during this review, as requested.

I independently checked the source member set, exact one-line production replacement, byte-for-byte scoped-diff reconstruction, all 41 candidate identity records, and read-only file/directory permissions in both freezes. The retained custody script checks deterministic offline packet regeneration and source joins; its source and results are consistent with the report. The packet remains UNAPPROVED OFFLINE and this review does not authorize a live invocation or make a performance claim.

No source edits, provider/network calls, SDK, native image, Docker, FFmpeg or child-agent execution occurred during this review. Only this review document was written. The separate proposed Task 9 work-headroom allocation is outside this diff and was not evaluated here.
