# Task 10 report: bounded records for twelve cases

Ready for independent review. Three production literals change from 8 MiB to 10 MiB: the `Evidence` default, the independent checker's uncompressed ZIP sum limit, and the third `CUSTODY` allowance. The original design table at `/workspace/scratch/codec-capacity-diagnostic-design.md:111` labels that third entry expanded evidence and the final 8 MiB entry controls/logs. The runtime tuple was unlabeled and README had no table. README now states the labels and arithmetic; controls/logs remain unchanged.

Root custody is `28093104 + 20971520 + 10485760 + 3145728 + 4259840 + 2097152 + 262144 + 8388608 = 77703856`. The 2097152-byte increase leaves `83886080 - 77703856 = 6182224` bytes. The independent local and transport/decode caps remain 80 MiB. Nonterminal evidence now admits 9437184 bytes; the terminal reserve and runtime terminal-result cap remain 1048576 bytes each. ZIP output remains 10485760 bytes and 128 members. Runtime 12 GiB total, 2 GiB small-work, workload, helpers, probe, pins, renderer, CPU/memory/storage/time, EOF, cleanup and measurement rules are unchanged. Exact byte comparison proves that all other production source remains unchanged, including Task 8's release guard and Task 9's budget.

The observed 558062-byte negative ZIP remains historical evidence. Its final cell's missing metrics stay missing. This prospective record adjustment does not guarantee twelve-case completion or qualify production capacity. Small-work exhaustion can still block terminal evidence; no recording framework, reset, reserve or unmetered write path was added.

## Verification

- Final RED, `verification-task10/red-final.log`, and reproducible `baseline_red.py` against immutable Task 9: **6 tests, 1 assertion failure, 2 expected old-limit exceptions, 3 passes**. Failures identify the old CUSTODY, raw admission and independent expansion bound. Initial `red.log` also retains one test-fixture error: trailing ZIP padding exceeded ZIP reader discovery. The fixture was corrected to a supported prefixed ZIP before final RED; no production change addressed that error.
- GREEN, `PYTHONPATH=tests python -B -m unittest test_evidence_capacity test_boundaries test_small_work test_storage test_release_sampling -v`: **52 passed in 0.975 seconds**, then **52 passed in 0.975 seconds** from the candidate freeze. Six generated tests cover the exact 9 MiB raw boundary plus 1 MiB terminal remainder, one-byte overflow without a write, a valid setup-negative ZIP expanded to exactly 10 MiB, expansion plus one rejection, unchanged physical ZIP/member admission, and exact custody arithmetic. Relevant suites preserve exhaustion and release regressions. Root's bounded instruction excludes an unchanged full-suite rerun.
- `verification-task10/custody.py` passes in working and frozen directories. It verifies all **38 Task 9 identity records**, baseline read-only modes, exact production replacements, unchanged historical packet, scoped diff, Python/inline compilation, six delivered-source joins, and deterministic ZIP/envelope/pins/request/readiness regeneration.

Exactly six source members differ from Task 9: `diagnostic.py`, `check_result.py`, `README.md`, generated `manifest.json`, `tests/test_boundaries.py`, and new `tests/test_evidence_capacity.py`. The existing boundary test changes only the prospective custody sum. `task10-scoped.diff` captures those differences. Earlier freezes, packets, artifacts, checkers and metrics remain intact.

## Immutable offline handoff and identities

`/workspace/scratch/codec-task10-source-freeze` is nonnested, **41 files, 517909 logical bytes**, files 0444/directories 0555. Its read-only proof is `/workspace/scratch/codec-task10-freeze-proof.log`. `source-identities.json` verifies all 40 other members, 4836 bytes, SHA256 `35fed224e9e937bd6541784c392222c93626c89fd442c1eecbd179d5e3c1c1a5`.

| Member | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 83968 | `6ac199b750c45e476ae45e34ff0b803e8ef8a56685797eb098464e9131bc1dc2` |
| check_result.py | 41026 | `a3220faff333b1983384c635bbd07c4709ebe4fa1aabd414fe80f0eb31515c9d` |
| manifest.json | 542 | `8d9d8928f07f30de0fc71d0ca1a0dab777fa1c851c6de29711c9de8bb2c70bb8` |
| tests/test_evidence_capacity.py | 4718 | `3b66feb69fe3c061be6bd1467081e16b28420e65d67a31d386228451b72d7a85` |
| task10-scoped.diff | 12099 | `959fdca0f86ee7f5dea8886cdb9ec51672a9264bda37ee40c683acc804489a2b` |
| packet-task10-review/code.zip | 41108 | `648b1e13f8ea16d4c343d694fdbc7a64f0afe4833c9b40a0764db1de40493522` |
| packet-task10-review/code-envelope.json | 54970 | `0e5eccd34bb832c73beabf712e69049319225812fea21163e36cb9fd3c3951c1` |
| inline | 10861 | `734c4e164b89f8405c6fdfbb6389ff6df4e626f6bbd01ec4d1e5dbcb1cfb8ea9` |
| request | 12018 | `416136258f6fe94abdd429a467ef2f5a84e037a32370cee64574fa812c30d5c4` |

The normal `packet-task10-review` is marked **UNAPPROVED OFFLINE**, nonce `task10review`, source key `synthetic-benchmarks/codec-diagnostic-review/task10/code-envelope.json`, evidence prefix `synthetic-benchmarks/codec-diagnostic-review/task10/evidence`, role `arn:aws:iam::079358094174:role/codec-diagnostic-task10review`. Root owns independent review, fresh-nonce admission, all live actions and the $20 cap. This task made no provider/network/SDK/native-image/Docker/FFmpeg calls, spawned no agents and changed no paid hold. The possible next $1 hold was not invoked.
