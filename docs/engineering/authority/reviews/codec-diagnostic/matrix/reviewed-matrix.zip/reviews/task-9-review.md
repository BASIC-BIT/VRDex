# Task 9 independent scoped review

SPEC: PASS. QUALITY: PASS. No actionable findings within this amendment.

Reviewed the Task 9 brief, implementation report, small-work amendment, frozen diff, source, generated packet and recorded boundary evidence. This review accepts Task 8's prior source review and 155-test baseline. It does not repeat the full diagnostic review or qualify benchmark results.

## Scope and arithmetic

Independent read-only comparison against the identity-verified Task 8 freeze confirms exactly three production literal replacements: runtime `WORK['small']`, reported `resources.smallWorkLimit`, and the checker's independent expectation change from `536870912` to `2147483648`. There is no old/new fallback. All other runtime and checker bytes are unchanged. The eight changed source members match the delivered diff exactly; existing test edits only update prospective literals.

Independently added non-small charges total `10518781669`. Adding `2147483648` produces `12666265317`; subtracting from unchanged `WORK_CAP=12884901888` leaves `218636571`. This reallocates `1610612736` bytes from existing headroom. CPU, memory, storage, scan-entry/time/charge, runtime, admission and Root custody bounds remain unchanged. Byte comparison also preserves Task 8's post-RELEASE sampling guard, process/control/argv/EOF joins, cleanup and metric rules.

The active README gives the new arithmetic and explicitly states that exhausted `small()` accounting can prevent terminal or negative evidence writes. No reserve, reset, borrowed reservation or unmetered escape path was added. Renderer and readiness schema remain unchanged as Root directed; readiness has no existing arithmetic fields. Root must record the new sum in admission. No companion is required.

## Boundary evidence and quality

Inspected the five new generated tests and relevant existing tests. They cover cumulative exact-bucket acceptance followed by one-byte-over rejection without admitted-state growth; independently enumerated non-small charges and unchanged total-cap exact acceptance/overflow rejection; runtime report and independent checker agreement; old, changed and missing reported-limit rejection; and blocked terminal evidence writes after bucket exhaustion. Existing scan tests retain shared accounting across both roots and partial observations on failure.

Recorded working and frozen runs each pass all 52 relevant tests, including both retained Task 8 release regressions, in 1.308 and 1.301 seconds respectively. The recorded immutable-baseline RED run has 10 tests, 4 assertion failures, 4 old-limit exceptions and 2 passes. I inspected these records and did not rerun tests, as instructed. The narrow production diff and focused boundary evidence are sufficient for this mechanical amendment.

## Identity and handoff

Independent read-only hashing verified all 38 listed Task 9 members, the exact file set, 0444 files/0555 directories, and absence of symlinks. `source-identities.json` is 4567 bytes with SHA256 `1f4348b0a290c3d8bdaa9994bc7e33837a243066d58d02bbd98b117a040429c1`. All 41 listed Task 8 baseline members also match their recorded identities. The scoped diff is independently reproduced byte-for-byte, SHA256 `681dcc380fac8803dafe6abda684638d92829fac54b20964f11d9e8c6bdfdcb2`.

Verified packet ZIP/envelope/manifest pins, all six archived source joins, inline and request identities, and readiness external-pin joins. ZIP SHA256 is `b520f8b48a9ec80f112b05f5c9136571601b20b628a051d3bbcad4a2eda723d7`; envelope is `26d6531abe0454de0f27238ab7750526a1544e13e6f8bc323fb39fe187e04ef5`; inline is `d087f73588130622620d46da4edee72e50baa606cc6335323470006da95325a8`; request is `8b7aaa7519ac19cb1a8d5b046290874a02cdde669f1585c6aa1d42114129db2c`. Existing custody records additionally report deterministic regeneration and unchanged historical Task 8 packet. The review packet remains marked UNAPPROVED OFFLINE.

Task 9 source is ready for Root's fresh admission and actual twelve-case matrix under the existing controls. This verdict does not guarantee matrix completion, establish current-image or Fargate capacity, change paid holds, or reclassify earlier failed runs. Exhaustion can still leave terminal evidence absent. Benchmark results remain unqualified, delegated completed cells incomplete, and production capacity tables empty. This review made no source edits, test reruns, provider/native/SDK/Docker/network calls or child-agent requests.
