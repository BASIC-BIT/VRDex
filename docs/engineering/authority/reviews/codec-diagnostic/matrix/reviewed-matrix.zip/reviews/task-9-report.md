# Task 9 report: prospective small-work reallocation

Ready for independent review. The only production changes replace `536870912` with `2147483648` in runtime `WORK['small']`, reported `resources.smallWorkLimit`, and the checker's independent literal expectation. The new checker requires the exact new value and rejects the old, changed or missing limit. Task 8's post-RELEASE guard and all control/process/argv/EOF/cleanup/metric joins remain unchanged.

Unchanged non-small charges total **10518781669** bytes. Adding **2147483648** gives **12666265317** planned bytes; unchanged `WORK_CAP=12884901888` leaves **218636571**. This moves **1610612736** bytes from existing headroom. All other charges and bounds remain unchanged, including 100000 scan entries, 0.8 seconds, 256 bytes per stat, disk limits, runtime and Root custody. Active README arithmetic and the exhaustion limitation are updated. Root explicitly directed that renderer/readiness schema remain unchanged because existing readiness has no arithmetic fields; no accounting companion was added.

## Verification and exact scope

- RED, `verification-task9/red.log`, then reproducible final `baseline_red.py` against immutable Task 8: **10 tests, 4 assertion failures and 4 expected old-limit exceptions, 2 passes**. These expose the old bucket, old report, old checker, planned total and cumulative scan cap.
- GREEN, `PYTHONPATH=tests python -B -m unittest test_small_work test_boundaries test_monitor test_storage test_release_sampling -v`: **52 passed in 1.308 seconds**. Frozen copy: **52 passed in 1.301 seconds**. Five new tests cover exact cumulative bucket acceptance, one-byte-over rejection, unchanged total-cap enforcement and independently derived arithmetic, runtime/checker agreement, changed/missing limits, and exhausted terminal evidence writes. Relevant existing suites include both retained Task 8 release regressions; unrelated suites were not rerun under Root's bounded instruction.
- `verification-task9/custody.py` passed in working and frozen directories. It verifies all 41 immutable Task 8 identity records and permissions, exact production replacements, unchanged other source and historical Task 8 packet, independent arithmetic, Python/inline compilation, all six delivered source joins and deterministic ZIP/envelope/pins/request/readiness regeneration.

Exactly eight source members differ from Task 8: `diagnostic.py`, `check_result.py`, `README.md`, generated `manifest.json`, existing `tests/test_boundaries.py`, `tests/test_monitor.py`, `tests/test_storage.py`, and new `tests/test_small_work.py`. The existing tests only change prospective literals. `task9-scoped.diff` records the exact diff. Probe, helpers, pins, renderer and all other source tests are byte-identical. Earlier source/checker snapshots, negatives and ledgers remain intact.

## Immutable offline handoff

`/workspace/scratch/codec-task9-source-freeze` contains **39 files, 523792 logical bytes**, with all 38 identity-listed members verified after freezing. Files are 0444 and directories 0555; `/workspace/scratch/codec-task9-freeze-proof.log` records the read-only check. `source-identities.json` is **4567 bytes**, SHA256 `1f4348b0a290c3d8bdaa9994bc7e33837a243066d58d02bbd98b117a040429c1`.

| Member | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 83966 | `bcb9f52f8fe045fb77836ba5e6af63ac80db795476c2d3ff15247cdbd785bb4d` |
| check_result.py | 41025 | `340d97cfaf76f2e865f836738491593843048c45d932610af892795c181a0763` |
| manifest.json | 542 | `8485bfeda1167f20eb794f13e3f7b0e16e22f45273e1e1fab0a1fc0da671a93a` |
| tests/test_small_work.py | 3663 | `1c94cce9bffb170a0e0babb422bd70dc9279c52e19543c9ab7ea790699c306bf` |
| task9-scoped.diff | 20354 | `681dcc380fac8803dafe6abda684638d92829fac54b20964f11d9e8c6bdfdcb2` |
| packet-task9-review/code.zip | 41111 | `b520f8b48a9ec80f112b05f5c9136571601b20b628a051d3bbcad4a2eda723d7` |
| packet-task9-review/code-envelope.json | 54974 | `26d6531abe0454de0f27238ab7750526a1544e13e6f8bc323fb39fe187e04ef5` |
| inline | 10859 | `d087f73588130622620d46da4edee72e50baa606cc6335323470006da95325a8` |
| request | 12011 | `8b7aaa7519ac19cb1a8d5b046290874a02cdde669f1585c6aa1d42114129db2c` |

The normal refreshed packet is `packet-task9-review`, nonce `task9review`, source key `synthetic-benchmarks/codec-diagnostic-review/task9/code-envelope.json`, evidence prefix `synthetic-benchmarks/codec-diagnostic-review/task9/evidence`, role `arn:aws:iam::079358094174:role/codec-diagnostic-task9review`. `UNAPPROVED.txt` marks it **UNAPPROVED OFFLINE**. Root owns fresh-nonce admission, live execution and spending. This task made no provider/network/SDK/native-image/Docker/FFmpeg calls, created no children, changed no paid hold and reclassified no prior run.

**Remaining limitation:** evidence writes also call `small()`. Once the bucket is exhausted, terminal or negative evidence writes can fail; a complete negative artifact is not guaranteed. No meter redesign, reserve, reset, borrowed reservation or unmetered escape path was added. The 2 GiB bucket does not guarantee the full matrix. Benchmark results remain unqualified, delegated completed cells remain incomplete, and production capacity tables remain empty.
