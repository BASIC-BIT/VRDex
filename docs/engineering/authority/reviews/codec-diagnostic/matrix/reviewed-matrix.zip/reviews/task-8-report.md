# Task 8 report: stop keeper sampling after release

Ready for Root's independent review. The only production change adds `not released` to the periodic keeper-sampling guard in `diagnostic.py`. EXIT still captures `raw.final` before sending RELEASE. The controller then drains both attach streams under the existing deadline, waits for zero attach exit, and runs the unchanged closure and completion checks. Active sampling still propagates a missing keeper as `cell_FileNotFoundError`.

Only `diagnostic.py`, generated `manifest.json`, and new `tests/test_release_sampling.py` differ from Task 7. The custody check verifies that exact source scope and exact one-line production change. Probe, helpers, pins, renderer, independent checker, README, image, workload, limits, storage and all resource/namespace/ancestor proof logic remain byte-identical. No provider, SDK, Docker, FFmpeg, native-image or network execution occurred. No child agents or commits were created.

## RED and GREEN

The generated regression runs the real `run_cell`, metric derivation, completion logic and independent checker with mocked attach process, selector and keeper. It emits READY, STARTED, two progress messages ending at 750 frames and 25.002667 seconds, then EXIT 0 with progress EOF. RELEASE immediately removes keeper availability. The selector delays both output EOFs beyond a periodic sampling interval while the attach process remains alive.

The success test verifies no snapshot after RELEASE, the final snapshot immediately before RELEASE, both EOFs drained, attach exit zero, closed cleanup, full finite output, and independent checker recognition as one completed delegated cell. Its disposition remains INCOMPLETE with `hidden_higher_ancestors`; CPU percent remains unavailable. The second test makes the keeper disappear during active periodic sampling and requires failure, no final snapshot, and no RELEASE.

Retained evidence under `/workspace/scratch/codec-task8-source-freeze/verification-task8`:

- `red.log`: two tests, one expected failure with `cell_FileNotFoundError`; active negative passed before the production edit.
- `final-baseline-red.log`: final tests run against the immutable Task 7 `run_cell` loaded into memory, two tests and exactly the same expected failure. Reproduce with `python -B verification-task8/baseline_red.py`.
- `green.log`: `PYTHONPATH=tests python -B -m unittest test_release_sampling -v`, two passed in 0.016 seconds. The frozen candidate also passed both tests after copying.
- `full-suite.log`: `python -B -m unittest discover -s tests -v`, 155 tests, seven sandbox AF_UNIX `PermissionError` errors. These were both foreign-marker variants of `test_live_foreign_socket_and_marker_are_never_removed`, plus `test_live_nested_socket_keeps_runtime_incomplete`, `test_owned_python_daemon_group_is_reaped_before_stale_unlink`, `test_short_root_known_paths_bind_real_unix_sockets`, `test_stale_socket_removed_only_after_process_absence`, and `test_unclosed_group_and_tracked_container_keep_stale_socket`.
- `full-suite-escalated.log`: the same command with the authorized normal local-socket escalation, **155 passed in 4.161 seconds**.
- `custody.log`: `python -B verification-task8/custody.py`, 38 frozen Task 7 members verified unchanged, immutable baseline permissions checked, exact source diff checked, Python and trusted inline compilation, all six delivered source joins, and deterministic ZIP/envelope/pins/request/readiness regeneration passed. It also passed when run from the frozen Task 8 artifact.

Initial fixture errors are retained in named logs: a wrong controller-constant name, an overly exact final timestamp assertion, and missing fixture clock/capture/CSV evidence. These were corrected in test code. An initial custody draft compared inline renderings with different dictionary insertion orders; rebuilding pins in the renderer's canonical generation order fixed that comparison. Production remained a single guard edit.

## Immutable handoff

Candidate `/workspace/scratch/codec-task8-source-freeze` is non-nested, contains 42 files and 539934 logical bytes, and contains only current source/tests, Task 8 packet, scoped diff and Task 8 verification evidence. Files are 0444 and directories 0555. All 41 members in `source-identities.json` were rehashed after copying and again at final verification. Task 7 remains immutable and unchanged.

`source-identities.json` is 5058 bytes, SHA256 `d837a6d3f13ce48f533d183d81f7ac808469722db9e2dfbc03c9482009f40448`.

| Candidate member | Bytes | SHA256 |
| --- | ---: | --- |
| diagnostic.py | 83964 | b84133968d25c0a0853fd7e9a01cb8bce0768b073790a2529c94931803935a0f |
| tests/test_release_sampling.py | 9334 | 559d42a6821c09c5cfa850c44be09ddbb710330ed2de3fea13dd613f0df5ab88 |
| task8-scoped.diff | 11372 | 2f00cda6d6abf6e91b1e3fe575d81af68ac302350bde090622a1dcdb30185f65 |
| manifest.json | 542 | c559335a526084523a583995fbfe619183c5a78ab39ac0ed1f72ef5c7aac3656 |
| packet-task8-review/code.zip | 41118 | 5788cec21137f4e7e5ba9764d5a4fe724c8365a2797e7f99f74629dd6b9f7973 |
| packet-task8-review/code-envelope.json | 54982 | 60ee428a52df2085d2df373a8524933455843b6b3bb31e2a451068b99156e801 |

The trusted inline fixture is 10859 bytes, SHA256 `70b1b2e0c149176112e1cf1d6541e66ecf7bf4a490d5816d1d977966d8b226f9`. The canonical create-project fixture is 12011 bytes, SHA256 `a1e4665d56a56b43800b77b972bf5239efa5513415170ab5ebe5896327460ed1`.

Exact offline rendering command:

```sh
python -B packet_renderer.py --root . --destination packet-task8-review \
  --nonce task8review \
  --source-key synthetic-benchmarks/codec-diagnostic-review/task8/code-envelope.json \
  --evidence-prefix synthetic-benchmarks/codec-diagnostic-review/task8/evidence \
  --role-arn arn:aws:iam::079358094174:role/codec-diagnostic-task8review
```

`packet-task8-review/UNAPPROVED.txt` marks the deterministic packet UNAPPROVED OFFLINE and prohibits live invocation before independent review and Root's fresh-nonce request rendering/admission. Root owns the next actual matrix and all spending. This local regression makes no actual performance or source/image qualification claim.
