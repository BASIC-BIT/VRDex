# Task 9: prospective small-work reallocation only

Implement the narrow reviewed amendment `/workspace/scratch/codec-small-work-amendment.md` in the private diagnostic source. No provider/network/native/image execution, child agents, new meter framework, evidence-reserve redesign or live run. Root separately owns any invocation and cost reconciliation.

Change the small-work allowance from **536870912** to **2147483648**, including the runtime WORK entry, reported `resources.smallWorkLimit` and the checker's independent literal expectation. Keep `WORK_CAP=12884901888` and all other charges/limits unchanged. New planned sum is **12666265317**, leaving **218636571**. Update active explanatory documentation/readiness arithmetic without rewriting historical ledgers, source/checker snapshots or prior negatives. Do not add a fallback accepting either limit for a new packet; use the new exact reviewed expectation while retaining old checkers for old artifacts.

Add/update focused generated tests: new bucket exact-bound acceptance and one-byte-over rejection; unchanged total-cap enforcement; independently computed non-small total/sum/headroom; runtime report and independent checker agree; changed/missing reported limit is rejected. Existing per-scan 100000 entries, 0.8 seconds, 256-byte charge, disk/runtime/Root custody bounds and cumulative charging behavior must remain unchanged. No test needs the actual image. Run the relevant existing suite and record exact results.

Preserve the Task 8 post-RELEASE sampling fix and every control/process/argv/EOF/cleanup/metric join. Keep the known exhaustion limitation explicit: evidence writes can fail when `small()` has exhausted the bucket. Do not hide this with unmetered writes, a reset, borrowed reservation or a new terminal reserve in this task.

Deliver the precise diff, tests, prospective arithmetic, source hashes and normal refreshed packet/envelope/inline identities for independent review. No reclassification of earlier failed runs, no cost-hold change, no guaranteed-full-matrix claim. The intent is to fund the actually observed scan cost within the already authorized 12 GiB envelope.
