# Codec small-work reallocation

**Recommendation: accept prospectively.** Increase only this diagnostic's small-work bucket from 536870912 bytes (512 MiB) to 2147483648 bytes (2 GiB), funded entirely from its existing unassigned headroom. The total runtime allocation remains **12884901888 bytes (12 GiB)**. This addresses observed accounting cost; it neither raises the total nor repairs prior attempts retroactively.

| Accounting item | Bytes |
| --- | ---: |
| Unchanged non-small planned charges | 10518781669 |
| Previous small-work bucket | 536870912 |
| Previous planned total | 11055652581 |
| Reallocated from existing headroom | 1610612736 |
| New small-work bucket | 2147483648 |
| **New planned total** | **12666265317** |
| **Remaining unassigned headroom** | **218636571** |

Arithmetic: `11055652581 − 536870912 + 2147483648 = 12666265317`; `12884901888 − 12666265317 = 218636571`. No other charge, controller scope, Root custody allowance, per-scan entry/time limit, 256-byte entry charge, disk ceiling, cadence, runtime deadline or paid reservation changes.

Root's latest closed-run facts provide a concrete basis: the loaded image has 53093 scanned entries, costing **13591808 charged bytes per complete scan**. Setup plus the first cell consumed 72860804 small-work bytes, including 62618368 filesystem-observation bytes across 27 scans. Holding that already-observed usage aside, 2 GiB permits **152 additional scans** at the final image size, with 8668028 bytes left before other future small work; the former bucket permitted only 34. These are accounting illustrations, not an execution guarantee. Later presets may encode more slowly; new evidence/progress/metadata work and changing entry counts also consume the bucket. The existing time envelope can permit more scans than 2 GiB funds. Exhaustion must still stop the attempt.

Root reports the first 480 case produced 25 media seconds in approximately 2.07 encoding wall seconds (about 12×), zero FFmpeg exit and captured final counters; its roughly 4.09-second whole-cell duration does not predict all resolutions. The post-RELEASE sampling race and its Task 8 fix are separate. This reallocation does not reclassify that failure or replace independent verification of any next result.

**Explicit remaining limitation:** `small()` also meters later evidence writes. If the bucket is exhausted, terminal/negative evidence writes may themselves fail, so a complete negative artifact is not guaranteed. Record that limitation; do not add a new reserve/meter framework or unmetered escape path in this change. Existing Root provider capture/cleanup remains required, and absent evidence stays absent.

Apply only the prospective constants, independent checker expectation, explanatory accounting and focused tests, then review/repackage. Existing source lines identify the small bucket (`diagnostic.py:5`), reported monitor limit (`diagnostic.py:603`) and independent expectation (`check_result.py:259`). Keep old source/checker/artifact identities and negative ledgers intact. Root supplied all-resources-closed ledger: known compute USD 1.64346, held USD 12.56346; this amendment changes neither and authorizes no new hold or live action. Benchmark results remain explicitly unqualified; delegated completed cells stay incomplete and production capacity tables empty.
