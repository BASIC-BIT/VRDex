"""Reproduce this read-only summary from the archived result.json, with assertions."""
import csv
import hashlib
import json
from decimal import Decimal, localcontext
from pathlib import Path
import zipfile

SOURCE = Path('/workspace/scratch/codec-capacity-live-e8935a9f69ff4700ae0cf084681546fa/artifact-read-1.zip')
EXPECTED_SHA256 = 'a81ba4b8112ad84c6ec536b06385a542effce4378161a5e4fa27ff483f78f940'
OUT = Path(__file__).resolve().parent
assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == EXPECTED_SHA256
with zipfile.ZipFile(SOURCE) as archive:
    result = json.loads(archive.read('result.json'), parse_float=Decimal)
    host = json.loads(archive.read('host.json'))
    raw = json.loads(archive.read('cell-00-raw.json'))
cpu_models = sorted({line.split(':',1)[1].strip() for line in host['cpuinfo'].splitlines() if line.split(':',1)[0].strip() == 'model name'})
assert cpu_models == ['Intel(R) Xeon(R) Platinum 8488C']
assert raw['controls']['leafQuotaCores'] == 2
assert raw['controls']['affinity'] == [0,1]
assert raw['controls']['memoryBytes'] == 4294967296
assert result['cleanup']['state'] == 'closed'
cells = result['cells']
assert len(cells) == 12
assert sum(c['executionComplete'] for c in cells) == 12
assert all(c['state'] == 'incomplete' for c in cells)
assert all(c['reason'] == 'hidden_higher_ancestors' for c in cells)
assert all(m['state'] == 'available' for c in cells for name,m in c['metrics'].items() if name != 'cpuPercent')
assert all(c['metrics']['cpuPercent']['state'] == 'missing' for c in cells)

fields = ['preset','audioKbps','state','reason','executionComplete','fps','speed','cpuCores',
          'ffmpegPeakMiB','cgroupPeakMiB','throttledSeconds','cpuPercent','cpuPercentState',
          'cpuPercentMissingReason','derivedCpuSecondsPerMediaSecond','derivedCpuSecondsPerMediaSecondStatus',
          'ffmpegPeakBytes','cgroupPeakBytes','sourceRefs']
rows = []
interval_checks = []

def available(cell, name):
    metric = cell['metrics'][name]
    return metric['value'] if metric['state'] == 'available' else ''

def mib(value):
    return Decimal(value) / Decimal(1048576) if value != '' else ''

for cell in cells:
    row = {name: cell[name] for name in ['preset','audioKbps','state','reason','executionComplete']}
    row['executionComplete'] = str(row['executionComplete']).lower()
    for name in ['fps','speed','cpuCores','throttledSeconds','cpuPercent']:
        row[name] = available(cell, name)
    for prefix in ['ffmpeg','cgroup']:
        row[prefix+'PeakBytes'] = available(cell, prefix+'PeakBytes')
        row[prefix+'PeakMiB'] = mib(row[prefix+'PeakBytes'])
    row['cpuPercentState'] = cell['metrics']['cpuPercent']['state']
    row['cpuPercentMissingReason'] = cell['metrics']['cpuPercent'].get('reason', '')
    cpu = cell['metrics']['cpuCores']
    speed = cell['metrics']['speed']
    same_interval = (cpu.get('interval') == speed.get('interval') and 'interval' in cpu)
    qualified_for_derivation = cpu['state'] == speed['state'] == 'available' and speed['value'] > 0 and same_interval
    if qualified_for_derivation:
        with localcontext() as context:
            context.prec = 40
            row['derivedCpuSecondsPerMediaSecond'] = cpu['value'] / speed['value']
        row['derivedCpuSecondsPerMediaSecondStatus'] = 'derived_from_available_same_interval_values_not_new_qualified_metric'
    else:
        row['derivedCpuSecondsPerMediaSecond'] = ''
        row['derivedCpuSecondsPerMediaSecondStatus'] = 'missing_inputs'
    interval_checks.append({'cell':cell['id'], 'sameMeasurementInterval':same_interval,
                            'derivationAvailable':qualified_for_derivation,
                            'cpuCoresInterval':cpu.get('interval'), 'speedInterval':speed.get('interval')})
    row['sourceRefs'] = ';'.join(cell.get('sourceRefs', []))
    rows.append(row)
with (OUT/'matrix.csv').open('w', newline='') as handle:
    writer = csv.DictWriter(handle, fieldnames=fields)
    writer.writeheader()
    writer.writerows(rows)

completed = [c for c in cells if c['executionComplete']]
worst = min(completed, key=lambda c: available(c, 'speed'))
ffmax = max(completed, key=lambda c: available(c, 'ffmpegPeakBytes'))
cgmax = max(completed, key=lambda c: available(c, 'cgroupPeakBytes'))
assert all(available(c,'speed') > 1 for c in completed)
assert all(available(c,'throttledSeconds') == 0 for c in completed)
assert all(x['derivationAvailable'] for x in interval_checks)

def fmt(value):
    return f'{value:.2f}' if value != '' else 'missing'

lines = [
    '# Complete retained-image codec matrix',
    '',
    'All twelve cases completed execution and all twelve measured post-warmup speeds exceeded real time. '
    f"The lowest observed speed was {fmt(available(worst,'speed'))}x at {worst['id']}. "
    'Every case remains `incomplete` solely for `hidden_higher_ancestors`. No case failed, was censored, or is `not_run`. ',
    '',
    '| Preset | AAC160 speed | AAC320 speed | AAC160 peak MiB, FFmpeg / cgroup | AAC320 peak MiB, FFmpeg / cgroup |',
    '|---|---:|---:|---:|---:|',
]
for index in range(0, len(rows), 2):
    a,b=rows[index:index+2]
    lines.append(f"| {a['preset']} | {fmt(a['speed'])}{'x' if a['speed'] != '' else ''} | {fmt(b['speed'])}{'x' if b['speed'] != '' else ''} | {fmt(a['ffmpegPeakMiB'])} / {fmt(a['cgroupPeakMiB'])} | {fmt(b['ffmpegPeakMiB'])} / {fmt(b['cgroupPeakMiB'])} |")
lines += [
    '',
    f"The largest available FFmpeg peak was {fmt(mib(available(ffmax,'ffmpegPeakBytes')))} MiB "
    f"at {ffmax['id']} ({available(ffmax,'ffmpegPeakBytes')} bytes). The largest available child-cgroup peak "
    f"was {fmt(mib(available(cgmax,'cgroupPeakBytes')))} MiB at {cgmax['id']} "
    f"({available(cgmax,'cgroupPeakBytes')} bytes). These measure different memory scopes and must not be added. "
    'FFmpeg peaks use wait4; cgroup peaks cover the whole run including the keeper.',
    '',
    'CPU core equivalents are available for all twelve cases. CPU percentage is missing throughout because effective '
    'CPU entitlement is unknown. Observed child-cgroup throttled time was 0 seconds in all twelve measured cases. '
    'The CSV preserves source numerical precision and '
    'exact byte-to-MiB conversions; blank numeric fields mean missing, never zero. Its CPU-seconds/media-second '
    'column is derived as CPU core equivalents divided by speed only after confirming identical recorded measurement '
    'intervals and positive speed. It is a derived ratio, not a new qualified metric.',
    '',
    'This is one observation per combination, with uncontrolled shared-parent contention and keeper overhead. '
    'The retained image is bound to baseline `db9abbcd59a30d206d85c0dcb2f407150e31dd9e` and was run in '
    'CodeBuild advertised as 4 vCPU and 7 GB. Archived host cpuinfo reports Intel Xeon Platinum 8488C. '
    'The child quota was 2 CPUs, restricted to CPUs 0 and 1, with 4 GiB memory. '
    'The workload generated 25 seconds of testsrc2 video and a synthetic tone, then encoded directly to MPEG-TS '
    'at `/dev/null`. It did not decode or downscale an input, exercise the full worker, or measure network/provider '
    'delivery. These observations do not qualify Fargate or the current image, establish statistical AAC cost, '
    'or justify a capacity increase. Hidden higher cgroup ancestors prevent a complete effective-entitlement assessment.',
    '',
    f'Source: archived `result.json` and `host.json` in `artifact-read-1.zip`, SHA-256 `{EXPECTED_SHA256}`. '
    'Extraction and interval checks are reproducible with `extract_summary.py`; `provenance.json` records their results.',
]
(OUT/'findings.md').write_text('\n'.join(lines)+'\n')
provenance = {
    'artifactPath':str(SOURCE), 'artifactSha256':EXPECTED_SHA256,
    'sourceMembers':['result.json','host.json','cell-00-raw.json'], 'nonce':result['nonce'], 'rowCount':len(rows),
    'cpuModelsFromArchivedHostCpuinfo':cpu_models, 'cleanupState':result['cleanup']['state'],
    'childControls':{'quotaCores':2,'affinity':[0,1],'memoryBytes':4294967296},
    'executionCompleteCount':len(completed), 'qualifiedCompleteCount':0,
    'cpuPercentAvailableCount':0, 'derivedRatioCount':sum(x['derivationAvailable'] for x in interval_checks),
    'derivedRatioFormula':'cpuCores / speed; CPU-seconds/media-second; derived, not a new qualified metric',
    'missingNumericEncoding':'blank CSV field', 'mibDivisorBytes':1048576,
    'measurementIntervalChecks':interval_checks,
}
(OUT/'provenance.json').write_text(json.dumps(provenance, indent=2, default=str)+'\n')
# Verify the written artifact directly, including missing data and source values.
with (OUT/'matrix.csv').open(newline='') as handle:
    written = list(csv.DictReader(handle))
assert len(written) == 12
for cell, row in zip(cells,written):
    for metric in ['fps','speed','cpuCores','throttledSeconds','cpuPercent']:
        expected = available(cell, metric)
        assert row[metric] == (str(expected) if expected != '' else '')
    for prefix in ['ffmpeg','cgroup']:
        expected = available(cell,prefix+'PeakBytes')
        assert row[prefix+'PeakBytes'] == (str(expected) if expected != '' else '')
        assert row[prefix+'PeakMiB'] == (str(mib(expected)) if expected != '' else '')
assert all(row['cpuPercent'] == '' for row in written)
assert all(row[name] != '' for row in written for name in ['fps','speed','cpuCores','ffmpegPeakMiB','cgroupPeakMiB','throttledSeconds','derivedCpuSecondsPerMediaSecond'])
print(json.dumps({'verification':'PASS','rows':12,'executionComplete':12,'missingFinalCase':False,'derivedRatiosWithIdenticalIntervals':12,'worstSpeed':str(available(worst,'speed')),'maxFfmpegPeakBytes':available(ffmax,'ffmpegPeakBytes'),'maxCgroupPeakBytes':available(cgmax,'cgroupPeakBytes')}))
