"""Prospective 2 GiB small-work accounting, with generated offline fixtures."""
import copy
import pathlib
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d
import check_result as c
import test_storage


class SmallWork(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)
        self.ledger = d.Ledger(self.root / 'ledger', 'codec-diagnostic-small-work')

    def test_exact_bucket_accepts_cumulative_charges_and_rejects_one_more_byte(self):
        with patch.object(d, '_METER', self.ledger):
            d.small('fixtureBytes', 2147483647)
            d.small('fixtureBytes', 1)
            with self.assertRaisesRegex(d.Failure, '^small_work_cap$'):
                d.small('fixtureBytes', 1)
        self.assertEqual(self.ledger.observed, {
            'smallObservableBytes': 2147483648, 'fixtureBytes': 2147483648})

    def test_planned_charges_leave_only_existing_total_headroom(self):
        # Hand-computed non-small charges, independent of runtime WORK arithmetic.
        expected = {'zip': 1791891162, 'selected': 1204540308,
                    'compressedHash': 301087947, 'raw': 5529867264,
                    'bootstrap': 491394988, 'tools': 1200000000}
        self.assertEqual({k: v for k, v in d.WORK.items() if k != 'small'}, expected)
        self.assertEqual(sum(expected.values()), 10518781669)
        for name, charge in d.WORK.items():
            self.ledger.charge(name, charge)
        self.assertEqual(self.ledger.used, 12666265317)
        self.assertEqual(self.ledger.cap, 12884901888)
        self.assertEqual(self.ledger.cap - self.ledger.used, 218636571)
        self.ledger.charge('remaining-headroom', 218636571)
        with self.assertRaisesRegex(d.Failure, '^byte_admission$'):
            self.ledger.charge('one-byte-over-total', 1)
        self.assertEqual(self.ledger.used, 12884901888)

    def test_runtime_report_matches_independent_checker(self):
        result = test_storage.CheckerStorage().fixture()
        monitor = d.Monitor(pathlib.Path('/tmp/cd'))
        monitor.storage = pathlib.Path(result['storage']['root'])
        result['resources'] = monitor.finish()
        self.assertEqual(result['resources']['smallWorkLimit'], 2147483648)
        c.storage_joins(result)

    def test_checker_rejects_old_changed_or_missing_reported_limit(self):
        result = test_storage.CheckerStorage().fixture()
        result['resources']['smallWorkLimit'] = 2147483648
        c.storage_joins(result)
        for limit in (536870912, 2147483647, 2147483649, None):
            bad = copy.deepcopy(result)
            if limit is None:
                bad['resources'].pop('smallWorkLimit')
            else:
                bad['resources']['smallWorkLimit'] = limit
            with self.subTest(limit=limit), self.assertRaisesRegex(c.Invalid, '^storage_monitor_limits$'):
                c.storage_joins(bad)

    def test_exhaustion_still_blocks_terminal_evidence_writes(self):
        evidence = d.Evidence(self.root / 'evidence')
        with patch.object(d, '_METER', self.ledger):
            d.small('fixtureBytes', 2147483648)
            with self.assertRaisesRegex(d.Failure, '^small_work_cap$'):
                evidence.save('negative.json', {'failed': True}, terminal=True)
        self.assertEqual(evidence.inventory, {})
        self.assertFalse((self.root / 'evidence' / 'negative.json').exists())


if __name__ == '__main__':
    unittest.main()
