"""Generated admission fixtures for the prospective 10 MiB evidence limit."""
import hashlib
import json
import pathlib
import sys
import tempfile
import unittest
import zipfile

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d
import check_result as c


class EvidenceCapacity(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = pathlib.Path(self.tmp.name)

    def archive(self, expanded=None, members=2):
        # A valid setup-negative result with bounded, generated inventory members.
        result = d.empty_result('capacity', {'imageId': 'fixture'}, 'setup_failed')
        result['cleanup'] = {'state': 'closed'}
        padding = 0 if expanded is None else expanded - 20000
        for _ in range(8):
            files = {f'padding-{i}': b'' for i in range(members - 1)}
            files['padding-0'] = b'x' * padding
            result['inventory'] = {name: {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}
                                   for name, body in files.items()}
            files['result.json'] = (json.dumps(result, sort_keys=True, separators=(',', ':')) + '\n').encode()
            total = sum(map(len, files.values()))
            if expanded is None or total == expanded:
                break
            padding += expanded - total
        self.assertTrue(expanded is None or total == expanded)
        path = self.root / 'evidence.zip'
        with zipfile.ZipFile(path, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
            for name, body in files.items():
                archive.writestr(name, body)
        return path

    def test_nine_mib_raw_boundary_preserves_one_mib_terminal_remainder(self):
        evidence = d.Evidence(self.root / 'evidence')
        evidence.save('raw', b'x' * 9437183)
        evidence.save('last-raw-byte', b'x')
        before = evidence.inventory.copy()
        with self.assertRaisesRegex(d.Failure, '^evidence_overflow$'):
            evidence.save('raw-overflow', b'x')
        self.assertEqual(evidence.inventory, before)
        self.assertFalse((evidence.root / 'raw-overflow').exists())
        evidence.save('terminal', b'y' * 1048576, terminal=True)
        self.assertEqual(sum(pin['bytes'] for pin in evidence.inventory.values()), 10485760)
        with self.assertRaisesRegex(d.Failure, '^evidence_overflow$'):
            evidence.save('terminal-overflow', b'y', terminal=True)
        self.assertFalse((evidence.root / 'terminal-overflow').exists())

    def test_checker_accepts_exact_ten_mib_expanded_valid_negative(self):
        path = self.archive(expanded=10485760)
        self.assertLess(path.stat().st_size, 10485760)
        summary = c.read_zip(path, 'capacity', expected_pins={'imageId': 'fixture'})
        self.assertEqual(summary['counts'], {'observed': 0, 'censored': 0, 'incomplete': 0, 'not_run': 12})
        self.assertEqual(summary['inventoryVerified'], 1)

    def test_checker_rejects_one_byte_above_expansion_limit(self):
        path = self.archive(expanded=10485761)
        with self.assertRaisesRegex(c.Invalid, '^output_expansion_cap$'):
            c.read_zip(path, 'capacity', expected_pins={'imageId': 'fixture'})

    def test_checker_zip_byte_limit_stays_ten_mib(self):
        path = self.archive()
        # ZIP readers support prefixed archives; enforce physical size independently.
        body = path.read_bytes()
        path.write_bytes(b'\0' * (10485760 - len(body)) + body)
        c.read_zip(path, 'capacity', expected_pins={'imageId': 'fixture'})
        with path.open('ab') as out:
            out.write(b'\0')
        with self.assertRaisesRegex(c.Invalid, '^output_zip_cap$'):
            c.read_zip(path, 'capacity', expected_pins={'imageId': 'fixture'})

    def test_checker_member_limit_stays_128(self):
        c.read_zip(self.archive(members=128), 'capacity', expected_pins={'imageId': 'fixture'})
        with self.assertRaisesRegex(c.Invalid, '^output_expansion_cap$'):
            c.read_zip(self.archive(members=129), 'capacity', expected_pins={'imageId': 'fixture'})

    def test_root_custody_changes_only_expanded_evidence_allowance(self):
        # Design table order: responses, ZIPs, expanded evidence, source envelope,
        # source response, source ZIP, inline authority, controls/logs.
        self.assertEqual(d.CUSTODY, (28093104, 20971520, 10485760, 3145728,
                                    4259840, 2097152, 262144, 8388608))
        self.assertEqual(sum(d.CUSTODY), 77703856)
        self.assertEqual(83886080 - sum(d.CUSTODY), 6182224)


if __name__ == '__main__':
    unittest.main()
