"""Generated attach protocol: keeper vanishes at RELEASE, output drains later."""
import copy, io, json, pathlib, sys, tempfile, types, unittest
from unittest.mock import patch
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, probe, check_result as checker, test_delegated as fixtures


class ReleaseSampling(unittest.TestCase):
    def run_protocol(self, missing_active=False):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = pathlib.Path(tmp.name)
        state = types.SimpleNamespace(now=100., released=False, stopped=False,
                                      snapshots=0, trace=[], reads={})
        cpus = [0, 1]
        argv = probe.ffmpeg_argv(d.MATRIX[0])
        facts = {'uid':65534, 'credentialEnvironment':False, 'interfaces':['lo'],
                 'routes':'header\n', 'affinity':cpus, 'namespaces':fixtures.fixture_namespaces(True)}
        events = [
            {'event':'READY', 'facts':facts},
            {'event':'STARTED', 'pid':7, 'affinity':cpus, 'argv':argv},
            {'event':'PROGRESS', 'raw':{'frame':'180', 'out_time_us':'6000000', 'progress':'continue'}},
            {'event':'PROGRESS', 'raw':{'frame':'750', 'out_time_us':'25002667', 'progress':'end'}},
            {'event':'EXIT', 'pid':7, 'exitCode':0, 'progressEOF':True, 'ffmpegPeakKiB':100},
        ]

        class Stream(io.BytesIO):
            def __init__(self, fd):super().__init__();self.fd=fd
            def fileno(self):return self.fd
            def write(self, data):
                state.trace.append(data.decode().strip())
                if data == b'RELEASE\n':state.released=True
                return super().write(data)

        proc = types.SimpleNamespace(pid=12345, stdin=Stream(9), stdout=Stream(10), stderr=Stream(11))
        proc.poll = lambda: None  # Attach stays alive while the keeper's /proc entry is gone.
        proc.wait = lambda **kw: 0

        class Selector:
            def __init__(self):self.keys={};self.round=0
            def register(self, stream, event, name):self.keys[name]=types.SimpleNamespace(fileobj=stream, data=name)
            def unregister(self, stream):self.keys.pop('stdout' if stream.fd==10 else 'stderr')
            def get_map(self):return self.keys
            def close(self):pass
            def select(self, timeout):
                state.now += .2
                self.round += 1
                if self.round <= len(events):
                    state.reads[10]=d.wire(events[self.round-1]);return [(self.keys['stdout'], 1)]
                # Force a full periodic-sampling interval after RELEASE and before either EOF.
                if self.round == 6:return []
                name = 'stdout' if self.round == 7 else 'stderr'
                state.reads[10 if name=='stdout' else 11]=b''
                return [(self.keys[name], 1)]

        class CG:
            def __init__(self, pid, **kw):
                self.pid=pid;self.groups=dict.fromkeys(d.REQUIRED_CONTROLLERS, fixtures.ROOT+'/leaf')
                self.ns=fixtures.fixture_namespaces(True);self.affinity=cpus
                kw['sink'](self.evidence())
            def evidence(self):
                value=fixtures.fixture(fixtures.ROOT+'/leaf', self.pid, True)
                if self.pid == 43:value['identity']['cmdline']='\0'.join(argv)+'\0'
                return fixtures.seal_capture(value)
            def snapshot(self):
                state.trace.append('snapshot_after_release' if state.released else 'snapshot')
                if state.released or (missing_active and state.snapshots == 1):
                    raise FileNotFoundError('/proc/42/cgroup')
                state.snapshots += 1;state.now += .001;n=state.snapshots
                values={'cpuacct.usage':n*1000000000, 'cpuacct.stat:user':n, 'cpuacct.stat:system':n,
                        'cpu.stat:nr_periods':n, 'cpu.stat:nr_throttled':0, 'cpu.stat:throttled_time':0,
                        'memory.usage_in_bytes':1000, 'memory.max_usage_in_bytes':2000,
                        'memory.failcnt':0, 'memory.oom_control:under_oom':0,
                        'memory.oom_control:oom_kill_disable':0}
                raw={}
                for key, value in values.items():
                    if ':' not in key:
                        ctl='cpu,cpuacct' if key.startswith('cpu') else 'memory'
                        raw['/sys/fs/cgroup/'+ctl+'/leaf/'+key]=str(value)
                for base in ('cpuacct.stat', 'cpu.stat', 'memory.oom_control'):
                    ctl='memory' if base.startswith('memory') else 'cpu,cpuacct'
                    raw['/sys/fs/cgroup/'+ctl+'/leaf/'+base]='\n'.join(k.split(':')[1]+' '+str(v) for k,v in values.items() if k.startswith(base+':'))
                return {'t':state.now, 'values':values, 'raw':raw, 'pid':self.pid,
                        'membership':self.evidence()['membership']}

        source=pathlib.Path(d.__file__).resolve().with_name('probe.py')
        info={'Id':'a'*64, 'Image':'image', 'Config':{'User':'65534:65534', 'Entrypoint':['python3']},
              'HostConfig':{'NetworkMode':'none', 'ReadonlyRootfs':True, 'Privileged':False,
                            'Memory':4294967296, 'MemorySwap':4294967296, 'CpuPeriod':100000,
                            'CpuQuota':200000, 'CpusetCpus':'0,1', 'PidsLimit':128, 'CapDrop':['ALL'],
                            'SecurityOpt':['no-new-privileges']},
              'Mounts':[{'Source':str(source), 'Destination':'/codec-probe.py', 'RW':False}],
              'State':{'Pid':42, 'Running':True, 'OOMKilled':False}}
        def command(args, *a, **kw):
            if args[1]=='kill':state.stopped=True
            if args[1]=='inspect':
                value=copy.deepcopy(info)
                if state.released or state.stopped:value['State'].update(Pid=0, Running=False)
                return {'stdout':d.wire([value])}
            return {'stdout':('a'*64+'\n').encode() if args[1]=='create' else b''}
        def read(fd, size):
            data=state.reads.pop(fd)
            if not data:state.trace.append('stdoutEOF' if fd==10 else 'stderrEOF')
            return data
        def bounded(path, *a):
            if str(path)=='/proc/42/task/42/children':return b'43'
            if str(path)=='/proc/43/status':return b'NSpid:\t43\t7\n'
            raise AssertionError(str(path))
        ev=d.Evidence(root/'evidence')
        pins={'imageId':'image', 'controlVisibilityPolicy':fixtures.POLICY}
        parent=types.SimpleNamespace(evidence=fixtures.fixture)
        with patch.object(d.time,'monotonic',side_effect=lambda:state.now), \
             patch.object(d,'command',side_effect=command), patch.object(d.subprocess,'Popen',return_value=proc), \
             patch.object(d.selectors,'DefaultSelector',Selector), patch.object(d.os,'set_blocking'), \
             patch.object(d.os,'read',side_effect=read), patch.object(d,'Cgroups',CG), \
             patch.object(d,'bounded',side_effect=bounded), patch.object(d,'kill_group',return_value=True):
            cell=d.run_cell(d.MATRIX[0],0,'test123',pins,root,{},
                            types.SimpleNamespace(cell=lambda start:(start+32,start+40)),
                            types.SimpleNamespace(check=lambda:None),ev,cpus,parent)
        raw=json.loads((ev.root/'cell-00-raw.json').read_bytes())
        return cell,raw,state,ev,pins

    def test_release_stops_sampling_and_drains_both_attach_streams(self):
        cell,raw,state,ev,pins=self.run_protocol()
        self.assertTrue(cell['executionComplete'], cell)
        self.assertEqual(cell['reason'], 'hidden_higher_ancestors')
        self.assertNotIn('snapshot_after_release', state.trace)
        release=state.trace.index('RELEASE')
        self.assertEqual(state.trace[release-1], 'snapshot')
        self.assertEqual(state.trace[release+1:], ['stdoutEOF', 'stderrEOF'])
        self.assertGreater(raw['final']['t'], max(s['t'] for s in raw['snapshots']))
        self.assertTrue(raw['stdoutEOF'] and raw['stderrEOF'])
        self.assertEqual(raw['attachExitCode'], 0)
        self.assertTrue(d.execution_complete(raw))
        self.assertEqual(raw['cleanup']['state'], 'closed')
        self.assertTrue(raw['cleanup']['attachGroupClosed'] and raw['cleanup']['removed'])
        self.assertEqual(raw['samples'][-1]['mediaUs'], 25002667)
        result=d.empty_result('test123',pins,'fixture_unrun');result['cells'][0]=cell
        result['cleanup']={'state':'closed'}
        files={name:(ev.root/name).read_bytes() for name in ev.inventory}
        files['metrics.csv']=d.metrics_csv(result['cells'])
        result['inventory']={name:{'bytes':len(body),'sha256':d.sha(body)} for name,body in files.items()}
        self.assertEqual(checker.check(result,files,'test123',expected_pins=pins)['completedButIncomplete'],1)

    def test_missing_keeper_during_active_sampling_still_fails(self):
        cell,raw,state,_,_=self.run_protocol(missing_active=True)
        self.assertEqual(cell['reason'], 'cell_FileNotFoundError')
        self.assertFalse(cell['executionComplete'])
        self.assertNotIn('RELEASE', state.trace)
        self.assertIsNone(raw['final'])
        self.assertFalse(raw['stdoutEOF'] or raw['stderrEOF'])


if __name__=='__main__':unittest.main()
