"""Finite unqualified retained-image codec diagnostic. Explicit CLI is the only live entry."""
import argparse, base64, contextlib, csv, hashlib, importlib.util, io, json, math, os, pathlib, re, selectors, shutil, signal, socket, errno, stat, subprocess, sys, tarfile, threading, time, urllib.error, urllib.parse, urllib.request, zipfile

WORK_CAP=12884901888
WORK={'zip':6*298648527,'selected':4*301135077,'compressedHash':301087947,'raw':6*921644544,'bootstrap':7*70199284,'tools':4*300000000,'small':2147483648}
CUSTODY=(28093104,20971520,10485760,3145728,4259840,2097152,262144,8388608)
PRESETS=[('480p30',854,480,30,1000,'veryfast'),('480p60',854,480,60,1500,'veryfast'),('720p30',1280,720,30,1800,'veryfast'),('720p60',1280,720,60,2500,'veryfast'),('1080p30',1920,1080,30,3000,'veryfast'),('1080p60',1920,1080,60,3500,'superfast')]
MATRIX=[dict(id=f'{n}-aac{a}',preset=n,width=w,height=h,fps=f,videoKbps=b,x264Preset=p,audioKbps=a) for n,w,h,f,b,p in PRESETS for a in (160,320)]
METRICS=('fps','speed','cpuCores','cpuPercent','cgroupPeakBytes','ffmpegPeakBytes','throttledSeconds','throttledPeriods')
class Failure(Exception): pass
_METER=None
_METER_LOCK=threading.Lock()
def small(name,n):
    if _METER is None:return
    with _METER_LOCK:
        total=_METER.observed.get('smallObservableBytes',0)+n
        need(total<=WORK['small'],'small_work_cap')
        _METER.observed['smallObservableBytes']=total
        _METER.observe(name,n)
def need(ok,why):
    if not ok: raise Failure(why)
def wire(x):return (json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=True,allow_nan=False)+'\n').encode('ascii')
def sha(b):return hashlib.sha256(b).hexdigest()
def tick(deadline):need(time.monotonic()<deadline,'deadline')
def bounded(path,cap=65536):
    with open(path,'rb') as f:b=f.read(cap+1)
    small('metadataReadBytes',len(b));need(len(b)<=cap,'metadata_cap');return b

class Ledger:
    """Exclusive allocation record; reservations are conservative work, never physical I/O."""
    def __init__(self,path,allocation,cap=WORK_CAP):
        need(re.fullmatch(r'codec-diagnostic-[a-zA-Z0-9-]+',allocation),'allocation')
        self.path=pathlib.Path(path);self.cap=cap;self.used=0;self.items=[];self.observed={};self.unknown=False;self.allocation=allocation
        try:
            with self.path.open('xb') as f:f.write(wire(self.record()))
        except FileExistsError:raise Failure('allocation_already_exists') from None
    def record(self):return {'allocation':self.allocation,'limit':self.cap,'conservativeChargedBytes':self.used,'items':self.items,'observed':self.observed,'uncertain':self.unknown,'opaqueExclusions':['Docker/native/kernel/interpreter internals','managed signing/credential provider internals','FFmpeg generated buffers']}
    def persist(self):
        with self.path.open('wb') as f:f.write(wire(self.record()));f.flush();os.fsync(f.fileno())
    def charge(self,stage,n):
        need(type(n) is int and n>=0 and self.used+n<=self.cap,'byte_admission')
        self.used+=n;self.items.append({'stage':stage,'bytes':n});self.persist()
    def observe(self,name,n):self.observed[name]=self.observed.get(name,0)+n
    def uncertain(self):self.used=self.cap;self.unknown=True;self.persist()

class Counted:
    def __init__(self,f,cap,check=lambda:None):self.f=f;self.cap=cap;self.total=0;self.check=check
    def read(self,n=-1):
        self.check();remaining=self.cap-self.total
        need(n>=0,'unbounded_read')
        need(remaining>0 or n==0,'compressed_read_cap')
        b=self.f.read(min(n,remaining));self.total+=len(b);return b
    def readinto(self,b):
        data=self.read(len(b));b[:len(data)]=data;return len(data)
    def seek(self,*a):self.check();return self.f.seek(*a)
    def tell(self):return self.f.tell()
    def __getattr__(self,name):return getattr(self.f,name)
    def __enter__(self):return self
    def __exit__(self,*a):self.f.close()

class TarFacade:
    """Only the privately loaded preflight module receives this facade."""
    def __init__(self,cap,deadline):self.cap=cap;self.deadline=deadline;self.total=0
    @contextlib.contextmanager
    def open(self,path,mode):
        f=Counted(open(path,'rb'),self.cap-self.total,lambda:tick(self.deadline))
        try:
            with tarfile.open(fileobj=f,mode=mode) as tf:yield tf
        except tarfile.TarError:raise Failure('bootstrap_archive_or_read_cap') from None
        finally:self.total+=f.total;f.f.close()

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self,*a,**kw):raise Failure('redirect_rejected')

def download(url,path,size,digest,deadline,*,opener=None,allowed=None,monitor=None):
    parts=urllib.parse.urlsplit(url)
    need(parts.scheme=='https' and parts.hostname and not parts.username and not parts.password and parts.port in (None,443),'download_origin')
    if allowed:need((parts.hostname,parts.path)==allowed,'download_origin')
    opener=opener or urllib.request.build_opener(urllib.request.ProxyHandler({}),NoRedirect())
    h=hashlib.sha256();n=0
    try:
        tick(deadline)
        with opener.open(urllib.request.Request(url),timeout=min(5,max(.01,deadline-time.monotonic()))) as response,open(path,'xb') as out:
            need(response.status==200 and response.geturl()==url,'download_response')
            while True:
                tick(deadline)
                if monitor:monitor.check()
                b=response.read(min(65536,size-n+1))
                if not b:break
                n+=len(b);need(n<=size,'download_size');h.update(b);out.write(b)
        need(n==size and h.hexdigest()==digest,'download_identity')
        return {'bytes':n,'sha256':h.hexdigest(),'eof':True}
    except Failure:raise
    except BaseException as e:raise Failure('download_'+type(e).__name__) from None

class Clocks:
    def __init__(self,provider_start,now_wall=None,now_mono=None):
        now_wall=time.time() if now_wall is None else now_wall;now_mono=time.monotonic() if now_mono is None else now_mono
        elapsed=now_wall-provider_start;need(0<=elapsed<900,'provider_timebase')
        self.origin=now_mono-elapsed;self.setup=self.origin+240;self.cells=self.origin+720;self.end=self.origin+900
        self.raw={'providerStartSeconds':provider_start,'hostWall':now_wall,'hostMono':now_mono,'elapsed':elapsed,'endMono':self.end}
    def admit(self,now):return now+40<=self.cells and now+40+180<=self.end
    def cell(self,now):need(self.admit(now),'cell_admission');return now+32,now+40

class Evidence:
    def __init__(self,root,cap=10485760,reserve=1048576):self.root=pathlib.Path(root);self.cap=cap;self.reserve=reserve;self.inventory={};self.root.mkdir(exist_ok=True)
    def save(self,name,data,terminal=False):
        need(re.fullmatch(r'[a-zA-Z0-9_.-]+',name),'evidence_path')
        b=data if isinstance(data,bytes) else wire(data)
        total=sum(x['bytes'] for n,x in self.inventory.items() if n!=name)
        need(total+len(b)<=self.cap-(0 if terminal else self.reserve),'evidence_overflow')
        small('evidenceWriteHashBytes',2*len(b));(self.root/name).write_bytes(b);self.inventory[name]={'bytes':len(b),'sha256':sha(b)};return name

def extract_selected(path,target,pins,read_cap,deadline):
    target=pathlib.Path(target);target.mkdir(mode=0o700)
    seen=set()
    with Counted(open(path,'rb'),read_cap,lambda:tick(deadline)) as counted:
        with zipfile.ZipFile(counted) as z:
            infos=z.infolist();need(len(infos)<=128 and sum(len(x.filename.encode())+len(x.extra)+46 for x in infos)<=1048576,'zip_directory_cap')
            total=0
            for x in infos:
                n=x.filename;mode=x.external_attr>>16
                need(n not in seen and not n.startswith('/') and '\\' not in n and all(v not in ('','..','.') for v in n.split('/')),'zip_path')
                need(not x.is_dir() and stat.S_IFMT(mode) in (0,stat.S_IFREG) and not x.flag_bits&1 and x.compress_type in (0,8),'zip_type')
                seen.add(n);total+=x.file_size
            need(total<=335544320 and set(pins)<=seen,'zip_expansion_or_missing')
            for name,pin in pins.items():
                x=z.getinfo(name);need(x.file_size==pin['bytes'],'member_size')
                h=hashlib.sha256();n=0;dest=target/pathlib.PurePosixPath(name).name
                fd=os.open(dest,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
                with z.open(x) as inp,os.fdopen(fd,'wb') as out:
                    while True:
                        tick(deadline);b=inp.read(min(65536,pin['bytes']-n+1))
                        if not b:break
                        n+=len(b);need(n<=pin['bytes'],'member_oversize');h.update(b);out.write(b)
                need(n==pin['bytes'] and h.hexdigest()==pin['sha256'],'member_identity')
        return {'compressedReadBytes':counted.total,'selectedBytes':sum(x['bytes'] for x in pins.values())}

def kill_group(proc,deadline):
    if proc is None:return True
    for sig in (signal.SIGTERM,signal.SIGKILL):
        try:os.killpg(proc.pid,sig)
        except ProcessLookupError:pass
        try:proc.wait(timeout=max(.01,min(.5,deadline-time.monotonic())))
        except subprocess.TimeoutExpired:pass
    try:os.killpg(proc.pid,0);return False
    except ProcessLookupError:return proc.poll() is not None

def pump(proc,deadline,producer=None,monitor=None,stdout_cap=131072,stderr_cap=131072,on_line=None):
    """One nonblocking owner drains output while enforcing stdin backpressure."""
    sel=selectors.DefaultSelector();buffers={'stdout':bytearray(),'stderr':bytearray()};eof={'stdout':False,'stderr':False}
    for n in buffers:os.set_blocking(getattr(proc,n).fileno(),False);sel.register(getattr(proc,n),selectors.EVENT_READ,n)
    pending=b'';exhausted=producer is None;stdin_closed=producer is None;linebuf=b'';written=0
    if producer is not None:os.set_blocking(proc.stdin.fileno(),False);sel.register(proc.stdin,selectors.EVENT_WRITE,'stdin')
    try:
        while sel.get_map():
            tick(deadline)
            if monitor:monitor.check()
            for key,_ in sel.select(min(.05,max(.001,deadline-time.monotonic()))):
                name=key.data
                if name=='stdin':
                    if not pending:
                        try:pending=next(producer);need(isinstance(pending,bytes) and len(pending)<=65536,'producer_chunk')
                        except StopIteration:
                            exhausted=True;sel.unregister(proc.stdin);proc.stdin.close();stdin_closed=True;continue
                    if pending:
                        try:n=os.write(proc.stdin.fileno(),pending)
                        except BlockingIOError:continue
                        except BrokenPipeError:raise Failure('load_broken_pipe') from None
                        need(n>0,'load_zero_write');written+=n;pending=pending[n:]
                else:
                    try:b=os.read(key.fileobj.fileno(),65536)
                    except BlockingIOError:continue
                    if not b:sel.unregister(key.fileobj);eof[name]=True;continue
                    small('commandReadBytes',len(b));cap=stdout_cap if name=='stdout' else stderr_cap
                    need(len(buffers[name])+len(b)<=cap,name+'_cap');buffers[name].extend(b)
                    if name=='stdout' and on_line:
                        linebuf+=b;need(len(linebuf)<=65536,'line_cap')
                        while b'\n' in linebuf:
                            line,linebuf=linebuf.split(b'\n',1);on_line(line)
        code=proc.wait(timeout=max(.01,deadline-time.monotonic()))
        return {'exitCode':code,'stdout':bytes(buffers['stdout']),'stderr':bytes(buffers['stderr']),'stdoutEOF':eof['stdout'],'stderrEOF':eof['stderr'],'exhausted':exhausted,'stdinClosed':stdin_closed,'writtenBytes':written}
    finally:sel.close()

def stream_load(generator,argv,env,size,digest,deadline,monitor=None):
    tick(deadline)
    h=hashlib.sha256();count=0;exhausted=False
    def source():
        nonlocal count,exhausted
        for b in generator:
            tick(deadline);count+=len(b);need(count<=size,'load_size');h.update(b);yield b
        exhausted=True;need(count==size and h.hexdigest()==digest,'load_identity')
    proc=subprocess.Popen(argv,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:
        facts=pump(proc,deadline,iter(source()),monitor)
        need(exhausted and facts['exhausted'] and facts['stdinClosed'] and facts['writtenBytes']==size and facts['exitCode']==0 and facts['stdoutEOF'] and facts['stderrEOF'],'load_incomplete')
        return {**facts,'bytes':count,'sha256':h.hexdigest()}
    except Failure:raise
    except BaseException as e:raise Failure('load_'+type(e).__name__) from None
    finally:
        clean=kill_group(proc,deadline)
        for f in (proc.stdin,proc.stdout,proc.stderr):
            if f and not f.closed:f.close()
        close=getattr(generator,'close',None)
        if close:close()
        need(clean,'load_cleanup_uncertain')

def signing_deadline(setup_deadline):return min(setup_deadline,time.monotonic()+30)

def signing_environment(base):
    env=dict(base);env.update(AWS_MAX_ATTEMPTS='1',AWS_RETRY_MODE='standard',AWS_EC2_METADATA_DISABLED='true',AWS_S3_US_EAST_1_REGIONAL_ENDPOINT='regional',AWS_DEFAULT_REGION='us-east-1',AWS_REGION='us-east-1');return env

def command(argv,env,deadline,monitor=None):
    tick(deadline)
    proc=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
    try:
        f=pump(proc,deadline,monitor=monitor);need(f['exitCode']==0,'command_exit');return f
    finally:
        clean=kill_group(proc,deadline);proc.stdout.close();proc.stderr.close();need(clean,'command_cleanup_uncertain')

REQUIRED_CONTROLLERS=('cpu','cpuacct','memory','cpuset')
DELEGATED_POLICY='allow-incomplete-delegated-v1'
def canonical_path(text):
    need(isinstance(text,str) and text.startswith('/') and not text.startswith('//') and '\\' not in text and all(c not in text for c in ('\x00','\n','\r','\t')),'resource_control_unproven')
    p=pathlib.PurePosixPath(text)
    need(str(p)==text and '..' not in p.parts,'resource_control_unproven');return p

def parse_cgroups(text):
    out={}
    for line in text.splitlines():
        fields=line.split(':',2);need(len(fields)==3,'resource_control_unproven');hierarchy,controllers,path=fields
        need(hierarchy.isdigit() and int(hierarchy)>0 and controllers,'resource_control_unproven');canonical_path(path)
        for c in controllers.split(','):
            need(c and c not in out,'resource_control_unproven');out[c]=path
    need(set(REQUIRED_CONTROLLERS)<=set(out),'resource_control_unproven');return out

def cpulist(text):
    result=set()
    for p in text.strip().split(','):
        need(re.fullmatch(r'[0-9]+(?:-[0-9]+)?',p),'cpuset');a=p.split('-');start=int(a[0]);end=int(a[-1]);need(0<=start<=end<65536,'cpuset');result.update(range(start,end+1))
    return sorted(result)

CONTROL_FILES=(('cpu','cpu.cfs_quota_us'),('cpu','cpu.cfs_period_us'),('memory','memory.limit_in_bytes'),('memory','memory.memsw.limit_in_bytes'),('cpuset','cpuset.cpus'))
COUNTER_FILES=(('cpuacct','cpuacct.usage'),('cpuacct','cpuacct.stat'),('cpu','cpu.stat'),('memory','memory.usage_in_bytes'),('memory','memory.max_usage_in_bytes'),('memory','memory.failcnt'),('memory','memory.oom_control'))
def resolve_visible_v1(raw,policy=None,*,target=False):
    need(policy in (None,'full-root-only',DELEGATED_POLICY),'control_visibility_policy')
    groups=parse_cgroups(raw['membership']);mounts={};roots={};devices={}
    for line in raw['mountinfo'].splitlines():
        left,sep,right=line.partition(' - ')
        need(sep,'resource_control_unproven');r=right.split();l=left.split()
        need(len(r)>=3 and len(l)>=6,'resource_control_unproven')
        need(r[0]!='cgroup2','resource_control_unproven')
        if r[0]!='cgroup':continue
        relevant=set(r[2].split(',')) & set(REQUIRED_CONTROLLERS)
        if not relevant:continue
        root=canonical_path(l[3]);mount=canonical_path(l[4]);need(re.fullmatch(r'[0-9]+:[0-9]+',l[2]),'resource_control_unproven')
        for c in relevant:
            need(c not in mounts,'resource_control_unproven');mounts[c]=str(mount);roots[c]=str(root);devices[c]=l[2]
    need(set(mounts)==set(REQUIRED_CONTROLLERS),'resource_control_unproven')
    need(len({groups[c] for c in REQUIRED_CONTROLLERS})==1 and len(set(roots.values()))==1,'resource_control_unproven')
    for c in REQUIRED_CONTROLLERS:need(canonical_path(groups[c]).is_relative_to(canonical_path(roots[c])),'resource_control_unproven')
    delegated=next(iter(roots.values()))!='/'
    if delegated:
        need(policy==DELEGATED_POLICY,'resource_control_unproven')
        # Collector admission stays strict. The observed Docker bind root may
        # only be parsed as a target; visible_view must prove its parent mapping.
        root=roots['cpu']
        need(re.fullmatch(r'/ecs/[^/]+/[^/]+',root) or (target and re.fullmatch(r'/ecs/[^/]+/[^/]+/docker/[0-9a-f]{64}',root) and groups['cpu']==root),'resource_control_unproven')
    return {'groups':groups,'mounts':mounts,'roots':roots,'devices':devices,'visibility':'delegated_subtree' if delegated else 'full_root','fullHostVisible':not delegated}

def resolve_hierarchy(membership,mountinfo):
    h=resolve_visible_v1({'membership':membership,'mountinfo':mountinfo})
    return h['groups'],{c:pathlib.Path(p) for c,p in h['mounts'].items()}

def ancestor_paths(path,root='/'):
    p=canonical_path(path);r=canonical_path(root);need(p.is_relative_to(r),'resource_control_unproven');out=[]
    while p!=r:p=p.parent;out.append(str(p))
    return out

def namespace_ids(value):
    required=('cgroup','mnt','pid','net','user')
    need(isinstance(value,dict) and set(value)==set(required),'namespace_identity_unproven')
    need(all(isinstance(value[n],str) and re.fullmatch(n+r':\[[1-9][0-9]*\]',value[n]) for n in required),'namespace_identity_unproven')
    return value

def visible_view(raw,policy=None):
    target=resolve_visible_v1(raw,policy,target=True);collector=raw.get('collector')
    if collector is None:
        need(target['fullHostVisible'],'collector_view_unproven');return target
    view=resolve_visible_v1(collector,policy)
    if re.fullmatch(r'/ecs/[^/]+/[^/]+/docker/[0-9a-f]{64}',target['roots']['cpu']):
        parent=str(canonical_path(target['roots']['cpu']).parent.parent)
        need(view['roots']['cpu']==view['groups']['cpu']==parent,'collector_mount_unproven')
    if not target['fullHostVisible'] or not view['fullHostVisible']:namespace_ids(raw.get('namespaces'));namespace_ids(collector.get('namespaces'))
    need(raw['namespaces']['cgroup']==collector['namespaces']['cgroup'],'collector_namespace_unproven')
    for c in REQUIRED_CONTROLLERS:
        need(target['devices'][c]==view['devices'][c] and canonical_path(target['roots'][c]).is_relative_to(canonical_path(view['roots'][c])) and canonical_path(target['groups'][c]).is_relative_to(canonical_path(view['roots'][c])),'collector_mount_unproven')
    # All subsequent file reads use this collector mapping, never target mountpoints.
    return {**view,'groups':target['groups']}

def reconstruct_controls(evidence,policy=None):
    view=visible_view(evidence,policy);groups=view['groups'];mounts={c:pathlib.Path(p) for c,p in view['mounts'].items()};path=groups['cpu'];files=evidence['controlFiles'];needed=set();records=[]
    for relative in [path]+ancestor_paths(path,view['roots']['cpu']):
        texts={}
        for controller,name in CONTROL_FILES:
            suffix=canonical_path(relative).relative_to(canonical_path(view['roots'][controller]));source=str(mounts[controller]/suffix/name)
            needed.add(source);need(source in files,'control_source_missing');texts[name]=files[source]
        records.append({'path':relative,'quota':int(texts['cpu.cfs_quota_us']),'period':int(texts['cpu.cfs_period_us']),'memory':int(texts['memory.limit_in_bytes']),'memsw':int(texts['memory.memsw.limit_in_bytes']),'cpus':cpulist(texts['cpuset.cpus'])})
    need(set(files)==needed,'control_source_paths')
    if not view['fullHostVisible']:
        reads=evidence.get('controlReads',{});need(set(reads)==needed,'control_read_unproven')
        for source in needed:
            fact=reads[source];need(fact.get('path')==source and fact.get('complete') is True and fact.get('value')==files[source] and 'error' not in fact and type(fact.get('t')) in (int,float) and math.isfinite(fact['t']),'control_read_unproven')
    for record in records:need(record['period']>0 and (record['quota']==-1 or record['quota']>0) and record['memory']>0 and record['memsw']>=record['memory'] and record['cpus'],'resource_control_unproven')
    return records[0],records[1:],groups,mounts


def prove_controls(leaf,ancestors,affinity,visible):
    need(leaf['path']!='/' and [a['path'] for a in ancestors]==ancestor_paths(leaf['path']) and ancestors,'resource_control_unproven')
    need(visible and leaf['quota']==200000 and leaf['period']==100000 and leaf['memory']==4294967296 and leaf['memsw']==4294967296,'resource_control_unproven')
    cpus=set(leaf['cpus']);need(len(cpus)==2 and cpus==set(affinity),'resource_control_unproven')
    for a in ancestors:
        need(a['quota']==-1 or a['quota']/a['period']>=2,'resource_control_unproven')
        need(a['memory']>=4294967296 and cpus<=set(a['cpus']),'resource_control_unproven')
    return {'effectiveCpus':2,'memoryBytes':4294967296,'leaf':leaf,'ancestors':ancestors,'affinity':sorted(affinity),'hierarchy':'v1','visible':True}

def capture_process(pid,sink,proc_root=pathlib.Path('/proc')):
    """Persist each bounded independent raw read before topology/control admission."""
    base=proc_root/str(pid);raw={'pid':pid,'capturedAt':time.monotonic(),'fields':{},'readErrors':{},'complete':False,'controlFiles':{}}
    sink(raw)
    def field(name,path,read):
        fact={'path':str(path),'t':time.monotonic(),'complete':False};raw['fields'][name]=fact
        try:
            value=read();fact.update(value=value,complete=True);return value
        except (OSError,UnicodeError,Failure) as error:
            fact['error']=type(error).__name__+':'+str(error)[:160];raw['readErrors'][name]=fact['error'];return None
        finally:sink(raw)
    for name,file in [('membership','cgroup'),('mountinfo','mountinfo')]:
        value=field(name,base/file,lambda file=file:bounded(base/file).decode())
        if value is not None:raw[name]=value
    raw['namespaces']={}
    for n in ('cgroup','mnt','pid','net','user'):
        value=field('namespaces.'+n,base/'ns'/n,lambda n=n:os.readlink(base/'ns'/n))
        if value is not None:raw['namespaces'][n]=value
    value=field('affinity',base/'status:sched_getaffinity',lambda:sorted(os.sched_getaffinity(pid)))
    if value is not None:raw['affinity']=value
    raw['identity']={}
    for n in ('stat','cmdline','status'):
        value=field('identity.'+n,base/n,lambda n=n:bounded(base/n).decode())
        if value is not None:raw['identity'][n]=value
    raw['complete']=not raw['readErrors'];sink(raw);return raw

def process_identity(raw):
    identity=raw['identity'];stat=identity['stat'];need(int(stat.split(' ',1)[0])==raw['pid'],'process_identity_unproven')
    start=stat.rsplit(')',1)[1].split()[19];need(start.isdigit(),'process_identity_unproven')
    need(identity.get('startTime',start)==start,'process_identity_unproven');return start

def captured_identity(raw):
    namespace_ids(raw.get('namespaces'))
    need(raw.get('complete') is True and not raw.get('readErrors') and not raw.get('failedSubcheck'),'process_capture_incomplete')
    expected={'membership':raw['membership'],'mountinfo':raw['mountinfo'],'affinity':raw['affinity'],**{'namespaces.'+n:raw['namespaces'][n] for n in ('cgroup','mnt','pid','net','user')},**{'identity.'+n:raw['identity'][n] for n in ('stat','cmdline','status')}}
    need(set(raw['fields'])==set(expected),'process_capture_unproven')
    for name,value in expected.items():need(raw['fields'][name].get('complete') is True and raw['fields'][name].get('value')==value and 'error' not in raw['fields'][name],'process_capture_unproven')
    return process_identity(raw)

def prove_visible_controls(parent,keeper,ffmpeg=None,policy=None):
    pl,pa,pg,pm=reconstruct_controls(parent,policy);kl,ka,kg,km=reconstruct_controls(keeper,policy)
    pv=visible_view(parent,policy);kv=visible_view(keeper,policy)
    need(pv['roots']==kv['roots'] and pv['mounts']==kv['mounts'] and pv['devices']==kv['devices'],'collector_mount_unproven')
    need(all(canonical_path(kg[c]).is_relative_to(canonical_path(pg[c])) and kg[c]!=pg[c] for c in REQUIRED_CONTROLLERS),'resource_control_unproven')
    selected=set(keeper['affinity']);need(selected<=set(parent['affinity']),'resource_control_unproven')
    for a in [pl]+pa+ka:
        need((a['quota']==-1 or a['quota']/a['period']>=2) and a['memory']>=4294967296 and a['memsw']>=a['memory'] and selected<=set(a['cpus']),'resource_control_unproven')
    need(keeper['namespaces']['net']!=parent['namespaces']['net'] and keeper['namespaces']['pid']!=parent['namespaces']['pid'],'isolation_unproven')
    delegated=not kv['fullHostVisible']
    if not delegated:proof=prove_controls(kl,ka,keeper['affinity'],True)
    else:
        need(policy==DELEGATED_POLICY and kl['path']!=kv['roots']['cpu'] and [a['path'] for a in ka]==ancestor_paths(kl['path'],kv['roots']['cpu']),'resource_control_unproven')
        need(kl['quota']==200000 and kl['period']==100000 and kl['memory']==kl['memsw']==4294967296 and len(selected)==2 and selected==set(kl['cpus']),'resource_control_unproven')
        for raw in (parent,keeper)+((ffmpeg,) if ffmpeg else ()):
            captured_identity(raw);need(raw.get('collector') and raw['collector']['pid']==parent['pid'] and raw['collector']['namespaces']==parent['namespaces'] and raw['collector']['membership']==parent['membership'] and captured_identity(raw['collector'])==process_identity(parent),'collector_identity_unproven')
            cv=resolve_visible_v1(raw['collector'],policy);need(all(cv[k]==pv[k] for k in ('roots','mounts','devices')),'collector_mount_unproven')
        proof={'effectiveCpus':None,'memoryBytes':4294967296,'leaf':kl,'ancestors':ka,'affinity':sorted(selected),'hierarchy':'v1','visible':False,'visibility':'delegated_subtree','fullHostVisible':False,'leafQuotaCores':2,'unknownHigherAncestors':[{'controller':c,'visibleRoot':kv['roots'][c]} for c in REQUIRED_CONTROLLERS],'rawRefs':['parent','keeper']+(['ffmpeg'] if ffmpeg else [])}
    if ffmpeg:
        fl,fa,fg,fm=reconstruct_controls(ffmpeg,policy)
        need(fg==kg and fm==km and fl==kl and fa==ka and ffmpeg['namespaces']==keeper['namespaces'] and ffmpeg['affinity']==keeper['affinity'],'resource_control_unproven')
    return proof

class Cgroups:
    def __init__(self,pid,proc_root=pathlib.Path('/proc'),*,policy=None,sink=lambda raw:None):
        self.pid=pid;self.proc=proc_root;self.policy=policy;self.sink=sink
        self.raw=capture_process(pid,sink,proc_root)
        try:
            # Retain both raw captures before delegated topology admission, even
            # when the target form is rejected. Controls use only the proven view.
            if policy==DELEGATED_POLICY:
                collector=capture_process(os.getpid(),lambda x:(self.raw.__setitem__('collector',x),sink(self.raw)),proc_root) if pid!=os.getpid() else {k:v for k,v in self.raw.items() if k!='collector'}
                self.raw['collector']=collector
            self.membership=self.raw['membership'];self.mountinfo=self.raw['mountinfo'];self.view=visible_view(self.raw,policy)
            if 'collector' in self.raw:need(self.raw['collector']['complete'],'collector_identity_unproven')
            self.ns=self.raw['namespaces'];self.affinity=self.raw['affinity'];self.start=process_identity(self.raw);self.raw['identity']['startTime']=self.start
            need(all(n in self.ns for n in ('cgroup','mnt','pid','net','user')),'process_namespace_unproven')
            self.groups=self.view['groups'];self.mounts={c:pathlib.Path(p) for c,p in self.view['mounts'].items()};self.root=self.view['roots']['cpu'];sink(self.raw)
        except (Failure,KeyError,ValueError,IndexError) as error:
            self.raw['failedSubcheck']=str(error) if isinstance(error,Failure) else 'process_identity_unproven';sink(self.raw);raise Failure(self.raw['failedSubcheck']) from None
    def path(self,c,relative=None):
        path=canonical_path(self.groups[c] if relative is None else relative);root=canonical_path(self.view['roots'][c]);need(path.is_relative_to(root),'resource_control_unproven');return self.mounts[c]/path.relative_to(root)
    def text(self,c,name,relative=None):return bounded(self.path(c,relative)/name).decode().strip()
    def controls(self,relative=None):
        val=lambda c,n:int(self.text(c,n,relative))
        return {'path':relative if relative is not None else self.groups['cpu'],'quota':val('cpu','cpu.cfs_quota_us'),'period':val('cpu','cpu.cfs_period_us'),'memory':val('memory','memory.limit_in_bytes'),'memsw':val('memory','memory.memsw.limit_in_bytes'),'cpus':cpulist(self.text('cpuset','cpuset.cpus',relative))}
    def ancestors(self):return [self.controls(p) for p in ancestor_paths(self.groups['cpu'],self.root)]
    def evidence(self):
        self.stable()
        try:
            for relative in [self.groups['cpu']]+ancestor_paths(self.groups['cpu'],self.root):
                for controller,name in CONTROL_FILES:
                    path=str(self.path(controller,relative)/name);fact={'path':path,'t':time.monotonic(),'complete':False};self.raw.setdefault('controlReads',{})[path]=fact
                    try:
                        value=bounded(path).decode().strip();self.raw['controlFiles'][path]=value;fact.update(value=value,complete=True)
                    except (OSError,UnicodeError,Failure) as error:
                        fact['error']=type(error).__name__;self.raw['readErrors'][path]=type(error).__name__;self.raw['failedSubcheck']='control_source_missing';raise
                    finally:self.sink(self.raw)
            reconstruct_controls(self.raw,self.policy);return self.raw
        except (Failure,ValueError,OSError) as error:
            self.raw['failedSubcheck']=str(error) if isinstance(error,Failure) else 'control_source_invalid';self.sink(self.raw);raise Failure(self.raw['failedSubcheck']) from None
    def stable(self):
        need(bounded(self.proc/str(self.pid)/'cgroup').decode()==self.membership,'process_moved')
        need(bounded(self.proc/str(self.pid)/'stat').decode().rsplit(')',1)[1].split()[19]==self.start,'process_replaced')
        need({n:os.readlink(self.proc/str(self.pid)/'ns'/n) for n in self.ns}==self.ns,'process_namespace_changed')
        need(sorted(os.sched_getaffinity(self.pid))==self.affinity,'process_affinity_changed')
        if 'collector' in self.raw:
            collector=self.raw['collector'];need(all(os.readlink(self.proc/str(collector['pid'])/'ns'/n)==collector['namespaces'][n] for n in ('mnt','cgroup')),'collector_namespace_changed')
    def snapshot(self):
        self.stable();raw={};vals={}
        for c,n in [('cpuacct','cpuacct.usage'),('cpuacct','cpuacct.stat'),('cpu','cpu.stat'),('memory','memory.usage_in_bytes'),('memory','memory.max_usage_in_bytes'),('memory','memory.failcnt'),('memory','memory.oom_control')]:
            text=self.text(c,n);raw[str(self.path(c)/n)]=text
            if n in ('cpuacct.stat','cpu.stat','memory.oom_control'):
                for line in text.splitlines():
                    k,v=line.split();vals[n+':'+k]=int(v)
            else:vals[n]=int(text)
        required=['cpuacct.usage','cpuacct.stat:user','cpuacct.stat:system','cpu.stat:nr_periods','cpu.stat:nr_throttled','cpu.stat:throttled_time','memory.usage_in_bytes','memory.max_usage_in_bytes','memory.failcnt','memory.oom_control:under_oom','memory.oom_control:oom_kill_disable']
        need(all(k in vals for k in required),'missing_counters');need(all(v>=0 for v in vals.values()),'negative_counter')
        return {'t':time.monotonic(),'raw':raw,'values':vals,'pid':self.pid,'membership':self.membership}

def missing(reason):return {'state':'missing','reason':reason}
def available(value,unit,interval,refs):return {'state':'available','value':value,'unit':unit,'interval':interval,'sourceRefs':refs}
def derive(samples,denominator,refs=None,*,proof=None):
    refs=refs or ['cell-raw.json'];out={k:missing('insufficient_post_warmup_samples') for k in ('fps','speed','cpuCores','cpuPercent')}
    need(denominator==2 or (denominator is None and proof and proof.get('visibility')=='delegated_subtree' and proof.get('fullHostVisible') is False and proof.get('effectiveCpus') is None),'cpu_denominator')
    if denominator is None:out['cpuPercent']=missing('effective_cpu_entitlement_unknown')
    for sample in samples:
        need(set(sample)=={'t','frame','mediaUs','cpuNs'} and all(type(sample[k]) in (int,float) and math.isfinite(sample[k]) and sample[k]>=0 for k in sample),'invalid_sample')
        need(all(type(sample[k]) is int for k in ('frame','mediaUs','cpuNs')),'sample_units')
    for a,b in zip(samples,samples[1:]):
        need(b['t']>a['t'] and b['frame']>=a['frame'] and b['mediaUs']>=a['mediaUs'] and b['cpuNs']>=a['cpuNs'],'negative_or_reset_interval')
    post=[s for s in samples if s['mediaUs']>=5000000]
    if len(post)<2:return out
    a,b=post[0],post[-1];dt=b['t']-a['t'];need(dt>0,'interval')
    interval={'wallMono':[a['t'],b['t']],'mediaSeconds':[a['mediaUs']/1e6,b['mediaUs']/1e6],'frames':[a['frame'],b['frame']],'coverage':'actual_sampled_post_warmup'}
    cpu=(b['cpuNs']-a['cpuNs'])/1e9/dt
    for k,value,unit in [('fps',(b['frame']-a['frame'])/dt,'frames/s'),('speed',(b['mediaUs']-a['mediaUs'])/1e6/dt,'media_s/wall_s'),('cpuCores',cpu,'core-equivalents')]:out[k]=available(value,unit,interval,refs)
    if denominator is not None:out['cpuPercent']=available(cpu/denominator*100,'percent_of_verified_2_cpus',interval,refs)
    return out

def disposition(reason=None,exit_code=None,complete=False,controls=False,metrics=False):
    if reason in ('timeout','oom','exit_failure'):return 'censored'
    if reason or not (exit_code==0 and complete and controls and metrics):return 'incomplete'
    return 'observed'
def empty_result(nonce,pins,reason):
    return {'schema':'unqualified-codec-diagnostic-v1','kind':'UNQUALIFIED_SYNTHETIC_CODEC_DIAGNOSTIC','nonce':nonce,'identities':pins,'host':{},'clocks':{},'ledger':{},'resources':{},'cells':[{**x,'state':'not_run','reason':reason,'nonce':nonce,'imageId':pins.get('imageId'),'metrics':{k:missing('not_run:'+reason) for k in METRICS}} for x in MATRIX],'inventory':{},'cleanup':{'state':'incomplete'},'limitations':['Synthetic generation, encoding and MPEG-TS only; no worker admission, native, registry, Fargate or qualification claim.','One observation per cell; shared-parent contention and keeper overhead included.','Controller ledger excludes opaque runtime I/O.']}

CSV_COLUMNS=['cell','state','reason','metric','metricState','value','unit','missingReason','measurementStatus','executionComplete','controlVisibility','fullHostVisible']
def metrics_csv(cells):
    table=io.StringIO();writer=csv.writer(table);writer.writerow(CSV_COLUMNS)
    for cell in cells:
        metadata=[str(cell.get(k,'')).lower() if type(cell.get(k)) is bool else cell.get(k,'') for k in CSV_COLUMNS[8:]]
        for metric,fact in cell['metrics'].items():writer.writerow([cell['id'],cell['state'],cell.get('reason') or '',metric,fact['state'],fact.get('value',''),fact.get('unit',''),fact.get('reason','')]+metadata)
    return table.getvalue().encode('ascii')

def execution_complete(raw):
    exit=raw.get('exit');final=raw.get('final');samples=raw.get('samples',[]);snapshots=raw.get('snapshots',[]);cleanup=raw.get('cleanup',{});terminal=raw.get('terminalInspect',{}).get('State',{})
    complete=bool(raw.get('attachExitCode')==0 and raw.get('controls') and raw.get('ffmpeg') and exit and exit.get('exitCode')==0 and exit.get('progressEOF') is True and raw.get('progressEnd') is True and raw.get('stdoutEOF') is True and raw.get('stderrEOF') is True and final and snapshots and samples and samples[-1]['mediaUs']>=24900000 and cleanup.get('state')=='closed' and cleanup.get('attachGroupClosed') is True and cleanup.get('removed') is True and terminal.get('Pid')==0 and terminal.get('Running') is False and terminal.get('OOMKilled') is False and final['values']['memory.failcnt']==snapshots[0]['values']['memory.failcnt'] and final['values']['memory.oom_control:under_oom']==0)
    if not complete:return False
    cumulative=('cpuacct.usage','cpuacct.stat:user','cpuacct.stat:system','cpu.stat:nr_periods','cpu.stat:nr_throttled','cpu.stat:throttled_time','memory.max_usage_in_bytes','memory.failcnt')
    snaps=snapshots+[final]
    return all(b['t']>a['t'] and all(b['values'][k]>=a['values'][k] for k in cumulative) for a,b in zip(snaps,snaps[1:]))

def child_args(name,image,cpus,probe_path,cell):
    return ['docker','create','--name',name,'--pull=never','--network=none','--read-only','--user=65534:65534','--cap-drop=ALL','--security-opt=no-new-privileges','--pids-limit=128','--memory=4294967296','--memory-swap=4294967296','--cpu-period=100000','--cpu-quota=200000','--cpuset-cpus='+cpus,'--mount=type=bind,src='+str(probe_path)+',dst=/codec-probe.py,readonly','--entrypoint=python3','--interactive',image,'-I','-B','/codec-probe.py','--cell',wire(cell).decode().strip()]

STORAGE_PARENT=pathlib.Path('/codebuild/output')

def storage_mounts(text):
    need(isinstance(text,str) and len(text.encode())<=262144,'storage_mountinfo_cap')
    rows=[]
    for line in text.splitlines():
        fields=line.split();need(len(fields)>=10 and fields.count('-')==1,'storage_mountinfo')
        sep=fields.index('-');need(sep>=6 and len(fields)>=sep+4,'storage_mountinfo')
        point=fields[4];need('\\' not in point and str(canonical_path(point))==point,'storage_mount_path')
        rows.append({'mountpoint':point,'device':fields[2],'filesystem':fields[sep+1],'readWrite':'rw' in fields[5].split(',') and 'rw' in fields[sep+3].split(','),'mountId':fields[0]})
    return rows

def storage_backing(root,text):
    root=pathlib.Path(root);parent=STORAGE_PARENT
    need(root.is_absolute() and str(root)==str(canonical_path(str(root))) and root.is_relative_to(parent),'storage_path')
    for part in [root]+list(root.parents):
        if os.path.lexists(part):need(stat.S_ISDIR(part.lstat().st_mode) and not part.is_symlink(),'storage_symlink')
    rows=storage_mounts(text)
    matches=[r for r in rows if root.is_relative_to(pathlib.Path(r['mountpoint']))]
    need(bool(matches),'storage_mount_missing');effective=max(matches,key=lambda r:len(r['mountpoint']))
    need(effective['mountpoint']==str(parent) and effective['filesystem']=='xfs' and effective['readWrite'],'storage_backing')
    need(sum(r['mountpoint']==str(parent) for r in rows)==1 and not any(pathlib.Path(r['mountpoint']).is_relative_to(root) and r['mountpoint']!=str(parent) for r in rows),'storage_intervening_mount')
    for path in (parent,root):
        if path.exists():
            dev=path.stat().st_dev;need(effective['device']==f'{os.major(dev)}:{os.minor(dev)}','storage_device')
    return effective

def storage_identity(path):
    value=path.lstat();return {'device':value.st_dev,'inode':value.st_ino,'uid':value.st_uid,'mode':stat.S_IMODE(value.st_mode)}

def create_storage(nonce,source,facts=None):
    need(re.fullmatch(r'[a-z0-9-]{6,40}',nonce),'nonce')
    facts={} if facts is None else facts;root=STORAGE_PARENT/('codec-'+nonce);text=bounded('/proc/self/mountinfo',262144).decode('ascii')
    backing=storage_backing(root,text);root.mkdir(mode=0o700,exist_ok=False)
    facts.update(root=str(root),dataRoot=str(root/'data'),nonce=nonce,source=source,identity=storage_identity(root),mountinfo=text,backing=backing,created=True)
    marker=wire({'nonce':nonce,'source':source})
    with (root/'.owner').open('xb') as out:out.write(marker)
    os.chmod(root/'.owner',0o600);facts.update(marker={'bytes':len(marker),'sha256':sha(marker),'identity':storage_identity(root/'.owner')})
    (root/'data').mkdir(mode=0o700,exist_ok=False)
    facts['dataIdentity']=storage_identity(root/'data');facts['backing']=storage_backing(root/'data',bounded('/proc/self/mountinfo',262144).decode('ascii'));facts['owned']=True
    return facts

def owned_daemon_args(control_root,data_root):
    source=pathlib.Path(__file__).resolve().parent;pins=json.loads(bounded(source/'pins.json'))
    helper=verified_module(source/'support/preflight.py','codec_storage_preflight',pins['helpers']['support/preflight.py'])
    args=helper.daemon_args(control_root);expected='--data-root='+str(control_root/'data')
    need(args.count(expected)==1 and sum(arg.startswith('--data-root') for arg in args)==1 and not any(arg.startswith('--storage-driver') for arg in args),'storage_helper_args')
    return [('--data-root='+str(data_root)) if arg==expected else arg for arg in args]+['--storage-driver=overlay2']

def verify_storage(info,version,data_root):
    need(str(data_root)==str(pathlib.Path(data_root).resolve(strict=True)) and info.get('DockerRootDir')==str(data_root),'storage_actual_root')
    need(info.get('Driver')=='overlay2','storage_actual_driver')
    need(info.get('ServerVersion')=='24.0.9' and version.get('Server',{}).get('Version')=='24.0.9' and version.get('Client',{}).get('Version')=='24.0.9','storage_actual_version')
    statuses=info.get('DriverStatus');need(isinstance(statuses,list) and all(isinstance(p,list) and len(p)==2 for p in statuses),'storage_driver_status')
    need(sum(p[0]=='Backing Filesystem' for p in statuses)==sum(p[0]=='Supports d_type' for p in statuses)==1,'storage_driver_status')
    values=dict(statuses);need(values.get('Backing Filesystem')=='xfs' and values.get('Supports d_type')=='true','storage_actual_backing')
    return {'verified':True,'driver':'overlay2','dataRoot':str(data_root),'backingFilesystem':'xfs','supportsDType':True,'dockerVersion':'24.0.9'}

def close_storage(facts):
    root=pathlib.Path(facts['root']);need(root==STORAGE_PARENT/('codec-'+facts['nonce']) and str(root.resolve(strict=True))==str(root),'storage_cleanup_path')
    text=bounded('/proc/self/mountinfo',262144).decode('ascii');mounts=[r for r in storage_mounts(text) if pathlib.Path(r['mountpoint']).is_relative_to(root)]
    facts['closure']={'mountinfo':text,'mountsBeneath':mounts,'absent':False}
    need(not mounts,'storage_mounts_remain');storage_backing(root,text)
    need(storage_identity(root)==facts['identity'] and facts['identity']['mode']==0o700 and facts['identity']['uid']==os.geteuid(),'storage_cleanup_ownership')
    marker=root/'.owner';need(stat.S_ISREG(marker.lstat().st_mode) and storage_identity(marker)==facts['marker']['identity'],'storage_cleanup_marker')
    body=bounded(marker,4096);need(body==wire({'nonce':facts['nonce'],'source':facts['source']}) and sha(body)==facts['marker']['sha256'],'storage_cleanup_marker')
    facts['closure'].update(identity=storage_identity(root),markerSHA256=sha(body));shutil.rmtree(root);facts['closure']['absent']=not os.path.lexists(root);need(facts['closure']['absent'],'storage_cleanup_absence');return facts['closure']

class Monitor:
    """Operational allocated-block/free-space/RSS monitoring, not a filesystem quota."""
    def __init__(self,root):self.root=root;self.error=None;self.peak=0;self.rssPeak=0;self.scans=0;self.lastScan=None;self.stop=threading.Event();self.thread=threading.Thread(target=self.loop,daemon=True);self.storage=None
    def add_storage(self,root):
        root=pathlib.Path(root);work=pathlib.Path(self.root)
        need(self.storage is None and self.lastScan is None and self.thread.ident is None and not root.is_relative_to(work) and not work.is_relative_to(root) and root.resolve(strict=True)==root and work.resolve(strict=True)==work,'monitor_roots')
        need(shutil.disk_usage(root).free>=8589934592,'initial_disk_headroom');self.storage=root
    def scan(self):
        total=0;count=0;started=time.monotonic();complete=False;roots=[self.root]+([self.storage] if self.storage is not None else []);parts=[{'root':str(root),'entries':0,'allocatedBlocksBytes':0} for root in roots];pending=[(root,i) for i,root in reversed(list(enumerate(roots)))]
        try:
            while pending:
                base,index=pending.pop()
                try:
                    with os.scandir(base) as entries:
                        for entry in entries:
                            count+=1;parts[index]['entries']+=1
                            need(count<=100000,'disk_scan_entry_cap')
                            need(time.monotonic()-started<.8,'disk_scan_deadline')
                            try:s=entry.stat(follow_symlinks=False)
                            except FileNotFoundError:continue
                            total+=s.st_blocks*512;parts[index]['allocatedBlocksBytes']+=s.st_blocks*512;small('filesystemObservationBytes',256)
                            if stat.S_ISDIR(s.st_mode):pending.append((entry.path,index))
                except FileNotFoundError:continue
            self.peak=max(self.peak,total);need(total<=6442450944,'disk_ceiling')
            for root in roots:need(shutil.disk_usage(root).free>=2147483648,'disk_headroom')
            status=bounded('/proc/self/status').decode();rss=int(re.search(r'^VmRSS:\s+(\d+)',status,re.M)[1])*1024
            self.rssPeak=max(self.rssPeak,rss);need(rss<=268435456,'parent_rss_ceiling')
            complete=True
        finally:
            self.lastScan={'entries':count,'elapsedSeconds':time.monotonic()-started,'complete':False,'allocatedBlocksBytes':total,'roots':parts,'activeRoot':str(roots[index])}
            if complete:need(self.lastScan['elapsedSeconds']<.8,'disk_scan_deadline')
        self.lastScan['complete']=True;self.scans+=1
    def loop(self):
        while not self.stop.is_set():
            try:self.scan()
            except BaseException as e:self.error=str(e) if isinstance(e,Failure) else 'monitor_observation_failed';return
            self.stop.wait(.9)
    def start(self):need(shutil.disk_usage(self.root).free>=8589934592,'initial_disk_headroom');self.thread.start()
    def check(self):
        if self.error:raise Failure(self.error)
    def finish(self):
        self.stop.set()
        if self.thread.ident is not None:self.thread.join(timeout=1)
        return {'allocatedBlockPeak':self.peak,'parentRSSPeak':self.rssPeak,'scans':self.scans,'lastScan':self.lastScan,'monitorError':self.error,'diskCeilingBytes':6442450944,'roots':[str(self.root)]+([str(self.storage)] if self.storage is not None else []),'scanEntryLimit':100000,'scanSecondsLimit':.8,'entryChargeBytes':256,'smallWorkLimit':2147483648,'mode':'sampled_operational_not_quota'}

def verified_module(source,name,pin):
    data=bounded(source,100000);need(len(data)==pin['bytes'] and sha(data)==pin['sha256'],'helper_source_identity')
    spec=importlib.util.spec_from_file_location(name,source);module=importlib.util.module_from_spec(spec);sys.modules[name]=module;spec.loader.exec_module(module);return module

def choose_cpus():
    allowed=sorted(os.sched_getaffinity(0));need(len(allowed)>=2,'resource_control_unproven');topology=[]
    for cpu in allowed:
        base=pathlib.Path('/sys/devices/system/cpu')/f'cpu{cpu}'/'topology'
        topology.append({'cpu':cpu,'core':int(bounded(base/'core_id')),'socket':int(bounded(base/'physical_package_id')),'siblings':bounded(base/'thread_siblings_list').decode().strip()})
    for a in topology:
        for b in topology:
            if (a['core'],a['socket'])!=(b['core'],b['socket']):return [a['cpu'],b['cpu']],topology
    return allowed[:2],topology

def inspect_child(value,pins,cpus,probe_path):
    need(value['Image']==pins['imageId'],'image_binding')
    h=value['HostConfig'];config=value['Config']
    need(h['NetworkMode']=='none' and h['ReadonlyRootfs'] is True and h['Privileged'] is False and h['Memory']==4294967296 and h['MemorySwap']==4294967296 and h['CpuPeriod']==100000 and h['CpuQuota']==200000 and cpulist(h['CpusetCpus'])==cpus and h['PidsLimit']==128,'resource_control_unproven')
    need(set(h['CapDrop'])=={'ALL'} and 'no-new-privileges' in h['SecurityOpt'],'isolation_unproven')
    need(not h.get('Devices') and not h.get('DeviceRequests') and not h.get('ExtraHosts') and not h.get('Binds') and not h.get('Tmpfs') and not h.get('PidMode') and not h.get('IpcMode')=='host','isolation_unproven')
    need(config['User']=='65534:65534' and config['Entrypoint']==['python3'],'isolation_unproven')
    mounts=value['Mounts'];need(len(mounts)==1 and mounts[0]['Source']==str(probe_path) and mounts[0]['Destination']=='/codec-probe.py' and mounts[0]['RW'] is False,'mount_leak')
    return True

def run_cell(cell,index,nonce,pins,root,env,clocks,monitor,evidence,cpus,parent,attach_groups=None,container_state=None):
    attach_groups={} if attach_groups is None else attach_groups
    start=time.monotonic();encode_end,end=clocks.cell(start);name=f'codec-{nonce}-{index:02d}';created=False;create_admitted=False;proc=None;sel=None;keeper=None
    raw={'nonce':nonce,'imageId':pins['imageId'],'cellId':cell['id'],'start':start,'encodeDeadline':encode_end,'deadline':end,'events':[],'snapshots':[],'samples':[],'counterUnits':{'cpuacct.usage':'nanoseconds','cpuacct.stat':'USER_HZ='+str(os.sysconf('SC_CLK_TCK')),'cpu.stat:throttled_time':'nanoseconds','memory':'bytes','wait4.ru_maxrss':'Linux_KiB'},'controls':None,'stdoutEOF':False,'stderrEOF':False,'final':None,'exit':None,'cleanup':{'state':'incomplete'}}
    result={**cell,'nonce':nonce,'imageId':pins['imageId'],'state':'incomplete','reason':'missing_evidence','metrics':{k:missing('missing_evidence') for k in METRICS}}
    stdout=bytearray();stderr=bytearray();pending=b'';last_sample=0;released=False;reason=None;progress_end=False
    cmd=lambda args:command(args,env,min(end,time.monotonic()+3),monitor)
    inspect=lambda:json.loads(cmd(['docker','inspect',name])['stdout'])[0]
    send=lambda b:(proc.stdin.write(b),proc.stdin.flush())
    try:
        args=child_args(name,pins['imageId'],','.join(map(str,cpus)),pathlib.Path(__file__).resolve().with_name('probe.py'),cell)
        raw['createArgv']=args;raw['parent']=parent.evidence();raw['controlVisibilityPolicy']=pins.get('controlVisibilityPolicy')
        mode=visible_view(raw['parent'],pins.get('controlVisibilityPolicy'))
        if not mode['fullHostVisible']:result.update(measurementStatus='partial',executionComplete=False,controlVisibility='delegated_subtree',fullHostVisible=False,ancestryLimitation='hidden_higher_ancestors')
        create_admitted=True
        if container_state is not None:
            container_state['createAdmissions']+=1;container_state['tracked'][name]=None
        creation=cmd(args);created=True;raw['createdContainerId']=creation['stdout'].decode().strip();need(re.fullmatch(r'[0-9a-f]{64}',raw['createdContainerId']),'container_identity')
        if container_state is not None:container_state['tracked'][name]=raw['createdContainerId']
        proc=subprocess.Popen(['docker','start','--attach','--interactive',name],env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,start_new_session=True)
        attach_groups[proc.pid]=proc;raw['attachGroupPid']=proc.pid
        sel=selectors.DefaultSelector()
        for stream in ('stdout','stderr'):os.set_blocking(getattr(proc,stream).fileno(),False);sel.register(getattr(proc,stream),selectors.EVENT_READ,stream)
        while sel.get_map():
            tick(end);monitor.check();now=time.monotonic()
            if not released and now>=encode_end and reason!='timeout':
                reason='timeout';send(b'STOP\n')
            if keeper and not released and now-last_sample>=.1:
                need(proc.poll() is None,'keeper_dead');raw['snapshots'].append(keeper.snapshot());need(len(raw['snapshots'])<=401,'sample_cap');last_sample=now
            for key,_ in sel.select(.02):
                stream=key.data;b=os.read(key.fileobj.fileno(),8192)
                if not b:sel.unregister(key.fileobj);raw[stream+'EOF']=True;continue
                small('cellCaptureBytes',len(b));target=stdout if stream=='stdout' else stderr;target.extend(b)
                need(len(target)<=(65536 if stream=='stdout' else 131072),stream+'_cap')
                if stream=='stderr':continue
                pending+=b;need(len(pending)<=65536,'message_cap')
                while b'\n' in pending:
                    line,pending=pending.split(b'\n',1);event=json.loads(line);raw['events'].append({'t':time.monotonic(),'message':event});tag=event['event']
                    if tag=='READY':
                        need(keeper is None,'duplicate_ready');value=inspect();raw['readyInspect']=value;need(value['Id']==raw['createdContainerId'],'container_identity');inspect_child(value,pins,cpus,pathlib.Path(__file__).resolve().with_name('probe.py'))
                        f=event['facts'];need(f['uid']==65534 and not f['credentialEnvironment'] and f['interfaces']==['lo'] and len(f['routes'].splitlines())==1 and f['affinity']==cpus,'isolation_unproven')
                        capture_name=f'cell-{index:02d}-keeper-capture.json';raw.setdefault('processCaptures',[]).append(capture_name)
                        keeper=Cgroups(value['State']['Pid'],policy=pins.get('controlVisibilityPolicy'),sink=lambda x:evidence.save(capture_name,x))
                        keeper_evidence=keeper.evidence();raw['keeper']=keeper_evidence
                        if result.get('controlVisibility')=='delegated_subtree':need(namespace_ids(f.get('namespaces'))==namespace_ids(keeper_evidence.get('namespaces')),'ready_namespace_unproven')
                        controls=prove_visible_controls(raw['parent'],keeper_evidence,policy=pins.get('controlVisibilityPolicy'))
                        raw['controls']=controls;raw['snapshots'].append(keeper.snapshot());send(b'GO\n')
                    elif tag=='STARTED':
                        need(keeper is not None and 'ffmpeg' not in raw,'probe_sequence')
                        children=bounded(pathlib.Path('/proc')/str(keeper.pid)/'task'/str(keeper.pid)/'children').decode().split();need(len(children)==1,'ffmpeg_identity')
                        ff_capture_name=f'cell-{index:02d}-ffmpeg-capture.json';raw.setdefault('processCaptures',[]).append(ff_capture_name)
                        ff=Cgroups(int(children[0]),policy=pins.get('controlVisibilityPolicy'),sink=lambda x:evidence.save(ff_capture_name,x));need(ff.groups==keeper.groups and ff.ns==keeper.ns and ff.affinity==cpus and event['affinity']==cpus,'resource_control_unproven')
                        nspid=next(line for line in bounded(pathlib.Path('/proc')/str(ff.pid)/'status').decode().splitlines() if line.startswith('NSpid:')).split()
                        need(int(nspid[-1])==event['pid'],'ffmpeg_identity')
                        ff_evidence=ff.evidence();controls=prove_visible_controls(raw['parent'],keeper_evidence,ff_evidence,pins.get('controlVisibilityPolicy'));raw['controls']=controls
                        if 'identity' in ff_evidence:need(ff_evidence['identity']['cmdline'].split('\x00')[:-1]==event['argv'],'ffmpeg_identity')
                        raw['ffmpeg']={**ff_evidence,'hostPid':ff.pid,'namespacePid':event['pid'],'argv':event['argv']};send(b'RUN\n')
                    elif tag=='PROGRESS':
                        need(keeper is not None and 'ffmpeg' in raw,'probe_sequence');v=event['raw'];snap=keeper.snapshot();raw['snapshots'].append(snap);last_sample=snap['t'];need(len(raw['snapshots'])<=401,'sample_cap')
                        # FFmpeg out_time_us and historical out_time_ms are both microseconds; require explicit out_time_us.
                        sample={'t':snap['t'],'frame':int(v['frame']),'mediaUs':int(v['out_time_us']),'cpuNs':snap['values']['cpuacct.usage']}
                        need(sample['frame']>=0 and sample['mediaUs']>=0,'progress_values');raw['samples'].append(sample);progress_end=v['progress']=='end'
                    elif tag=='EXIT':
                        need(keeper is not None and not released,'probe_sequence');need(proc.poll() is None,'keeper_dead')
                        raw['exit']=event
                        if result.get('controlVisibility')=='delegated_subtree':need('ffmpeg' in raw and event.get('pid')==raw['ffmpeg']['namespacePid'],'exit_process_identity')
                        raw['final']=keeper.snapshot();send(b'RELEASE\n');released=True
                    else:raise Failure('probe_error')
        if reason:raise Failure(reason)
        code=proc.wait(timeout=max(.01,end-time.monotonic()));raw['attachExitCode']=code
        need(code==0 and raw['stdoutEOF'] and raw['stderrEOF'] and released and not pending,'capture_incomplete')
        raw['progressEnd']=progress_end
        need(raw['exit'] and raw['final'],'missing_final')
        if raw['exit']['exitCode']!=0:reason='exit_failure'
        elif not progress_end or not raw['exit']['progressEOF']:reason='progress_incomplete'
        elif not raw['samples'] or raw['samples'][-1]['mediaUs']<24900000:reason='finite_output_incomplete'
    except BaseException as e:reason=str(e) if isinstance(e,Failure) else 'cell_'+type(e).__name__
    finally:
        if sel:sel.close()
        attach_closed=True
        if proc:
            try:attach_closed=kill_group(proc,end)
            except BaseException:attach_closed=False
            if attach_closed:attach_groups.pop(proc.pid,None)
            for f in (proc.stdin,proc.stdout,proc.stderr):
                if f and not f.closed:f.close()
        try:
            if created:
                # Stop even after protocol failure; inspect before removal and preserve OOM fact.
                value=inspect()
                if value['State']['Running']:cmd(['docker','kill',name]);value=inspect()
                stopped=not value['State']['Running'] and value['State']['Pid']==0
                raw['terminalInspect']=value;need(value['Id']==raw['createdContainerId'],'container_identity')
                if value['State']['OOMKilled']:reason='oom'
                cmd(['docker','rm',name]);left=json.loads(cmd(['docker','ps','-aq','--filter','name=^/'+name+'$','--format','{{json .ID}}'])['stdout'] or b'null')
                need(stopped and left is None,'cell_cleanup_incomplete')
                if container_state is not None:container_state['tracked'].pop(name,None)
                raw['cleanup']={'state':'closed','stopped':True,'pidZero':True,'removed':True,'oomKilled':value['State']['OOMKilled']}
            elif create_admitted:raw['cleanup']={'state':'incomplete','obligations':['container_create_outcome_unproven']}
            else:raw['cleanup']={'state':'closed','notCreated':True}
        except BaseException:raw['cleanup']={'state':'incomplete'};reason=reason or 'cell_cleanup_incomplete'
        raw['cleanup']['attachGroupClosed']=attach_closed
        if not attach_closed:
            raw['cleanup']['state']='incomplete';raw['cleanup']['obligations']=['attach_group_unclosed'];reason=reason or 'attach_group_unclosed'
        raw['end']=time.monotonic()
        if raw['end']>end:reason=reason or 'timeout'
        raw['reason']=reason
        rawname=f'cell-{index:02d}-raw.json';raw['stderrBytes']=len(stderr);raw['stdoutBytes']=len(stdout)
        try:
            evidence.save(f'cell-{index:02d}-stderr.log',bytes(stderr));evidence.save(f'cell-{index:02d}-stdout.log',bytes(stdout));evidence.save(rawname,raw)
            result['sourceRefs']=[rawname]
            delegated=result.get('controlVisibility')=='delegated_subtree'
            complete=execution_complete(raw) and reason is None
            # Delegated availability requires completed execution and every join.
            need(not delegated or complete,'delegated_execution_incomplete')
            metrics=derive(raw['samples'],None if delegated else 2,[rawname],proof=raw['controls']);result['metrics'].update(metrics)
            if raw['final'] and raw['snapshots']:
                first=raw['snapshots'][0];final=raw['final'];v=final['values'];interval={'wallMono':[first['t'],final['t']],'coverage':'whole_run_including_keeper'}
                for key,counter,unit,factor in [('cgroupPeakBytes','memory.max_usage_in_bytes','bytes',1),('throttledSeconds','cpu.stat:throttled_time','seconds',1e-9),('throttledPeriods','cpu.stat:nr_throttled','periods',1)]:
                    value=v[counter] if key=='cgroupPeakBytes' else v[counter]-first['values'][counter];need(value>=0,'counter_reset');result['metrics'][key]=available(value*factor,unit,interval,[rawname])
                if v['memory.failcnt']>first['values']['memory.failcnt'] or v['memory.oom_control:under_oom']:reason='oom'
            if raw['exit'] and type(raw['exit'].get('ffmpegPeakKiB')) in (int,float):result['metrics']['ffmpegPeakBytes']=available(raw['exit']['ffmpegPeakKiB']*1024,'bytes',{'coverage':'true_ffmpeg_wait4_peak'},[rawname])
            all_metrics=all(x['state']=='available' for k,x in result['metrics'].items() if not (delegated and k=='cpuPercent'))
            need(not delegated or all_metrics,'required_metric_missing')
            result['state']=disposition(reason=reason,exit_code=raw['exit']['exitCode'] if raw['exit'] else None,complete=raw['stdoutEOF'] and raw['stderrEOF'] and progress_end and raw['cleanup']['state']=='closed',controls=raw['controls'] is not None,metrics=all_metrics)
            if delegated and complete and all_metrics:
                result.update(state='incomplete',reason='hidden_higher_ancestors',measurementStatus='partial',executionComplete=True,controlVisibility='delegated_subtree',fullHostVisible=False);reason='hidden_higher_ancestors'
        except BaseException as error:
            reason=reason or (str(error) if isinstance(error,Failure) else 'evidence_or_metric_incomplete');result['state']=disposition(reason=reason)
            result['metrics']={k:missing(reason) for k in METRICS}
        if not result.get('executionComplete') and reason!=raw.get('reason'):
            raw['reason']=reason
            try:evidence.save(rawname,raw)
            except Failure:pass
        result['reason']=reason or (None if result['state']=='observed' else 'missing_evidence');result['cleanup']=raw['cleanup']
    return result

def cell_blocker(item):
    if item.get('controlVisibility')=='delegated_subtree' and not item.get('executionComplete'):return item['reason'] or 'delegated_execution_incomplete'
    if item['cleanup']['state']!='closed' or item['reason'] in ('resource_control_unproven','isolation_unproven','image_binding','keeper_dead','process_moved','process_replaced','mount_leak'):return item['reason'] or 'cleanup_incomplete'
    return None

def owned_command(root,cmdline):
    """Require a complete path argument within the exclusive runtime root."""
    if not isinstance(cmdline,bytes) or not cmdline.endswith(b'\0'):return False
    marker=os.fsencode(str(root))
    options={b'--host',b'--data-root',b'--exec-root',b'--pidfile',b'--config-file',b'--config',b'--address',b'--state',b'--root',b'--debug-address'}
    for arg in cmdline[:-1].split(b'\0'):
        if arg.startswith(b'--') and b'=' in arg:
            option,arg=arg.split(b'=',1)
            if option not in options:continue
        if arg.startswith(b'unix://'):arg=arg[7:]
        elif arg.startswith(b'unix:'):arg=arg[5:]
        if not re.fullmatch(rb'/[A-Za-z0-9._/-]+',arg):continue
        if any(part in (b'',b'.',b'..') for part in arg.split(b'/')[1:]):continue
        if arg==marker or arg.startswith(marker+b'/'):return True
    return False

def owned_processes(root,deadline,proc=pathlib.Path('/proc'),attach_groups=()):
    """Bounded absence observation for daemon/shim commands carrying the owned root."""
    found=[];count=0
    for pgid in attach_groups:
        tick(deadline)
        try:os.killpg(pgid,0);found.append(pgid)
        except ProcessLookupError:pass
        except PermissionError:raise Failure('attach_group_absence_unproven') from None
    for entry in proc.iterdir():
        if not entry.name.isdigit() or int(entry.name)==os.getpid():continue
        tick(deadline);count+=1;need(count<=65536,'process_census_cap')
        try:data=bounded(entry/'cmdline',65536)
        except FileNotFoundError:continue
        except PermissionError:raise Failure('process_absence_unproven') from None
        if owned_command(root,data):found.append(int(entry.name))
    return found

def runtime_sockets(root):
    paths=tuple(root/name for name in ('daemon.sock','exec/docker.sock','exec/containerd/containerd.sock','exec/containerd/containerd-debug.sock','exec/containerd/daemon/s/'+64*'a'))
    need(all(str(path).isascii() and len(str(path).encode('ascii'))<=103 for path in paths),'runtime_socket_path')
    return paths

def runtime_owner(root,nonce):
    info=root.lstat();marker=root/'.owner';mi=marker.lstat()
    need(stat.S_ISDIR(info.st_mode) and info.st_uid==os.geteuid() and stat.S_ISREG(mi.st_mode) and mi.st_uid==os.geteuid() and bounded(marker,128)==(nonce+'\n').encode('ascii'),'runtime_ownership')

def create_runtime(parent,nonce):
    root=parent/'d';runtime_sockets(root);runtime_owner(parent,nonce)
    root.mkdir(mode=0o700,exist_ok=False)
    with (root/'.owner').open('xb') as marker:marker.write((nonce+'\n').encode('ascii'))
    (root/'data').mkdir(mode=0o700,exist_ok=False)
    return root

def close_runtime(root,nonce,daemon,env,deadline,attach_groups,containers):
    obligations=[];owned=False;processes_absent=False;container_absence='unproven'
    try:runtime_owner(root.parent,nonce);runtime_owner(root,nonce);owned=True
    except BaseException:obligations.append('runtime_ownership_unproven')
    try:
        need(owned and containers['freshDataRoot'] is True,'fresh_data_root_unproven')
        if containers['createAdmissions']==0:
            need(not containers['tracked'],'create_admission_inconsistent');container_absence='no_create_admitted'
        else:
            need(env is not None,'owned_container_absence_unproven')
            for name,expected in list(containers['tracked'].items()):
                need(re.fullmatch(r'codec-'+re.escape(nonce)+r'-[0-9]{2}',name),'owned_container_name')
                args=['docker','ps','-aq','--no-trunc','--filter','name=^/'+name+'$']
                ids=command(args,env,deadline)['stdout'].decode().split();need(len(ids)<=1,'owned_container_identity')
                for cid in ids:
                    need(re.fullmatch(r'[0-9a-f]{64}',cid) and (expected is None or cid==expected),'owned_container_identity')
                    command(['docker','rm','-f',cid],env,deadline)
                need(not command(args,env,deadline)['stdout'].strip(),'owned_containers_remain');containers['tracked'].pop(name)
            container_absence='tracked_reconciled'
    except BaseException:obligations.append('owned_container_absence_unproven')
    for pgid,attach in list(attach_groups.items()):
        try:closed=kill_group(attach,deadline)
        except BaseException:closed=False
        if closed:attach_groups.pop(pgid)
        else:obligations.append('attach_group_unclosed:'+str(pgid))
    try:clean=kill_group(daemon,deadline)
    except BaseException:clean=False
    if not clean:obligations.append('daemon_process_group_unclosed')
    try:
        # A separately grouped containerd may outlive dockerd. Signal only a group
        # whose leader still carries this exclusive runtime root, then prove absence.
        need(owned,'runtime_ownership_unproven')
        residual=owned_processes(root,deadline,attach_groups=attach_groups);groups=set()
        for pid in residual:
            tick(deadline);pgid=os.getpgid(pid)
            need(pgid!=os.getpgrp() and owned_command(root,bounded(pathlib.Path('/proc')/str(pgid)/'cmdline',65536)),'owned_group_identity')
            groups.add(pgid)
        for pgid in groups:
            try:os.killpg(pgid,signal.SIGTERM)
            except ProcessLookupError:pass
        term_end=min(deadline,time.monotonic()+.5)
        while groups and time.monotonic()<term_end:
            for pgid in tuple(groups):
                try:os.killpg(pgid,0)
                except ProcessLookupError:groups.remove(pgid)
            if groups:time.sleep(.02)
        for pgid in groups:
            try:os.killpg(pgid,signal.SIGKILL)
            except ProcessLookupError:pass
        for pgid in groups:
            try:os.killpg(pgid,0);obligations.append('owned_process_group_unclosed:'+str(pgid))
            except ProcessLookupError:pass
        residual=owned_processes(root,deadline,attach_groups=attach_groups)
        processes_absent=not residual and not any('group_unclosed' in x for x in obligations)
        if residual:obligations.append('owned_processes_remain:'+','.join(map(str,residual)))
    except BaseException:obligations.append('owned_process_absence_unproven')
    paths=runtime_sockets(root)[:-1]
    try:
        shim=root/'exec/containerd/daemon/s'
        if shim.exists():
            entries=list(shim.iterdir());need(len(entries)<=128,'shim_socket_census_cap')
            need(all(re.fullmatch(r'[0-9a-f]{64}',path.name) for path in entries),'shim_socket_identity');paths+=tuple(entries)
    except BaseException:obligations.append('socket_census_unproven')
    # No state mutation while any ownership, container, or process obligation remains.
    if not obligations and owned and clean and processes_absent:
        for path in paths:
            if not os.path.lexists(path):continue
            try:
                tick(deadline);info=path.lstat();need(stat.S_ISSOCK(info.st_mode) and info.st_uid==os.geteuid(),'socket_ownership_unproven')
                with socket.socket(socket.AF_UNIX,socket.SOCK_STREAM) as probe:
                    probe.settimeout(min(.1,max(.001,deadline-time.monotonic())))
                    need(probe.connect_ex(str(path))==errno.ECONNREFUSED,'socket_live_or_uncertain')
                again=path.lstat();need((info.st_dev,info.st_ino)==(again.st_dev,again.st_ino),'socket_replaced');path.unlink()
            except BaseException:obligations.append('socket_cleanup_unproven:'+str(path.relative_to(root)))
    absent=all(not os.path.lexists(path) for path in paths)
    if not absent:obligations.append('socket_still_present')
    return {'state':'closed' if not obligations else 'incomplete','obligations':obligations,'daemonReaped':clean,'unclosedAttachGroups':sorted(attach_groups),'ownedProcessesAbsent':processes_absent,'socketAbsent':absent,'ownedRoot':str(root),'freshDataRoot':containers['freshDataRoot'],'createAdmissions':containers['createAdmissions'],'trackedContainers':sorted(containers['tracked']),'containerAbsence':container_absence}

def run(nonce,output,provider_start):
    need(re.fullmatch(r'[a-z0-9-]{6,40}',nonce),'nonce')
    source=pathlib.Path(__file__).resolve().parent;pins=json.loads(bounded(source/'pins.json',65536));output=pathlib.Path(output).resolve()
    need(output.name=='evidence','evidence_directory');root=create_runtime(output.parent,nonce)
    output.mkdir(parents=False,exist_ok=False)
    clocks=Clocks(provider_start);ledger=Ledger(output.parent/('ledger-'+nonce+'.json'),'codec-diagnostic-'+nonce);evidence=Evidence(output)
    result=empty_result(nonce,pins,'setup_not_complete');result['clocks']={**clocks.raw,'providerStartMilliseconds':int(provider_start*1000)};result['phase']='setup';daemon=None;daemon_log=None;monitor=Monitor(output.parent);env=None;preflight=None;cancelled=False
    previous={};attach_groups={};containers={'freshDataRoot':True,'createAdmissions':0,'tracked':{}}
    def cancel(sig,frame):
        nonlocal cancelled
        if cancelled:return
        cancelled=True;raise Failure('cancelled')
    for sig in (signal.SIGTERM,signal.SIGINT):previous[sig]=signal.signal(sig,cancel)
    try:
        for stage,n in WORK.items():ledger.charge(stage,n)
        global _METER
        _METER=ledger
        result['sourceIdentities']={}
        for name in ('diagnostic.py','probe.py','pins.json','manifest.json','support/encode.py','support/preflight.py'):
            body=bounded(source/name,2097152);result['sourceIdentities'][name]={'bytes':len(body),'sha256':sha(body)}
        tick(clocks.setup)
        encode=verified_module(source/'support/encode.py','codec_lossless',pins['helpers']['support/encode.py'])
        preflight=verified_module(source/'support/preflight.py','codec_preflight',pins['helpers']['support/preflight.py'])
        result['setupStage']='parent_controls';result['host']={'sourceRefs':['parent-capture.json'],'failedSubcheck':'parent_capture_incomplete'}
        parent=Cgroups(os.getpid(),policy=pins.get('controlVisibilityPolicy'),sink=lambda x:evidence.save('parent-capture.json',x))
        parent_evidence=parent.evidence();pc,anc,_,_=reconstruct_controls(parent_evidence,pins.get('controlVisibilityPolicy'));cpu,topology=choose_cpus()
        need(set(cpu)<=set(parent.affinity) and all((x['quota']==-1 or x['quota']/x['period']>=2) and x['memory']>=4294967296 and set(cpu)<=set(x['cpus']) for x in [pc]+anc),'resource_control_unproven')
        host={'parent':parent_evidence,'topology':topology,'selectedCPUs':cpu,'cpuinfo':bounded('/proc/cpuinfo',1048576).decode(),'python':sys.version,'sharedParentContention':'uncontrolled'}
        evidence.save('host.json',host);result['host']={'sourceRefs':['host.json','parent-capture.json'],'selectedCPUs':cpu,'parentControlsObserved':True,'sharedParentContention':'uncontrolled'}
        result['setupStage']='storage_setup';result['storage']={};create_storage(nonce,result['sourceIdentities']['diagnostic.py'],result['storage']);evidence.save('storage.json',result['storage']);monitor.add_storage(pathlib.Path(result['storage']['root']));monitor.start()
        result['setupStage']='retained_sign';signenv=signing_environment(os.environ)
        cli=command(['aws','--version'],signenv,min(clocks.setup,time.monotonic()+5),monitor);host['awsCLI']=cli['stdout'].decode().strip();evidence.save('host.json',host)
        signed=command(['aws','s3','presign','s3://'+pins['bucket']+'/'+pins['retainedKey'],'--region',pins['region'],'--expires-in','300'],signenv,signing_deadline(clocks.setup),monitor)['stdout'].decode().strip()
        result['setupStage']='retained_download';result['retainedDownload']=download(signed,root/'input.zip',pins['zip']['bytes'],pins['zip']['sha256'],clocks.setup,allowed=(pins['bucket']+'.s3.'+pins['region']+'.amazonaws.com','/'+pins['retainedKey']),monitor=monitor);signed=None
        # Independent full reread/hash is separate from the network hash.
        h=hashlib.sha256();n=0
        with (root/'input.zip').open('rb') as f:
            while True:
                tick(clocks.setup);monitor.check();b=f.read(65536)
                if not b:break
                n+=len(b);h.update(b)
        need(n==pins['zip']['bytes'] and h.hexdigest()==pins['zip']['sha256'],'independent_zip_identity')
        result['setupStage']='selected_extract';facts=extract_selected(root/'input.zip',root/'encoded',pins['selected'],pins['zip']['bytes']+1048576,clocks.setup);ledger.observe('selectedZIPCompressedReads',facts['compressedReadBytes']);result['extraction']=facts
        result['setupStage']='docker_bootstrap';docker=pins['docker'];download(docker['url'],root/'docker.tgz',docker['bytes'],docker['sha256'],clocks.setup,allowed=('download.docker.com','/linux/static/stable/x86_64/docker-24.0.9.tgz'),monitor=monitor)
        h=hashlib.sha256();n=0
        with (root/'docker.tgz').open('rb') as f:
            while True:
                tick(clocks.setup);b=f.read(65536)
                if not b:break
                n+=len(b);h.update(b)
        need(n==docker['bytes'] and h.hexdigest()==docker['sha256'],'tool_reread_identity')
        facade=TarFacade(2*docker['bytes'],clocks.setup);preflight.tarfile=facade;preflight.extract(root/'docker.tgz',root/'bin',clocks.setup);ledger.observe('bootstrapCompressedReads',facade.total)
        executable_hashes={}
        for f in (root/'bin').iterdir():
            hh=hashlib.sha256();nn=0
            with f.open('rb') as inp:
                while True:
                    tick(clocks.setup);b=inp.read(65536)
                    if not b:break
                    nn+=len(b);hh.update(b)
            executable_hashes[f.name]={'bytes':nn,'sha256':hh.hexdigest()}
        result['tools']=executable_hashes
        for name in ('config','runtime'):(root/name).mkdir(mode=0o700)
        (root/'daemon.json').write_bytes(b'{}\n');env=preflight.environment(root)
        # Signing credentials are never inherited by the owned daemon or child CLI.
        env={k:v for k,v in env.items() if k in ('PATH','DOCKER_HOST','DOCKER_CONFIG','XDG_RUNTIME_DIR')};env.update(HOME=str(root/'config'),LANG='C',LC_ALL='C')
        result['setupStage']='daemon_start';argv=owned_daemon_args(root,pathlib.Path(result['storage']['dataRoot']));result['daemon']={'socket':str(root/'daemon.sock'),'args':argv,'config':{}}
        daemon=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        daemon_log=preflight.DaemonLog(daemon.stdout,4194304);daemon_log.start();ready=min(clocks.setup,time.monotonic()+25)
        while not (root/'daemon.sock').exists():tick(ready);monitor.check();need(daemon.poll() is None,'daemon_early_exit');time.sleep(.05)
        result['setupStage']='storage_actual';result['daemon']['pid']=daemon.pid
        result['daemon']['version']=command(['docker','version','--format','{{json .}}'],env,clocks.setup,monitor)['stdout'].decode()
        result['daemon']['info']=json.loads(command(['docker','info','--format','{{json .}}'],env,clocks.setup,monitor)['stdout'])
        result['storage']['preloadMountinfo']=bounded('/proc/self/mountinfo',262144).decode('ascii');storage_backing(pathlib.Path(result['storage']['dataRoot']),result['storage']['preloadMountinfo'])
        result['storage']['actual']=verify_storage(result['daemon']['info'],json.loads(result['daemon']['version']),pathlib.Path(result['storage']['dataRoot']));evidence.save('storage.json',result['storage'])
        result['setupStage']='single_replay_load';result['load']=stream_load(encode.replay(root/'encoded',check=lambda:(tick(clocks.setup),monitor.check())),['docker','image','load'],env,pins['save']['bytes'],pins['save']['sha256'],clocks.setup,monitor)
        # Captured command bytes live in evidence, never directly JSON encoded.
        evidence.save('load-stdout.log',result['load'].pop('stdout'));evidence.save('load-stderr.log',result['load'].pop('stderr'))
        result['setupStage']='loaded_image_inspect';inspected=json.loads(command(['docker','image','inspect',pins['imageId']],env,clocks.setup,monitor)['stdout']);need(len(inspected)==1 and inspected[0]['Id']==pins['imageId'] and set(inspected[0]['RootFS']['Layers'])==set(pins['diffIds']) and len(inspected[0]['RootFS']['Layers'])==8,'loaded_image_identity')
        result['loadedImage']=inspected[0];result['phase']='loaded';tick(clocks.setup);result['phase']='cells';blocker=None
        for i,cell in enumerate(MATRIX):
            monitor.check();daemon_log.check();need(daemon.poll() is None,'daemon_died')
            if blocker or not clocks.admit(time.monotonic()):
                result['cells'][i]['reason']=blocker or 'phase_deadline';result['cells'][i]['metrics']={k:missing('not_run:'+result['cells'][i]['reason']) for k in METRICS};continue
            result['cells'][i]=run_cell(cell,i,nonce,pins,root,env,clocks,monitor,evidence,cpu,parent,attach_groups,containers)
            item=result['cells'][i]
            blocker=cell_blocker(item)
    except BaseException as e:
        if len(ledger.items)!=len(WORK):ledger.uncertain()
        result['failedPhase']=result['phase'];result['failedStage']=result.get('setupStage');result['failure']=str(e) if isinstance(e,Failure) else 'setup_'+type(e).__name__
        if result.get('failedStage')=='parent_controls':result['host']['failedSubcheck']=result['failure']
        for cell in result['cells']:
            if cell['state']=='not_run':cell['reason']=result['failure'];cell['metrics']={k:missing('not_run:'+result['failure']) for k in METRICS}
    finally:
        # Shield closure from repeated cancellation, within the fixed 60-second closure budget.
        for sig in previous:signal.signal(sig,signal.SIG_IGN)
        result['phase']='closure';closure_end=min(clocks.end-120,time.monotonic()+60);obligations=[]
        cleanup=close_runtime(root,nonce,daemon,env,closure_end,attach_groups,containers);obligations=cleanup['obligations']
        if daemon_log:
            daemon_log.finish()
            try:evidence.save('daemon.log',bytes(daemon_log.data))
            except Failure:result.setdefault('failure','evidence_overflow')
            result['daemonCapture']={'complete':daemon_log.complete,'reason':daemon_log.error}
            if daemon_log.error:result.setdefault('failure',daemon_log.error)
        result['resources']=monitor.finish();result['cleanup']=cleanup
        # Deleting state is allowed only after ownership closure is proved.
        if result.get('storage',{}).get('created'):
            if not obligations:
                try:tick(closure_end);close_storage(result['storage'])
                except BaseException as error:obligations.append(str(error) if isinstance(error,Failure) else 'storage_closure_unproven')
            else:obligations.append('storage_closure_pending')
            try:evidence.save('storage.json',result['storage'])
            except Failure:result.setdefault('failure','evidence_overflow')
        if not obligations:
            try:runtime_owner(root,nonce);runtime_owner(root.parent,nonce);shutil.rmtree(root);cleanup['runtimeAbsent']=not os.path.lexists(root);need(cleanup['runtimeAbsent'],'runtime_removal_unproven')
            except BaseException:obligations.append('runtime_removal_unproven')
        cleanup['state']='incomplete' if obligations else 'closed'
        result['cancelled']=cancelled;result['ledger']=ledger.record();result['phase']='terminal';ledger.persist()
        try:
            evidence.save('ledger.json',ledger.record());evidence.save('metrics.csv',metrics_csv(result['cells']))
        except Failure:result.setdefault('failure','evidence_overflow')
        result['inventory']=evidence.inventory.copy();terminal=wire(result)
        if len(terminal)>1048576:
            # Preserve explicit failure and external raw inventory within the terminal reserve.
            result.setdefault('failure','terminal_record_cap');result.pop('loadedImage',None);result.pop('daemon',None);terminal=wire(result)
        need(len(terminal)<=1048576,'terminal_record_cap');evidence.save('result.json',terminal,terminal=True)
        for sig,handler in previous.items():signal.signal(sig,handler)
        _METER=None
    return result

if __name__=='__main__':
    ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--nonce',required=True);ap.add_argument('--output',type=pathlib.Path,required=True);ap.add_argument('--provider-start-ms',type=int,default=None);args=ap.parse_args()
    start=args.provider_start_ms
    if start is None:
        raw=os.environ.get('CODEBUILD_START_TIME','');need(re.fullmatch(r'\d{13}',raw),'provider_timebase_missing');start=int(raw)
    result=run(args.nonce,args.output,start/1000);print(json.dumps({'schema':result['schema'],'states':[x['state'] for x in result['cells']],'cleanup':result['cleanup']['state']}))
