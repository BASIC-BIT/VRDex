"""Run final Task 10 expectations against immutable Task 9 runtime/checker."""
import importlib.util
import pathlib
import sys
import unittest

root = pathlib.Path(__file__).resolve().parents[1]
base = pathlib.Path('/workspace/scratch/codec-task9-source-freeze')
sys.path[:0] = [str(root / 'tests'), str(root)]
for name in ('diagnostic', 'check_result'):
    spec = importlib.util.spec_from_file_location(name, base / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
result = unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromName('test_evidence_capacity'))
sys.exit(not result.wasSuccessful())
