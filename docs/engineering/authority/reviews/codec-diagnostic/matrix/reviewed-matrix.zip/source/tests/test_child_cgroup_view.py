"""Bounded reproduction of live task6 keeper bind roots, with generated controls only.

The live keeper and collector share the cgroup namespace and controller devices;
the keeper mount root is exactly collector-root/docker/<64 lowercase hex>.
No fixture here is a measurement or a capacity qualification.
"""
import copy, os, pathlib, tempfile, unittest
from unittest.mock import patch
import diagnostic as d, check_result as checker
from test_delegated import ROOT, POLICY, CTLS, hierarchy, fixture, seal_capture
import test_delegated as delegated_tests

CID='ff12bb92047e6da44f5ae842b6e0a18576a0f0341395fbfdf1bea60fe01a9c65'
LEAF=ROOT+'/docker/'+CID

def child_fixture(pid=42):
    raw=fixture(LEAF,pid,True)
    raw['mountinfo']=hierarchy(LEAF,LEAF)['mountinfo'].replace('/sys/fs/cgroup','/target-only/cgroup')
    parent=fixture()
    for name,value in parent['controlFiles'].items():
        p=pathlib.PurePosixPath(name)
        raw['controlFiles'][str(p.parent/'docker'/p.name)]=value
    return seal_capture(raw)

class ChildView(unittest.TestCase):
    def test_nested_target_maps_through_strict_parent_without_target_reads(self):
        raw=child_fixture();view=d.visible_view(raw,POLICY)
        self.assertEqual(view['roots'],dict.fromkeys(CTLS,ROOT))
        self.assertEqual(view['mounts'],d.resolve_visible_v1(fixture(),POLICY)['mounts'])
        leaf,anc,groups,_=d.reconstruct_controls(raw,POLICY)
        self.assertEqual(leaf['path'],LEAF);self.assertEqual([a['path'] for a in anc],[ROOT+'/docker',ROOT])
        self.assertEqual(groups['cpu'],LEAF)
        proof=d.prove_visible_controls(fixture(),raw,policy=POLICY)
        self.assertIsNone(proof['effectiveCpus']);self.assertFalse(proof['fullHostVisible'])
        self.assertEqual(proof['leaf']['quota'],200000);self.assertEqual(proof['leaf']['memory'],4294967296)

    def test_checker_independently_reconstructs_nested_controls_and_counters(self):
        parent=fixture();child=child_fixture();proof=d.prove_visible_controls(parent,child,policy=POLICY)
        cleanup={'state':'closed','attachGroupClosed':True}
        raw={'parent':parent,'keeper':child,'controls':proof,'events':[{'message':{'event':'READY','facts':{'affinity':[0,1],'uid':65534,'credentialEnvironment':False,'interfaces':['lo'],'routes':'header\n','namespaces':child['namespaces']}}}], 'cleanup':cleanup}
        with patch.object(d,'resolve_visible_v1',side_effect=AssertionError('runtime parser reused')),patch.object(d,'visible_view',side_effect=AssertionError('runtime mapping reused')),patch.object(d,'prove_visible_controls',side_effect=AssertionError('runtime proof reused')):
            paths,delegated=checker.process_controls(raw,{'cleanup':cleanup},'incomplete',POLICY)
        self.assertTrue(delegated);self.assertTrue(all('/docker/'+CID+'/' in p for p in paths));self.assertFalse(any('/target-only/' in p for p in paths))

    def test_nested_root_remains_inadmissible_as_collector(self):
        raw=child_fixture()
        with self.assertRaises(d.Failure):d.resolve_visible_v1(raw,POLICY)
        with self.assertRaises(checker.Invalid):checker.hierarchy(raw,POLICY)
        raw['collector']=copy.deepcopy(raw['collector']);raw['collector'].update(hierarchy(LEAF,LEAF))
        for parse,error in [(d.visible_view,d.Failure),(checker.collector_view,checker.Invalid)]:
            with self.assertRaises(error):parse(raw,POLICY)

    def test_mapping_rejects_unproven_nested_shapes_and_foreign_parent(self):
        mutations={
            'arbitrary_descendant':lambda r:r.update(hierarchy(ROOT+'/other/'+CID,ROOT+'/other/'+CID)),
            'malformed_id':lambda r:r.update(hierarchy(LEAF[:-1]+'X',LEAF[:-1]+'X')),
            'membership_below_bind_root':lambda r:r.__setitem__('membership',r['membership'].replace(LEAF,LEAF+'/extra')),
            'foreign_parent':lambda r:r['collector'].update(hierarchy('/ecs/foreign/container','/ecs/foreign/container')),
            'collector_member_below_root':lambda r:r['collector'].__setitem__('membership',hierarchy(ROOT+'/other')['membership']),
            'device':lambda r:r.__setitem__('mountinfo',r['mountinfo'].replace('0:1','0:99')),
            'cgroup_namespace':lambda r:r['namespaces'].__setitem__('cgroup','cgroup:[999]'),
            'unaligned_root':lambda r:r.__setitem__('mountinfo',r['mountinfo'].replace(LEAF,ROOT,1)),
            'hybrid':lambda r:r.__setitem__('membership',r['membership']+'0::/\n'),
            'missing_collector':lambda r:r.pop('collector'),
            'canonical_escape':lambda r:r.update(hierarchy(LEAF+'/../escape',LEAF+'/../escape')),
        }
        for name,mutate in mutations.items():
            for parse,error in [(d.visible_view,d.Failure),(checker.collector_view,checker.Invalid)]:
                with self.subTest(name=name,parser=parse.__name__):
                    raw=child_fixture();mutate(raw)
                    with self.assertRaises(error):parse(raw,POLICY)
        for policy in (None,'full-root-only'):
            for parse,error in [(d.visible_view,d.Failure),(checker.collector_view,checker.Invalid)]:
                with self.subTest(policy=policy,parser=parse.__name__),self.assertRaises(error):parse(child_fixture(),policy)

    def test_missing_ancestor_and_read_fact_still_block_proof(self):
        for mutation in ('ancestor','read'):
            raw=child_fixture()
            if mutation=='ancestor':raw['controlFiles'].pop('/sys/fs/cgroup/cpu,cpuacct/docker/cpu.cfs_quota_us')
            else:raw['controlReads'].pop(next(iter(raw['controlReads'])))
            for parse,error in [(d.reconstruct_controls,d.Failure),(checker.control_records,(checker.Invalid,KeyError))]:
                with self.subTest(mutation=mutation,parser=parse.__name__),self.assertRaises(error):parse(raw,POLICY)

class ChildCapture(unittest.TestCase):
    setUp=delegated_tests.CaptureIntegration.setUp
    proc=delegated_tests.CaptureIntegration.proc
    def setup_capture(self,root=LEAF):
        mount=self.root/'controls';mount.mkdir()
        for name,value in child_fixture()['controlFiles'].items():
            p=mount/pathlib.PurePosixPath(name).relative_to('/sys/fs/cgroup');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(value)
        parent_mi=hierarchy()['mountinfo'].replace('/sys/fs/cgroup',str(mount))
        target_mi=hierarchy(root,root)['mountinfo'].replace('/sys/fs/cgroup','/target-only/cgroup')
        self.proc(os.getpid(),ROOT,mountinfo=parent_mi);self.proc(42,root,True,target_mi)
        return mount

    def test_constructor_reads_controls_and_counters_only_through_parent(self):
        mount=self.setup_capture()
        for c,n in d.COUNTER_FILES:
            base='cpu,cpuacct' if c in ('cpu','cpuacct') else c
            text={'cpuacct.stat':'user 1\nsystem 1','cpu.stat':'nr_periods 1\nnr_throttled 0\nthrottled_time 0','memory.oom_control':'oom_kill_disable 0\nunder_oom 0'}.get(n,'1')
            (mount/base/'docker'/CID/n).write_text(text)
        with patch.object(d.os,'sched_getaffinity',side_effect=lambda pid:{0,1} if pid==42 else {0,1,2,3}):
            cg=d.Cgroups(42,self.root/'proc',policy=POLICY);raw=cg.evidence();snap=cg.snapshot()
        self.assertEqual(cg.root,ROOT);self.assertEqual(cg.path('cpu'),mount/'cpu,cpuacct'/'docker'/CID)
        self.assertEqual(len(raw['controlFiles']),15);self.assertTrue(all(p.startswith(str(mount)) for p in raw['controlFiles']))
        self.assertTrue(all(p.startswith(str(mount)) for p in snap['raw']));self.assertEqual(raw['collector']['pid'],os.getpid())

    def test_target_admission_failure_preserves_both_captures(self):
        self.setup_capture(ROOT+'/other/'+CID);saved=[]
        with patch.object(d.os,'sched_getaffinity',return_value={0,1}),self.assertRaises(d.Failure):
            d.Cgroups(42,self.root/'proc',policy=POLICY,sink=lambda r:saved.append(copy.deepcopy(r)))
        self.assertIn('failedSubcheck',saved[-1]);self.assertEqual(saved[-1]['controlFiles'],{})
        self.assertIn('collector',saved[-1]);self.assertIn('membership',saved[-1]['collector']);self.assertIn('mountinfo',saved[-1]['collector'])
