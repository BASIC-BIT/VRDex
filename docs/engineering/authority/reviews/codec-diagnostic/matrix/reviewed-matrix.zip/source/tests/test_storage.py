"""Generated XFS/storage and two-root budget fixtures. No mounts or Docker."""
import contextlib, copy, importlib.util, itertools, json, os, pathlib, stat, sys, tempfile, types, unittest
from unittest.mock import patch
sys.path.insert(0,str(pathlib.Path(__file__).resolve().parents[1]))
import diagnostic as d, check_result as c
NONCE='task6fixture'
SOURCE={'bytes':1,'sha256':'a'*64}
class Storage(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.parent=pathlib.Path(self.tmp.name)/'output';self.parent.mkdir()
        self.control=pathlib.Path(self.tmp.name)/'control';self.control.mkdir();pp=patch.object(d,'STORAGE_PARENT',self.parent,create=True);pp.start();self.addCleanup(pp.stop)
    def api(self,name):
        self.assertTrue(callable(getattr(d,name,None)),name+' missing');return getattr(d,name)
    def mounts(self,kind='xfs',mode='rw',extra=''):
        dev=self.parent.stat().st_dev
        return f'1 0 0:1 / / rw - overlay overlay rw\n2 1 {os.major(dev)}:{os.minor(dev)} / {self.parent} {mode} - {kind} /dev/fixture {mode}\n'+extra
    def create(self):
        with patch.object(d,'STORAGE_PARENT',self.parent,create=True),patch.object(d,'bounded',side_effect=lambda p,cap=65536:self.mounts().encode() if str(p)=='/proc/self/mountinfo' else pathlib.Path(p).read_bytes()):
            return self.api('create_storage')(NONCE,SOURCE)
    def test_supported_mapping_records_effective_xfs_device(self):
        with patch.object(d,'STORAGE_PARENT',self.parent,create=True):facts=self.api('storage_backing')(self.parent,self.mounts())
        self.assertEqual(facts['filesystem'],'xfs');self.assertEqual(facts['mountpoint'],str(self.parent));self.assertTrue(facts['readWrite'])
    def test_unsupported_missing_readonly_and_intervening_rejected(self):
        fn=self.api('storage_backing');root=self.parent/('codec-'+NONCE);root.mkdir()
        cases=[self.mounts('overlay'),self.mounts().splitlines()[0],self.mounts(mode='ro'),self.mounts(extra=f'3 2 0:4 / {root} rw - xfs /dev/other rw\n')]
        for text in cases:
            with self.subTest(text=text),patch.object(d,'STORAGE_PARENT',self.parent,create=True),self.assertRaises(d.Failure):fn(root,text)
    def test_symlink_rejected(self):
        self.api('storage_backing');link=self.parent/'link';link.symlink_to(self.control,target_is_directory=True)
        with self.assertRaises(d.Failure):d.storage_backing(link,self.mounts())
    def test_exclusive_marker_mode_and_identity(self):
        facts=self.create();root=pathlib.Path(facts['root']);self.assertEqual(root,self.parent/('codec-'+NONCE));self.assertEqual(root.stat().st_mode&0o777,0o700)
        self.assertEqual(json.loads((root/'.owner').read_bytes()),{'nonce':NONCE,'source':SOURCE});self.assertEqual(facts['identity']['uid'],os.geteuid());self.assertTrue((root/'data').is_dir())
        with self.assertRaises(FileExistsError):self.create()
    def test_adapter_rewrites_exactly_one_helper_argument_and_preserves_source(self):
        fn=self.api('owned_daemon_args');helper=pathlib.Path(d.__file__).parent/'support/preflight.py';before=helper.read_bytes();args=fn(self.control,self.parent/'data')
        self.assertEqual([a for a in args if a.startswith('--data-root=')],['--data-root='+str(self.parent/'data')]);self.assertEqual(args[-1],'--storage-driver=overlay2');self.assertIn('--exec-root='+str(self.control/'exec'),args);self.assertEqual(helper.read_bytes(),before)
    def test_adapter_rejects_duplicate_or_unexpected_helper_data_root(self):
        fn=self.api('owned_daemon_args')
        for argv in [['dockerd','--data-root=other'],['dockerd','--data-root='+str(self.control/'data')]*2]:
            with patch.object(d,'verified_module',return_value=types.SimpleNamespace(daemon_args=lambda root:argv)),self.assertRaises(d.Failure):fn(self.control,self.parent/'data')
    def info(self,root):return {'Driver':'overlay2','DockerRootDir':str(root/'data'),'DriverStatus':[['Backing Filesystem','xfs'],['Supports d_type','true']],'ServerVersion':'24.0.9'}
    def test_actual_storage_gate_accepts_expected_and_rejects_every_mismatch(self):
        fn=self.api('verify_storage');root=self.parent/('codec-'+NONCE);root.mkdir();(root/'data').mkdir();info=self.info(root);version={'Client':{'Version':'24.0.9'},'Server':{'Version':'24.0.9'}}
        self.assertTrue(fn(info,version,root/'data')['verified'])
        variants=[{**info,'Driver':x} for x in ('vfs','fuse-overlayfs')]+[{**info,'DockerRootDir':str(self.control)},{**info,'ServerVersion':'25.0.0'},{**info,'DriverStatus':[['Backing Filesystem','extfs'],['Supports d_type','true']]},{**info,'DriverStatus':[['Backing Filesystem','xfs'],['Supports d_type','false']]}]
        for bad in variants:
            with self.subTest(info=bad),self.assertRaises(d.Failure):fn(bad,version,root/'data')
        with self.assertRaises(d.Failure):fn(info,{'Server':{'Version':'25.0.0'}},root/'data')
    def test_closure_removes_only_owned_root_and_retains_absence(self):
        facts=self.create();other=self.parent/'other';other.mkdir()
        with patch.object(d,'bounded',side_effect=lambda p,cap=65536:self.mounts().encode() if str(p)=='/proc/self/mountinfo' else pathlib.Path(p).read_bytes()):closed=self.api('close_storage')(facts)
        self.assertTrue(closed['absent']);self.assertEqual(closed['mountsBeneath'],[]);self.assertFalse(pathlib.Path(facts['root']).exists());self.assertTrue(other.exists())
    def test_residual_mount_or_marker_mismatch_prevents_deletion(self):
        fn=self.api('close_storage');facts=self.create();root=pathlib.Path(facts['root'])
        text=self.mounts(extra=f'3 2 0:4 / {root}/data/merged rw - overlay overlay rw\n')
        with patch.object(d,'bounded',side_effect=lambda p,cap=65536:text.encode() if str(p)=='/proc/self/mountinfo' else pathlib.Path(p).read_bytes()),self.assertRaises(d.Failure):fn(facts)
        self.assertTrue(root.exists());(root/'.owner').write_text('foreign')
        with patch.object(d,'bounded',side_effect=lambda p,cap=65536:self.mounts().encode() if str(p)=='/proc/self/mountinfo' else pathlib.Path(p).read_bytes()),self.assertRaises(d.Failure):fn(facts)
        self.assertTrue(root.exists())

class TwoRoots(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory();self.addCleanup(self.tmp.cleanup);self.work=pathlib.Path(self.tmp.name)/'work';self.storage=pathlib.Path(self.tmp.name)/'storage';self.work.mkdir();self.storage.mkdir()
        self.api=getattr(d.Monitor,'add_storage',None);self.assertTrue(callable(self.api),'fixed second root missing');self.mon=d.Monitor(self.work);self.mon.add_storage(self.storage)
    def entry(self,blocks=1):return types.SimpleNamespace(path='unused',stat=lambda **kw:types.SimpleNamespace(st_blocks=blocks,st_mode=stat.S_IFREG|0o600))
    def scan(self,n=1,blocks=1,error=False):
        @contextlib.contextmanager
        def entries(root):
            def stream():
                yield from itertools.repeat(self.entry(blocks),n)
                if error and pathlib.Path(root)==self.storage:raise PermissionError('second root')
            yield stream()
        return patch.object(d.os,'scandir',entries)
    def test_combined_entries_exceed_one_limit(self):
        with self.scan(50001),patch.object(d.time,'monotonic',return_value=10):self.mon.loop()
        f=self.mon.finish();self.assertEqual(f['monitorError'],'disk_scan_entry_cap');self.assertEqual(f['lastScan']['entries'],100001);self.assertEqual(len(f['lastScan']['roots']),2)
    def test_combined_disk_exceeds_one_limit(self):
        with self.scan(blocks=7000000):self.mon.loop()
        self.assertEqual(self.mon.finish()['monitorError'],'disk_ceiling')
    def test_combined_deadline_and_second_root_partial_error(self):
        with self.scan(),patch.object(d.time,'monotonic',side_effect=[10,10.3,10.81,10.81]):self.mon.loop()
        self.assertEqual(self.mon.finish()['monitorError'],'disk_scan_deadline');self.assertEqual(self.mon.lastScan['roots'][1]['entries'],1);self.assertEqual(self.mon.lastScan['activeRoot'],str(self.storage))
        self.mon=d.Monitor(self.work);self.mon.add_storage(self.storage)
        with self.scan(error=True):self.mon.loop()
        self.assertEqual(self.mon.finish()['monitorError'],'monitor_observation_failed');self.assertFalse(self.mon.lastScan['complete']);self.assertEqual(self.mon.lastScan['roots'][1]['entries'],1)
    def test_combined_small_work_has_no_second_allowance(self):
        meter=types.SimpleNamespace(observed={'smallObservableBytes':2147483392});meter.observe=lambda n,v:meter.observed.__setitem__(n,meter.observed.get(n,0)+v)
        with self.scan(),patch.object(d,'_METER',meter):self.mon.loop()
        self.assertEqual(self.mon.finish()['monitorError'],'small_work_cap');self.assertEqual(meter.observed['filesystemObservationBytes'],256)
    def test_exact_limits_and_both_free_space_checks(self):
        with self.scan(blocks=1),patch.object(d.shutil,'disk_usage',return_value=types.SimpleNamespace(free=8589934592)) as disk:self.mon.scan()
        f=self.mon.finish();self.assertEqual(f['roots'],[str(self.work),str(self.storage)]);self.assertEqual(f['diskCeilingBytes'],6442450944);self.assertEqual(f['scanEntryLimit'],100000);self.assertEqual(f['scanSecondsLimit'],.8);self.assertEqual(f['entryChargeBytes'],256);self.assertEqual(f['smallWorkLimit'],2147483648);self.assertEqual({pathlib.Path(call.args[0]) for call in disk.call_args_list},{self.work,self.storage})
    def test_exact_aggregate_entry_and_disk_boundaries_pass(self):
        with self.scan(50000,blocks=0),patch.object(d.time,'monotonic',return_value=10):self.mon.scan()
        self.assertEqual(self.mon.lastScan['entries'],100000)
        with self.scan(blocks=6291456):self.mon.scan()
        self.assertEqual(self.mon.lastScan['allocatedBlocksBytes'],6442450944)
    def test_second_filesystem_headroom_is_enforced(self):
        with self.scan(),patch.object(d.shutil,'disk_usage',side_effect=[types.SimpleNamespace(free=8589934592),types.SimpleNamespace(free=1073741824)]):self.mon.loop()
        self.assertEqual(self.mon.finish()['monitorError'],'disk_headroom')
    def test_storage_cannot_be_added_after_any_scan(self):
        monitor=d.Monitor(self.work);monitor.scan()
        with self.assertRaises(d.Failure):monitor.add_storage(self.storage)
    def test_overlap_and_third_root_rejected(self):
        with self.assertRaises(d.Failure):d.Monitor(self.work).add_storage(self.work/'child')
        with self.assertRaises(d.Failure):self.mon.add_storage(self.storage)

if __name__=='__main__':unittest.main()

class RunStorage(unittest.TestCase):
    setUp=Storage.setUp
    mounts=Storage.mounts
    info=Storage.info
    # Inherit generated storage cases; integration uses only tiny Python fixtures.
    def attempt(self,driver,fail_data=False):
        import io, shutil
        self.control=pathlib.Path('/tmp')/pathlib.Path(self.tmp.name).name[-5:];self.control.mkdir();self.addCleanup(shutil.rmtree,self.control)
        helper_path=pathlib.Path(d.__file__).parent/'support/preflight.py';spec=importlib.util.spec_from_file_location('fixture_preflight',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
        payload=b'x';pins=json.loads((pathlib.Path(d.__file__).parent/'pins.json').read_bytes());pins['zip']={'bytes':1,'sha256':d.sha(payload)};pins['docker'].update(bytes=1,sha256=d.sha(payload))
        (self.control/'.owner').write_text(NONCE+'\n');calls=[];replay=types.SimpleNamespace(replay=lambda *a,**kw:calls.append(('replay',None)) or iter([b'x']))
        unstarted_monitor=d.Monitor(self.control)
        monitor=types.SimpleNamespace(start=lambda:calls.append(('monitor_start',None)),add_storage=lambda root:calls.append(('monitor',str(root))),check=lambda:None,finish=unstarted_monitor.finish)
        real_bounded=d.bounded
        def bounded(path,cap=65536):
            if str(path)=='/proc/self/mountinfo':return self.mounts().encode()
            if pathlib.Path(path)==pathlib.Path(d.__file__).parent/'pins.json':return d.wire(pins)
            return real_bounded(path,cap)
        def download(url,path,*a,**kw):path.write_bytes(payload);return {}
        def extract(path,target,*a):target.mkdir();(target/'dockerd').write_bytes(payload)
        helper.extract=extract;helper.DaemonLog=lambda *a:types.SimpleNamespace(start=lambda:None,finish=lambda:None,data=b'',complete=True,error=None)
        def spawn(argv,**kw):
            calls.append(('executed',argv));(self.control/'d'/'daemon.sock').touch();return types.SimpleNamespace(pid=99999,poll=lambda:None,stdout=io.BytesIO())
        def command(argv,*a,**kw):
            if argv[:2]==['aws','s3']:return {'stdout':b'https://fixture.invalid/one'}
            if argv[:2]==['docker','version']:return {'stdout':d.wire({'Client':{'Version':'24.0.9'},'Server':{'Version':'24.0.9'}})}
            if argv[:2]==['docker','info']:return {'stdout':d.wire({**self.info(self.parent/('codec-'+NONCE)),'Driver':driver})}
            return {'stdout':b'fixture'}
        def stream(*a,**kw):calls.append(('load',None));raise d.Failure('fixture_stop_at_load')
        real_mkdir=pathlib.Path.mkdir
        def mkdir(path,*args,**kwargs):
            if fail_data and path==self.parent/('codec-'+NONCE)/'data':raise OSError(28,'fixture data child full')
            return real_mkdir(path,*args,**kwargs)
        import time
        with patch.object(pathlib.Path,'mkdir',new=mkdir),patch.object(d,'bounded',side_effect=bounded),patch.object(d,'Monitor',return_value=monitor),patch.object(d,'verified_module',side_effect=lambda path,*a:helper if pathlib.Path(path).name=='preflight.py' else replay),patch.object(d,'Cgroups',return_value=types.SimpleNamespace(evidence=lambda:{},affinity=[0,1])),patch.object(d,'reconstruct_controls',return_value=({'quota':-1,'period':100000,'memory':8589934592,'cpus':{0,1}},[],None,None)),patch.object(d,'choose_cpus',return_value=([0,1],{})),patch.object(d,'command',side_effect=command),patch.object(d,'download',side_effect=download),patch.object(d,'extract_selected',return_value={'compressedReadBytes':0}),patch.object(d.subprocess,'Popen',side_effect=spawn),patch.object(d,'stream_load',side_effect=stream),patch.object(d,'close_runtime',return_value={'state':'closed','obligations':[]}):
            result=d.run(NONCE,self.control/'evidence',time.time())
        return result,calls
    def test_run_records_exact_executed_argv_and_gates_before_single_load(self):
        result,calls=self.attempt('overlay2');executed=next(v for k,v in calls if k=='executed')
        self.assertLess(next(i for i,(k,v) in enumerate(calls) if k=='monitor'),next(i for i,(k,v) in enumerate(calls) if k=='monitor_start'));self.assertEqual(result['daemon']['args'],executed);self.assertIn('--storage-driver=overlay2',executed);self.assertIn('--data-root='+str(self.parent/('codec-'+NONCE)/'data'),executed);self.assertTrue(result['storage']['actual']['verified']);self.assertEqual(sum(k=='load' for k,v in calls),1);self.assertTrue(result['storage']['closure']['absent'])
    def test_wrong_driver_stops_before_any_replay_load(self):
        result,calls=self.attempt('vfs');self.assertEqual(result['failure'],'storage_actual_driver');self.assertFalse(any(k=='load' for k,v in calls));self.assertTrue(result['storage']['closure']['absent'])

class CheckerStorage(unittest.TestCase):
    def fixture(self):
        root='/codebuild/output/codec-'+NONCE;control=pathlib.Path('/tmp/cd/d');device=os.makedev(259,2)
        text='1 0 0:1 / / rw - overlay overlay rw\n2 1 259:2 / /codebuild/output rw - xfs /dev/fixture rw\n'
        marker=d.wire({'nonce':NONCE,'source':SOURCE});ident={'device':device,'inode':123,'uid':0,'mode':0o700}
        backing={'mountpoint':'/codebuild/output','device':'259:2','filesystem':'xfs','readWrite':True,'mountId':'2'}
        storage={'root':root,'dataRoot':root+'/data','nonce':NONCE,'source':SOURCE,'identity':ident,'dataIdentity':{**ident,'inode':124},'created':True,'owned':True,'marker':{'bytes':len(marker),'sha256':d.sha(marker),'identity':{**ident,'mode':0o600,'inode':125}},'mountinfo':text,'preloadMountinfo':text,'backing':backing,'actual':{'verified':True,'driver':'overlay2','dataRoot':root+'/data','backingFilesystem':'xfs','supportsDType':True,'dockerVersion':'24.0.9'},'closure':{'mountinfo':text,'mountsBeneath':[],'absent':True,'identity':ident,'markerSHA256':d.sha(marker)}}
        info={'Driver':'overlay2','DockerRootDir':root+'/data','ServerVersion':'24.0.9','DriverStatus':[['Backing Filesystem','xfs'],['Supports d_type','true']]}
        result=d.empty_result(NONCE,{'imageId':'image'},'fixture');result.update(storage=storage,sourceIdentities={'diagnostic.py':SOURCE},daemon={'args':d.owned_daemon_args(control,pathlib.Path(root)/'data'),'socket':str(control/'daemon.sock'),'config':{},'info':info,'version':json.dumps({'Client':{'Version':'24.0.9'},'Server':{'Version':'24.0.9'}})},resources={'roots':['/tmp/cd',root],'scanEntryLimit':100000,'scanSecondsLimit':.8,'entryChargeBytes':256,'smallWorkLimit':2147483648,'diskCeilingBytes':6442450944,'allocatedBlockPeak':1024,'lastScan':{'entries':2,'elapsedSeconds':.1,'complete':True,'allocatedBlocksBytes':1024,'roots':[{'root':'/tmp/cd','entries':1,'allocatedBlocksBytes':512},{'root':root,'entries':1,'allocatedBlocksBytes':512}]}})
        result['cleanup']={'state':'closed','runtimeAbsent':True,'obligations':[]};return result
    def test_storage_checker_accepts_complete_and_rejects_missing_or_mismatched_joins(self):
        self.assertTrue(callable(getattr(c,'storage_joins',None)),'storage checker missing');good=self.fixture();c.storage_joins(good)
        mutations=[lambda r:r['storage'].pop('actual'),lambda r:r['daemon']['args'].append('--data-root=/var/lib/docker'),lambda r:r['daemon']['info'].__setitem__('Driver','vfs'),lambda r:r['storage']['marker'].__setitem__('sha256','b'*64),lambda r:r['storage'].__setitem__('dataRoot','/tmp/foreign'),lambda r:r['resources'].__setitem__('scanEntryLimit',200000),lambda r:r['resources']['lastScan']['roots'][1].__setitem__('entries',2),lambda r:r['storage']['closure'].__setitem__('absent',False),lambda r:r['storage']['closure'].__setitem__('mountsBeneath',['residual']),lambda r:r['storage']['closure'].__setitem__('markerSHA256','b'*64),lambda r:r['resources'].__setitem__('roots',['/tmp/cd'])]
        for change in mutations:
            bad=copy.deepcopy(good);change(bad)
            with self.subTest(change=change),self.assertRaises(c.Invalid):c.storage_joins(bad)
    def test_checker_requires_storage_for_load_and_rejects_storage_removal(self):
        result=self.fixture();result.pop('storage');result['load']={'bytes':1}
        with self.assertRaises(c.Invalid):c.check(result,{},NONCE,expected_pins={'imageId':'image'})

    def test_checker_requires_retained_storage_record(self):
        with self.assertRaises(c.Invalid):c.check(self.fixture(),{},NONCE,expected_pins={'imageId':'image'})


class PartialStorageRun(unittest.TestCase):
    setUp=Storage.setUp
    mounts=Storage.mounts
    info=Storage.info
    attempt=RunStorage.attempt
    def test_partial_child_mkdir_failure_closes_and_passes_checker(self):
        result,calls=self.attempt('overlay2',fail_data=True)
        self.assertEqual(result['failure'],'setup_OSError');self.assertEqual(result['failedStage'],'storage_setup');self.assertEqual(result['cleanup']['state'],'closed');self.assertTrue(result['cleanup']['runtimeAbsent'])
        storage=result['storage'];self.assertTrue(storage['created']);self.assertNotIn('owned',storage);self.assertNotIn('dataIdentity',storage);self.assertTrue(storage['closure']['absent']);self.assertFalse(pathlib.Path(storage['root']).exists());self.assertFalse(any(k in ('executed','replay','load','monitor_start') for k,v in calls));self.assertNotIn('daemon',result);self.assertNotIn('load',result)
        # Runtime is generated under temporary paths. Rebind only those fixture paths
        # to the fixed production names for the independent offline checker.
        replacements={str(self.parent):'/codebuild/output',str(self.control):'/tmp/cd'}
        def fixed(value):
            if isinstance(value,str):
                for old,new in replacements.items():value=value.replace(old,new)
                return value
            if isinstance(value,list):return [fixed(v) for v in value]
            if isinstance(value,dict):return {k:fixed(v) for k,v in value.items()}
            return value
        result=fixed(result);files={name:(self.control/'evidence'/name).read_bytes() for name in result['inventory']}
        files['storage.json']=d.wire(result['storage']);result['inventory']['storage.json']={'bytes':len(files['storage.json']),'sha256':d.sha(files['storage.json'])}
        pins={k:result['identities'][k] for k in ('imageId','controlVisibilityPolicy')}
        c.storage_joins(result);c.check(result,files,NONCE,expected_pins=pins)
        mutations=[lambda r:r['storage'].pop('marker'),lambda r:r['storage']['marker'].__setitem__('sha256','b'*64),lambda r:r['storage'].pop('closure'),lambda r:r['storage']['closure'].__setitem__('absent',False),lambda r:r['storage']['closure'].__setitem__('identity',{}),lambda r:r['storage']['closure'].__setitem__('markerSHA256','b'*64),lambda r:r['storage']['closure'].__setitem__('mountsBeneath',['residual']),lambda r:r['storage'].__setitem__('root','/codebuild/output/foreign'),lambda r:r['storage'].__setitem__('source',{}),lambda r:r.__setitem__('daemon',{'args':[]}),lambda r:r.__setitem__('daemon',{}),lambda r:r['storage']['marker'].pop('identity'),lambda r:r['storage']['marker']['identity'].__setitem__('mode',0o644),lambda r:r.__setitem__('load',{})]
        for change in mutations:
            bad=copy.deepcopy(result);change(bad)
            with self.subTest(change=change),self.assertRaises(c.Invalid):c.storage_joins(bad)
