"""Read-only verification of every Task 10 frozen member and its permissions."""
import hashlib
import json
import pathlib

root = pathlib.Path('/workspace/scratch/codec-task10-source-freeze')
pins = json.loads((root / 'source-identities.json').read_bytes())
files = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
assert files == set(pins) | {'source-identities.json'}
for name, pin in pins.items():
    body = (root / name).read_bytes()
    assert pin == {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}, name
for path in (root, *root.rglob('*')):
    assert not path.is_symlink(), str(path)
    assert path.stat().st_mode & 0o777 == (0o555 if path.is_dir() else 0o444), str(path)
body = (root / 'source-identities.json').read_bytes()
print(json.dumps({'passed': True, 'files': len(files), 'verifiedMembers': len(pins),
                  'logicalBytes': sum((root / name).stat().st_size for name in files),
                  'sourceIdentities': {'bytes': len(body), 'sha256': hashlib.sha256(body).hexdigest()}}, sort_keys=True))
