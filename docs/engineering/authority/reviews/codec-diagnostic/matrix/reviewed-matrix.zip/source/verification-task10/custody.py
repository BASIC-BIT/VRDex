"""Offline Task 10 exact scope, baseline integrity and packet custody checks."""
import difflib
import hashlib
import json
import pathlib
import sys
import tempfile

root = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
import packet_renderer as p
import diagnostic as d
base = pathlib.Path('/workspace/scratch/codec-task9-source-freeze')
identity = lambda b: {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
old = json.loads((base / 'source-identities.json').read_bytes())
for name, pin in old.items():
    assert identity((base / name).read_bytes()) == pin, name
for path in [base, *base.rglob('*')]:
    assert not path.is_symlink(), str(path)
    assert path.stat().st_mode & 0o777 == (0o555 if path.is_dir() else 0o444), str(path)
source = sorted([*root.glob('*.py'), root / 'README.md', root / 'pins.json', root / 'manifest.json',
                 *root.glob('support/*.py'), *root.glob('tests/*.py')])
changed = [str(path.relative_to(root)) for path in source
           if not (base / path.relative_to(root)).exists() or path.read_bytes() != (base / path.relative_to(root)).read_bytes()]
assert sorted(changed) == ['README.md', 'check_result.py', 'diagnostic.py', 'manifest.json',
                           'tests/test_boundaries.py', 'tests/test_evidence_capacity.py'], changed
before = (base / 'diagnostic.py').read_text()
expected = before.replace('CUSTODY=(28093104,20971520,8388608,', 'CUSTODY=(28093104,20971520,10485760,')
expected = expected.replace('root,cap=8388608,reserve=1048576', 'root,cap=10485760,reserve=1048576')
assert (root / 'diagnostic.py').read_text() == expected
before_checker = (base / 'check_result.py').read_text()
assert before_checker.count('sum(x.file_size for x in infos)<=8388608') == 1
assert (root / 'check_result.py').read_text() == before_checker.replace('sum(x.file_size for x in infos)<=8388608', 'sum(x.file_size for x in infos)<=10485760')
assert (root / 'tests/test_boundaries.py').read_text() == (base / 'tests/test_boundaries.py').read_text().replace('75606704', '77703856')
assert d.CUSTODY == (28093104, 20971520, 10485760, 3145728, 4259840, 2097152, 262144, 8388608)
assert sum(d.CUSTODY) == 77703856 and 83886080 - sum(d.CUSTODY) == 6182224
assert d.WORK_CAP == 12884901888 and d.WORK['small'] == 2147483648
assert sum(d.WORK.values()) == 12666265317
for path in (base / 'packet-task9-review').iterdir():
    historical = pathlib.Path('/workspace/scratch/codec-capacity-diagnostic/packet-task9-review') / path.name
    assert path.read_bytes() == historical.read_bytes(), path.name
parts = []
for name in sorted(changed):
    prior = base / name
    parts.extend(difflib.unified_diff(prior.read_text().splitlines(True) if prior.exists() else [],
                 (root / name).read_text().splitlines(True), fromfile='task9/' + name, tofile='task10/' + name))
assert (root / 'task10-scoped.diff').read_text() == ''.join(parts)
packet = root / 'packet-task10-review'
pins = json.loads((packet / 'packet-pins.json').read_bytes())
files = p.verify((packet / 'code-envelope.json').read_bytes(), pins)
for name, body in files.items():
    assert body == (root / name).read_bytes(), name
req = json.loads((packet / 'create-project.json').read_bytes())
ready = json.loads((packet / 'readiness.json').read_bytes())
inline = req['source']['buildspec']
assert identity(inline.encode()) == ready['inline']
assert identity(p.wire(req)) == ready['request'] and ready['externalPins'] == pins
script = json.loads(inline)['phases']['build']['commands'][0].split('\n', 1)[1].rsplit('CODEC_TRUSTED_BOOTSTRAP', 1)[0]
assert script.isascii()
compile(script, 'trusted-inline', 'exec')
for path in [*source, *root.glob('verification-task10/*.py')]:
    if path.suffix == '.py':
        compile(path.read_bytes(), str(path), 'exec')
with tempfile.TemporaryDirectory() as td:
    temporary = pathlib.Path(td)
    for name in p.FILES:
        item = temporary / name
        item.parent.mkdir(parents=True, exist_ok=True)
        item.write_bytes((root / name).read_bytes())
    out = temporary / 'packet'
    again = p.freeze(temporary, out)
    assert again == pins
    for name in ('code.zip', 'code-envelope.json', 'packet-pins.json'):
        assert (out / name).read_bytes() == (packet / name).read_bytes(), name
    request, record = p.render(again, nonce=ready['nonce'], bucket=req['artifacts']['location'],
                               source_key=ready['sourceKey'], evidence_prefix=req['artifacts']['path'], role_arn=req['serviceRole'])
    assert p.wire(request) == (packet / 'create-project.json').read_bytes()
    assert p.wire(record) == (packet / 'readiness.json').read_bytes()
assert 'UNAPPROVED OFFLINE' in (packet / 'UNAPPROVED.txt').read_text()
print(json.dumps({'passed': True, 'immutableBaselineMembers': len(old), 'changedSourceFiles': sorted(changed),
                  'productionChange': 'Evidence default, one expanded CUSTODY slot, independent expansion bound',
                  'custodyBytes': 77703856, 'custodyCap': 83886080, 'custodyHeadroom': 6182224,
                  'unchangedAllOtherProductionBytes': True, 'historicalTask9PacketUnchanged': True,
                  'sourceMembers': sorted(files), 'deterministicRebuild': True, 'packetPins': pins,
                  'inline': ready['inline'], 'request': ready['request']}, sort_keys=True))
