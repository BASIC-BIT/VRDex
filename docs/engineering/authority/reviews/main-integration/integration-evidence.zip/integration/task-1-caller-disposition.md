# Resolver and caller disposition

Raw search contains 132 matches across 21 files. Every match is retained in `logs/caller-search.txt`.

- `convex/events.ts`: Required typed factory resolver; fresh allocation and nested snapshot validators share it. Single production registration explicitly supplies resolveWorkerAllocation.
- `scripts/event-media-ecs-bridge.mjs`: Typed {resolveAllocation} dependency object; runBridge forwards to claimAndProcess/startCommand/registerTaskDefinition/taskDefinitionFor. One loop binding. Default main uses production resolver; no dual convention.
- `scripts/event-media-lambda-bridge.mjs`: Unchanged production default runBridge dependency; no fixture resolver in runtime configuration.
- `tests/backend/_eventCapacityFixture.ts`: Branch loader substitutes only scheduler registration with shared fixtureCapacityResolver, retained byte-for-byte feature.
- `tests/backend/event-api-ownership.test.ts`: Branch scheduling module loader retained byte-for-byte feature. Real authorization, account, time, output, session and command handlers/assertions remain in use; no production authority changes.
- `tests/backend/event-broadcast-capacity-admission.test.ts`: Pristine production scheduling rejection, real persisted snapshot rejection, same-process isolation and validators remain byte-for-byte feature.
- `tests/backend/event-broadcast-control.test.ts`: Branch fixture loader retained; narrow direct-seeded session helper body unchanged. Later real scheduling uses explicit fixture module loader.
- `tests/backend/event-broadcast-output.test.ts`: Shared allocatedSession paired with shared resolver for both task definitions; no synthetic-ID rebinding.
- `tests/backend/event-broadcast-settings.test.ts`: Default helper loader adapted to branch loader; incoming isolation/production-rejection and forged-snapshot tests retained with fixture-capacity-v1 literal. Production case passes pristine events loader.
- `tests/backend/event-broadcast-sources.test.ts`: Branch scheduling module loader retained byte-for-byte feature. Real authorization, account, time, output, session and command handlers/assertions remain in use; no production authority changes.
- `tests/backend/event-broadcast-worker.test.ts`: Removed auto-merged bare-resolver wrapper. Direct claims retain explicit dependency objects for allocation/launch paths; denial, unknown-admission and stop paths use defaults without allocation. Region explicit at registration/launch/cleanup calls. Contention finally/guard and all existing lifecycle assertions preserved.
- `tests/backend/event-corrections.test.ts`: Branch scheduling module loader retained byte-for-byte feature. Real authorization, account, time, output, session and command handlers/assertions remain in use; no production authority changes.
- `tests/backend/event-media-worker.test.ts`: Branch loader and taskDefinitionFor fixture resolver retained. Revoked source list empties; previously captured formerSource.key still rejects /unavailable/i.
- `tests/backend/event-output-authorization.test.ts`: Branch scheduling module loader retained byte-for-byte feature. Real authorization, account, time, output, session and command handlers/assertions remain in use; no production authority changes.
- `tests/fixtures/event-capacity.mjs`: Incoming isolated unit-test-synthetic-capacity-v1 resolver, 4096/8192, retained byte-for-byte main.
- `tests/fixtures/event-modules.ts`: Incoming loader constructs scheduler with its own resolveSyntheticAllocation, retained byte-for-byte main.
- `tests/scripts/_event-allocation-fixture.mjs`: Shared fixture-capacity-v1 resolver and typed allocatedSession retained byte-for-byte feature, all twelve combinations 4096/8192.
- `tests/scripts/event-broadcast-capacity.test.mjs`: Shared fixture resolver alias; production all-twelve rejection and malformed evidence/profile/resource assertions retained byte-for-byte feature.
- `tests/scripts/event-broadcast-migration-rehearsal.test.ts`: Incoming optional synthetic module loader uses its own syntheticAllocation identity. Pristine production branch still asserts whole-flow failure and cleanup; synthetic success is in-memory unit evidence.
- `tests/scripts/event-media-bridge-lifecycle.test.mjs`: Real synthetic loader paired with shared resolver via dependency object at direct claim and all loops. Both default production rejection tests retained; literal task/container resource assertions and bounded drain preserved.
- `tests/scripts/event-media-lambda-bridge.test.mjs`: Inject realRunBridge wrapper through handler dependency options; shared resolver matches allocatedSession and taskDefinitionFor expectation. Literal task/container resources preserved.
