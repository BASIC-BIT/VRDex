# Main integration independent source review

Reviewer: independent integration reviewer `/root/review_main_integration`, 2026-10-26 UTC.

**SPEC: PASS. QUALITY: PASS. No blocking findings.** This is approval of the resolved source below, not completion of runtime verification, CI, whole-flow admission, native qualification, measured capacity, or external A.

## Exact review subject

- Feature parent / HEAD: `1d814dfb61806875eb6cd2e9a64a17ead656a23f`.
- Incoming parent / MERGE_HEAD: `0a7231acf3eb59c5107360536a615a1f6773a19b`.
- Merge base: `db9abbcd59a30d206d85c0dcb2f407150e31dd9e`.
- Resolved index tree: `965d03ab60989340290804dee8e4aaa981017b2c`.
- Resolution hashsheet SHA-256: `70110bde4909e5e466d756faefda98d394954ef0f8a6c6ebcebee5ac39b595cb`.
- Review package: 965,694 bytes, SHA-256 `51b2c3494a43dbef8461e85200e5c47955df4992e967d5232909d7ae6025baee`.

Read repository AGENTS.md, the integration brief, complete prior integration assessment, capacity seam design/implementation plan, writer report, caller dispositions, resolution/protected/hash/check records, and relevant source and tests. Reviewed both parent diffs, including every conflict resolution and the clean-merge caller hazards. The integration brief explicitly supersedes the historical capacity plan's migration-scope restriction by incorporating incoming main's separate blocked lane; historical records retain their original meaning.

Independently recomputed every recorded resolution file's worktree SHA-256/length and index blob identity: all 136 match, and worktree bytes equal index bytes. Both recorded parent patches equal fresh `git diff --cached` output. Both actual parent diffs with eight lines of context are present verbatim in the review package. HEAD, MERGE_HEAD and tree were checked directly; no unmerged entries or unstaged tracked changes remain. Conflict-marker search and cached whitespace check are clean. No source changes or commits were made during this review.

## SPEC findings

None requiring changes.

- The scheduler factory requires the typed resolver, preserves inferred mutation registration and public arguments, and explicitly registers production with `resolveWorkerAllocation`. Fresh allocations and existing frozen snapshots use the same resolver through both real validators. The production map remains empty, with no fixture imports, public override, environment authority, mutable singleton or evidence-ID exception.
- The bridge retains one fifth-argument dependency object, `{resolveAllocation}`, propagated through `runBridge`, `claimAndProcess`, `startCommand`, registration and `taskDefinitionFor`. Production entrypoints retain production defaults. The incompatible incoming bare-resolver wrapper and duplicate loop binding are absent.
- The branch loader/allocated-session fixture remains `fixture-capacity-v1`, 4096 CPU units / 8192 MiB across all twelve combinations. Incoming `tests/fixtures/event-capacity.mjs` and its loader retain `unit-test-synthetic-capacity-v1`; migration protocol unit callers use that matching pair. No identity rebinding crosses the fixtures.
- All 116 protected files were independently compared byte-for-byte with the feature parent, including authority/review/adoption records, qualification sources, packaging, policy and native names. No protected file changed upstream relative to the merge base. Packaging contains 134 paths; native inventory contains 42 Python and 90 Node entries. The hash-verified cardinality record retains 139 CI / 136 Root producers and 79,996 IDs / 83 groups / 294 invocations. Qualification sources, limits, deadlines and recorded ID/contract hashes are unchanged; this review did not generate or execute a corpus.
- All 927 tracked frontend files match incoming main. Of its 82 changed paths, 67 match exactly; the remaining 15 are precisely the 14 conflict paths plus current capacity documentation. Package/lock/workspace and generated backend files have no differences requiring installation or regeneration.

## Conflict and caller review

| Resolution | Verified disposition |
| --- | --- |
| `convex/events.ts` | Required typed factory and explicit production registration; incoming construction-authority comment retained. |
| `scripts/event-media-ecs-bridge.mjs` | Byte-identical to feature; single typed dependency convention and production defaults preserved. |
| `event-api-ownership`, `event-broadcast-sources`, `event-corrections`, `event-output-authorization` backend tests | Branch loaders retained; corresponding incoming differences are loader names, with real authorization and negative handlers preserved. |
| `event-broadcast-control` backend tests | Direct-seeded control helper preserved; explicit branch loader retained for scheduling. |
| `event-broadcast-output` backend tests | Both task-definition calls pair shared allocated sessions with the shared resolver. |
| `event-broadcast-settings` backend tests | Default loader and literal evidence ID adapted together; incoming pristine-production rejection/no-write/isolation and forged snapshot tests retained alongside branch immutable settings tests. |
| `event-broadcast-worker` backend tests | Direct import replaces incompatible wrapper; positive paths use object dependencies and explicit region. Launch ambiguity, release, reservation, cleanup, contention guard/finally and winner-definition assertions retained. |
| `event-media-worker` backend tests | Matching resolver/loader retained; real revoked source disappears and the captured old key rejects `/unavailable/i`. |
| `_event-allocation-fixture.mjs` | Branch typed fixture retained byte-for-byte. |
| `event-media-bridge-lifecycle.test.mjs` | Both default production rejection cases retained; explicit positive resolver, literal resources, launch fences and bounded drain assertions retained. |
| `event-media-lambda-bridge.test.mjs` | Real bridge injected through handler dependencies with matching fixture; four independent literal resource assertions and launch ordering preserved. |

A fresh complete search found the same 132 references in 21 files across scripts/tests/convex. Inspected direct claim defaults: denial/unknown-admission cases stop before capacity registration, and stop/cleanup callers do not need synthetic authority. Allocation/launch paths explicitly supply their matching resolver. The Lambda runtime retains its unmodified production bridge default.

## QUALITY findings

None requiring changes. The resolution keeps nonoverlapping incoming backend/CI/docs/UI work and preserves the reviewed branch's rejection, resource, lifecycle and cleanup coverage. The three added region values restore registration/cleanup tests after removing the incoming wrapper; assertions still require the intended registration behavior rather than accepting early capacity failure.

The incoming migration driver, bounded inspector, runner, workflow and tests remain coherent and byte-identical to incoming main. The blocked driver requires an acting owner, historical migration, the exact production error or fixed server envelope, equality of complete owned admission snapshots, and cleanup. The inspector hashes complete event/program/output/session/command/audit rows with ownership/bounds checks. Runner acceptance requires matching source/run/backend identity, explicit blocked scope, historical evidence, exactly one blocked evidence item and no real-admission item. Default whole-flow and blocked receipts reject each other's scope. Negative tests cover unexpected success/errors/writes/missing owner; default whole-flow remains failed with the empty production registry. Current qualification/capacity docs state these limits explicitly.

## Verification evidence and open gates

Independently checked artifact and command-log lengths/SHA-256 values and inspected the actual typecheck/full-suite summaries. Accepted writer execution evidence for this frozen tree:

- Backend typecheck: exit 0.
- Focused backend: 442 passed; focused scripts: 235 passed; explicit resource suite: 14 passed.
- Full backend: 2,022/2,022 passed, zero skips/failures.
- Full scripts: 986 passed, six existing skips, zero failures (992 total).

The reported initial duplicate-parameter parse failure is not behavioral red evidence. The subsequent named registration-contract failure and its passing correction are retained. The nonexistent focused resource path is disclosed and was corrected by an explicit 14-test run plus the complete backend suite. No passing suites were rerun during review.

**OPEN:** Root's actual local `migration-admission-blocked` rehearsal, fresh analyzed function-spec/API inspection and MCP verification against clean committed source; normal selected CI/generated-backend/browser/visual checks. This review does not claim any of these occurred. Root may create the reviewed local merge commit first, bind these new receipts to that clean committed source, and retain their results before final push/readiness claims. Any source change invalidates the affected portion of this tree-bound approval and requires review of that change.

A passing blocked lane proves historical migration plus exact production rejection, unchanged admission rows and owned cleanup. It supplies no successful production whole-flow admission, native132/PROGRAM acceptance, measured allocation, actual-image correspondence, paid continuation or external A.
