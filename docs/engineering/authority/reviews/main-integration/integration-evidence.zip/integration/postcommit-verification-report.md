# Postcommit integration verification

**PASS for both requested commands.** MCP verification passed, including 12 MCP unit tests and a nested scripts stage with **986 passes, six skips, zero failures**. Docs lint checked **271 files with zero errors** and the Docusaurus production build succeeded. Hosted/real production readiness is not established by these checks.

## Exact committed subject

- HEAD: `f0c1005f9a9220aa8a5150c8dc6bc16a9a25693f`.
- Tree: `965d03ab60989340290804dee8e4aaa981017b2c`.
- Parents, preserved in order: `1d814dfb61806875eb6cd2e9a64a17ead656a23f 0a7231acf3eb59c5107360536a615a1f6773a19b`.
- Node `v24.19.0`, pnpm `10.15.1`; `/workspace/vrdex-env.sh` activated for every shell.
- Clean tracked working tree before and after; every tracked file's SHA256 remained identical (`changed_tracked_bytes={}`). Complete identities are in `postcommit-subject-before.json` and `postcommit-subject-after.json`.

## Actual commands and results

| Command | Exit | External watchdog | UTC start | UTC end |
| --- | ---: | --- | --- | --- |
| `pnpm verify:vrdex-mcp` | 0 | not fired (1200s bound) | 2026-10-26T23:09:57.541045+00:00 | 2026-10-26T23:12:44.102302+00:00 |
| `pnpm verify:docs` | 0 | not fired (900s bound) | 2026-10-26T23:12:52.716524+00:00 | 2026-10-26T23:13:04.779973+00:00 |

Commands ran once each, sequentially, with host escalation for reliable Node subprocess stdio. No test failures, cancellations or watchdog terminations occurred. Full stdout/stderr are retained in `postcommit-01-mcp.log` and `postcommit-02-docs.log`, with adjacent exact exit JSON.

MCP stages reached: typecheck passed; MCP unit suite 12 tests, 12 passes, zero failures/skips/cancellations/todo (1641.240426 ms); nested scripts 992 tests, 35 suites, 986 passes, six skips, zero failures/cancellations/todo (158519.180409 ms); local stdio smoke passed; client-matrix command passed. The unavoidable nested scripts overlap was authorized; no additional standalone backend/scripts suite was run by this verifier.

Docs stages reached: markdownlint 271 files, zero errors; Docusaurus client and server compiled successfully and generated static files in `apps/docs/build`. No docs server was started.

## Every skip and matrix scope limit

The six script skips:

- R93 retained-source complete encoder/output/local argv, defaults, getters and factory errors
- R93 retained-source capacity fixture and native noise complete argv with independent fake probe/capture
- R93 retained-source six hold frames compare every byte, isolated backing stores and per-instance reuse
- R93 retained-source input factory omitted/undefined/null and supplied quality late reads
- R93 retained-source full PCM families/defaults/boundaries and unchanged 636-frame canary
- proof servers own isolated media and cleanup while another server streams

The five R93 comparisons require the possessed original retained-source baseline; no substitute was acquired or supplied. The playback proof remains opt-in and was not enabled.

Hosted Streamable HTTP compatibility smoke skipped because no hosted URL was supplied. The matrix command evaluates existing evidence; it did not perform new hosted probes. Its successful exit does not erase the existing Claude Code hosted-anonymous-read failure, pending OAuth work, or unselected clients. Exact smoke/matrix output:

| Smoke target | Status | Details |
| --- | --- | --- |
| Local stdio MCP protocol | pass | stdio initialize, tool list, and all curated read tool calls passed |
| Hosted Streamable HTTP MCP | skip | pass --hosted-url or set VRDEX_MCP_SMOKE_URL to test a deployed Streamable HTTP endpoint |
| Client | Launch-gating checks | Launch status | Nonblocking follow-up |
| --- | ---: | --- | --- |
| Claude Desktop | 0 | not selected | local-stdio: pending, hosted-anonymous-read: pending, hosted-oauth: pending |
| Claude Code | 1 | local-stdio: pass | hosted-anonymous-read: fail, hosted-oauth: pending |
| Gemini CLI | 2 | local-stdio: pass, hosted-anonymous-read: pass | hosted-oauth: pending |
| VS Code | 2 | local-stdio: pass, hosted-anonymous-read: pass | hosted-oauth: pending |
| Cursor | 0 | not selected | local-stdio: pending, hosted-anonymous-read: pending, hosted-oauth: pending |
| Codex desktop and CLI | 0 | not selected | local-stdio: pending, hosted-anonymous-read: pending, hosted-oauth-cli-startup: pending |
| OpenAI and ChatGPT MCP-capable surfaces | 1 | hosted-anonymous-read: pass | hosted-oauth: pending |
| Devin Desktop / Windsurf Cascade | 0 | not selected | local-stdio: pending, hosted-anonymous-read: pending, hosted-oauth: pending |
| MCP Inspector | 3 | local-stdio: pass, hosted-anonymous-read: pass, hosted-oauth: pass | none |
| Hosted readiness check | Required | Status |
| --- | --- | --- |
| hosted-data-backed-anonymous-read | yes | pass |
| hosted-dynamic-client-registration | yes | pass |
| hosted-client-id-metadata-document | yes | pass |

## Boundaries and separate evidence

Root separately supplied fresh integrated backend **2022/2022** and standalone scripts **986 passes, six skips**. Those were not repeated here. Temporal runtime/inference source is unchanged from prior passing **14 + 7** tests, so neither was rerun. Root owns the actual local API analysis; no local service or API analysis was repeated here.

Real production admission and whole-flow migration remain blocked on measured production capacity. Root will use actual GitHub blocked-lane evidence; no CI runner, fabricated CI identity, hosted smoke, provider operation, service, or subagent was launched here. No source edits occurred. Ordinary docs build outputs are generated ignored artifacts.

## Artifact integrity

`postcommit-artifacts.sha256` records all postcommit verification artifacts, including this report, excluding the manifest itself. The before/after subject files include all tracked file hashes. Full historical source/runtime acceptance and Root-owned integration evidence remain separately retained.
