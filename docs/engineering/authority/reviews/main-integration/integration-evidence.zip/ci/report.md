# PR #388 integration CI evidence

PR: <https://github.com/BASIC-BIT/VRDex/pull/388>
Run: <https://github.com/BASIC-BIT/VRDex/actions/runs/40417706641> (attempt 1, pull_request).

The completed run succeeded: 19 jobs, 10 successful, 0 failed, 9 skipped. This is directly observed CI evidence, separate from supplied local results.

## Source binding

Run/PR head is `f0c1005f9a9220aa8a5150c8dc6bc16a9a25693f`; PR remains draft. Actual checkout/artifact source is GitHub's synthetic merge `8bfb97a967e4d4c254292fc6ea9362c383398ab5`, whose parents are base `0a7231acf3eb59c5107360536a615a1f6773a19b` and this PR head. GitHub commit metadata proves its tree is `965d03ab60989340290804dee8e4aaa981017b2c`, identical to the reviewed integration head's local Git tree. CI tested that tree through a different commit identity, not a hypothetical future merge.

## Jobs and observed test results

All core jobs passed: Lint Web, Typecheck Web, Verify Docs, Typecheck Backend, Verify API and MCP, Verify Backend Local, Restream Local Checks, Select Visual Evidence, Build Web and PR Verification Report. No failure to diagnose in this run.

- Backend: 2022 tests, 2022 pass, 0 fail/skip; backend typecheck passed. Temporal runtime: 14/14 pass; Python temporal inference: 7 tests OK. These previously blocked stages actually ran.
- API contracts: 70/70 pass. MCP package suite: 12/12 pass. Script suite: 992 total, 986 pass, 0 fail, 6 skip. MCP verification command completed successfully, including later verification stages.
- Restream job actually ran its image build, required transport gate, dependency/FFmpeg installation, gateway typecheck and 7 gateway tests, image dry run and local validation/check. The transport gate reported `passed:true`, 42 Python and 90 Node checks, exit 0 and cleanup true. Its binding explicitly remains `Unproven`, missing `reviewed_candidate_bundle`, with `measurementAdmitted:false`; this passing job does not establish measured capacity or reviewed native qualification.
- Build Web and consolidated PR verification passed.

Nine skipped jobs: Build Storybook, Storybook Image Diff, Storybook Component Preview, Playwright Hosted Data Flow, Playwright Image Diff, Playwright Data Flow, Playwright Public Smoke, Playwright Public Preview, and Deploy Convex Production. Browser/Storybook jobs were unselected under the workflow's optional browsers/visuals conditions; production deployment requires push to main, while this is a PR run. These skips are not successful browser/visual/deployment evidence. Six script tests also remain explicitly skipped.

## Safe migration artifact

Artifact `event-broadcast-migration-local-40417706641-1`, ID `12696048601`, was downloaded through native GitHub download_workflow_artifact, then fetched from its temporary file reference without printing or retaining the signed download URL. The original ZIP is retained locally. Its 12553-byte length and SHA256 `4e3cc67e8f2c2dc41b73750425dc9fa03d705bfdccc5fa769722939799fdc38c` exactly match GitHub artifact metadata. Extraction was bounded to at most 32 flat JSON members and 1 MiB aggregate uncompressed bytes; actual member/byte counts are in verified-summary.json.

The actual successful evidence scope is `migration-admission-blocked`, from workflow CLI `run-admission-blocked`. Driver, phase, recovery and result all explicitly report that same scope and passed status. It is not a whole-flow success.

- Historical migration recorded 162 calls and historical-result evidence, including expected rejection/replay scenarios.
- Exactly one production-admission-blocked evidence record reports `unproved-broadcast-configuration`, `unchanged:true`, `noSessionWrites:true`, and `noStartCommandWrites:true`. The recorded owner schedule RPC has the matching denial reason. There are zero real-admission evidence records. The 14 earlier backfill RPC exceptions belong to expected negative scenarios; they do not make the successful denial scope a failure.
- Driver cleanup passed and deleted 47 fixture records. Phase and recovery both prove fixtureCleanup, manifestEmpty, both temporary binding removals, and privateFileRemoved. Recovery passed with independent=false: ordinary cleanup succeeded, rather than a separate independent recovery run.
- Result backend closure and work closure passed with empty remaining-process/listener arrays; no forced kill was required. Generated-file command and parent native wrapper returned 0. Phase native returned 0, without timeout/overflow. These are process/runner cleanup results, not evidence of worker transport admission or native qualification.

## Limits and retained evidence

This run establishes green CI for the exact reviewed integration tree under the current selection and explicit admission-blocked migration scope. Production scheduling still rejects unmeasured allocation. No successful actual production admission, whole-flow migration protocol lifecycle, measured capacity, browser/visual run, production deployment or reviewed native qualification is established here.

Retained: run.json, jobs.json, artifacts.json, source-commit.json, pr.json, run-logs.zip, extracted logs/, original migration-evidence.zip, bounded migration-evidence/ JSON and verified-summary.json. No reruns, labels, comments, source edits, services, Docker/AWS activity or credential discovery were performed.
